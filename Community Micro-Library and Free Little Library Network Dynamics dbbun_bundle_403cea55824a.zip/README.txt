================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : f24ec681-9224-4de6-aa6e-db646b8c87e5
    Generated   : 2026-04-23  19:50:51 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Community Micro-Library and Free Little Library Network Dynamics

    CATEGORIES
    ----------
    Social Sciences, Agent-based, Education and Learning Technologies, Demographic, Other

    KEYWORDS
    --------
    micro-library, community sharing, agent-based model, urban resource exchange, free little library

    ABSTRACT
    --------
    This simulator models the stochastic dynamics of a network of community micro-libraries (Free Little Libraries and community sharing boxes) inspired by five visually distinct real-world nodes observed in an urban neighborhood. Each node is characterized by design attractiveness, multilingual accessibility, food-sharing capability, and steward maintenance frequency, all of which drive visitor arrivals and inventory fluctuations. The model reproduces take-one-leave-one exchange dynamics, seasonal visitor variation, steward restocking cycles, and optional inter-node book redistribution, generating synthetic time-series of inventory, visitor counts, and exchange events. Researchers can use the simulator to evaluate how design choices, community engagement levels, and stewardship practices affect equitable access to shared resources across a neighborhood network. Students and urban planners can explore intervention scenarios such as multilingual signage upgrades or cooperative redistribution programs through the provided CSV datasets and publication-quality figures.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Screenshot 2026-04-23 154713.png

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    book_inventory, visitor_count, take_rate, leave_rate, steward_restock_threshold, restock_amount, multilingual_score, design_attractiveness, node_age_days, cumulative_exchanges

    SCENARIOS  (6 total)
    ---------------------------------
        1. baseline_5node_network — Five nodes with heterogeneous attractiveness and multilingual scores matching the five observed library types: artistic (node1), stone-embedded (node2), tall cabinet (node3), multilingual food box (node4), red armoire (node5). Default parameters applied.
2. high_community_engagement — Visitor rate doubled and leave_rate increased to simulate a highly active neighborhood with strong donation culture. All nodes see higher baseline traffic.
3. low_steward_maintenance — Steward check frequency reduced to every 10 days and restock amount halved, simulating neglected or under-resourced nodes. Inventory depletion events become frequent.
4. multilingual_expansion — All nodes receive multilingual signage upgrade (multilingual_score set to 4 for all), increasing visitor diversity and overall visit rates across the network.
5. seasonal_summer_peak — Simulation starts at summer solstice (day 172), maximizing seasonal visitor amplitude. Tests network resilience when peak demand stresses inventory.
6. network_redistribution_active — Inter-node donation flow probability raised to 0.2, modeling an organized neighborhood network that actively redistributes books between nodes to equalize inventory.

    PARAMETERS
    ----------
    12 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6

    DOMAIN SUMMARY
    --------------
    This source documents community-based micro-libraries (Free Little Libraries and community food/book sharing boxes) distributed across urban neighborhoods, capturing their diversity in design, multilingual accessibility, and resource-sharing dynamics. The content illustrates how decentralized peer-to-peer resource exchange points operate across a neighborhood network.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.