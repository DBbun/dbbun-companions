# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-23T19:50:51.120170Z
# Run ID    : f24ec681-9224-4de6-aa6e-db646b8c87e5
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Community Micro-Library and Free Little Library Network Dynamics Simulator

Paper: Community Micro-Library and Free Little Library Network Dynamics
Domain: Community-based micro-libraries (Free Little Libraries and community food/book sharing boxes)
         distributed across urban neighborhoods, modeling decentralized peer-to-peer resource exchange.

This simulator implements an agent-based model of five micro-library nodes with heterogeneous
design attractiveness, multilingual accessibility, food-sharing capability, and steward maintenance
frequency. It runs six scenarios and generates publication-quality figures plus CSV/JSON outputs.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ─── MODEL PROFILE ────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "parameters": {
        "n_nodes": {"value": 5, "unit": "nodes", "source": "extracted",
                    "description": "Number of micro-library nodes in the simulated network"},
        "sim_days": {"value": 365, "unit": "days", "source": "assumed",
                     "description": "Total simulation duration representing one year of operation"},
        "base_daily_visitors": {"value": 8.0, "unit": "visitors/day", "source": "assumed",
                                "description": "Baseline daily visitor arrival rate for average node"},
        "attractiveness_multiplier": {"value": 2.5, "unit": "a.u.", "source": "assumed",
                                      "description": "Maximum multiplicative factor on visitor rate for highly attractive nodes"},
        "multilingual_visitor_boost": {"value": 0.15, "unit": "a.u.", "source": "extracted",
                                       "description": "Additional fractional visitor rate increase per additional language"},
        "weekend_multiplier": {"value": 1.6, "unit": "a.u.", "source": "assumed",
                               "description": "Multiplier applied to visitor arrivals on weekends"},
        "seasonal_amplitude": {"value": 0.3, "unit": "a.u.", "source": "assumed",
                               "description": "Amplitude of seasonal sinusoidal modulation of visitor rate"},
        "max_capacity": {"value": 30, "unit": "items", "source": "assumed",
                         "description": "Maximum number of books/items a node can hold"},
        "item_decay_rate": {"value": 0.002, "unit": "items/day", "source": "assumed",
                            "description": "Daily probability of an item becoming unusable"},
        "steward_check_freq": {"value": 3.0, "unit": "days", "source": "assumed",
                               "description": "Average number of days between steward check-in visits"},
        "network_donation_flow": {"value": 0.05, "unit": "a.u.", "source": "assumed",
                                  "description": "Probability per day of inter-node inventory redistribution"},
        "food_box_fraction": {"value": 0.2, "unit": "a.u.", "source": "extracted",
                              "description": "Fraction of nodes that also distribute food items"},
        "steward_restock_threshold": {"value": 4.0, "unit": "items", "source": "assumed",
                                      "description": "Inventory level below which a steward restocks"},
        "restock_amount": {"value": 10.0, "unit": "items", "source": "assumed",
                           "description": "Number of items added by steward during a restock event"},
        "season_start_offset": {"value": 0.0, "unit": "days", "source": "assumed",
                                "description": "Day offset for seasonal sinusoidal phase"},
    },
    "node_profiles": [
        {"node_id": 1, "node_type": "artistic",         "attractiveness": 0.9, "multilingual": 2,
         "is_food": False, "init_inventory": 10, "take_rate": 0.45, "leave_rate": 0.30},
        {"node_id": 2, "node_type": "stone_embedded",   "attractiveness": 0.4, "multilingual": 1,
         "is_food": False, "init_inventory": 14, "take_rate": 0.35, "leave_rate": 0.35},
        {"node_id": 3, "node_type": "tall_cabinet",     "attractiveness": 0.7, "multilingual": 1,
         "is_food": False, "init_inventory": 18, "take_rate": 0.40, "leave_rate": 0.32},
        {"node_id": 4, "node_type": "multilingual_food","attractiveness": 0.85,"multilingual": 5,
         "is_food": True,  "init_inventory": 8,  "take_rate": 0.60, "leave_rate": 0.25},
        {"node_id": 5, "node_type": "red_armoire",      "attractiveness": 0.65,"multilingual": 1,
         "is_food": False, "init_inventory": 15, "take_rate": 0.38, "leave_rate": 0.33},
    ],
    "scenarios": [
        {"label": "baseline_5node_network",      "index": 0, "param_overrides": {}},
        {"label": "high_community_engagement",   "index": 1,
         "param_overrides": {"base_daily_visitors": 16.0, "leave_rate_global": 0.5}},
        {"label": "low_steward_maintenance",     "index": 2,
         "param_overrides": {"steward_check_freq": 10.0, "restock_amount": 5.0}},
        {"label": "multilingual_expansion",      "index": 3,
         "param_overrides": {"multilingual_score_all": 4.0}},
        {"label": "seasonal_summer_peak",        "index": 4,
         "param_overrides": {"seasonal_amplitude": 0.6, "season_start_offset": 172.0}},
        {"label": "network_redistribution_active","index": 5,
         "param_overrides": {"network_donation_flow": 0.2}},
    ],
}

# ─── DATA CONTAINERS ──────────────────────────────────────────────────────────
@dataclass
class NodeState:
    node_id: int
    node_type: str
    attractiveness: float
    multilingual: int
    is_food: bool
    inventory: float
    take_rate: float
    leave_rate: float
    cumulative_exchanges: float = 0.0

@dataclass
class DailyRecord:
    day: int
    scenario: str
    node_id: int
    node_type: str
    design_attractiveness: float
    multilingual_score: int
    is_food_node: int
    daily_visitors: int
    daily_takes: int
    daily_leaves: int
    daily_decay: int
    steward_restock: int
    restock_amount_actual: float
    network_transfer_in: float
    network_transfer_out: float
    book_inventory_end_of_day: float
    cumulative_exchanges: float
    inventory_at_visitor_arrival_mean: float
    weekend_flag: int
    season_factor: float


def get_base_params(overrides: Dict[str, Any]) -> Dict[str, Any]:
    """Build a parameter dict from MODEL_PROFILE defaults, then apply overrides."""
    p = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    for k, v in overrides.items():
        if k in p:
            p[k] = v
    # Special override keys that don't map directly to parameter names
    # handled at simulation time: leave_rate_global, multilingual_score_all, season_start_offset
    p["_overrides"] = overrides
    return p


def build_nodes(params: Dict[str, Any]) -> List[NodeState]:
    """Instantiate node states from profiles, applying scenario-level overrides."""
    overrides = params.get("_overrides", {})
    nodes = []
    for prof in MODEL_PROFILE["node_profiles"]:
        leave_rate = prof["leave_rate"]
        if "leave_rate_global" in overrides:
            leave_rate = float(overrides["leave_rate_global"])
        multilingual = prof["multilingual"]
        if "multilingual_score_all" in overrides:
            multilingual = int(overrides["multilingual_score_all"])
        node = NodeState(
            node_id=prof["node_id"],
            node_type=prof["node_type"],
            attractiveness=prof["attractiveness"],
            multilingual=multilingual,
            is_food=prof["is_food"],
            inventory=float(prof["init_inventory"]),
            take_rate=prof["take_rate"],
            leave_rate=leave_rate,
            cumulative_exchanges=0.0,
        )
        nodes.append(node)
    return nodes


# ─── SIMULATION ENGINE ────────────────────────────────────────────────────────
def run_scenario(scenario: Dict[str, Any]) -> Tuple[List[DailyRecord], List[Any]]:
    """
    Run one scenario and return (records, inventory_arrival_samples).
    inventory_arrival_samples: list of (scenario_label, inventory_value) at each visitor arrival.
    """
    label = scenario["label"]
    idx = scenario["index"]
    overrides = scenario["param_overrides"]

    np.random.seed(idx)

    params = get_base_params(overrides)
    nodes = build_nodes(params)

    sim_days = int(params["sim_days"])
    base_daily_visitors = float(params["base_daily_visitors"])
    attractiveness_multiplier = float(params["attractiveness_multiplier"])
    multilingual_visitor_boost = float(params["multilingual_visitor_boost"])
    weekend_multiplier = float(params["weekend_multiplier"])
    seasonal_amplitude = float(params["seasonal_amplitude"])
    season_start_offset = float(overrides.get("season_start_offset", params.get("season_start_offset", 0.0)))
    max_capacity = int(params["max_capacity"])
    item_decay_rate = float(params["item_decay_rate"])
    steward_check_freq = float(params["steward_check_freq"])
    restock_amount = float(params["restock_amount"])
    steward_restock_threshold = float(params["steward_restock_threshold"])
    network_donation_flow = float(params["network_donation_flow"])

    records: List[DailyRecord] = []
    arrival_samples: List[Tuple[str, float]] = []  # (label, inventory)

    # Track per-node daily transfers (reset each day)
    n = len(nodes)
    transfer_in = np.zeros(n, dtype=float)
    transfer_out = np.zeros(n, dtype=float)

    for t in range(sim_days):
        is_weekend = int((t % 7) in [5, 6])
        season_factor = 1.0 + seasonal_amplitude * math.sin(
            2.0 * math.pi * (t - 80 + season_start_offset) / 365.0
        )
        # clamp season_factor to reasonable range
        season_factor = max(0.1, min(2.0, season_factor))
        weekend_factor = weekend_multiplier if is_weekend else 1.0

        transfer_in[:] = 0.0
        transfer_out[:] = 0.0

        daily_visitors_arr = np.zeros(n, dtype=int)
        daily_takes_arr = np.zeros(n, dtype=int)
        daily_leaves_arr = np.zeros(n, dtype=int)
        daily_decay_arr = np.zeros(n, dtype=int)
        daily_restock_flag = np.zeros(n, dtype=int)
        daily_restock_amt = np.zeros(n, dtype=float)
        arrival_mean_arr = np.zeros(n, dtype=float)

        for i, node in enumerate(nodes):
            # Visitor arrival rate
            lam = (
                base_daily_visitors
                * node.attractiveness
                * attractiveness_multiplier
                * (1.0 + multilingual_visitor_boost * (node.multilingual - 1))
                * (1.0 + 0.5 * float(node.is_food))
                * season_factor
                * weekend_factor
            )
            lam = max(0.01, lam)
            n_visitors = int(np.random.poisson(lam))
            daily_visitors_arr[i] = n_visitors

            takes_today = 0
            leaves_today = 0
            arrivals_inv: List[float] = []

            for _ in range(n_visitors):
                inv_at_arrival = max(0.0, min(float(max_capacity), node.inventory))
                arrivals_inv.append(inv_at_arrival)
                arrival_samples.append((label, inv_at_arrival))
                # Take
                if node.inventory > 0 and np.random.uniform() < node.take_rate:
                    node.inventory -= 1.0
                    takes_today += 1
                # Leave
                if node.inventory < max_capacity and np.random.uniform() < node.leave_rate:
                    node.inventory += 1.0
                    leaves_today += 1

            daily_takes_arr[i] = takes_today
            daily_leaves_arr[i] = leaves_today
            arrival_mean_arr[i] = float(np.mean(arrivals_inv)) if arrivals_inv else float(node.inventory)

            # Item decay
            inv_int = max(0, int(node.inventory))
            decay = int(np.random.binomial(inv_int, item_decay_rate)) if inv_int > 0 else 0
            node.inventory = max(0.0, node.inventory - decay)
            daily_decay_arr[i] = decay

            # Steward restock
            restock_rate = 1.0 / max(steward_check_freq, 0.1)
            restock_event = int(np.random.poisson(restock_rate)) > 0
            restocked = 0.0
            if restock_event and node.inventory <= steward_restock_threshold:
                restocked = min(restock_amount, float(max_capacity) - node.inventory)
                restocked = max(0.0, restocked)
                node.inventory += restocked
            daily_restock_flag[i] = int(restock_event and restocked > 0)
            daily_restock_amt[i] = restocked

            # Clamp inventory
            node.inventory = max(0.0, min(float(max_capacity), node.inventory))

            # Update cumulative exchanges
            node.cumulative_exchanges += takes_today + leaves_today
            node.cumulative_exchanges = max(0.0, min(100000.0, node.cumulative_exchanges))

        # Network redistribution
        if np.random.uniform() < network_donation_flow:
            inventories = [nd.inventory for nd in nodes]
            donor_idx = int(np.argmax(inventories))
            recip_idx = int(np.argmin(inventories))
            if donor_idx != recip_idx and (nodes[donor_idx].inventory - nodes[recip_idx].inventory) > 5:
                gap = nodes[donor_idx].inventory - nodes[recip_idx].inventory
                tx = math.floor(gap / 3.0)
                tx = max(1, tx)
                # Ensure donor has enough
                tx = min(tx, int(nodes[donor_idx].inventory))
                # Ensure recipient won't exceed capacity
                tx = min(tx, max_capacity - int(nodes[recip_idx].inventory))
                if tx > 0:
                    nodes[donor_idx].inventory -= tx
                    nodes[recip_idx].inventory += tx
                    transfer_out[donor_idx] += tx
                    transfer_in[recip_idx] += tx

        # Clamp after redistribution
        for nd in nodes:
            nd.inventory = max(0.0, min(float(max_capacity), nd.inventory))

        # Record rows
        for i, node in enumerate(nodes):
            rec = DailyRecord(
                day=t + 1,
                scenario=label,
                node_id=node.node_id,
                node_type=node.node_type,
                design_attractiveness=round(node.attractiveness, 4),
                multilingual_score=node.multilingual,
                is_food_node=int(node.is_food),
                daily_visitors=int(daily_visitors_arr[i]),
                daily_takes=int(daily_takes_arr[i]),
                daily_leaves=int(daily_leaves_arr[i]),
                daily_decay=int(daily_decay_arr[i]),
                steward_restock=int(daily_restock_flag[i]),
                restock_amount_actual=round(float(daily_restock_amt[i]), 2),
                network_transfer_in=round(float(transfer_in[i]), 2),
                network_transfer_out=round(float(transfer_out[i]), 2),
                book_inventory_end_of_day=round(float(node.inventory), 2),
                cumulative_exchanges=round(float(node.cumulative_exchanges), 2),
                inventory_at_visitor_arrival_mean=round(float(arrival_mean_arr[i]), 4),
                weekend_flag=is_weekend,
                season_factor=round(season_factor, 6),
            )
            records.append(rec)

    return records, arrival_samples


# ─── CSV WRITERS ──────────────────────────────────────────────────────────────
SCHEMA = [
    "day", "scenario", "node_id", "node_type", "design_attractiveness",
    "multilingual_score", "is_food_node", "daily_visitors", "daily_takes",
    "daily_leaves", "daily_decay", "steward_restock", "restock_amount_actual",
    "network_transfer_in", "network_transfer_out", "book_inventory_end_of_day",
    "cumulative_exchanges", "inventory_at_visitor_arrival_mean", "weekend_flag",
    "season_factor",
]


def write_simulation_outputs(all_records: List[DailyRecord], out_dir: pathlib.Path) -> None:
    path = out_dir / "simulation_outputs.csv"
    if not all_records:
        print("WARNING: No simulation records to write.")
        return
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SCHEMA)
        writer.writeheader()
        for rec in all_records:
            writer.writerow({
                "day": rec.day,
                "scenario": rec.scenario,
                "node_id": rec.node_id,
                "node_type": rec.node_type,
                "design_attractiveness": rec.design_attractiveness,
                "multilingual_score": rec.multilingual_score,
                "is_food_node": rec.is_food_node,
                "daily_visitors": rec.daily_visitors,
                "daily_takes": rec.daily_takes,
                "daily_leaves": rec.daily_leaves,
                "daily_decay": rec.daily_decay,
                "steward_restock": rec.steward_restock,
                "restock_amount_actual": rec.restock_amount_actual,
                "network_transfer_in": rec.network_transfer_in,
                "network_transfer_out": rec.network_transfer_out,
                "book_inventory_end_of_day": rec.book_inventory_end_of_day,
                "cumulative_exchanges": rec.cumulative_exchanges,
                "inventory_at_visitor_arrival_mean": rec.inventory_at_visitor_arrival_mean,
                "weekend_flag": rec.weekend_flag,
                "season_factor": rec.season_factor,
            })
    print(f"Wrote {path}")


def write_scenario_summary(all_records: List[DailyRecord], out_dir: pathlib.Path) -> None:
    path = out_dir / "scenario_summary.csv"
    if not all_records:
        print("WARNING: No records for scenario summary.")
        return

    from collections import defaultdict
    grouped: Dict[str, List[DailyRecord]] = defaultdict(list)
    for rec in all_records:
        grouped[rec.scenario].append(rec)

    fieldnames = [
        "scenario",
        "mean_inventory", "std_inventory", "min_inventory", "max_inventory",
        "mean_daily_visitors", "std_daily_visitors",
        "mean_daily_takes", "mean_daily_leaves",
        "mean_daily_decay",
        "total_restock_events", "total_restock_amount",
        "total_network_transfer",
        "final_cumulative_exchanges_mean",
        "mean_inventory_at_arrival",
        "pct_days_depleted",
    ]

    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for sc, recs in sorted(grouped.items()):
            inventories = np.array([r.book_inventory_end_of_day for r in recs])
            visitors = np.array([r.daily_visitors for r in recs])
            takes = np.array([r.daily_takes for r in recs])
            leaves = np.array([r.daily_leaves for r in recs])
            decays = np.array([r.daily_decay for r in recs])
            restock_events = sum(1 for r in recs if r.steward_restock > 0)
            restock_amt = sum(r.restock_amount_actual for r in recs)
            net_transfer = sum(r.network_transfer_in for r in recs)
            cum_ex = np.array([r.cumulative_exchanges for r in recs])
            arr_inv = np.array([r.inventory_at_visitor_arrival_mean for r in recs])
            pct_depleted = float(np.mean(inventories < 1.0)) * 100.0

            writer.writerow({
                "scenario": sc,
                "mean_inventory": round(float(np.mean(inventories)), 4),
                "std_inventory": round(float(np.std(inventories)), 4),
                "min_inventory": round(float(np.min(inventories)), 4),
                "max_inventory": round(float(np.max(inventories)), 4),
                "mean_daily_visitors": round(float(np.mean(visitors)), 4),
                "std_daily_visitors": round(float(np.std(visitors)), 4),
                "mean_daily_takes": round(float(np.mean(takes)), 4),
                "mean_daily_leaves": round(float(np.mean(leaves)), 4),
                "mean_daily_decay": round(float(np.mean(decays)), 6),
                "total_restock_events": restock_events,
                "total_restock_amount": round(restock_amt, 2),
                "total_network_transfer": round(net_transfer, 2),
                "final_cumulative_exchanges_mean": round(float(np.mean(cum_ex)), 2),
                "mean_inventory_at_arrival": round(float(np.mean(arr_inv)), 4),
                "pct_days_depleted": round(pct_depleted, 4),
            })
    print(f"Wrote {path}")


def write_parameters_used(out_dir: pathlib.Path) -> None:
    path = out_dir / "parameters_used.csv"
    fieldnames = ["name", "value", "unit", "source", "description"]
    rows = []
    for name, meta in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": meta["value"],
            "unit": meta["unit"],
            "source": meta["source"],
            "description": meta["description"],
        })
    if not rows:
        print("WARNING: No parameters to write.")
        return
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {path}")


# ─── FIGURE GENERATION ────────────────────────────────────────────────────────
SCENARIO_COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"
]
NODE_COLORS = ["#4e79a7", "#f28e2b", "#e15759", "#76b7b2", "#59a14f"]
NODE_LABELS = ["node1_artistic", "node2_stone", "node3_cabinet", "node4_food", "node5_armoire"]


def fig1_inventory_per_node(all_records: List[DailyRecord], out_dir: pathlib.Path,
                             scenario_label: str = "baseline_5node_network") -> None:
    """fig1: Daily inventory per node for a given scenario."""
    try:
        recs = [r for r in all_records if r.scenario == scenario_label]
        if not recs:
            print(f"WARNING fig1: No records for scenario {scenario_label}")
            return
        node_ids = sorted(set(r.node_id for r in recs))
        days = sorted(set(r.day for r in recs))
        n_days = len(days)
        if n_days == 0:
            print("WARNING fig1: no days found.")
            return

        fig, ax = plt.subplots(figsize=(12, 6))
        for ni, nid in enumerate(node_ids):
            node_recs = sorted([r for r in recs if r.node_id == nid], key=lambda x: x.day)
            x_arr = np.array([r.day for r in node_recs])
            y_arr = np.array([r.book_inventory_end_of_day for r in node_recs])
            assert len(x_arr) == len(y_arr), f"Shape mismatch node {nid}"
            if len(x_arr) == 0:
                continue
            ntype = node_recs[0].node_type
            ax.plot(x_arr, y_arr, color=NODE_COLORS[ni % len(NODE_COLORS)],
                    label=f"Node {nid} ({ntype})", linewidth=1.2, alpha=0.85)

        ax.set_xlim(1, 365)
        ax.set_ylim(0, 30)
        ax.set_xlabel("Day", fontsize=12)
        ax.set_ylabel("Book Inventory (items)", fontsize=12)
        ax.set_title(f"Daily Inventory Level per Node — {scenario_label}", fontsize=13)
        ax.legend(loc="upper right", fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / f"fig1_inventory_per_node_{scenario_label}.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig1 failed — {e}")
        plt.close("all")


def fig2_cumulative_exchanges(all_records: List[DailyRecord], out_dir: pathlib.Path,
                               scenario_label: str = "baseline_5node_network") -> None:
    """fig2: Cumulative exchange events per node."""
    try:
        recs = [r for r in all_records if r.scenario == scenario_label]
        if not recs:
            print(f"WARNING fig2: No records for scenario {scenario_label}")
            return
        node_ids = sorted(set(r.node_id for r in recs))

        fig, ax = plt.subplots(figsize=(12, 6))
        for ni, nid in enumerate(node_ids):
            node_recs = sorted([r for r in recs if r.node_id == nid], key=lambda x: x.day)
            x_arr = np.array([r.day for r in node_recs])
            y_arr = np.array([r.cumulative_exchanges for r in node_recs])
            assert len(x_arr) == len(y_arr), f"Shape mismatch node {nid}"
            if len(x_arr) == 0:
                continue
            ntype = node_recs[0].node_type
            ax.plot(x_arr, y_arr, color=NODE_COLORS[ni % len(NODE_COLORS)],
                    label=f"Node {nid} ({ntype})", linewidth=1.5)

        ax.set_xlim(1, 365)
        ax.set_xlabel("Day", fontsize=12)
        ax.set_ylabel("Cumulative Exchanges", fontsize=12)
        ax.set_title(f"Cumulative Exchange Events per Node — {scenario_label}", fontsize=13)
        ax.legend(loc="upper left", fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / f"fig2_cumulative_exchanges_{scenario_label}.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig2 failed — {e}")
        plt.close("all")


def fig3_attractiveness_vs_visitors(all_records: List[DailyRecord], out_dir: pathlib.Path) -> None:
    """fig3: Scatter of design attractiveness vs mean daily visitors, colored by scenario."""
    try:
        from collections import defaultdict
        scenario_labels = sorted(set(r.scenario for r in all_records))
        node_ids = sorted(set(r.node_id for r in all_records))

        fig, ax = plt.subplots(figsize=(9, 6))
        for si, sc in enumerate(scenario_labels):
            x_vals = []
            y_vals = []
            for nid in node_ids:
                node_sc_recs = [r for r in all_records if r.scenario == sc and r.node_id == nid]
                if not node_sc_recs:
                    continue
                attr = node_sc_recs[0].design_attractiveness
                mean_vis = float(np.mean([r.daily_visitors for r in node_sc_recs]))
                x_vals.append(attr)
                y_vals.append(mean_vis)
            x_arr = np.array(x_vals)
            y_arr = np.array(y_vals)
            if len(x_arr) == 0 or len(y_arr) == 0:
                continue
            assert len(x_arr) == len(y_arr)
            color = SCENARIO_COLORS[si % len(SCENARIO_COLORS)]
            ax.scatter(x_arr, y_arr, color=color, label=sc, s=80, alpha=0.85, edgecolors="k", linewidths=0.5)

        ax.set_xlabel("Design Attractiveness (a.u.)", fontsize=12)
        ax.set_ylabel("Mean Daily Visitors", fontsize=12)
        ax.set_title("Design Attractiveness vs. Mean Daily Visitors\nAcross Nodes and Scenarios", fontsize=13)
        ax.legend(fontsize=8, bbox_to_anchor=(1.01, 1), loc="upper left")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig3_attractiveness_vs_visitors.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig3 failed — {e}")
        plt.close("all")


def fig4_heatmap_inventory(all_records: List[DailyRecord], out_dir: pathlib.Path) -> None:
    """fig4: Heatmap of mean inventory by node and scenario."""
    try:
        scenario_labels = [s["label"] for s in MODEL_PROFILE["scenarios"]]
        node_ids = sorted(set(r.node_id for r in all_records))

        matrix = np.zeros((len(scenario_labels), len(node_ids)), dtype=float)
        for si, sc in enumerate(scenario_labels):
            for ni, nid in enumerate(node_ids):
                recs = [r for r in all_records if r.scenario == sc and r.node_id == nid]
                if recs:
                    matrix[si, ni] = float(np.mean([r.book_inventory_end_of_day for r in recs]))

        fig, ax = plt.subplots(figsize=(10, 5))
        im = ax.imshow(matrix, aspect="auto", cmap="YlGnBu",
                       vmin=0.0, vmax=float(MODEL_PROFILE["parameters"]["max_capacity"]["value"]))
        plt.colorbar(im, ax=ax, label="Mean Daily Inventory (items)")

        ax.set_xticks(np.arange(len(node_ids)))
        ax.set_xticklabels([f"Node {nid}" for nid in node_ids], fontsize=10)
        ax.set_yticks(np.arange(len(scenario_labels)))
        ax.set_yticklabels(scenario_labels, fontsize=9)
        ax.set_title("Mean Inventory Level by Node and Scenario (Heatmap)", fontsize=13)

        for si in range(len(scenario_labels)):
            for ni in range(len(node_ids)):
                val = matrix[si, ni]
                txt_color = "white" if val < 10 else "black"
                ax.text(ni, si, f"{val:.1f}", ha="center", va="center",
                        fontsize=8, color=txt_color)

        plt.tight_layout()
        fpath = out_dir / "fig4_heatmap_inventory.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig4 failed — {e}")
        plt.close("all")


def fig5_inventory_at_arrival_hist(all_records: List[DailyRecord],
                                    arrival_samples_by_scenario: Dict[str, List[float]],
                                    out_dir: pathlib.Path) -> None:
    """fig5: Histogram of inventory at visitor arrival, per scenario."""
    try:
        scenario_labels = [s["label"] for s in MODEL_PROFILE["scenarios"]]
        fig, ax = plt.subplots(figsize=(11, 6))
        bins = np.arange(0, 32, 1)

        for si, sc in enumerate(scenario_labels):
            samples = arrival_samples_by_scenario.get(sc, [])
            if not samples:
                print(f"WARNING fig5: No arrival samples for {sc}")
                continue
            arr = np.array(samples, dtype=float)
            color = SCENARIO_COLORS[si % len(SCENARIO_COLORS)]
            ax.hist(arr, bins=bins, alpha=0.45, color=color, label=sc,
                    density=True, edgecolor="none")

        ax.set_xlabel("Inventory at Visitor Arrival (items)", fontsize=12)
        ax.set_ylabel("Density", fontsize=12)
        ax.set_title("Distribution of Inventory Levels at Moment of Visitor Arrival", fontsize=13)
        ax.legend(fontsize=9, bbox_to_anchor=(1.01, 1), loc="upper left")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig5_inventory_at_arrival_hist.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig5 failed — {e}")
        plt.close("all")


def fig6_network_total_inventory(all_records: List[DailyRecord], out_dir: pathlib.Path) -> None:
    """fig6: Total network inventory over time for each scenario."""
    try:
        scenario_labels = [s["label"] for s in MODEL_PROFILE["scenarios"]]
        sim_days = int(MODEL_PROFILE["parameters"]["sim_days"]["value"])
        days_arr = np.arange(1, sim_days + 1)

        fig, ax = plt.subplots(figsize=(13, 6))
        for si, sc in enumerate(scenario_labels):
            sc_recs = [r for r in all_records if r.scenario == sc]
            if not sc_recs:
                print(f"WARNING fig6: no records for {sc}")
                continue
            # Sum inventory across all nodes per day
            daily_totals = {}
            for r in sc_recs:
                daily_totals[r.day] = daily_totals.get(r.day, 0.0) + r.book_inventory_end_of_day

            x_arr = np.array(sorted(daily_totals.keys()), dtype=int)
            y_arr = np.array([daily_totals[d] for d in x_arr], dtype=float)
            assert len(x_arr) == len(y_arr), "fig6 shape mismatch"
            if len(x_arr) == 0:
                continue
            color = SCENARIO_COLORS[si % len(SCENARIO_COLORS)]
            ax.plot(x_arr, y_arr, color=color, label=sc, linewidth=1.5, alpha=0.85)

        ax.set_xlim(1, sim_days)
        ax.set_xlabel("Day", fontsize=12)
        ax.set_ylabel("Total Network Inventory (items)", fontsize=12)
        ax.set_title("Total Network Inventory Across All Scenarios Over Time", fontsize=13)
        ax.legend(fontsize=9, bbox_to_anchor=(1.01, 1), loc="upper left")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig6_network_total_inventory.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig6 failed — {e}")
        plt.close("all")


# ─── SUMMARY JSON ─────────────────────────────────────────────────────────────
def write_summary_json(all_records: List[DailyRecord], out_dir: pathlib.Path) -> None:
    path = out_dir / "summary.json"
    try:
        scenario_labels = sorted(set(r.scenario for r in all_records))
        summary: Dict[str, Any] = {
            "title": "Community Micro-Library and Free Little Library Network Dynamics",
            "total_records": len(all_records),
            "scenarios": {},
        }
        for sc in scenario_labels:
            recs = [r for r in all_records if r.scenario == sc]
            inventories = [r.book_inventory_end_of_day for r in recs]
            visitors = [r.daily_visitors for r in recs]
            exchanges = [r.cumulative_exchanges for r in recs]
            summary["scenarios"][sc] = {
                "n_records": len(recs),
                "mean_inventory": round(float(np.mean(inventories)), 4),
                "std_inventory": round(float(np.std(inventories)), 4),
                "mean_daily_visitors": round(float(np.mean(visitors)), 4),
                "total_cumulative_exchanges": round(float(np.max(exchanges) if exchanges else 0), 2),
                "pct_depleted_days": round(float(np.mean([v < 1.0 for v in inventories])) * 100, 4),
            }
        with open(path, "w") as f:
            json.dump(summary, f, indent=2)
        print(f"Wrote {path}")
    except Exception as e:
        print(f"WARNING: summary.json failed — {e}")


# ─── MAIN ─────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Community Micro-Library Network Dynamics Simulator"
    )
    parser.add_argument("--output", default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("Community Micro-Library Network Dynamics Simulator")
    print("=" * 60)

    all_records: List[DailyRecord] = []
    arrival_samples_by_scenario: Dict[str, List[float]] = {}

    for scenario in MODEL_PROFILE["scenarios"]:
        print(f"\nRunning scenario [{scenario['index']}]: {scenario['label']}")
        records, arrival_samples = run_scenario(scenario)
        all_records.extend(records)
        # arrival_samples is list of (label, inv_value)
        sc_arrivals = [inv for (lbl, inv) in arrival_samples if lbl == scenario["label"]]
        arrival_samples_by_scenario[scenario["label"]] = sc_arrivals
        print(f"  → {len(records)} records, {len(sc_arrivals)} visitor arrival events")

    print(f"\nTotal records across all scenarios: {len(all_records)}")

    # ── Write CSVs ────────────────────────────────────────────────────────────
    print("\nWriting CSV files...")
    write_simulation_outputs(all_records, out_dir)
    write_scenario_summary(all_records, out_dir)
    write_parameters_used(out_dir)

    # ── Write Summary JSON ────────────────────────────────────────────────────
    print("\nWriting summary JSON...")
    write_summary_json(all_records, out_dir)

    # ── Generate Figures ──────────────────────────────────────────────────────
    print("\nGenerating figures...")

    # fig1 & fig2 — per-scenario line plots (generate for baseline and one other)
    for sc_label in ["baseline_5node_network", "low_steward_maintenance",
                     "high_community_engagement", "network_redistribution_active",
                     "multilingual_expansion", "seasonal_summer_peak"]:
        fig1_inventory_per_node(all_records, out_dir, scenario_label=sc_label)
        fig2_cumulative_exchanges(all_records, out_dir, scenario_label=sc_label)

    # fig3 — scatter
    fig3_attractiveness_vs_visitors(all_records, out_dir)

    # fig4 — heatmap
    fig4_heatmap_inventory(all_records, out_dir)

    # fig5 — histogram
    fig5_inventory_at_arrival_hist(all_records, arrival_samples_by_scenario, out_dir)

    # fig6 — network total inventory
    fig6_network_total_inventory(all_records, out_dir)

    print("\n" + "=" * 60)
    print(f"All outputs saved to: {out_dir.resolve()}")
    print("=" * 60)


if __name__ == "__main__":
    main()