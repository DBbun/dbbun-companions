# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-06-28T22:30:14.216480Z
# Run ID    : 463ffbe2-8dec-4677-b744-5d5b96ec572d
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Disability Through U.S. History: Barriers, Access, and the Fight for Public Life
— A Simulator-Ready Public-History Report for DBbun

This simulator models U.S. disability history as a dynamical system in which barriers,
legal protections, advocacy capacity, federal implementation delay, community services,
and public attitudes interact annually from 1850 to 2025. Five scenarios generate
counterfactual trajectories demonstrating how laws, protests, and design decisions
change who can access public life.

All outputs are synthetic educational artifacts transparently derived from
disability-rights source documents and labeled as computationally generated.
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import numpy as np

# =============================================================================
# MODEL PROFILE
# =============================================================================
MODEL_PROFILE = {
    "title": "Disability Through U.S. History: Barriers, Access, and the Fight for Public Life",
    "domain": "U.S. Disability History / Social Policy Dynamical System",
    "backend": "dynamical_system",
    "parameters": {
        "barrier_reduction_rate": 0.03,
        "advocacy_growth_rate": 0.05,
        "advocacy_carrying_capacity": 1.0,
        "law_enactment_section504": 1973.0,
        "sitin_year": 1977.0,
        "sitin_duration_days": 25.0,
        "ada_enactment_year": 1990.0,
        "olmstead_year": 1999.0,
        "ada_amendments_year": 2008.0,
        "legal_impact_on_barriers": 0.25,
        "sitin_advocacy_boost": 0.30,
        "implementation_delay_decay": 0.08,
        "community_service_growth_rate": 0.04,
        "olmstead_community_boost": 0.20,
        "institutional_to_community_rate": 0.03,
        "public_attitude_learning_rate": 0.04,
        "accessibility_feature_rollout_rate": 0.05,
        "digital_access_era_start": 2008.0,
        "rehabilitation_funding_growth": 0.02,
        "noise_std": 0.01,
        "simulation_start_year": 1850.0,
        "simulation_end_year": 2025.0,
    },
    "state_variables": {
        "barrier_level": {"init": 0.95, "range": [0.0, 1.0]},
        "participation_rate": {"init": 0.05, "range": [0.0, 1.0]},
        "legal_protection_strength": {"init": 0.0, "range": [0.0, 1.0]},
        "advocacy_capacity": {"init": 0.02, "range": [0.0, 1.0]},
        "institutional_placement_rate": {"init": 0.60, "range": [0.0, 1.0]},
        "community_service_availability": {"init": 0.05, "range": [0.0, 1.0]},
        "federal_implementation_delay": {"init": 1.0, "range": [0.0, 1.0]},
        "public_attitude_index": {"init": 0.05, "range": [0.0, 1.0]},
        "rehabilitation_funding": {"init": 0.10, "range": [0.0, 1.0]},
        "accessibility_feature_coverage": {"init": 0.01, "range": [0.0, 1.0]},
    },
    "scenarios": [
        {
            "label": "baseline_exclusion",
            "description": "No major policy interventions. Counterfactual world without Section 504, ADA, or Olmstead.",
            "param_overrides": {
                "legal_impact_on_barriers": 0.0,
                "sitin_advocacy_boost": 0.0,
                "olmstead_community_boost": 0.0,
                "accessibility_feature_rollout_rate": 0.005,
                "barrier_reduction_rate": 0.005,
            },
        },
        {
            "label": "section504_only",
            "description": "Section 504 enacted and sit-in drives implementation, but ADA not passed.",
            "param_overrides": {
                "legal_impact_on_barriers": 0.10,
                "sitin_advocacy_boost": 0.30,
                "olmstead_community_boost": 0.0,
                "accessibility_feature_rollout_rate": 0.02,
                "ada_enactment_year": 9999.0,
            },
        },
        {
            "label": "ada_full_implementation",
            "description": "ADA enacted in 1990 and rapidly implemented. Full historical trajectory.",
            "param_overrides": {
                "legal_impact_on_barriers": 0.25,
                "sitin_advocacy_boost": 0.30,
                "olmstead_community_boost": 0.20,
                "accessibility_feature_rollout_rate": 0.05,
                "barrier_reduction_rate": 0.03,
            },
        },
        {
            "label": "early_community_services",
            "description": "Community-based services funded 15 years earlier (Olmstead-style policy from 1975).",
            "param_overrides": {
                "olmstead_year": 1975.0,
                "olmstead_community_boost": 0.25,
                "community_service_growth_rate": 0.07,
                "institutional_to_community_rate": 0.06,
            },
        },
        {
            "label": "slow_federal_implementation",
            "description": "Laws enacted but federal implementation severely delayed (high bureaucratic inertia).",
            "param_overrides": {
                "implementation_delay_decay": 0.02,
                "legal_impact_on_barriers": 0.10,
                "barrier_reduction_rate": 0.01,
                "sitin_advocacy_boost": 0.15,
            },
        },
    ],
}

# =============================================================================
# PARAMETER METADATA (for parameters_used.csv)
# =============================================================================
PARAMETER_METADATA = [
    ("barrier_reduction_rate", 0.03, "per year", "assumed",
     "Rate at which barriers are reduced per year when legal protections and advocacy are active"),
    ("advocacy_growth_rate", 0.05, "per year", "assumed",
     "Logistic growth rate of disability-rights advocacy capacity"),
    ("advocacy_carrying_capacity", 1.0, "index", "assumed",
     "Maximum achievable advocacy capacity index"),
    ("law_enactment_section504", 1973.0, "year", "extracted",
     "Year Section 504 of the Rehabilitation Act was enacted"),
    ("sitin_year", 1977.0, "year", "extracted",
     "Year of the Section 504 sit-in in San Francisco"),
    ("sitin_duration_days", 25.0, "days", "extracted",
     "Duration of the 1977 Section 504 sit-in protest"),
    ("ada_enactment_year", 1990.0, "year", "extracted",
     "Year the Americans with Disabilities Act was enacted"),
    ("olmstead_year", 1999.0, "year", "extracted",
     "Year of the Olmstead Supreme Court decision"),
    ("ada_amendments_year", 2008.0, "year", "extracted",
     "Year the ADA Amendments Act expanded disability protections"),
    ("legal_impact_on_barriers", 0.25, "index reduction", "assumed",
     "Step-change reduction in barrier level when major legislation is enacted"),
    ("sitin_advocacy_boost", 0.30, "index increase", "assumed",
     "Boost to advocacy capacity caused by the 1977 sit-in"),
    ("implementation_delay_decay", 0.08, "per year", "assumed",
     "Rate at which federal implementation delay decreases per year under advocacy pressure"),
    ("community_service_growth_rate", 0.04, "per year", "assumed",
     "Rate of growth in community-based services driven by Olmstead compliance"),
    ("olmstead_community_boost", 0.20, "index increase", "assumed",
     "Additional boost to community service availability triggered by Olmstead decision"),
    ("institutional_to_community_rate", 0.03, "per year", "assumed",
     "Rate of transition from institutional placement to community living"),
    ("public_attitude_learning_rate", 0.04, "per year", "assumed",
     "Rate at which public attitudes shift toward civil-rights recognition"),
    ("accessibility_feature_rollout_rate", 0.05, "per year", "assumed",
     "Rate at which accessibility features are deployed across public infrastructure"),
    ("digital_access_era_start", 2008.0, "year", "extracted",
     "Year digital and web accessibility became a significant domain"),
    ("rehabilitation_funding_growth", 0.02, "per year", "assumed",
     "Annual growth rate of rehabilitation and disability-services funding"),
    ("noise_std", 0.01, "index", "assumed",
     "Standard deviation of Gaussian noise added to state variables"),
    ("simulation_start_year", 1850.0, "year", "extracted",
     "Starting year of the simulation"),
    ("simulation_end_year", 2025.0, "year", "extracted",
     "Ending year of the simulation"),
]

# =============================================================================
# SCENARIO COLORS
# =============================================================================
SCENARIO_COLORS = {
    "baseline_exclusion": "#d62728",
    "section504_only": "#ff7f0e",
    "ada_full_implementation": "#2ca02c",
    "early_community_services": "#1f77b4",
    "slow_federal_implementation": "#9467bd",
}


# =============================================================================
# SIMULATION CORE
# =============================================================================
def run_scenario(scenario_cfg: Dict[str, Any], scenario_index: int) -> List[Dict[str, Any]]:
    """Run a single scenario and return list of row dicts."""
    np.random.seed(scenario_index)

    # Build parameter set: start from defaults, apply overrides
    params = dict(MODEL_PROFILE["parameters"])
    for k, v in scenario_cfg.get("param_overrides", {}).items():
        params[k] = v

    label = scenario_cfg["label"]

    # Unpack parameters
    barrier_reduction_rate = params["barrier_reduction_rate"]
    advocacy_growth_rate = params["advocacy_growth_rate"]
    advocacy_carrying_capacity = params["advocacy_carrying_capacity"]
    law_enactment_section504 = int(params["law_enactment_section504"])
    sitin_year = params["sitin_year"]
    ada_enactment_year = params["ada_enactment_year"]
    olmstead_year = params["olmstead_year"]
    ada_amendments_year = params["ada_amendments_year"]
    digital_access_era_start = params["digital_access_era_start"]
    legal_impact_on_barriers = params["legal_impact_on_barriers"]
    sitin_advocacy_boost = params["sitin_advocacy_boost"]
    implementation_delay_decay = params["implementation_delay_decay"]
    community_service_growth_rate = params["community_service_growth_rate"]
    olmstead_community_boost = params["olmstead_community_boost"]
    institutional_to_community_rate = params["institutional_to_community_rate"]
    public_attitude_learning_rate = params["public_attitude_learning_rate"]
    accessibility_feature_rollout_rate = params["accessibility_feature_rollout_rate"]
    rehabilitation_funding_growth = params["rehabilitation_funding_growth"]
    noise_std = params["noise_std"]
    start_year = int(params["simulation_start_year"])
    end_year = int(params["simulation_end_year"])

    # Initialize state variables
    barrier_level = 0.95
    participation_rate = 0.05
    legal_protection_strength = 0.0
    advocacy_capacity = 0.02
    institutional_placement_rate = 0.60
    community_service_availability = 0.05
    federal_implementation_delay = 1.0
    public_attitude_index = 0.05
    rehabilitation_funding = 0.10
    accessibility_feature_coverage = 0.01

    # Domain compliance
    domain_employment = 0.01
    domain_transportation = 0.01
    domain_public_accommodations = 0.01
    domain_state_local_gov = 0.01
    domain_telecom = 0.01
    domain_digital = 0.01

    rows = []

    for t in range(start_year, end_year + 1):
        tf = float(t)

        # === 1. EVENT DETECTION ===
        sitin_event_active = 1 if abs(tf - sitin_year) < 1.0 else 0
        section504_enacted = 1 if tf >= law_enactment_section504 else 0
        ada_enacted = 1 if tf >= ada_enactment_year else 0
        olmstead_enacted = 1 if tf >= olmstead_year else 0
        ada_amendments_enacted = 1 if tf >= ada_amendments_year else 0
        digital_era_active = 1 if tf >= digital_access_era_start else 0

        # Major law label
        if ada_enacted and olmstead_enacted and ada_amendments_enacted:
            major_law_enacted = "ADA+Olmstead+Amendments"
        elif ada_enacted and olmstead_enacted:
            major_law_enacted = "ADA+Olmstead"
        elif ada_enacted:
            major_law_enacted = "ADA"
        elif section504_enacted:
            major_law_enacted = "Section504"
        else:
            major_law_enacted = "None"

        # === 2. LEGAL PROTECTION STRENGTH ===
        # Normalize by 0.25; if legal_impact_on_barriers=0, steps are zero
        norm = legal_impact_on_barriers / 0.25 if legal_impact_on_barriers > 0 else 0.0
        if t == law_enactment_section504:
            legal_protection_strength += 0.15 * norm
        if tf == ada_enactment_year:
            legal_protection_strength += 0.40 * norm
        if tf == olmstead_year:
            legal_protection_strength += 0.20 * norm
        if tf == ada_amendments_year:
            legal_protection_strength += 0.10 * norm
        legal_protection_strength = float(np.clip(legal_protection_strength, 0.0, 1.0))

        # === 3. ADVOCACY CAPACITY (logistic + sit-in boost) ===
        dA = advocacy_growth_rate * advocacy_capacity * (
            1.0 - advocacy_capacity / advocacy_carrying_capacity
        )
        if sitin_event_active:
            dA += sitin_advocacy_boost
        noise_a = np.random.normal(0.0, noise_std)
        advocacy_capacity = float(np.clip(advocacy_capacity + dA + noise_a, 0.0, 1.0))

        # === 4. FEDERAL IMPLEMENTATION DELAY ===
        delay_reduction = implementation_delay_decay * advocacy_capacity * section504_enacted
        if sitin_event_active:
            delay_reduction += sitin_advocacy_boost * 0.5
        noise_d = np.random.normal(0.0, noise_std)
        federal_implementation_delay = float(
            np.clip(federal_implementation_delay - delay_reduction + noise_d, 0.0, 1.0)
        )

        # === 5. BARRIER LEVEL ===
        effective_reduction = (
            barrier_reduction_rate
            * legal_protection_strength
            * advocacy_capacity
            * (1.0 - federal_implementation_delay)
        )
        noise_b = np.random.normal(0.0, noise_std * 0.5)
        barrier_level = float(np.clip(barrier_level - effective_reduction + noise_b, 0.0, 1.0))

        # === 6. PUBLIC ATTITUDE INDEX ===
        dPublic = public_attitude_learning_rate * advocacy_capacity * (1.0 - public_attitude_index)
        noise_p = np.random.normal(0.0, noise_std)
        public_attitude_index = float(np.clip(public_attitude_index + dPublic + noise_p, 0.0, 1.0))

        # === 7. REHABILITATION FUNDING ===
        rehab_growth = rehabilitation_funding_growth * (1.0 + 0.5 * ada_enacted)
        noise_r = np.random.normal(0.0, noise_std)
        rehabilitation_funding = float(np.clip(rehabilitation_funding + rehab_growth + noise_r, 0.0, 1.0))

        # === 8. COMMUNITY SERVICE AVAILABILITY ===
        olmstead_boost_applied = olmstead_community_boost if (tf == olmstead_year) else 0.0
        dCS = community_service_growth_rate * olmstead_enacted * (1.0 - community_service_availability)
        noise_cs = np.random.normal(0.0, noise_std)
        community_service_availability = float(
            np.clip(community_service_availability + dCS + olmstead_boost_applied + noise_cs, 0.0, 1.0)
        )

        # === 9. INSTITUTIONAL PLACEMENT RATE ===
        dI = -institutional_to_community_rate * community_service_availability * olmstead_enacted
        noise_i = np.random.normal(0.0, noise_std * 0.5)
        institutional_placement_rate = float(
            np.clip(institutional_placement_rate + dI + noise_i, 0.0, 1.0)
        )

        # === 10. ACCESSIBILITY FEATURE COVERAGE ===
        feature_growth = accessibility_feature_rollout_rate * ada_enacted * (
            1.0 - accessibility_feature_coverage
        )
        if digital_era_active:
            feature_growth *= 1.3
        noise_af = np.random.normal(0.0, noise_std)
        accessibility_feature_coverage = float(
            np.clip(accessibility_feature_coverage + feature_growth + noise_af, 0.0, 1.0)
        )

        # === 11. PARTICIPATION RATE ===
        noise_part = np.random.normal(0.0, noise_std)
        participation_rate = float(
            np.clip(
                0.30 * (1.0 - barrier_level)
                + 0.25 * legal_protection_strength * (1.0 - federal_implementation_delay)
                + 0.20 * community_service_availability
                + 0.15 * accessibility_feature_coverage
                + 0.10 * public_attitude_index
                + noise_part,
                0.0,
                1.0,
            )
        )

        # === 12. ADA DOMAIN COMPLIANCE ===
        noise_de = np.random.normal(0.0, noise_std)
        domain_employment = float(
            np.clip(domain_employment + 0.04 * ada_enacted * (1.0 - domain_employment) + noise_de, 0.0, 1.0)
        )
        noise_dt = np.random.normal(0.0, noise_std)
        domain_transportation = float(
            np.clip(
                domain_transportation + 0.035 * ada_enacted * (1.0 - domain_transportation) + noise_dt,
                0.0, 1.0,
            )
        )
        noise_dpa = np.random.normal(0.0, noise_std)
        domain_public_accommodations = float(
            np.clip(
                domain_public_accommodations
                + 0.045 * ada_enacted * (1.0 - domain_public_accommodations)
                + noise_dpa,
                0.0, 1.0,
            )
        )
        noise_dsg = np.random.normal(0.0, noise_std)
        domain_state_local_gov = float(
            np.clip(
                domain_state_local_gov
                + 0.04 * section504_enacted * (1.0 - domain_state_local_gov)
                + noise_dsg,
                0.0, 1.0,
            )
        )
        noise_dtc = np.random.normal(0.0, noise_std)
        domain_telecom = float(
            np.clip(domain_telecom + 0.03 * ada_enacted * (1.0 - domain_telecom) + noise_dtc, 0.0, 1.0)
        )
        noise_ddi = np.random.normal(0.0, noise_std)
        domain_digital = float(
            np.clip(
                domain_digital + 0.06 * digital_era_active * (1.0 - domain_digital) + noise_ddi,
                0.0, 1.0,
            )
        )

        # === 13. NOISE REALIZATION FOR CSV ===
        noise_realization = float(np.random.normal(0.0, noise_std))

        rows.append({
            "year": t,
            "scenario": label,
            "barrier_level": round(barrier_level, 6),
            "participation_rate": round(participation_rate, 6),
            "legal_protection_strength": round(legal_protection_strength, 6),
            "advocacy_capacity": round(advocacy_capacity, 6),
            "institutional_placement_rate": round(institutional_placement_rate, 6),
            "community_service_availability": round(community_service_availability, 6),
            "federal_implementation_delay": round(federal_implementation_delay, 6),
            "public_attitude_index": round(public_attitude_index, 6),
            "rehabilitation_funding": round(rehabilitation_funding, 6),
            "accessibility_feature_coverage": round(accessibility_feature_coverage, 6),
            "domain_employment_compliance": round(domain_employment, 6),
            "domain_transportation_compliance": round(domain_transportation, 6),
            "domain_public_accommodations_compliance": round(domain_public_accommodations, 6),
            "domain_state_local_government_compliance": round(domain_state_local_gov, 6),
            "domain_telecommunications_compliance": round(domain_telecom, 6),
            "domain_digital_information_compliance": round(domain_digital, 6),
            "sitin_event_active": sitin_event_active,
            "major_law_enacted": major_law_enacted,
            "noise_realization": round(noise_realization, 6),
        })

    return rows


# =============================================================================
# CSV WRITERS
# =============================================================================
DATASET_SCHEMA = [
    "year", "scenario", "barrier_level", "participation_rate",
    "legal_protection_strength", "advocacy_capacity", "institutional_placement_rate",
    "community_service_availability", "federal_implementation_delay",
    "public_attitude_index", "rehabilitation_funding", "accessibility_feature_coverage",
    "domain_employment_compliance", "domain_transportation_compliance",
    "domain_public_accommodations_compliance", "domain_state_local_government_compliance",
    "domain_telecommunications_compliance", "domain_digital_information_compliance",
    "sitin_event_active", "major_law_enacted", "noise_realization",
]


def write_simulation_outputs(all_rows: List[Dict[str, Any]], output_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv with all scenario rows."""
    if not all_rows:
        print("WARNING: No simulation rows to write to simulation_outputs.csv")
        return
    filepath = output_dir / "simulation_outputs.csv"
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA)
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"Written: {filepath}")
    except Exception as e:
        print(f"WARNING: Could not write simulation_outputs.csv: {e}")


def write_scenario_summary(all_rows: List[Dict[str, Any]], output_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv with one row per scenario."""
    if not all_rows:
        print("WARNING: No data for scenario_summary.csv")
        return

    numeric_cols = [
        "barrier_level", "participation_rate", "legal_protection_strength",
        "advocacy_capacity", "institutional_placement_rate", "community_service_availability",
        "federal_implementation_delay", "public_attitude_index", "rehabilitation_funding",
        "accessibility_feature_coverage",
    ]

    # Group by scenario
    scenario_data: Dict[str, List[Dict]] = {}
    for row in all_rows:
        s = row["scenario"]
        scenario_data.setdefault(s, []).append(row)

    summary_rows = []
    for scenario_label, rows in scenario_data.items():
        summary = {"scenario": scenario_label, "n_years": len(rows)}
        for col in numeric_cols:
            vals = np.array([r[col] for r in rows], dtype=float)
            summary[f"{col}_mean"] = round(float(np.mean(vals)), 6)
            summary[f"{col}_std"] = round(float(np.std(vals)), 6)
            summary[f"{col}_min"] = round(float(np.min(vals)), 6)
            summary[f"{col}_max"] = round(float(np.max(vals)), 6)
        # Final year values (at year 2025)
        final_rows = [r for r in rows if r["year"] == 2025]
        if final_rows:
            fr = final_rows[0]
            for col in numeric_cols:
                summary[f"{col}_final"] = fr[col]
        summary_rows.append(summary)

    if not summary_rows:
        print("WARNING: No summary rows computed")
        return

    # Build field names
    fieldnames = ["scenario", "n_years"]
    for col in numeric_cols:
        fieldnames += [f"{col}_mean", f"{col}_std", f"{col}_min", f"{col}_max", f"{col}_final"]

    filepath = output_dir / "scenario_summary.csv"
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(summary_rows)
        print(f"Written: {filepath}")
    except Exception as e:
        print(f"WARNING: Could not write scenario_summary.csv: {e}")


def write_parameters_used(output_dir: pathlib.Path) -> None:
    """Write parameters_used.csv."""
    filepath = output_dir / "parameters_used.csv"
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "value", "unit", "source", "description"])
            for row in PARAMETER_METADATA:
                writer.writerow(list(row))
        print(f"Written: {filepath}")
    except Exception as e:
        print(f"WARNING: Could not write parameters_used.csv: {e}")


# =============================================================================
# DATA EXTRACTION HELPERS
# =============================================================================
def get_scenario_arrays(all_rows: List[Dict], scenarios: List[str]) -> Dict[str, Dict[str, np.ndarray]]:
    """Build {scenario: {field: array}} from all_rows."""
    result = {}
    for s in scenarios:
        s_rows = [r for r in all_rows if r["scenario"] == s]
        s_rows_sorted = sorted(s_rows, key=lambda r: r["year"])
        if not s_rows_sorted:
            continue
        result[s] = {}
        for col in DATASET_SCHEMA:
            if col in ("scenario", "major_law_enacted"):
                result[s][col] = [r[col] for r in s_rows_sorted]
            else:
                result[s][col] = np.array([r[col] for r in s_rows_sorted], dtype=float)
    return result


# =============================================================================
# FIGURE GENERATORS
# =============================================================================
def make_fig1(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig1: Participation rate by scenario over time."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("participation_rate")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig1: No data to plot")
            plt.close(fig)
            return
        ax.axvline(1977, color="gray", linestyle="--", alpha=0.6, linewidth=1)
        ax.axvline(1990, color="navy", linestyle="--", alpha=0.6, linewidth=1)
        ax.axvline(1999, color="darkgreen", linestyle="--", alpha=0.6, linewidth=1)
        ax.text(1977, 0.92, "Sit-in\n1977", fontsize=7, color="gray", ha="center")
        ax.text(1990, 0.87, "ADA\n1990", fontsize=7, color="navy", ha="center")
        ax.text(1999, 0.82, "Olmstead\n1999", fontsize=7, color="darkgreen", ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Participation Rate [0,1]")
        ax.set_title("Disability Participation Rate Over U.S. History by Scenario")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig1_participation_rate.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig1: {e}")
        plt.close("all")


def make_fig2(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig2: Barrier level by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("barrier_level")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig2: No data to plot")
            plt.close(fig)
            return
        for yr, lbl, clr in [
            (1973, "Sec.504\n1973", "orange"),
            (1977, "Sit-in\n1977", "gray"),
            (1990, "ADA\n1990", "navy"),
            (1999, "Olmstead\n1999", "darkgreen"),
            (2008, "ADAAA\n2008", "purple"),
        ]:
            ax.axvline(yr, color=clr, linestyle=":", alpha=0.5, linewidth=1)
            ax.text(yr, 0.15, lbl, fontsize=6.5, color=clr, ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Barrier Level [0=accessible, 1=excluded]")
        ax.set_title("Composite Barrier Level Across Historical Epochs and Scenarios")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig2_barrier_level.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig2: {e}")
        plt.close("all")


def make_fig3(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig3: Advocacy capacity by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("advocacy_capacity")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig3: No data to plot")
            plt.close(fig)
            return
        ax.axvline(1977, color="gray", linestyle="--", alpha=0.7, linewidth=1.2)
        ax.text(1977, 0.95, "1977 Sit-in\nBoost", fontsize=8, color="gray", ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Advocacy Capacity [0,1]")
        ax.set_title("Disability Rights Advocacy Capacity: Growth and Movement Events")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig3_advocacy_capacity.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig3: {e}")
        plt.close("all")


def make_fig4(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig4: Institutional placement rate by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("institutional_placement_rate")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig4: No data to plot")
            plt.close(fig)
            return
        ax.axvline(1975, color="steelblue", linestyle=":", alpha=0.6)
        ax.axvline(1999, color="darkgreen", linestyle="--", alpha=0.6)
        ax.text(1975, 0.05, "Early\nOlmstead\n(counterfactual)", fontsize=6.5, color="steelblue", ha="center")
        ax.text(1999, 0.10, "Olmstead\n1999", fontsize=7, color="darkgreen", ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Institutional Placement Rate [0,1]")
        ax.set_title("Institutional Placement Rate vs. Community Living Over Time")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig4_institutional_placement.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig4: {e}")
        plt.close("all")


def make_fig5(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig5: Community service availability by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("community_service_availability")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig5: No data to plot")
            plt.close(fig)
            return
        ax.axvline(1975, color="steelblue", linestyle=":", alpha=0.6)
        ax.axvline(1999, color="darkgreen", linestyle="--", alpha=0.6)
        ax.text(1975, 0.95, "Early services\n1975", fontsize=7, color="steelblue", ha="center")
        ax.text(1999, 0.85, "Olmstead\n1999", fontsize=7, color="darkgreen", ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Community Service Availability [0,1]")
        ax.set_title("Community-Based Service Availability and the Olmstead Effect")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig5_community_service.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig5: {e}")
        plt.close("all")


def make_fig6(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig6: Federal implementation delay by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("federal_implementation_delay")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig6: No data to plot")
            plt.close(fig)
            return
        ax.axvline(1973, color="orange", linestyle=":", alpha=0.6)
        ax.axvline(1977, color="gray", linestyle="--", alpha=0.7)
        ax.axvline(1990, color="navy", linestyle="--", alpha=0.6)
        ax.text(1973, 0.65, "Sec.504\n1973", fontsize=7, color="orange", ha="center")
        ax.text(1977, 0.55, "Sit-in\n1977", fontsize=7, color="gray", ha="center")
        ax.text(1990, 0.45, "ADA\n1990", fontsize=7, color="navy", ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Federal Implementation Delay [0=implemented, 1=delayed]")
        ax.set_title("Federal Implementation Delay: Law Enactment vs. Executed Access")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig6_implementation_delay.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig6: {e}")
        plt.close("all")


def make_fig7(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig7: Accessibility feature coverage by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("accessibility_feature_coverage")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig7: No data to plot")
            plt.close(fig)
            return
        ax.axvline(1990, color="navy", linestyle="--", alpha=0.6)
        ax.axvline(2008, color="purple", linestyle="--", alpha=0.6)
        ax.text(1990, 0.92, "ADA\n1990", fontsize=7, color="navy", ha="center")
        ax.text(2008, 0.80, "Digital Era\n2008", fontsize=7, color="purple", ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Accessibility Feature Coverage [0,1]")
        ax.set_title("Accessibility Feature Rollout: From Ramps to Captions to Digital Access")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig7_accessibility_coverage.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig7: {e}")
        plt.close("all")


def make_fig8(all_rows: List[Dict], scenarios: List[str], output_dir: pathlib.Path) -> None:
    """Fig8: Heatmap of ADA domain coverage by scenario at year 2025."""
    try:
        domain_cols = [
            "domain_employment_compliance",
            "domain_transportation_compliance",
            "domain_public_accommodations_compliance",
            "domain_state_local_government_compliance",
            "domain_telecommunications_compliance",
            "domain_digital_information_compliance",
        ]
        domain_labels = [
            "Employment",
            "Transportation",
            "Public Accommodations",
            "State/Local Government",
            "Telecommunications",
            "Digital/Information",
        ]

        # Get final year values per scenario
        data_matrix = np.zeros((len(domain_cols), len(scenarios)))
        for j, s in enumerate(scenarios):
            final_rows = [r for r in all_rows if r["scenario"] == s and r["year"] == 2025]
            if final_rows:
                fr = final_rows[0]
                for i, col in enumerate(domain_cols):
                    data_matrix[i, j] = float(fr.get(col, 0.0))
            else:
                # Fallback: use last available year
                s_rows = sorted([r for r in all_rows if r["scenario"] == s], key=lambda r: r["year"])
                if s_rows:
                    fr = s_rows[-1]
                    for i, col in enumerate(domain_cols):
                        data_matrix[i, j] = float(fr.get(col, 0.0))

        if data_matrix.size == 0:
            print("WARNING fig8: Empty data matrix")
            return

        fig, ax = plt.subplots(figsize=(12, 6))
        im = ax.imshow(data_matrix, aspect="auto", cmap="YlGn", vmin=0.0, vmax=1.0)
        ax.set_xticks(range(len(scenarios)))
        ax.set_xticklabels([s.replace("_", "\n") for s in scenarios], fontsize=9)
        ax.set_yticks(range(len(domain_labels)))
        ax.set_yticklabels(domain_labels, fontsize=9)
        ax.set_title("ADA Access Domain Coverage by Scenario at Year 2025")
        plt.colorbar(im, ax=ax, label="Compliance Level [0,1]")
        for i in range(len(domain_cols)):
            for j in range(len(scenarios)):
                val = data_matrix[i, j]
                ax.text(j, i, f"{val:.2f}", ha="center", va="center", fontsize=8,
                        color="black" if val < 0.7 else "white")
        fig.tight_layout()
        fp = output_dir / "fig8_domain_heatmap.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig8: {e}")
        plt.close("all")


def make_fig9(scenario_arrays: Dict, scenarios: List[str], output_dir: pathlib.Path) -> None:
    """Fig9: Scatter of advocacy capacity vs. participation rate, all years/scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(10, 7))
        plotted = False
        for label in scenarios:
            arrays = scenario_arrays.get(label)
            if arrays is None:
                continue
            x = arrays.get("advocacy_capacity")
            y = arrays.get("participation_rate")
            years = arrays.get("year")
            if x is None or y is None or years is None:
                continue
            if len(x) != len(y):
                print(f"WARNING fig9: shape mismatch for {label}, skipping")
                continue
            if len(x) == 0:
                continue
            ax.scatter(x, y, label=label, color=SCENARIO_COLORS.get(label, None),
                       alpha=0.4, s=15)
            plotted = True
            # Annotate historical anchor years
            for anchor_year, anchor_label in [(1977, "1977"), (1990, "1990")]:
                idx_list = np.where(years == anchor_year)[0]
                if len(idx_list) > 0:
                    idx = idx_list[0]
                    ax.annotate(
                        f"{label[:6]}:{anchor_label}",
                        (x[idx], y[idx]),
                        fontsize=6, alpha=0.8,
                        xytext=(5, 3), textcoords="offset points",
                    )
        if not plotted:
            print("WARNING fig9: No data to plot")
            plt.close(fig)
            return
        ax.set_xlabel("Advocacy Capacity [0,1]")
        ax.set_ylabel("Participation Rate [0,1]")
        ax.set_title("Advocacy Capacity vs. Participation Rate: Scatter Across All Years and Scenarios")
        ax.legend(fontsize=8, markerscale=2)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        fig.tight_layout()
        fp = output_dir / "fig9_advocacy_vs_participation.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig9: {e}")
        plt.close("all")


def make_fig10(scenario_arrays: Dict, output_dir: pathlib.Path) -> None:
    """Fig10: Public attitude index by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for label, arrays in scenario_arrays.items():
            x = arrays.get("year")
            y = arrays.get("public_attitude_index")
            if x is None or y is None:
                continue
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=label, color=SCENARIO_COLORS.get(label, None), linewidth=2)
            plotted = True
        if not plotted:
            print("WARNING fig10: No data to plot")
            plt.close(fig)
            return
        ax.axvline(1977, color="gray", linestyle="--", alpha=0.6)
        ax.axvline(1990, color="navy", linestyle="--", alpha=0.6)
        ax.text(1977, 0.92, "Sit-in\n1977", fontsize=7, color="gray", ha="center")
        ax.text(1990, 0.87, "ADA\n1990", fontsize=7, color="navy", ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Public Attitude Index [0=charity model, 1=civil rights]")
        ax.set_title("Public Attitude Toward Disability Rights: From Charity Model to Civil Rights")
        ax.legend(fontsize=9)
        ax.set_ylim(0, 1)
        ax.set_xlim(1850, 2025)
        fig.tight_layout()
        fp = output_dir / "fig10_public_attitude.png"
        fig.savefig(fp, dpi=120)
        plt.close(fig)
        print(f"Written: {fp}")
    except Exception as e:
        print(f"WARNING fig10: {e}")
        plt.close("all")


# =============================================================================
# SUMMARY JSON
# =============================================================================
def write_summary_json(all_rows: List[Dict], scenarios: List[str], output_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    summary = {
        "title": MODEL_PROFILE["title"],
        "note": "All outputs are synthetic educational artifacts.",
        "scenarios": {},
    }
    for s in scenarios:
        s_rows = [r for r in all_rows if r["scenario"] == s]
        if not s_rows:
            continue
        pr_vals = np.array([r["participation_rate"] for r in s_rows])
        bl_vals = np.array([r["barrier_level"] for r in s_rows])
        ac_vals = np.array([r["advocacy_capacity"] for r in s_rows])
        final_rows = [r for r in s_rows if r["year"] == 2025]
        final_pr = final_rows[0]["participation_rate"] if final_rows else float(pr_vals[-1])
        final_bl = final_rows[0]["barrier_level"] if final_rows else float(bl_vals[-1])
        summary["scenarios"][s] = {
            "n_years": len(s_rows),
            "participation_rate_mean": round(float(np.mean(pr_vals)), 4),
            "participation_rate_final_2025": round(float(final_pr), 4),
            "barrier_level_mean": round(float(np.mean(bl_vals)), 4),
            "barrier_level_final_2025": round(float(final_bl), 4),
            "advocacy_capacity_mean": round(float(np.mean(ac_vals)), 4),
        }
    filepath = output_dir / "summary.json"
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(f"Written: {filepath}")
    except Exception as e:
        print(f"WARNING: Could not write summary.json: {e}")


# =============================================================================
# MAIN
# =============================================================================
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Disability History Dynamical System Simulator"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    # Run all scenarios
    scenarios = MODEL_PROFILE["scenarios"]
    scenario_labels = [s["label"] for s in scenarios]
    all_rows: List[Dict[str, Any]] = []

    for idx, scenario_cfg in enumerate(scenarios):
        label = scenario_cfg["label"]
        print(f"\nRunning scenario [{idx}]: {label}")
        try:
            rows = run_scenario(scenario_cfg, scenario_index=idx)
            all_rows.extend(rows)
            print(f"  -> {len(rows)} rows generated")
        except Exception as e:
            print(f"WARNING: Scenario {label} failed: {e}")

    print(f"\nTotal rows: {len(all_rows)}")

    # Write CSV files
    print("\n--- Writing CSV files ---")
    write_simulation_outputs(all_rows, output_dir)
    write_scenario_summary(all_rows, output_dir)
    write_parameters_used(output_dir)

    # Build scenario arrays for plotting
    scenario_arrays = get_scenario_arrays(all_rows, scenario_labels)

    # Generate figures
    print("\n--- Generating figures ---")
    make_fig1(scenario_arrays, output_dir)
    make_fig2(scenario_arrays, output_dir)
    make_fig3(scenario_arrays, output_dir)
    make_fig4(scenario_arrays, output_dir)
    make_fig5(scenario_arrays, output_dir)
    make_fig6(scenario_arrays, output_dir)
    make_fig7(scenario_arrays, output_dir)
    make_fig8(all_rows, scenario_labels, output_dir)
    make_fig9(scenario_arrays, scenario_labels, output_dir)
    make_fig10(scenario_arrays, output_dir)

    # Write summary JSON
    print("\n--- Writing summary JSON ---")
    write_summary_json(all_rows, scenario_labels, output_dir)

    print("\nSimulation complete.")
    print(f"All outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()