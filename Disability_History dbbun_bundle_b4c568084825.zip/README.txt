================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 463ffbe2-8dec-4677-b744-5d5b96ec572d
    Generated   : 2026-06-28  22:30:14 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Disability Through U.S. History: Barriers, Access, and the Fight for Public Life — A Simulator-Ready Public-History Report for DBbun

    CATEGORIES
    ----------
    Social Sciences, Health, Education and Learning Technologies, Demographic

    KEYWORDS
    --------
    disability history, access simulation, Americans with Disabilities Act, Section 504 sit-in, community integration

    ABSTRACT
    --------
    This simulator models U.S. disability history as a dynamical system in which barriers, legal protections, advocacy capacity, federal implementation delay, community services, and public attitudes interact annually from 1850 to 2025. Rather than modeling disabled people as medical variables, it models the systems that determine participation: physical and communication barriers, legislative events (Section 504, the ADA, Olmstead), protest dynamics (the 1977 25-day sit-in), and community-based service availability. Five scenarios — from baseline exclusion to early community services — generate counterfactual trajectories that visually demonstrate how laws, protests, and design decisions change who can access public life. Researchers, educators, and public historians can use the simulator to explore how the gap between law-on-paper and executed access is itself measurable, and how advocacy capacity is the critical driver of participation gains. All outputs are synthetic educational artifacts transparently derived from disability-rights source documents and labeled as computationally generated.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    DBbun_Disability_History_Report for dbbun.docx

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    barrier_level, participation_rate, legal_protection_strength, advocacy_capacity, institutional_placement_rate, community_service_availability, federal_implementation_delay, public_attitude_index, rehabilitation_funding, accessibility_feature_coverage

    SCENARIOS  (5 total)
    ---------------------------------
        1. baseline_exclusion — No major policy interventions occur. Barriers remain high, advocacy grows slowly, and participation stays suppressed throughout. Represents a counterfactual world without Section 504, ADA, or Olmstead.
2. section504_only — Section 504 is enacted and the 1977 sit-in drives implementation, but the ADA is not passed. Models the partial-access world of the late 1970s and 1980s, with federal programs covered but no broad public-accommodation mandate.
3. ada_full_implementation — ADA enacted in 1990 and rapidly implemented. Full scenario with Section 504, the 1977 sit-in, ADA, Olmstead (1999), and ADA Amendments Act (2008). Represents the historical trajectory with all major access interventions.
4. early_community_services — Counterfactual scenario where community-based services and independent living supports are funded 15 years earlier (starting 1975 instead of 1990). Models what participation would look like if Olmstead-style policy had preceded the ADA.
5. slow_federal_implementation — Laws are enacted but federal implementation is severely delayed (high bureaucratic inertia). Models the real tension described in the report between law-on-paper and executed access. Advocacy must work harder to force compliance.

    PARAMETERS
    ----------
    22 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig10

    DOMAIN SUMMARY
    --------------
    This report frames U.S. disability history as a systems problem — modeling barriers, policies, institutions, protests, and access interventions — spanning from 19th-century almshouses through the ADA and Olmstead decision to digital accessibility. It provides a structured, scenario-driven simulator blueprint centered on how changes in laws, protests, funding, and physical/communication infrastructure alter participation rates for disabled people in public life.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.