================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : ab44c10e-b34e-4ff3-8a01-b128119d80d9
    Generated   : 2026-04-23  16:06:17 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    FAIR assessment of nanosafety data reusability with community standards

    CATEGORIES
    ----------
    Biomedical and Health Sciences, Machine Learning, Standards Research Data, Health, Sensors

    KEYWORDS
    --------
    FAIR data principles, nanosafety, maturity indicators, minimum reporting standards, engineered nanomaterials, metadata reusability, nanomaterial risk assessment

    ABSTRACT
    --------
    This simulator models the NanoSafety Data Reusability Assessment (NSDRA) framework, which evaluates how well nanosafety datasets comply with 12 community-developed minimum reporting standards translated into 281 machine-readable FAIR maturity indicators. The simulator generates synthetic nanosafety dataset populations with controllable reporting completeness profiles across three variable categories (physicochemical, in vitro, in vivo) and evaluates each dataset against all 12 MI lists and five application use cases (grouping/read-across, nanoform identification, toxicity prediction, regulatory requirements, NanoInChI calculation). Researchers can use the synthetic data and figures to understand how reporting completeness affects reusability scores, which MI lists are most demanding, and how many nanosafety applications can be satisfied at different levels of metadata quality. Students and data stewards can use the simulator to explore FAIR assessment workflows, while engineers building nanosafety platforms can calibrate completeness thresholds for automated data quality gates.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    41597_2024_Article_3324.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    mi_pass_count, mi_fail_count, reusability_score, physchem_score, invitro_score, invivo_score, application_coverage, generic_indicator_coverage, total_reported_variables

    SCENARIOS  (6 total)
    ---------------------------------
        1. low_quality_datasets — Simulates datasets with poor metadata completeness, representing early-era nanosafety data with low variable reporting rates across all MI lists
2. average_quality_datasets — Simulates datasets at typical literature-level completeness, where roughly half the required variables are reported per MI list
3. high_quality_datasets — Simulates datasets representing best-practice reporting with high compliance to community standards
4. physchem_specialist_datasets — Simulates datasets that excel at physicochemical reporting (high physchem rate) but lack in vitro and in vivo variables, matching the five physchem-only MI lists
5. multi_list_assessment — Assesses the same synthetic dataset pool across all 12 MI lists simultaneously, revealing how reusability scores vary by list and demonstrating that no single list fulfills all applications
6. application_coverage_analysis — Evaluates how many of the five nanosafety applications (GR, NI, TP, RR, NC) each dataset can satisfy as a function of overall reporting completeness

    PARAMETERS
    ----------
    28 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This paper presents the NanoSafety Data Reusability Assessment (NSDRA) framework, which converts 12 published minimum reporting standards for engineered nanomaterials into machine-readable FAIR maturity indicators to evaluate and improve the reusability of nanosafety datasets for toxicity prediction, regulatory compliance, and risk assessment. The framework encompasses 281 maturity indicators spanning physicochemical, in vitro, and in vivo variable categories, two web applications for metadata generation and automated reusability assessment, and a mapping of indicators to five nanosafety application use cases.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.