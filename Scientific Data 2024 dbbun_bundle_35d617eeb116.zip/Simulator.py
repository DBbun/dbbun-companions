# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-23T16:06:17.789968Z
# Run ID    : ab44c10e-b34e-4ff3-8a01-b128119d80d9
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
NSDRA Simulator: FAIR Assessment of NanoSafety Data Reusability with Community Standards

Based on: 'FAIR assessment of nanosafety data reusability with community standards'

This simulator models the NanoSafety Data Reusability Assessment (NSDRA) framework,
evaluating synthetic nanosafety datasets against 12 minimum reporting standards (MI lists)
and 5 application use cases using 281 machine-readable FAIR maturity indicators.
"""

import argparse
import csv
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Any, Optional

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Patch

# =============================================================================
# MODEL PROFILE
# =============================================================================
MODEL_PROFILE = {
    "title": "FAIR assessment of nanosafety data reusability with community standards",
    "parameters": {
        "n_mrs_lists": {"value": 12, "unit": "count", "source": "extracted",
                        "description": "Total number of minimum reporting standards"},
        "total_mis": {"value": 281, "unit": "count", "source": "extracted",
                      "description": "Total maturity indicators across all 12 MI lists"},
        "n_generic_indicators": {"value": 30, "unit": "count", "source": "extracted",
                                 "description": "Number of generic indicators grouping overlapping MIs"},
        "n_overlapping_mis": {"value": 119, "unit": "count", "source": "extracted",
                              "description": "Overlapping MIs grouped under 30 generic indicators"},
        "n_applications": {"value": 5, "unit": "count", "source": "extracted",
                           "description": "Nanosafety applications: GR, NI, TP, RR, NC"},
        "min_mis_per_list": {"value": 9, "unit": "count", "source": "extracted",
                             "description": "Minimum MIs in any single list (ISO/TR13014)"},
        "max_mis_per_list": {"value": 37, "unit": "count", "source": "extracted",
                             "description": "Maximum MIs in any single list (caLIBRAte/MetadataStewardship)"},
        "n_physchem_only_lists": {"value": 5, "unit": "count", "source": "extracted",
                                  "description": "MI lists with only physicochemical indicators"},
        "n_all_three_category_lists": {"value": 2, "unit": "count", "source": "extracted",
                                       "description": "MI lists covering all three categories"},
        "n_physchem_invitro_lists": {"value": 3, "unit": "count", "source": "extracted",
                                     "description": "MI lists covering physchem and in vitro"},
        "n_physchem_invivo_lists": {"value": 1, "unit": "count", "source": "extracted",
                                    "description": "MI lists covering physchem and in vivo"},
        "n_invitro_invivo_only_lists": {"value": 1, "unit": "count", "source": "extracted",
                                        "description": "MI lists covering in vitro and in vivo only"},
        "n_datasets_assessed": {"value": 5, "unit": "count", "source": "extracted",
                                 "description": "NanoSafety Cluster datasets in demonstration"},
        "msds_insufficient_pct": {"value": 0.67, "unit": "fraction", "source": "extracted",
                                   "description": "Fraction of MSDSs with insufficient nanomaterial hazard data"},
        "n_simulated_datasets": {"value": 100, "unit": "count", "source": "assumed",
                                  "description": "Synthetic datasets simulated per scenario"},
        "baseline_reporting_rate": {"value": 0.45, "unit": "fraction", "source": "assumed",
                                     "description": "Baseline probability any variable is reported"},
        "calibrate_mi_count": {"value": 37, "unit": "count", "source": "extracted",
                                "description": "MIs in caLIBRAte list"},
        "riskgone_mi_count": {"value": 34, "unit": "count", "source": "extracted",
                               "description": "MIs in RiskGONE list"},
        "minbe_mi_count": {"value": 28, "unit": "count", "source": "extracted",
                            "description": "MIs in MINBE list"},
        "nanometa_mi_count": {"value": 37, "unit": "count", "source": "extracted",
                               "description": "MIs in Metadata Stewardship 2020 list"},
        "bionano_mi_count": {"value": 26, "unit": "count", "source": "extracted",
                              "description": "MIs in BioNano 2018 list"},
        "harmonize_mi_count": {"value": 32, "unit": "count", "source": "extracted",
                                "description": "MIs in HarmonizingMedia list"},
        "acsnano2015_mi_count": {"value": 19, "unit": "count", "source": "extracted",
                                  "description": "MIs in ACS Nano 2015 list"},
        "zetapot_mi_count": {"value": 18, "unit": "count", "source": "extracted",
                              "description": "MIs in ZetaPotential list"},
        "unece_mi_count": {"value": 19, "unit": "count", "source": "extracted",
                            "description": "MIs in UNECE GHS list"},
        "nanoreg_mi_count": {"value": 12, "unit": "count", "source": "extracted",
                              "description": "MIs in Nanomaterial Registry list"},
        "iso_mi_count": {"value": 9, "unit": "count", "source": "extracted",
                          "description": "MIs in ISO/TR13014 list"},
        "harper_mi_count": {"value": 10, "unit": "count", "source": "extracted",
                             "description": "MIs in minimal analytical characterization list (2010)"},
    },
    "scenarios": [
        {"label": "low_quality_datasets", "baseline_reporting_rate": 0.2, "n_simulated_datasets": 100},
        {"label": "average_quality_datasets", "baseline_reporting_rate": 0.45, "n_simulated_datasets": 100},
        {"label": "high_quality_datasets", "baseline_reporting_rate": 0.80, "n_simulated_datasets": 100},
        {"label": "physchem_specialist_datasets", "baseline_reporting_rate": 0.75, "n_simulated_datasets": 100},
        {"label": "multi_list_assessment", "baseline_reporting_rate": 0.50, "n_simulated_datasets": 50},
        {"label": "application_coverage_analysis", "baseline_reporting_rate": 0.55, "n_simulated_datasets": 200},
    ]
}

# =============================================================================
# MI LISTS DEFINITION
# Each list: id, name, size, physchem, invitro, invivo, basic, apps, category
# CRITICAL: physchem + invitro + invivo + basic MUST equal size
# =============================================================================
def build_mi_lists():
    """
    Define all 12 MI lists. Components must sum to size exactly.
    Category types:
      'physchem_only' - only physchem MIs
      'physchem_invitro' - physchem + invitro
      'physchem_invivo' - physchem + invivo
      'all_three' - physchem + invitro + invivo
      'invitro_invivo' - invitro + invivo only
    """
    mi_lists = [
        # id=1: ACSNano2015, size=19, physchem=14, invitro=0, invivo=0, basic=5 -> sum=19
        {
            "id": 1, "name": "ACSNano2015", "size": 19,
            "physchem": 14, "invitro": 0, "invivo": 0, "basic": 5,
            "apps": ["GR", "NI", "TP"],
            "category": "physchem_only"
        },
        # id=2: ZetaPotential, size=18, physchem=16, invitro=0, invivo=0, basic=2 -> sum=18
        {
            "id": 2, "name": "ZetaPotential", "size": 18,
            "physchem": 16, "invitro": 0, "invivo": 0, "basic": 2,
            "apps": ["NI"],
            "category": "physchem_only"
        },
        # id=3: MetadataStewardship, size=37, physchem=22, invitro=12, invivo=0, basic=3 -> sum=37
        {
            "id": 3, "name": "MetadataStewardship", "size": 37,
            "physchem": 22, "invitro": 12, "invivo": 0, "basic": 3,
            "apps": ["GR", "TP", "RR"],
            "category": "physchem_invitro"
        },
        # id=4: MinimalAnalytical, size=10, physchem=8, invitro=0, invivo=0, basic=2 -> sum=10
        {
            "id": 4, "name": "MinimalAnalytical", "size": 10,
            "physchem": 8, "invitro": 0, "invivo": 0, "basic": 2,
            "apps": ["GR"],
            "category": "physchem_only"
        },
        # id=5: HarmonizingMedia, size=32, physchem=0, invitro=20, invivo=12, basic=0 -> sum=32
        {
            "id": 5, "name": "HarmonizingMedia", "size": 32,
            "physchem": 0, "invitro": 20, "invivo": 12, "basic": 0,
            "apps": [],
            "category": "invitro_invivo"
        },
        # id=6: MINBE, size=28, physchem=15, invitro=10, invivo=0, basic=3 -> sum=28
        {
            "id": 6, "name": "MINBE", "size": 28,
            "physchem": 15, "invitro": 10, "invivo": 0, "basic": 3,
            "apps": ["GR", "TP"],
            "category": "physchem_invitro"
        },
        # id=7: UNECE_GHS, size=19, physchem=14, invitro=0, invivo=0, basic=5 -> sum=19
        {
            "id": 7, "name": "UNECE_GHS", "size": 19,
            "physchem": 14, "invitro": 0, "invivo": 0, "basic": 5,
            "apps": ["RR"],
            "category": "physchem_only"
        },
        # id=8: NanomaterialRegistry, size=12, physchem=10, invitro=0, invivo=0, basic=2 -> sum=12
        {
            "id": 8, "name": "NanomaterialRegistry", "size": 12,
            "physchem": 10, "invitro": 0, "invivo": 0, "basic": 2,
            "apps": ["NI", "NC"],
            "category": "physchem_only"
        },
        # id=9: caLIBRAte, size=37, physchem=15, invitro=12, invivo=7, basic=3 -> sum=37
        {
            "id": 9, "name": "caLIBRAte", "size": 37,
            "physchem": 15, "invitro": 12, "invivo": 7, "basic": 3,
            "apps": ["GR", "NI", "TP", "RR", "NC"],
            "category": "all_three"
        },
        # id=10: RiskGONE, size=34, physchem=12, invitro=12, invivo=7, basic=3 -> sum=34
        {
            "id": 10, "name": "RiskGONE", "size": 34,
            "physchem": 12, "invitro": 12, "invivo": 7, "basic": 3,
            "apps": ["GR", "TP", "RR", "NC"],
            "category": "all_three"
        },
        # id=11: ISO_TR13014, size=9, physchem=7, invitro=0, invivo=0, basic=2 -> sum=9
        {
            "id": 11, "name": "ISO_TR13014", "size": 9,
            "physchem": 7, "invitro": 0, "invivo": 0, "basic": 2,
            "apps": ["GR", "NI"],
            "category": "physchem_only"
        },
        # id=12: BioNano2018, size=26, physchem=14, invitro=8, invivo=4, basic=0 -> sum=26
        {
            "id": 12, "name": "BioNano2018", "size": 26,
            "physchem": 14, "invitro": 8, "invivo": 4, "basic": 0,
            "apps": ["GR", "TP"],
            "category": "physchem_invitro"
        },
    ]

    # Validate that components sum to size
    for ml in mi_lists:
        total = ml["physchem"] + ml["invitro"] + ml["invivo"] + ml["basic"]
        assert total == ml["size"], (
            f"MI list {ml['name']} components ({ml['physchem']}+{ml['invitro']}+"
            f"{ml['invivo']}+{ml['basic']}={total}) != size {ml['size']}"
        )

    return mi_lists


# =============================================================================
# GENERIC INDICATORS DEFINITION (30 total)
# =============================================================================
GENERIC_INDICATORS = {
    "Basic": [
        "chemical_composition", "surface_chemistry", "purity", "labeling", "nanomaterial_source"
    ],
    "PhysChem": [
        "size", "shape", "surface_area", "surface_charge", "zeta_potential",
        "crystallinity", "solubility", "stability", "dispersibility", "density", "agglomeration_state"
    ],
    "Toxicity": [
        "dose", "exposure_duration", "n_controls", "n_replicates", "data_analysis",
        "organism", "administration_route", "invivo_n_subjects", "invivo_age", "invivo_sex",
        "invivo_weight", "invivo_strain", "invitro_passage", "invitro_mycoplasma"
    ]
}

# Flat list of all 30 generic indicators
ALL_GENERIC = (
    GENERIC_INDICATORS["Basic"] +
    GENERIC_INDICATORS["PhysChem"] +
    GENERIC_INDICATORS["Toxicity"]
)
assert len(ALL_GENERIC) == 30, f"Expected 30 generic indicators, got {len(ALL_GENERIC)}"

# Category lookup for each indicator
INDICATOR_CATEGORY = {}
for cat, indicators in GENERIC_INDICATORS.items():
    for ind in indicators:
        INDICATOR_CATEGORY[ind] = cat

# =============================================================================
# APPLICATION REQUIREMENTS
# =============================================================================
APP_REQUIRED = {
    "GR": ["chemical_composition", "surface_chemistry", "size", "shape", "surface_area", "dose", "organism"],
    "NI": ["chemical_composition", "size", "shape", "zeta_potential", "crystallinity", "nanomaterial_source"],
    "TP": ["size", "surface_charge", "dose", "exposure_duration", "n_controls", "n_replicates",
           "data_analysis", "organism"],
    "RR": ["chemical_composition", "purity", "size", "surface_area", "dose", "exposure_duration", "organism"],
    "NC": ["chemical_composition", "size", "shape", "crystallinity", "nanomaterial_source"]
}

APPS = ["GR", "NI", "TP", "RR", "NC"]

# =============================================================================
# MI LIST COVERAGE OF GENERIC INDICATORS (for heatmap fig2)
# Maps each MI list to which generic indicators it covers
# =============================================================================
def build_mi_list_generic_coverage():
    """
    For each of the 12 MI lists, define which of the 30 generic indicators
    are covered (presence/absence). This is used for the heatmap figure.
    """
    # Coverage matrix: mi_list_id (1-12) -> set of generic indicator names
    coverage = {
        1: {"chemical_composition", "surface_chemistry", "purity", "nanomaterial_source",
            "size", "shape", "surface_area", "zeta_potential", "crystallinity",
            "solubility", "stability", "agglomeration_state", "surface_charge", "labeling"},
        2: {"nanomaterial_source", "surface_chemistry",
            "size", "zeta_potential", "stability", "surface_charge",
            "dispersibility", "density", "agglomeration_state", "shape",
            "crystallinity", "solubility", "surface_area", "chemical_composition",
            "purity", "labeling"},
        3: {"chemical_composition", "surface_chemistry", "labeling",
            "size", "shape", "surface_area", "surface_charge", "zeta_potential",
            "crystallinity", "stability", "agglomeration_state",
            "dose", "exposure_duration", "n_controls", "n_replicates",
            "data_analysis", "organism", "invitro_passage"},
        4: {"chemical_composition", "purity",
            "size", "shape", "surface_area", "surface_charge",
            "crystallinity", "stability", "surface_chemistry", "nanomaterial_source"},
        5: {"dose", "exposure_duration", "n_controls", "n_replicates",
            "data_analysis", "organism", "administration_route",
            "invivo_n_subjects", "invivo_age", "invivo_sex",
            "invivo_weight", "invivo_strain", "invitro_passage", "invitro_mycoplasma"},
        6: {"chemical_composition", "surface_chemistry", "labeling",
            "size", "shape", "surface_area", "surface_charge", "zeta_potential",
            "crystallinity", "stability", "agglomeration_state",
            "dose", "exposure_duration", "n_controls", "n_replicates", "data_analysis"},
        7: {"chemical_composition", "surface_chemistry", "purity", "labeling", "nanomaterial_source",
            "size", "shape", "surface_area", "surface_charge",
            "zeta_potential", "crystallinity", "solubility", "stability",
            "agglomeration_state"},
        8: {"chemical_composition", "surface_chemistry",
            "size", "shape", "surface_area", "surface_charge",
            "zeta_potential", "crystallinity", "stability", "purity",
            "nanomaterial_source", "labeling"},
        9: {"chemical_composition", "surface_chemistry", "purity", "labeling", "nanomaterial_source",
            "size", "shape", "surface_area", "surface_charge", "zeta_potential",
            "crystallinity", "stability", "agglomeration_state",
            "dose", "exposure_duration", "n_controls", "n_replicates", "data_analysis",
            "organism", "administration_route", "invivo_n_subjects", "invivo_sex",
            "invitro_passage", "invitro_mycoplasma"},
        10: {"chemical_composition", "surface_chemistry", "purity", "nanomaterial_source",
             "size", "shape", "surface_area", "surface_charge", "zeta_potential",
             "crystallinity", "stability", "agglomeration_state",
             "dose", "exposure_duration", "n_controls", "n_replicates", "data_analysis",
             "organism", "administration_route", "invivo_n_subjects",
             "invitro_passage", "invitro_mycoplasma"},
        11: {"chemical_composition", "nanomaterial_source",
             "size", "shape", "surface_area", "surface_charge",
             "zeta_potential", "crystallinity", "stability"},
        12: {"chemical_composition", "surface_chemistry",
             "size", "shape", "surface_area", "surface_charge", "zeta_potential",
             "crystallinity", "stability", "agglomeration_state", "solubility",
             "dose", "exposure_duration", "n_controls", "n_replicates",
             "organism", "administration_route", "invivo_sex",
             "invitro_passage", "invitro_mycoplasma"}
    }
    return coverage


# =============================================================================
# SIMULATION CORE
# =============================================================================
def simulate_scenario(scenario_label: str, base_rate: float, n_datasets: int,
                      mi_lists: list, scenario_index: int) -> list:
    """
    Simulate n_datasets synthetic nanosafety datasets for a given scenario.
    Returns a list of row dicts matching dataset_schema.
    """
    np.random.seed(scenario_index)
    rows = []

    is_physchem_specialist = (scenario_label == "physchem_specialist_datasets")

    for dataset_idx in range(n_datasets):
        # --- Generate per-dataset reporting rates ---
        if is_physchem_specialist:
            physchem_rate = np.clip(0.75 + np.random.normal(0, 0.05), 0.0, 1.0)
            invitro_rate = np.clip(0.15 + np.random.normal(0, 0.05), 0.0, 1.0)
            invivo_rate = np.clip(0.10 + np.random.normal(0, 0.05), 0.0, 1.0)
            basic_rate = np.clip(0.60 + np.random.normal(0, 0.05), 0.0, 1.0)
            dataset_type = "physchem_specialist"
        else:
            physchem_rate = np.clip(base_rate + np.random.normal(0, 0.08), 0.0, 1.0)
            invitro_rate = np.clip(base_rate + np.random.normal(0, 0.08), 0.0, 1.0)
            invivo_rate = np.clip(base_rate * 0.8 + np.random.normal(0, 0.08), 0.0, 1.0)
            basic_rate = np.clip(base_rate + np.random.normal(0, 0.05), 0.0, 1.0)
            dataset_type = "standard"

        # --- Generate binary vector of 30 generic indicators ---
        generic_reported = {}
        for indicator in ALL_GENERIC:
            cat = INDICATOR_CATEGORY[indicator]
            if cat == "PhysChem":
                rate = physchem_rate
            elif cat == "Toxicity":
                # Distinguish invitro vs invivo by name
                if indicator.startswith("invitro"):
                    rate = invitro_rate
                elif indicator.startswith("invivo") or indicator in ["organism", "administration_route"]:
                    rate = invivo_rate
                else:
                    # dose, exposure_duration, n_controls, n_replicates, data_analysis
                    rate = (invitro_rate + invivo_rate) / 2.0
                rate = np.clip(rate, 0.0, 1.0)
            else:  # Basic
                rate = basic_rate
            generic_reported[indicator] = int(np.random.random() < rate)

        generic_coverage = int(np.clip(sum(generic_reported.values()), 0, 30))
        total_reported = int(np.clip(generic_coverage, 0, 281))

        # --- Check application satisfaction ---
        app_satisfied = {}
        for app in APPS:
            required = APP_REQUIRED[app]
            satisfied = all(generic_reported.get(req, 0) == 1 for req in required)
            app_satisfied[app] = int(satisfied)
        application_coverage = int(np.clip(sum(app_satisfied.values()), 0, 5))

        # --- Evaluate against each MI list ---
        for ml in mi_lists:
            pc_n = ml["physchem"]
            vi_n = ml["invitro"]
            vv_n = ml["invivo"]
            ba_n = ml["basic"]
            list_size = ml["size"]

            # Passes per subcategory using binomial draws
            pc_pass = int(np.random.binomial(pc_n, physchem_rate)) if pc_n > 0 else 0
            vi_pass = int(np.random.binomial(vi_n, invitro_rate)) if vi_n > 0 else 0
            vv_pass = int(np.random.binomial(vv_n, invivo_rate)) if vv_n > 0 else 0
            ba_pass = int(np.random.binomial(ba_n, basic_rate)) if ba_n > 0 else 0

            total_pass = pc_pass + vi_pass + vv_pass + ba_pass
            total_pass = int(np.clip(total_pass, 0, list_size))
            total_fail = list_size - total_pass

            reusability_score = float(np.clip(total_pass / list_size, 0.0, 1.0))
            physchem_score = float(np.clip(pc_pass / pc_n, 0.0, 1.0)) if pc_n > 0 else 0.0
            invitro_score = float(np.clip(vi_pass / vi_n, 0.0, 1.0)) if vi_n > 0 else 0.0
            invivo_score = float(np.clip(vv_pass / vv_n, 0.0, 1.0)) if vv_n > 0 else 0.0
            basic_score = float(np.clip(ba_pass / ba_n, 0.0, 1.0)) if ba_n > 0 else 0.0

            # Determine list category label
            if pc_n > 0 and vi_n > 0 and vv_n > 0:
                mi_list_category = "all_three"
            elif pc_n > 0 and vi_n > 0 and vv_n == 0:
                mi_list_category = "physchem_invitro"
            elif pc_n > 0 and vi_n == 0 and vv_n > 0:
                mi_list_category = "physchem_invivo"
            elif pc_n == 0 and (vi_n > 0 or vv_n > 0):
                mi_list_category = "invitro_invivo"
            else:
                mi_list_category = "physchem_only"

            row = {
                "dataset_id": f"{scenario_label}_ds{dataset_idx:04d}",
                "scenario": scenario_label,
                "mi_list_id": ml["id"],
                "mi_list_name": ml["name"],
                "mi_list_size": list_size,
                "mi_list_category": mi_list_category,
                "n_physchem_mis_in_list": pc_n,
                "n_invitro_mis_in_list": vi_n,
                "n_invivo_mis_in_list": vv_n,
                "n_basic_mis_in_list": ba_n,
                "mi_pass_count": total_pass,
                "mi_fail_count": total_fail,
                "reusability_score": round(reusability_score, 6),
                "physchem_score": round(physchem_score, 6),
                "invitro_score": round(invitro_score, 6),
                "invivo_score": round(invivo_score, 6),
                "basic_score": round(basic_score, 6),
                "generic_indicator_coverage": generic_coverage,
                "total_reported_variables": total_reported,
                "app_GR_satisfied": app_satisfied["GR"],
                "app_NI_satisfied": app_satisfied["NI"],
                "app_TP_satisfied": app_satisfied["TP"],
                "app_RR_satisfied": app_satisfied["RR"],
                "app_NC_satisfied": app_satisfied["NC"],
                "application_coverage": application_coverage,
                "reporting_rate_used": round(base_rate, 4),
                "dataset_type": dataset_type,
            }
            rows.append(row)

    return rows


# =============================================================================
# FIGURE GENERATION
# =============================================================================

def fig1_mi_counts(mi_lists: list, output_dir: Path):
    """Bar chart of MI counts per list, color-coded by category."""
    try:
        names = [ml["name"] for ml in mi_lists]
        sizes = np.array([ml["size"] for ml in mi_lists], dtype=float)
        categories = [ml["category"] for ml in mi_lists]

        assert len(names) == len(sizes), "Mismatch in names/sizes"

        cat_colors = {
            "physchem_only": "#4878CF",
            "physchem_invitro": "#6ACC65",
            "physchem_invivo": "#D65F5F",
            "all_three": "#B47CC7",
            "invitro_invivo": "#C4AD66",
        }
        colors = [cat_colors.get(c, "#888888") for c in categories]

        fig, ax = plt.subplots(figsize=(12, 6))
        x_pos = np.arange(len(names))
        bars = ax.bar(x_pos, sizes, color=colors, edgecolor="white", linewidth=0.8)
        mean_size = float(np.mean(sizes))
        ax.axhline(mean_size, color="red", linestyle="--", linewidth=1.5,
                   label=f"Mean = {mean_size:.1f} MIs")
        ax.set_xticks(x_pos)
        ax.set_xticklabels(names, rotation=45, ha="right", fontsize=9)
        ax.set_xlabel("Minimum Reporting Standard", fontsize=11)
        ax.set_ylabel("Number of Maturity Indicators", fontsize=11)
        ax.set_title("Maturity Indicator Counts per Minimum Reporting Standard", fontsize=13)
        ax.set_ylim(0, max(sizes) * 1.15)

        legend_patches = [Patch(color=v, label=k.replace("_", " ").title())
                          for k, v in cat_colors.items()]
        legend_patches.append(plt.Line2D([0], [0], color="red", linestyle="--",
                                          label=f"Mean = {mean_size:.1f}"))
        ax.legend(handles=legend_patches, fontsize=8, loc="upper right")

        # Annotate bars with values
        for bar, val in zip(bars, sizes):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                    str(int(val)), ha="center", va="bottom", fontsize=8)

        plt.tight_layout()
        plt.savefig(output_dir / "fig1_mi_counts.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig1_mi_counts.png")
    except Exception as e:
        print(f"  WARNING: fig1 failed: {e}")


def fig2_coverage_heatmap(mi_lists: list, output_dir: Path):
    """Heatmap of generic indicator coverage across 12 MI lists."""
    try:
        coverage = build_mi_list_generic_coverage()
        n_generic = len(ALL_GENERIC)
        n_lists = len(mi_lists)

        matrix = np.zeros((n_generic, n_lists), dtype=float)
        for j, ml in enumerate(mi_lists):
            covered = coverage.get(ml["id"], set())
            for i, ind in enumerate(ALL_GENERIC):
                matrix[i, j] = 1.0 if ind in covered else 0.0

        assert matrix.shape == (n_generic, n_lists)

        fig, ax = plt.subplots(figsize=(13, 10))
        im = ax.imshow(matrix, aspect="auto", cmap="Blues", vmin=0, vmax=1)

        ax.set_xticks(np.arange(n_lists))
        ax.set_xticklabels([ml["name"] for ml in mi_lists], rotation=45, ha="right", fontsize=8)
        ax.set_yticks(np.arange(n_generic))
        ax.set_yticklabels(ALL_GENERIC, fontsize=7)
        ax.set_xlabel("MI List", fontsize=11)
        ax.set_ylabel("Generic Indicator", fontsize=11)
        ax.set_title("Coverage Heatmap of Generic Indicators Across 12 MI Lists", fontsize=13)

        # Draw category separators
        n_basic = len(GENERIC_INDICATORS["Basic"])
        n_physchem = len(GENERIC_INDICATORS["PhysChem"])
        ax.axhline(n_basic - 0.5, color="orange", linewidth=2, linestyle="--")
        ax.axhline(n_basic + n_physchem - 0.5, color="red", linewidth=2, linestyle="--")

        # Category labels on the right
        mid_basic = n_basic / 2 - 0.5
        mid_physchem = n_basic + n_physchem / 2 - 0.5
        mid_toxicity = n_basic + n_physchem + len(GENERIC_INDICATORS["Toxicity"]) / 2 - 0.5
        ax.text(n_lists + 0.1, mid_basic, "Basic", fontsize=8, color="navy",
                va="center", ha="left")
        ax.text(n_lists + 0.1, mid_physchem, "PhysChem", fontsize=8, color="navy",
                va="center", ha="left")
        ax.text(n_lists + 0.1, mid_toxicity, "Toxicity", fontsize=8, color="navy",
                va="center", ha="left")

        plt.colorbar(im, ax=ax, fraction=0.02, pad=0.04, label="Covered (1) / Not covered (0)")
        plt.tight_layout()
        plt.savefig(output_dir / "fig2_coverage_heatmap.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig2_coverage_heatmap.png")
    except Exception as e:
        print(f"  WARNING: fig2 failed: {e}")


def fig3_reusability_histograms(all_rows: list, output_dir: Path):
    """Overlapping histograms of reusability scores for low/average/high scenarios."""
    try:
        scenario_labels = ["low_quality_datasets", "average_quality_datasets", "high_quality_datasets"]
        colors = ["#E74C3C", "#F39C12", "#27AE60"]
        labels_display = ["Low Quality (rate=0.20)", "Average Quality (rate=0.45)", "High Quality (rate=0.80)"]

        fig, ax = plt.subplots(figsize=(10, 6))
        has_data = False
        for sc, col, lbl in zip(scenario_labels, colors, labels_display):
            scores = np.array([r["reusability_score"] for r in all_rows
                               if r["scenario"] == sc], dtype=float)
            if len(scores) > 0:
                ax.hist(scores, bins=30, range=(0, 1), alpha=0.6, color=col,
                        label=lbl, edgecolor="white", linewidth=0.5)
                has_data = True

        if not has_data:
            print("  WARNING: fig3 no data found")
            plt.close(fig)
            return

        ax.set_xlabel("Reusability Score (fraction of MIs passed)", fontsize=11)
        ax.set_ylabel("Number of Dataset-Assessment Pairs", fontsize=11)
        ax.set_title("Distribution of Dataset Reusability Scores by Scenario", fontsize=13)
        ax.set_xlim(0, 1)
        ax.legend(fontsize=9)
        plt.tight_layout()
        plt.savefig(output_dir / "fig3_reusability_histograms.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig3_reusability_histograms.png")
    except Exception as e:
        print(f"  WARNING: fig3 failed: {e}")


def fig4_per_dataset_heatmap(all_rows: list, mi_lists: list, output_dir: Path):
    """Heatmap of reusability scores for 50 datasets vs 12 MI lists (multi_list scenario)."""
    try:
        sc = "multi_list_assessment"
        sc_rows = [r for r in all_rows if r["scenario"] == sc]
        if not sc_rows:
            print("  WARNING: fig4 no multi_list_assessment data")
            return

        # Get unique dataset_ids (up to 50)
        ds_ids = []
        seen = set()
        for r in sc_rows:
            if r["dataset_id"] not in seen:
                ds_ids.append(r["dataset_id"])
                seen.add(r["dataset_id"])
        ds_ids = ds_ids[:50]
        n_ds = len(ds_ids)
        n_lists = len(mi_lists)

        matrix = np.zeros((n_ds, n_lists), dtype=float)
        for r in sc_rows:
            if r["dataset_id"] in ds_ids:
                i = ds_ids.index(r["dataset_id"])
                j = r["mi_list_id"] - 1
                if 0 <= i < n_ds and 0 <= j < n_lists:
                    matrix[i, j] = r["reusability_score"]

        assert matrix.shape == (n_ds, n_lists)

        fig, ax = plt.subplots(figsize=(13, 10))
        im = ax.imshow(matrix, aspect="auto", cmap="RdYlGn", vmin=0, vmax=1)

        ax.set_xticks(np.arange(n_lists))
        ax.set_xticklabels([ml["name"] for ml in mi_lists], rotation=45, ha="right", fontsize=8)
        ax.set_yticks(np.arange(n_ds))
        ax.set_yticklabels([f"DS_{i+1}" for i in range(n_ds)], fontsize=6)
        ax.set_xlabel("MI List", fontsize=11)
        ax.set_ylabel("Dataset Index", fontsize=11)
        ax.set_title("Per-Dataset Reusability Score Across All 12 MI Lists", fontsize=13)
        plt.colorbar(im, ax=ax, fraction=0.02, pad=0.04, label="Reusability Score (0-1)")
        plt.tight_layout()
        plt.savefig(output_dir / "fig4_per_dataset_heatmap.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig4_per_dataset_heatmap.png")
    except Exception as e:
        print(f"  WARNING: fig4 failed: {e}")


def fig5_application_coverage_line(all_rows: list, output_dir: Path):
    """Line plot: mean application coverage vs overall reporting completeness."""
    try:
        sc = "application_coverage_analysis"
        sc_rows = [r for r in all_rows if r["scenario"] == sc]
        if not sc_rows:
            print("  WARNING: fig5 no application_coverage_analysis data")
            return

        # Use unique dataset-level data (pick first MI list occurrence per dataset)
        seen_ds = set()
        ds_data = []
        for r in sc_rows:
            if r["dataset_id"] not in seen_ds:
                seen_ds.add(r["dataset_id"])
                ds_data.append({
                    "completeness": r["total_reported_variables"] / 30.0,  # fraction of 30 generic
                    "app_coverage": r["application_coverage"]
                })

        if len(ds_data) < 5:
            print("  WARNING: fig5 insufficient dataset-level data")
            return

        completeness_arr = np.array([d["completeness"] for d in ds_data], dtype=float)
        app_cov_arr = np.array([d["app_coverage"] for d in ds_data], dtype=float)

        # Bin into 20 bins
        n_bins = 20
        bins = np.linspace(0, 1, n_bins + 1)
        bin_means = np.zeros(n_bins, dtype=float)
        bin_stds = np.zeros(n_bins, dtype=float)
        bin_centers = np.zeros(n_bins, dtype=float)
        valid_mask = np.zeros(n_bins, dtype=bool)

        for k in range(n_bins):
            lo, hi = bins[k], bins[k + 1]
            mask = (completeness_arr >= lo) & (completeness_arr < hi)
            if np.sum(mask) >= 2:
                bin_means[k] = np.mean(app_cov_arr[mask])
                bin_stds[k] = np.std(app_cov_arr[mask])
                valid_mask[k] = True
            elif np.sum(mask) == 1:
                bin_means[k] = np.mean(app_cov_arr[mask])
                bin_stds[k] = 0.0
                valid_mask[k] = True
            bin_centers[k] = (lo + hi) / 2.0

        x_plot = bin_centers[valid_mask]
        y_plot = bin_means[valid_mask]
        y_std = bin_stds[valid_mask]

        if len(x_plot) < 2:
            print("  WARNING: fig5 insufficient binned data")
            return

        assert len(x_plot) == len(y_plot) == len(y_std)

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(x_plot, y_plot, "b-o", linewidth=2, markersize=5, label="Mean app coverage")
        ax.fill_between(x_plot,
                         np.clip(y_plot - 1.96 * y_std, 0, 5),
                         np.clip(y_plot + 1.96 * y_std, 0, 5),
                         alpha=0.2, color="blue", label="95% CI")

        # Application threshold lines (visual reference)
        app_thresholds = {"GR": 1.0, "NI": 2.0, "TP": 3.0, "RR": 4.0, "NC": 5.0}
        colors_app = ["#E74C3C", "#E67E22", "#F1C40F", "#27AE60", "#2980B9"]
        for (app, thr), col in zip(app_thresholds.items(), colors_app):
            ax.axhline(thr, color=col, linestyle="--", linewidth=1.0, alpha=0.7, label=f"{app} threshold")

        ax.set_xlabel("Generic Indicator Coverage (fraction of 30 MIs)", fontsize=11)
        ax.set_ylabel("Mean Applications Satisfied (0-5)", fontsize=11)
        ax.set_title("Application Coverage vs. Dataset Reporting Completeness", fontsize=13)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 5.5)
        ax.legend(fontsize=8, loc="upper left")
        plt.tight_layout()
        plt.savefig(output_dir / "fig5_application_coverage_line.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig5_application_coverage_line.png")
    except Exception as e:
        print(f"  WARNING: fig5 failed: {e}")


def fig6_physchem_vs_toxicity(all_rows: list, output_dir: Path):
    """Scatter: physchem_score vs combined toxicity score, colored by scenario."""
    try:
        scenario_colors = {
            "low_quality_datasets": "#E74C3C",
            "average_quality_datasets": "#F39C12",
            "high_quality_datasets": "#27AE60",
            "physchem_specialist_datasets": "#2980B9",
            "multi_list_assessment": "#9B59B6",
            "application_coverage_analysis": "#1ABC9C",
        }

        # Use lists that have both physchem and toxicity components
        mixed_list_ids = {ml["id"] for ml in
                          [{"id": 3}, {"id": 5}, {"id": 6}, {"id": 9}, {"id": 10}, {"id": 12}]}

        fig, ax = plt.subplots(figsize=(10, 8))
        has_data = False

        # One point per dataset per scenario (average over MI lists)
        ds_scenario_map = {}
        for r in all_rows:
            key = (r["dataset_id"], r["scenario"])
            if key not in ds_scenario_map:
                ds_scenario_map[key] = {"physchem_scores": [], "invitro_scores": [],
                                        "invivo_scores": [], "scenario": r["scenario"]}
            ds_scenario_map[key]["physchem_scores"].append(r["physchem_score"])
            # Only include invitro/invivo from lists that have them
            if r["n_invitro_mis_in_list"] > 0:
                ds_scenario_map[key]["invitro_scores"].append(r["invitro_score"])
            if r["n_invivo_mis_in_list"] > 0:
                ds_scenario_map[key]["invivo_scores"].append(r["invivo_score"])

        plotted_scenarios = set()
        for (ds_id, sc), data in ds_scenario_map.items():
            if not data["physchem_scores"]:
                continue
            pc = float(np.mean(data["physchem_scores"]))
            tox_scores = data["invitro_scores"] + data["invivo_scores"]
            if not tox_scores:
                continue
            tox = float(np.mean(tox_scores))
            col = scenario_colors.get(sc, "#888888")
            label = sc if sc not in plotted_scenarios else None
            ax.scatter(pc, tox, color=col, alpha=0.5, s=20, label=label)
            plotted_scenarios.add(sc)
            has_data = True

        if not has_data:
            print("  WARNING: fig6 no data")
            plt.close(fig)
            return

        # Diagonal reference line
        ax.plot([0, 1], [0, 1], "k--", linewidth=1, alpha=0.5, label="Equal competence")
        ax.set_xlabel("PhysChem Reusability Score", fontsize=11)
        ax.set_ylabel("Toxicity (In Vitro + In Vivo) Reusability Score", fontsize=11)
        ax.set_title("Physicochemical vs. Toxicity Reporting Completeness per Dataset", fontsize=13)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.legend(fontsize=8, markerscale=2)
        plt.tight_layout()
        plt.savefig(output_dir / "fig6_physchem_vs_toxicity.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig6_physchem_vs_toxicity.png")
    except Exception as e:
        print(f"  WARNING: fig6 failed: {e}")


def fig7_score_vs_list_size(all_rows: list, mi_lists: list, output_dir: Path):
    """Line chart: mean reusability score vs MI list size, one line per scenario."""
    try:
        target_scenarios = [
            "low_quality_datasets",
            "average_quality_datasets",
            "high_quality_datasets",
            "physchem_specialist_datasets",
        ]
        colors = ["#E74C3C", "#F39C12", "#27AE60", "#2980B9"]
        labels_display = ["Low Quality", "Average Quality", "High Quality", "PhysChem Specialist"]

        # Sort MI lists by size
        sorted_ml = sorted(mi_lists, key=lambda x: x["size"])
        sorted_sizes = np.array([ml["size"] for ml in sorted_ml], dtype=float)
        sorted_ids = [ml["id"] for ml in sorted_ml]

        assert len(sorted_sizes) == len(sorted_ids)

        fig, ax = plt.subplots(figsize=(12, 6))
        has_any = False

        for sc, col, lbl in zip(target_scenarios, colors, labels_display):
            sc_rows = [r for r in all_rows if r["scenario"] == sc]
            if not sc_rows:
                continue

            means = np.zeros(len(sorted_ml), dtype=float)
            stds = np.zeros(len(sorted_ml), dtype=float)
            valid = np.zeros(len(sorted_ml), dtype=bool)

            for k, ml_id in enumerate(sorted_ids):
                list_scores = np.array([r["reusability_score"] for r in sc_rows
                                        if r["mi_list_id"] == ml_id], dtype=float)
                if len(list_scores) > 0:
                    means[k] = np.mean(list_scores)
                    stds[k] = np.std(list_scores) if len(list_scores) > 1 else 0.0
                    valid[k] = True

            x_vals = sorted_sizes[valid]
            y_vals = means[valid]
            e_vals = stds[valid]

            if len(x_vals) == 0:
                continue
            assert len(x_vals) == len(y_vals) == len(e_vals)

            ax.plot(x_vals, y_vals, "o-", color=col, linewidth=2, markersize=5, label=lbl)
            ax.fill_between(x_vals,
                            np.clip(y_vals - e_vals, 0, 1),
                            np.clip(y_vals + e_vals, 0, 1),
                            alpha=0.15, color=col)
            has_any = True

        if not has_any:
            print("  WARNING: fig7 no data")
            plt.close(fig)
            return

        ax.set_xlabel("MI List Size (number of indicators)", fontsize=11)
        ax.set_ylabel("Mean Reusability Score", fontsize=11)
        ax.set_title("Reusability Score vs. MI List Size Across Scenarios", fontsize=13)
        ax.set_ylim(0, 1)
        ax.legend(fontsize=9)
        plt.tight_layout()
        plt.savefig(output_dir / "fig7_score_vs_list_size.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig7_score_vs_list_size.png")
    except Exception as e:
        print(f"  WARNING: fig7 failed: {e}")


def fig8_generic_coverage_histogram(all_rows: list, output_dir: Path):
    """Histogram of generic indicator coverage per scenario."""
    try:
        scenario_labels = ["low_quality_datasets", "average_quality_datasets", "high_quality_datasets"]
        colors = ["#E74C3C", "#F39C12", "#27AE60"]
        labels_display = ["Low Quality", "Average Quality", "High Quality"]

        # Use unique datasets (first MI list row per dataset)
        seen_ds = set()
        ds_coverage = {sc: [] for sc in scenario_labels}
        for r in all_rows:
            ds_id = r["dataset_id"]
            sc = r["scenario"]
            if sc not in scenario_labels:
                continue
            if (ds_id, sc) not in seen_ds:
                seen_ds.add((ds_id, sc))
                ds_coverage[sc].append(r["generic_indicator_coverage"])

        fig, ax = plt.subplots(figsize=(10, 6))
        has_data = False
        for sc, col, lbl in zip(scenario_labels, colors, labels_display):
            data = np.array(ds_coverage[sc], dtype=float)
            if len(data) > 0:
                ax.hist(data, bins=np.arange(-0.5, 31.5, 1), alpha=0.6, color=col,
                        label=lbl, edgecolor="white", linewidth=0.5)
                has_data = True

        if not has_data:
            print("  WARNING: fig8 no data")
            plt.close(fig)
            return

        ax.axvline(15, color="black", linestyle="--", linewidth=1.5, label="Median reference (15)")
        ax.set_xlabel("Generic Indicator Coverage Count (0-30)", fontsize=11)
        ax.set_ylabel("Number of Datasets", fontsize=11)
        ax.set_title("Distribution of Generic Indicator Coverage Across Simulated Datasets", fontsize=13)
        ax.set_xlim(0, 30)
        ax.legend(fontsize=9)
        plt.tight_layout()
        plt.savefig(output_dir / "fig8_generic_coverage_histogram.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("  Saved fig8_generic_coverage_histogram.png")
    except Exception as e:
        print(f"  WARNING: fig8 failed: {e}")


# =============================================================================
# CSV WRITERS
# =============================================================================

SCHEMA_COLUMNS = [
    "dataset_id", "scenario", "mi_list_id", "mi_list_name", "mi_list_size",
    "mi_list_category", "n_physchem_mis_in_list", "n_invitro_mis_in_list",
    "n_invivo_mis_in_list", "n_basic_mis_in_list", "mi_pass_count", "mi_fail_count",
    "reusability_score", "physchem_score", "invitro_score", "invivo_score", "basic_score",
    "generic_indicator_coverage", "total_reported_variables",
    "app_GR_satisfied", "app_NI_satisfied", "app_TP_satisfied", "app_RR_satisfied",
    "app_NC_satisfied", "application_coverage", "reporting_rate_used", "dataset_type"
]


def write_simulation_outputs(all_rows: list, output_dir: Path):
    """Write simulation_outputs.csv."""
    try:
        if not all_rows:
            print("  WARNING: simulation_outputs.csv — no data to write")
            return
        filepath = output_dir / "simulation_outputs.csv"
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=SCHEMA_COLUMNS)
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"  Saved simulation_outputs.csv ({len(all_rows)} rows)")
    except Exception as e:
        print(f"  WARNING: simulation_outputs.csv write failed: {e}")


def write_scenario_summary(all_rows: list, output_dir: Path):
    """Write scenario_summary.csv — one row per scenario."""
    try:
        if not all_rows:
            print("  WARNING: scenario_summary.csv — no data")
            return

        scenarios = sorted(set(r["scenario"] for r in all_rows))
        numeric_cols = [
            "reusability_score", "physchem_score", "invitro_score", "invivo_score",
            "basic_score", "generic_indicator_coverage", "total_reported_variables",
            "application_coverage", "mi_pass_count", "mi_fail_count"
        ]

        summary_rows = []
        for sc in scenarios:
            sc_rows = [r for r in all_rows if r["scenario"] == sc]
            row = {"scenario": sc, "n_rows": len(sc_rows)}
            for col in numeric_cols:
                vals = np.array([r[col] for r in sc_rows], dtype=float)
                row[f"{col}_mean"] = round(float(np.mean(vals)), 6)
                row[f"{col}_std"] = round(float(np.std(vals)), 6)
                row[f"{col}_min"] = round(float(np.min(vals)), 6)
                row[f"{col}_max"] = round(float(np.max(vals)), 6)
            # App satisfaction rates
            for app in APPS:
                key = f"app_{app}_satisfied"
                vals = np.array([r[key] for r in sc_rows], dtype=float)
                row[f"{key}_rate"] = round(float(np.mean(vals)), 6)
            summary_rows.append(row)

        if not summary_rows:
            print("  WARNING: scenario_summary.csv — empty summary")
            return

        fieldnames = list(summary_rows[0].keys())
        filepath = output_dir / "scenario_summary.csv"
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(summary_rows)
        print(f"  Saved scenario_summary.csv ({len(summary_rows)} rows)")
    except Exception as e:
        print(f"  WARNING: scenario_summary.csv write failed: {e}")


def write_parameters_used(output_dir: Path):
    """Write parameters_used.csv — one row per parameter."""
    try:
        params = MODEL_PROFILE["parameters"]
        rows = []
        for name, info in params.items():
            rows.append({
                "name": name,
                "value": info["value"],
                "unit": info["unit"],
                "source": info["source"],
                "description": info["description"]
            })
        if not rows:
            print("  WARNING: parameters_used.csv — no parameters")
            return
        filepath = output_dir / "parameters_used.csv"
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
            writer.writeheader()
            writer.writerows(rows)
        print(f"  Saved parameters_used.csv ({len(rows)} rows)")
    except Exception as e:
        print(f"  WARNING: parameters_used.csv write failed: {e}")


def write_summary_json(all_rows: list, output_dir: Path):
    """Write summary.json with key aggregate metrics."""
    try:
        summary = {
            "title": MODEL_PROFILE["title"],
            "total_simulation_rows": len(all_rows),
            "n_scenarios": len(set(r["scenario"] for r in all_rows)) if all_rows else 0,
            "n_mi_lists": 12,
            "total_mis": 281,
            "n_generic_indicators": 30,
            "n_applications": 5,
        }
        if all_rows:
            scores = np.array([r["reusability_score"] for r in all_rows], dtype=float)
            summary["overall_reusability_mean"] = round(float(np.mean(scores)), 6)
            summary["overall_reusability_std"] = round(float(np.std(scores)), 6)
            app_cov = np.array([r["application_coverage"] for r in all_rows], dtype=float)
            summary["mean_application_coverage"] = round(float(np.mean(app_cov)), 6)

            by_scenario = {}
            for sc in set(r["scenario"] for r in all_rows):
                sc_scores = np.array([r["reusability_score"] for r in all_rows
                                      if r["scenario"] == sc], dtype=float)
                by_scenario[sc] = {
                    "mean_reusability": round(float(np.mean(sc_scores)), 6),
                    "std_reusability": round(float(np.std(sc_scores)), 6),
                }
            summary["by_scenario"] = by_scenario

        filepath = output_dir / "summary.json"
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(f"  Saved summary.json")
    except Exception as e:
        print(f"  WARNING: summary.json write failed: {e}")


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="NSDRA Simulator: FAIR Assessment of NanoSafety Data Reusability"
    )
    parser.add_argument("--output", default="./sim_outputs", help="Output directory")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    # Build MI lists and validate
    mi_lists = build_mi_lists()
    print(f"Built {len(mi_lists)} MI lists (all component sums validated)")

    # Run all scenarios
    scenarios = MODEL_PROFILE["scenarios"]
    all_rows = []

    for scenario_index, sc_cfg in enumerate(scenarios):
        label = sc_cfg["label"]
        base_rate = sc_cfg["baseline_reporting_rate"]
        n_datasets = sc_cfg["n_simulated_datasets"]
        print(f"\nRunning scenario [{scenario_index}]: {label} "
              f"(rate={base_rate}, n={n_datasets})")

        rows = simulate_scenario(label, base_rate, n_datasets, mi_lists, scenario_index)
        all_rows.extend(rows)
        print(f"  Generated {len(rows)} rows")

    print(f"\nTotal rows across all scenarios: {len(all_rows)}")

    # Generate figures
    print("\nGenerating figures...")
    fig1_mi_counts(mi_lists, output_dir)
    fig2_coverage_heatmap(mi_lists, output_dir)
    fig3_reusability_histograms(all_rows, output_dir)
    fig4_per_dataset_heatmap(all_rows, mi_lists, output_dir)
    fig5_application_coverage_line(all_rows, output_dir)
    fig6_physchem_vs_toxicity(all_rows, output_dir)
    fig7_score_vs_list_size(all_rows, mi_lists, output_dir)
    fig8_generic_coverage_histogram(all_rows, output_dir)

    # Write CSV files
    print("\nWriting CSV files...")
    write_simulation_outputs(all_rows, output_dir)
    write_scenario_summary(all_rows, output_dir)
    write_parameters_used(output_dir)

    # Write summary JSON
    print("\nWriting summary JSON...")
    write_summary_json(all_rows, output_dir)

    print("\nSimulation complete.")


if __name__ == "__main__":
    main()