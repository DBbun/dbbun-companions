================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 5375ff9b-3b0c-4897-b5fb-a9a706abe9bd
    Generated   : 2026-04-26  17:10:48 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Apple Inc. Form 10-K for the Fiscal Year Ended September 27, 2025

    CATEGORIES
    ----------
    Financial

    KEYWORDS
    --------
    Apple Inc financial modeling, revenue segmentation, gross margin analysis, tariff impact simulation, services growth trajectory

    ABSTRACT
    --------
    This simulator faithfully reproduces Apple Inc.'s financial dynamics as disclosed in the FY2025 Form 10-K, modeling revenue evolution across five product lines (iPhone, Mac, iPad, Wearables, Services) and five geographic segments (Americas, Europe, Greater China, Japan, Rest of Asia Pacific) at quarterly resolution from FY2021 through FY2028. The simulator captures seasonal demand patterns (Q1 holiday premium), services-vs-hardware gross margin differentials (~74% vs ~37%), tariff cost shocks on China-sourced manufacturing, share buyback effects on EPS, and R&D/SG&A operating leverage. Five scenarios spanning baseline, high-tariff stress, services acceleration, China revenue decline, and margin expansion allow systematic quantification of key strategic and geopolitical risk factors. Researchers, financial analysts, and business strategy students can use the generated dataset and figures to explore how Apple's structural shift toward services, its geographic revenue concentration, and international trade policy interact to determine long-run profitability.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    _10-K-2025-As-Filed.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    iphone_revenue, mac_revenue, ipad_revenue, wearables_revenue, services_revenue, total_net_sales, cost_of_sales, gross_profit, gross_margin_pct, rd_expense, sga_expense, operating_income, net_income, americas_revenue, europe_revenue, greater_china_revenue, japan_revenue, rest_asia_pacific_revenue, tariff_cost_impact, services_gross_margin_pct, products_gross_margin_pct, quarter_index, shares_outstanding, eps_diluted

    SCENARIOS  (5 total)
    ---------------------------------
        1. baseline_fy2025 — Baseline scenario mirroring reported FY2025 financials with no tariff shock, moderate services growth, and historical seasonality patterns across four fiscal quarters.
2. high_tariff_stress — High tariff scenario applying the announced 30% additional tariff on China-sourced goods with 40% pass-through, compressing margins and dampening Greater China revenues by 10%.
3. services_acceleration — Bull case where services revenue growth accelerates to 20% annually (App Store, Apple Intelligence-driven subscriptions, advertising expansion), while hardware remains at baseline.
4. china_revenue_decline — Adverse geopolitical scenario where Greater China revenue declines 15% year-over-year due to regulatory action, consumer boycott, or escalated trade conflict.
5. margin_expansion_case — Optimistic scenario combining services mix shift, supply chain diversification reducing tariff exposure, and operational leverage improving blended gross margin by 200 basis points.

    PARAMETERS
    ----------
    28 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1_revenue_by_product_line, fig2_geographic_revenue_mix, fig3_gross_margin_scenarios, fig4_quarterly_seasonality, fig5_tariff_impact_on_earnings, fig6_services_vs_products_revenue, fig7_eps_and_buyback_effect, fig8_rd_and_sga_opex

    DOMAIN SUMMARY
    --------------
    Apple Inc.'s 2025 annual SEC filing covering financial performance, revenue segmentation by product and geography, R&D investment, operating margins, and macroeconomic risk factors across five global segments (Americas, Europe, Greater China, Japan, Rest of Asia Pacific).

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.