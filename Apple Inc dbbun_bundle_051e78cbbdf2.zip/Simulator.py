# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-26T17:10:48.947504Z
# Run ID    : 5375ff9b-3b0c-4897-b5fb-a9a706abe9bd
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Apple Inc. Form 10-K for the Fiscal Year Ended September 27, 2025
Financial Simulator — Models revenue segmentation, gross margins, tariff impacts,
geographic segments, and EPS dynamics across five scenarios (FY2021-FY2028).

Paper reference: Apple Inc. Form 10-K for the Fiscal Year Ended September 27, 2025
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# =============================================================================
# MODEL PROFILE
# =============================================================================
MODEL_PROFILE = {
    "title": "Apple Inc. Form 10-K for the Fiscal Year Ended September 27, 2025",
    "base_year": 2025,
    "sim_start_year": 2021,
    "sim_end_year": 2028,
    "base_values": {
        "iphone_base": 201.0,
        "mac_base": 31.0,
        "ipad_base": 26.0,
        "wearables_base": 37.0,
        "services_base": 96.0,
        "shares_base": 14.776,  # billions
    },
    "seasonality": {1: 1.30, 2: 0.90, 3: 0.88, 4: 0.92},
    "parameters": {
        "iphone_growth_rate": {"value": 0.02, "unit": "fraction per year", "source": "extracted",
                                "description": "Annual organic iPhone revenue growth rate"},
        "services_growth_rate": {"value": 0.14, "unit": "fraction per year", "source": "extracted",
                                  "description": "Annual services revenue growth rate"},
        "mac_growth_rate": {"value": 0.08, "unit": "fraction per year", "source": "assumed",
                             "description": "Annual Mac revenue growth driven by Apple Silicon"},
        "ipad_growth_rate": {"value": 0.05, "unit": "fraction per year", "source": "assumed",
                              "description": "Annual iPad revenue growth"},
        "wearables_growth_rate": {"value": 0.04, "unit": "fraction per year", "source": "assumed",
                                   "description": "Annual Wearables growth rate"},
        "services_gross_margin_target": {"value": 0.74, "unit": "fraction", "source": "extracted",
                                          "description": "Services segment gross margin"},
        "products_gross_margin_target": {"value": 0.37, "unit": "fraction", "source": "extracted",
                                          "description": "Products segment blended gross margin"},
        "rd_as_pct_sales": {"value": 0.079, "unit": "fraction", "source": "extracted",
                             "description": "R&D expense as fraction of total net sales"},
        "sga_as_pct_sales": {"value": 0.069, "unit": "fraction", "source": "extracted",
                              "description": "SG&A expense as fraction of total net sales"},
        "effective_tax_rate": {"value": 0.245, "unit": "fraction", "source": "extracted",
                                "description": "Effective income tax rate"},
        "tariff_rate_china": {"value": 0.30, "unit": "fraction of China-sourced COGS", "source": "extracted",
                               "description": "Additional tariff rate on imports from China"},
        "china_cogs_fraction": {"value": 0.55, "unit": "fraction of total COGS", "source": "assumed",
                                 "description": "Fraction of COGS from China-based manufacturing"},
        "tariff_pass_through_rate": {"value": 0.40, "unit": "fraction", "source": "assumed",
                                      "description": "Fraction of tariff cost passed to consumers"},
        "q1_seasonality_boost": {"value": 0.30, "unit": "fraction above quarterly average", "source": "extracted",
                                  "description": "Q1 holiday quarter revenue premium"},
        "q2_seasonality_factor": {"value": 0.90, "unit": "fraction of quarterly average", "source": "assumed",
                                   "description": "Q2 post-holiday demand factor"},
        "q3_seasonality_factor": {"value": 0.88, "unit": "fraction of quarterly average", "source": "assumed",
                                   "description": "Q3 pre-launch seasonality factor"},
        "q4_seasonality_factor": {"value": 0.92, "unit": "fraction of quarterly average", "source": "assumed",
                                   "description": "Q4 new product launch factor"},
        "greater_china_revenue_share": {"value": 0.169, "unit": "fraction of total net sales", "source": "extracted",
                                         "description": "Greater China segment share of consolidated net sales"},
        "americas_revenue_share": {"value": 0.427, "unit": "fraction of total net sales", "source": "extracted",
                                    "description": "Americas segment share of consolidated net sales"},
        "europe_revenue_share": {"value": 0.258, "unit": "fraction of total net sales", "source": "extracted",
                                  "description": "Europe segment share of consolidated net sales"},
        "japan_revenue_share": {"value": 0.064, "unit": "fraction of total net sales", "source": "extracted",
                                 "description": "Japan segment share of consolidated net sales"},
        "rest_asia_pacific_revenue_share": {"value": 0.082, "unit": "fraction of total net sales", "source": "extracted",
                                             "description": "Rest of Asia Pacific share"},
        "direct_channel_share": {"value": 0.40, "unit": "fraction of net sales", "source": "extracted",
                                  "description": "Direct channel share"},
        "indirect_channel_share": {"value": 0.60, "unit": "fraction of net sales", "source": "extracted",
                                    "description": "Indirect channel share"},
        "employees_count": {"value": 166000.0, "unit": "FTE headcount", "source": "extracted",
                             "description": "Full-time equivalent employees as of September 27, 2025"},
        "market_cap_reference": {"value": 3253.431, "unit": "USD billions", "source": "extracted",
                                  "description": "Market cap as of March 28, 2025"},
        "shares_outstanding_millions": {"value": 14776.353, "unit": "millions of shares", "source": "extracted",
                                         "description": "Shares outstanding as of October 17, 2025"},
        "buyback_rate": {"value": 0.04, "unit": "fraction of shares per year", "source": "assumed",
                          "description": "Annual share repurchase rate"},
    },
    "scenarios": [
        {
            "label": "baseline_fy2025",
            "description": "Baseline scenario mirroring reported FY2025 financials with no tariff shock.",
            "param_overrides": {
                "tariff_rate_china": 0.0,
                "services_growth_rate": 0.14,
                "iphone_growth_rate": 0.02,
            }
        },
        {
            "label": "high_tariff_stress",
            "description": "High tariff scenario with 30% China tariff and dampened Greater China revenues.",
            "param_overrides": {
                "tariff_rate_china": 0.30,
                "tariff_pass_through_rate": 0.40,
                "greater_china_revenue_share": 0.152,
            }
        },
        {
            "label": "services_acceleration",
            "description": "Bull case with 20% services growth and higher services margins.",
            "param_overrides": {
                "services_growth_rate": 0.20,
                "services_gross_margin_target": 0.76,
                "iphone_growth_rate": 0.02,
            }
        },
        {
            "label": "china_revenue_decline",
            "description": "Adverse scenario: Greater China declines 15% YoY due to geopolitical conflict.",
            "param_overrides": {
                "greater_china_revenue_share": 0.144,
                "tariff_rate_china": 0.30,
                "tariff_pass_through_rate": 0.20,
            }
        },
        {
            "label": "margin_expansion_case",
            "description": "Optimistic scenario combining services mix shift and supply chain diversification.",
            "param_overrides": {
                "services_growth_rate": 0.18,
                "products_gross_margin_target": 0.39,
                "tariff_rate_china": 0.10,
                "iphone_growth_rate": 0.05,
            }
        },
    ],
}

# =============================================================================
# SEASONALITY
# =============================================================================
SEASONALITY = {1: 1.30, 2: 0.90, 3: 0.88, 4: 0.92}
# Sum = 4.00, so quarterly fraction = factor / 4.0

# =============================================================================
# DEFAULT PARAMETER DICT
# =============================================================================
def get_default_params() -> Dict[str, Any]:
    """Extract default parameter values from MODEL_PROFILE."""
    params = {}
    for name, meta in MODEL_PROFILE["parameters"].items():
        params[name] = meta["value"]
    return params

# =============================================================================
# CORE SIMULATION FUNCTION
# =============================================================================
def project_annual(params: Dict[str, Any], scenario_label: str,
                   start_year: int = 2021, end_year: int = 2028) -> List[Dict[str, Any]]:
    """
    Run the annual financial projection for a single scenario.
    Returns a list of dicts (one per fiscal quarter).
    """
    rows = []

    # Base values (FY2025 anchors)
    iphone_base = 201.0
    mac_base = 31.0
    ipad_base = 26.0
    wear_base = 37.0
    svc_base = 96.0
    shares_base = 14.776  # billions

    base_year = 2025

    for yr in range(start_year, end_year + 1):
        delta = yr - base_year  # negative for historical, positive for future

        # -----------------------------------------------------------------------
        # Revenue projections (compound growth from FY2025 anchor)
        # -----------------------------------------------------------------------
        iphone_rev = iphone_base * ((1.0 + params["iphone_growth_rate"]) ** delta)
        mac_rev = mac_base * ((1.0 + params["mac_growth_rate"]) ** delta)
        ipad_rev = ipad_base * ((1.0 + params["ipad_growth_rate"]) ** delta)
        wear_rev = wear_base * ((1.0 + params["wearables_growth_rate"]) ** delta)
        svc_rev = svc_base * ((1.0 + params["services_growth_rate"]) ** delta)

        # Clamp to state-variable ranges
        iphone_rev = float(np.clip(iphone_rev, 150.0, 280.0))
        mac_rev = float(np.clip(mac_rev, 20.0, 55.0))
        ipad_rev = float(np.clip(ipad_rev, 15.0, 45.0))
        wear_rev = float(np.clip(wear_rev, 20.0, 60.0))
        svc_rev = float(np.clip(svc_rev, 60.0, 160.0))

        total_products_pre_tariff = iphone_rev + mac_rev + ipad_rev + wear_rev

        # -----------------------------------------------------------------------
        # Tariff computation (pre-geographic adjustment)
        # -----------------------------------------------------------------------
        products_cogs_notariff = total_products_pre_tariff * (1.0 - params["products_gross_margin_target"])
        tariff_additional_cost = (params["china_cogs_fraction"] *
                                   products_cogs_notariff *
                                   params["tariff_rate_china"])
        # Net tariff cost after pass-through (absorbed by Apple)
        net_tariff_cost = tariff_additional_cost * (1.0 - params["tariff_pass_through_rate"])
        net_tariff_cost = float(np.clip(net_tariff_cost, 0.0, 25.0))
        # Revenue uplift from price pass-through
        price_increase_revenue = tariff_additional_cost * params["tariff_pass_through_rate"]

        # Adjusted totals
        total_products = total_products_pre_tariff + price_increase_revenue
        total_sales_pre = total_products + svc_rev

        # -----------------------------------------------------------------------
        # Geographic distribution (based on total sales pre-geographic adjustment)
        # -----------------------------------------------------------------------
        china_share = float(np.clip(params["greater_china_revenue_share"], 0.0, 0.5))
        americas_share = float(np.clip(params["americas_revenue_share"], 0.0, 0.6))
        europe_share = float(np.clip(params["europe_revenue_share"], 0.0, 0.5))
        japan_share = float(np.clip(params["japan_revenue_share"], 0.0, 0.3))
        roa_share = float(np.clip(params["rest_asia_pacific_revenue_share"], 0.0, 0.3))

        total_sales = total_sales_pre
        americas_rev = total_sales * americas_share
        europe_rev = total_sales * europe_share
        china_rev = total_sales * china_share
        japan_rev = total_sales * japan_share
        roa_rev = total_sales * roa_share

        # Clamp geographic revenues
        americas_rev = float(np.clip(americas_rev, 120.0, 220.0))
        europe_rev = float(np.clip(europe_rev, 70.0, 140.0))
        china_rev = float(np.clip(china_rev, 40.0, 100.0))
        japan_rev = float(np.clip(japan_rev, 15.0, 40.0))
        roa_rev = float(np.clip(roa_rev, 20.0, 50.0))

        # -----------------------------------------------------------------------
        # Cost of Sales
        # -----------------------------------------------------------------------
        cogs_products = (total_products * (1.0 - params["products_gross_margin_target"])
                         + net_tariff_cost)
        cogs_services = svc_rev * (1.0 - params["services_gross_margin_target"])
        total_cogs = cogs_products + cogs_services
        total_cogs = float(np.clip(total_cogs, 150.0, 290.0))

        gross_profit = total_sales - total_cogs
        gross_profit = float(np.clip(gross_profit, 120.0, 250.0))

        gm_pct = (gross_profit / total_sales * 100.0) if total_sales > 0 else 0.0
        gm_pct = float(np.clip(gm_pct, 35.0, 55.0))

        prod_gm_pct = ((total_products - cogs_products) / total_products * 100.0
                       if total_products > 0 else 0.0)
        prod_gm_pct = float(np.clip(prod_gm_pct, 28.0, 48.0))

        svc_gm_pct = params["services_gross_margin_target"] * 100.0
        svc_gm_pct = float(np.clip(svc_gm_pct, 60.0, 85.0))

        # -----------------------------------------------------------------------
        # Operating Expenses
        # -----------------------------------------------------------------------
        rd = total_sales * params["rd_as_pct_sales"]
        rd = float(np.clip(rd, 20.0, 50.0))
        sga = total_sales * params["sga_as_pct_sales"]
        sga = float(np.clip(sga, 18.0, 40.0))
        total_opex = rd + sga

        op_income = gross_profit - total_opex
        op_income = float(np.clip(op_income, 80.0, 180.0))
        op_margin = (op_income / total_sales * 100.0) if total_sales > 0 else 0.0

        # -----------------------------------------------------------------------
        # Net Income
        # -----------------------------------------------------------------------
        pretax_income = op_income
        tax = pretax_income * params["effective_tax_rate"]
        net_income = pretax_income - tax
        net_income = float(np.clip(net_income, 60.0, 140.0))
        net_margin = (net_income / total_sales * 100.0) if total_sales > 0 else 0.0

        # -----------------------------------------------------------------------
        # Shares and EPS (buyback effect)
        # -----------------------------------------------------------------------
        # For historical years (delta < 0): we reverse-project shares (more shares in past)
        shares_yr = shares_base * ((1.0 - params["buyback_rate"]) ** delta)
        shares_yr = float(np.clip(shares_yr, 12.0, 17.0))
        eps_annual = (net_income / shares_yr) if shares_yr > 0 else 0.0

        services_pct = (svc_rev / total_sales * 100.0) if total_sales > 0 else 0.0
        china_pct = (china_rev / total_sales * 100.0) if total_sales > 0 else 0.0

        # -----------------------------------------------------------------------
        # Quarterly decomposition
        # -----------------------------------------------------------------------
        for q in [1, 2, 3, 4]:
            sf = SEASONALITY[q]
            q_frac = sf / 4.0  # sum of 4 quarters = annual total

            # Quarterly EPS uses quarterly net income / annual shares
            q_net_income = net_income * q_frac
            eps_q = float(np.clip(q_net_income / shares_yr if shares_yr > 0 else 0.0, 3.0, 10.0))

            row = {
                "fiscal_year": yr,
                "fiscal_quarter": q,
                "quarter_label": f"FY{yr}-Q{q}",
                "scenario": scenario_label,
                "iphone_revenue": round(iphone_rev * q_frac, 4),
                "mac_revenue": round(mac_rev * q_frac, 4),
                "ipad_revenue": round(ipad_rev * q_frac, 4),
                "wearables_revenue": round(wear_rev * q_frac, 4),
                "services_revenue": round(svc_rev * q_frac, 4),
                "total_products_revenue": round(total_products * q_frac, 4),
                "total_net_sales": round(total_sales * q_frac, 4),
                "americas_revenue": round(americas_rev * q_frac, 4),
                "europe_revenue": round(europe_rev * q_frac, 4),
                "greater_china_revenue": round(china_rev * q_frac, 4),
                "japan_revenue": round(japan_rev * q_frac, 4),
                "rest_asia_pacific_revenue": round(roa_rev * q_frac, 4),
                "cost_of_sales_products": round(cogs_products * q_frac, 4),
                "cost_of_sales_services": round(cogs_services * q_frac, 4),
                "total_cost_of_sales": round(total_cogs * q_frac, 4),
                "gross_profit": round(gross_profit * q_frac, 4),
                "gross_margin_pct": round(gm_pct, 4),
                "products_gross_margin_pct": round(prod_gm_pct, 4),
                "services_gross_margin_pct": round(svc_gm_pct, 4),
                "rd_expense": round(rd * q_frac, 4),
                "sga_expense": round(sga * q_frac, 4),
                "total_opex": round(total_opex * q_frac, 4),
                "operating_income": round(op_income * q_frac, 4),
                "operating_margin_pct": round(op_margin, 4),
                "tariff_cost_impact": round(net_tariff_cost * q_frac, 4),
                "net_income_pretax": round(pretax_income * q_frac, 4),
                "tax_expense": round(tax * q_frac, 4),
                "net_income": round(q_net_income, 4),
                "net_margin_pct": round(net_margin, 4),
                "shares_outstanding_billions": round(shares_yr, 6),
                "eps_diluted": round(eps_q, 4),
                "services_pct_total_sales": round(services_pct, 4),
                "china_pct_total_sales": round(china_pct, 4),
                "seasonality_factor": sf,
            }
            rows.append(row)

    return rows


# =============================================================================
# RUN ALL SCENARIOS
# =============================================================================
def run_all_scenarios() -> List[Dict[str, Any]]:
    """Run all five scenarios and return combined row list."""
    all_rows = []
    default_params = get_default_params()

    for idx, scenario in enumerate(MODEL_PROFILE["scenarios"]):
        np.random.seed(idx)  # unique seed per scenario
        params = default_params.copy()
        # Apply scenario-specific overrides
        for k, v in scenario["param_overrides"].items():
            params[k] = v
        params["scenario_label"] = scenario["label"]

        rows = project_annual(
            params,
            scenario_label=scenario["label"],
            start_year=MODEL_PROFILE["sim_start_year"],
            end_year=MODEL_PROFILE["sim_end_year"],
        )
        all_rows.extend(rows)

    return all_rows


# =============================================================================
# HELPER: Get annual aggregates from row list
# =============================================================================
def get_annual_data(rows: List[Dict], scenario: str) -> Dict[str, np.ndarray]:
    """Aggregate quarterly rows to annual for a given scenario."""
    s_rows = [r for r in rows if r["scenario"] == scenario]
    years = sorted(set(r["fiscal_year"] for r in s_rows))
    result = {"years": np.array(years, dtype=float)}

    # Additive fields (sum quarters)
    additive = [
        "iphone_revenue", "mac_revenue", "ipad_revenue", "wearables_revenue",
        "services_revenue", "total_products_revenue", "total_net_sales",
        "americas_revenue", "europe_revenue", "greater_china_revenue",
        "japan_revenue", "rest_asia_pacific_revenue",
        "cost_of_sales_products", "cost_of_sales_services", "total_cost_of_sales",
        "gross_profit", "rd_expense", "sga_expense", "total_opex",
        "operating_income", "tariff_cost_impact", "net_income_pretax",
        "tax_expense", "net_income",
    ]
    # Average fields
    avg_fields = [
        "gross_margin_pct", "products_gross_margin_pct", "services_gross_margin_pct",
        "operating_margin_pct", "net_margin_pct", "shares_outstanding_billions",
        "services_pct_total_sales", "china_pct_total_sales",
    ]

    for field_name in additive:
        arr = np.array([
            sum(r[field_name] for r in s_rows if r["fiscal_year"] == yr)
            for yr in years
        ], dtype=float)
        result[field_name] = arr

    for field_name in avg_fields:
        arr = np.array([
            np.mean([r[field_name] for r in s_rows if r["fiscal_year"] == yr])
            for yr in years
        ], dtype=float)
        result[field_name] = arr

    # Annual EPS = annual net income / shares
    shares_arr = result["shares_outstanding_billions"]
    ni_arr = result["net_income"]
    eps_arr = np.where(shares_arr > 0, ni_arr / shares_arr, 0.0)
    result["eps_diluted"] = eps_arr

    return result


# =============================================================================
# FIGURE GENERATION FUNCTIONS
# =============================================================================

def fig1_revenue_by_product_line(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig 1: Revenue by product line under baseline scenario."""
    try:
        scenario = "baseline_fy2025"
        ann = get_annual_data(all_rows, scenario)
        years = ann["years"]

        product_lines = {
            "iPhone": ann["iphone_revenue"],
            "Mac": ann["mac_revenue"],
            "iPad": ann["ipad_revenue"],
            "Wearables": ann["wearables_revenue"],
            "Services": ann["services_revenue"],
        }

        assert len(years) > 0, "No data for fig1"
        for k, v in product_lines.items():
            assert len(years) == len(v), f"Length mismatch in fig1 for {k}"

        fig, ax = plt.subplots(figsize=(12, 7))
        colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
        for (label, values), color in zip(product_lines.items(), colors):
            ax.plot(years, values, marker="o", linewidth=2.5, label=label, color=color)

        ax.set_title("Apple Revenue by Product Line Over Projected Fiscal Years (Baseline Scenario)",
                     fontsize=13, fontweight="bold")
        ax.set_xlabel("Fiscal Year", fontsize=11)
        ax.set_ylabel("Revenue (USD Billions)", fontsize=11)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_xticks(years)
        plt.tight_layout()
        fig.savefig(out_dir / "fig1_revenue_by_product_line.png", dpi=150)
        plt.close(fig)
        print("Saved fig1_revenue_by_product_line.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def fig2_geographic_revenue_mix(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig 2: Geographic segment revenue — baseline vs high-tariff."""
    try:
        scenarios = ["baseline_fy2025", "high_tariff_stress"]
        segments = {
            "Americas": "americas_revenue",
            "Europe": "europe_revenue",
            "Greater China": "greater_china_revenue",
            "Japan": "japan_revenue",
            "Rest of Asia Pac": "rest_asia_pacific_revenue",
        }
        colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]
        linestyles = ["-", "--"]

        fig, ax = plt.subplots(figsize=(13, 7))

        for seg_label, field_name in segments.items():
            for scen, ls, color_idx in zip(scenarios, linestyles,
                                            [segments.keys().mapping if False else None][0:]):
                pass  # replaced below

        # Proper loop
        for color_i, (seg_label, field_name) in enumerate(segments.items()):
            for scen, ls in zip(scenarios, linestyles):
                ann = get_annual_data(all_rows, scen)
                years = ann["years"]
                values = ann[field_name]
                assert len(years) == len(values), f"Length mismatch fig2 {seg_label} {scen}"
                lbl = f"{seg_label} ({scen.replace('_', ' ')})"
                ax.plot(years, values, marker="o" if ls == "-" else "s",
                        linestyle=ls, linewidth=2, label=lbl,
                        color=colors[color_i])

        ax.set_title("Apple Geographic Segment Revenue Trends (Baseline vs High-Tariff)",
                     fontsize=13, fontweight="bold")
        ax.set_xlabel("Fiscal Year", fontsize=11)
        ax.set_ylabel("Segment Revenue (USD Billions)", fontsize=11)
        ax.legend(fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        # Retrieve years for ticks from last ann
        ann = get_annual_data(all_rows, scenarios[0])
        ax.set_xticks(ann["years"])

        plt.tight_layout()
        fig.savefig(out_dir / "fig2_geographic_revenue_mix.png", dpi=150)
        plt.close(fig)
        print("Saved fig2_geographic_revenue_mix.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def fig3_gross_margin_scenarios(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig 3: Blended gross margin across all five scenarios."""
    try:
        scenario_labels = [s["label"] for s in MODEL_PROFILE["scenarios"]]
        colors = ["#1f77b4", "#d62728", "#2ca02c", "#ff7f0e", "#9467bd"]

        fig, ax = plt.subplots(figsize=(12, 7))

        for scen, color in zip(scenario_labels, colors):
            ann = get_annual_data(all_rows, scen)
            years = ann["years"]
            gm = ann["gross_margin_pct"]
            assert len(years) == len(gm), f"Length mismatch fig3 {scen}"
            ax.plot(years, gm, marker="o", linewidth=2.5,
                    label=scen.replace("_", " "), color=color)

        ax.set_title("Apple Blended Gross Margin Trajectory Across Five Scenarios",
                     fontsize=13, fontweight="bold")
        ax.set_xlabel("Fiscal Year", fontsize=11)
        ax.set_ylabel("Gross Margin (%)", fontsize=11)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.set_ylim(35, 55)

        ann_base = get_annual_data(all_rows, "baseline_fy2025")
        ax.set_xticks(ann_base["years"])

        plt.tight_layout()
        fig.savefig(out_dir / "fig3_gross_margin_scenarios.png", dpi=150)
        plt.close(fig)
        print("Saved fig3_gross_margin_scenarios.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def fig4_quarterly_seasonality(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig 4: Quarterly revenue seasonality pattern for baseline scenario."""
    try:
        scenario = "baseline_fy2025"
        s_rows = [r for r in all_rows if r["scenario"] == scenario]
        years_all = sorted(set(r["fiscal_year"] for r in s_rows))
        # Pick 4 representative years
        highlight_years = [y for y in [2021, 2023, 2025, 2027] if y in years_all]
        if len(highlight_years) == 0:
            highlight_years = years_all[:4]

        fig, ax = plt.subplots(figsize=(12, 7))
        colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]
        quarter_labels = ["Q1", "Q2", "Q3", "Q4"]

        for yr, color in zip(highlight_years, colors):
            yr_rows = sorted([r for r in s_rows if r["fiscal_year"] == yr],
                             key=lambda r: r["fiscal_quarter"])
            x = np.arange(1, 5, dtype=float)
            y = np.array([r["total_net_sales"] for r in yr_rows], dtype=float)
            assert len(x) == len(y) == 4, f"Quarter count mismatch fig4 yr={yr}"
            ax.plot(x, y, marker="o", linewidth=2.5, label=f"FY{yr}", color=color)
            ax.bar(x + (0.15 * (highlight_years.index(yr) - 1.5)),
                   y, width=0.12, alpha=0.35, color=color)

        ax.set_title("Apple Quarterly Revenue Seasonality Pattern (Q1-Q4 Fiscal Year)",
                     fontsize=13, fontweight="bold")
        ax.set_xlabel("Fiscal Quarter", fontsize=11)
        ax.set_ylabel("Quarterly Revenue (USD Billions)", fontsize=11)
        ax.set_xticks([1, 2, 3, 4])
        ax.set_xticklabels(quarter_labels)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig4_quarterly_seasonality.png", dpi=150)
        plt.close(fig)
        print("Saved fig4_quarterly_seasonality.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def fig5_tariff_impact_on_earnings(out_dir: pathlib.Path) -> None:
    """Fig 5: Net income sensitivity to China tariff rate — parametric sweep."""
    try:
        tariff_rates = np.linspace(0.0, 0.50, 25)
        pass_through_rates = [0.20, 0.40, 0.60]
        colors = ["#d62728", "#1f77b4", "#2ca02c"]
        labels = ["Pass-through 20%", "Pass-through 40%", "Pass-through 60%"]

        # FY2025 base values
        iphone_rev = 201.0
        mac_rev = 31.0
        ipad_rev = 26.0
        wear_rev = 37.0
        svc_rev = 96.0
        total_products_base = iphone_rev + mac_rev + ipad_rev + wear_rev

        products_gm_target = 0.37
        svc_gm_target = 0.74
        rd_pct = 0.079
        sga_pct = 0.069
        tax_rate = 0.245
        china_cogs_frac = 0.55

        fig, ax = plt.subplots(figsize=(12, 7))

        for pt_rate, color, lbl in zip(pass_through_rates, colors, labels):
            net_incomes = np.zeros(len(tariff_rates))
            for i, tr in enumerate(tariff_rates):
                products_cogs_notariff = total_products_base * (1.0 - products_gm_target)
                tariff_add = china_cogs_frac * products_cogs_notariff * tr
                net_tariff = tariff_add * (1.0 - pt_rate)
                price_increase = tariff_add * pt_rate

                total_products = total_products_base + price_increase
                total_sales = total_products + svc_rev

                cogs_prod = total_products * (1.0 - products_gm_target) + net_tariff
                cogs_svc = svc_rev * (1.0 - svc_gm_target)
                total_cogs = cogs_prod + cogs_svc

                gp = total_sales - total_cogs
                rd = total_sales * rd_pct
                sga_val = total_sales * sga_pct
                op_inc = gp - rd - sga_val
                ni = op_inc * (1.0 - tax_rate)
                ni = float(np.clip(ni, 60.0, 140.0))
                net_incomes[i] = ni

            assert len(tariff_rates) == len(net_incomes), f"Length mismatch fig5 {lbl}"
            ax.plot(tariff_rates * 100, net_incomes, linewidth=2.5,
                    label=lbl, color=color, marker="o", markersize=4)

        ax.set_title("Net Income Sensitivity to China Tariff Rate (Parametric Sweep)",
                     fontsize=13, fontweight="bold")
        ax.set_xlabel("China Tariff Rate (%)", fontsize=11)
        ax.set_ylabel("Net Income (USD Billions)", fontsize=11)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig5_tariff_impact_on_earnings.png", dpi=150)
        plt.close(fig)
        print("Saved fig5_tariff_impact_on_earnings.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def fig6_services_vs_products_revenue(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig 6: Services vs products revenue divergence under services_acceleration scenario."""
    try:
        scenario = "services_acceleration"
        ann = get_annual_data(all_rows, scenario)
        years = ann["years"]
        products_rev = ann["total_products_revenue"]
        services_rev = ann["services_revenue"]
        total_sales = ann["total_net_sales"]

        assert len(years) == len(products_rev) == len(services_rev), "Length mismatch fig6"

        services_pct = np.where(total_sales > 0, services_rev / total_sales * 100.0, 0.0)

        fig, ax1 = plt.subplots(figsize=(12, 7))
        ax2 = ax1.twinx()

        l1, = ax1.plot(years, products_rev, color="#1f77b4", linewidth=2.5,
                       marker="o", label="Total Products Revenue")
        l2, = ax1.plot(years, services_rev, color="#d62728", linewidth=2.5,
                       marker="s", label="Services Revenue")
        l3, = ax2.plot(years, services_pct, color="#2ca02c", linewidth=2,
                       marker="^", linestyle="--", label="Services % of Total Sales (right)")

        ax1.set_title("Services vs. Total Products Revenue: Diverging Growth Paths",
                      fontsize=13, fontweight="bold")
        ax1.set_xlabel("Fiscal Year", fontsize=11)
        ax1.set_ylabel("Revenue (USD Billions)", fontsize=11)
        ax2.set_ylabel("Services % of Total Sales", fontsize=11, color="#2ca02c")
        ax2.tick_params(axis="y", labelcolor="#2ca02c")

        lines = [l1, l2, l3]
        labels_list = [l.get_label() for l in lines]
        ax1.legend(lines, labels_list, fontsize=9)
        ax1.grid(True, alpha=0.3)
        ax1.set_xticks(years)

        plt.tight_layout()
        fig.savefig(out_dir / "fig6_services_vs_products_revenue.png", dpi=150)
        plt.close(fig)
        print("Saved fig6_services_vs_products_revenue.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def fig7_eps_and_buyback_effect(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig 7: EPS decomposition — earnings growth vs. share buyback effect."""
    try:
        selected_scenarios = [
            ("baseline_fy2025", "#1f77b4"),
            ("high_tariff_stress", "#d62728"),
            ("margin_expansion_case", "#2ca02c"),
        ]

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(13, 10))

        # Top panel: EPS trajectories across scenarios
        for scen_label, color in selected_scenarios:
            ann = get_annual_data(all_rows, scen_label)
            years = ann["years"]
            eps = ann["eps_diluted"]
            assert len(years) == len(eps), f"Length mismatch fig7 {scen_label}"
            ax1.plot(years, eps, linewidth=2.5, marker="o",
                     label=scen_label.replace("_", " "), color=color)

        ax1.set_title("Diluted EPS Growth Across Scenarios", fontsize=12, fontweight="bold")
        ax1.set_ylabel("Diluted EPS (USD)", fontsize=11)
        ax1.legend(fontsize=9)
        ax1.grid(True, alpha=0.3)
        ax1.set_xticks(get_annual_data(all_rows, "baseline_fy2025")["years"])

        # Bottom panel: Stacked bar decomposition for baseline
        ann_base = get_annual_data(all_rows, "baseline_fy2025")
        years = ann_base["years"]
        eps_arr = ann_base["eps_diluted"]
        ni_arr = ann_base["net_income"]
        shares_arr = ann_base["shares_outstanding_billions"]

        # EPS from baseline net income at FY2025 share count
        shares_ref = 14.776
        eps_ni_component = np.where(shares_ref > 0, ni_arr / shares_ref, 0.0)
        eps_buyback_component = eps_arr - eps_ni_component

        x = np.arange(len(years))
        assert len(x) == len(eps_ni_component) == len(eps_buyback_component), "Length mismatch fig7 bars"

        ax2.bar(x, eps_ni_component, label="EPS from Net Income (at ref shares)", color="#1f77b4", alpha=0.8)
        ax2.bar(x, eps_buyback_component, bottom=eps_ni_component,
                label="EPS Uplift from Buybacks", color="#ff7f0e", alpha=0.8)
        ax2.plot(x, eps_arr, "k-o", linewidth=2, label="Total Diluted EPS")

        ax2.set_title("EPS Decomposition: Net Income vs. Buyback Effect (Baseline)",
                      fontsize=12, fontweight="bold")
        ax2.set_xlabel("Fiscal Year", fontsize=11)
        ax2.set_ylabel("Diluted EPS (USD)", fontsize=11)
        ax2.set_xticks(x)
        ax2.set_xticklabels([str(int(y)) for y in years])
        ax2.legend(fontsize=9)
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        fig.savefig(out_dir / "fig7_eps_and_buyback_effect.png", dpi=150)
        plt.close(fig)
        print("Saved fig7_eps_and_buyback_effect.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


def fig8_rd_and_sga_opex(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig 8: R&D and SG&A expense trends across scenarios."""
    try:
        selected_scenarios = [
            ("baseline_fy2025", "#1f77b4"),
            ("high_tariff_stress", "#d62728"),
            ("services_acceleration", "#2ca02c"),
        ]

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(13, 10))

        # Top panel: Absolute R&D and SG&A
        for scen_label, color in selected_scenarios:
            ann = get_annual_data(all_rows, scen_label)
            years = ann["years"]
            rd = ann["rd_expense"]
            sga = ann["sga_expense"]
            assert len(years) == len(rd) == len(sga), f"Length mismatch fig8 {scen_label}"
            ax1.plot(years, rd, linewidth=2, linestyle="-",
                     label=f"R&D {scen_label.replace('_', ' ')}", color=color)
            ax1.plot(years, sga, linewidth=2, linestyle="--",
                     label=f"SG&A {scen_label.replace('_', ' ')}", color=color, alpha=0.7)

        ax1.set_title("R&D and SG&A Operating Expense (Absolute, USD Billions)",
                      fontsize=12, fontweight="bold")
        ax1.set_ylabel("Expense (USD Billions)", fontsize=11)
        ax1.legend(fontsize=8, ncol=2)
        ax1.grid(True, alpha=0.3)
        ann_base = get_annual_data(all_rows, "baseline_fy2025")
        ax1.set_xticks(ann_base["years"])

        # Bottom panel: As % of net sales
        for scen_label, color in selected_scenarios:
            ann = get_annual_data(all_rows, scen_label)
            years = ann["years"]
            sales = ann["total_net_sales"]
            rd = ann["rd_expense"]
            sga = ann["sga_expense"]
            rd_pct = np.where(sales > 0, rd / sales * 100.0, 0.0)
            sga_pct = np.where(sales > 0, sga / sales * 100.0, 0.0)
            assert len(years) == len(rd_pct) == len(sga_pct), f"Length mismatch fig8 pct {scen_label}"
            ax2.plot(years, rd_pct, linewidth=2, linestyle="-",
                     label=f"R&D% {scen_label.replace('_', ' ')}", color=color)
            ax2.plot(years, sga_pct, linewidth=2, linestyle="--",
                     label=f"SG&A% {scen_label.replace('_', ' ')}", color=color, alpha=0.7)

        ax2.set_title("R&D and SG&A as Percentage of Net Sales",
                      fontsize=12, fontweight="bold")
        ax2.set_xlabel("Fiscal Year", fontsize=11)
        ax2.set_ylabel("Expense as % of Sales", fontsize=11)
        ax2.legend(fontsize=8, ncol=2)
        ax2.grid(True, alpha=0.3)
        ax2.set_xticks(ann_base["years"])

        plt.tight_layout()
        fig.savefig(out_dir / "fig8_rd_and_sga_opex.png", dpi=150)
        plt.close(fig)
        print("Saved fig8_rd_and_sga_opex.png")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")


# =============================================================================
# CSV WRITERS
# =============================================================================

DATASET_SCHEMA = [
    "fiscal_year", "fiscal_quarter", "quarter_label", "scenario",
    "iphone_revenue", "mac_revenue", "ipad_revenue", "wearables_revenue",
    "services_revenue", "total_products_revenue", "total_net_sales",
    "americas_revenue", "europe_revenue", "greater_china_revenue",
    "japan_revenue", "rest_asia_pacific_revenue",
    "cost_of_sales_products", "cost_of_sales_services", "total_cost_of_sales",
    "gross_profit", "gross_margin_pct", "products_gross_margin_pct",
    "services_gross_margin_pct", "rd_expense", "sga_expense", "total_opex",
    "operating_income", "operating_margin_pct", "tariff_cost_impact",
    "net_income_pretax", "tax_expense", "net_income", "net_margin_pct",
    "shares_outstanding_billions", "eps_diluted",
    "services_pct_total_sales", "china_pct_total_sales", "seasonality_factor",
]


def write_simulation_outputs_csv(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Write the full time-series simulation_outputs.csv."""
    try:
        if not all_rows:
            print("WARNING: No rows to write for simulation_outputs.csv")
            return
        fpath = out_dir / "simulation_outputs.csv"
        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({k: row.get(k, "") for k in DATASET_SCHEMA})
        print(f"Saved simulation_outputs.csv ({len(all_rows)} rows)")
    except Exception as e:
        print(f"WARNING: Failed to write simulation_outputs.csv: {e}")


def write_scenario_summary_csv(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv — one row per scenario."""
    try:
        numeric_fields = [
            "iphone_revenue", "mac_revenue", "ipad_revenue", "wearables_revenue",
            "services_revenue", "total_net_sales", "gross_profit", "gross_margin_pct",
            "operating_income", "net_income", "eps_diluted", "tariff_cost_impact",
            "services_pct_total_sales", "china_pct_total_sales",
        ]

        scenario_labels = [s["label"] for s in MODEL_PROFILE["scenarios"]]

        header = ["scenario"]
        for f in numeric_fields:
            header += [f"{f}_mean", f"{f}_std", f"{f}_min", f"{f}_max"]

        rows_out = []
        for scen in scenario_labels:
            s_rows = [r for r in all_rows if r["scenario"] == scen]
            if not s_rows:
                continue
            row_out = {"scenario": scen}
            for f in numeric_fields:
                vals = np.array([r[f] for r in s_rows if isinstance(r.get(f), (int, float))],
                                dtype=float)
                if len(vals) > 0:
                    row_out[f"{f}_mean"] = round(float(np.mean(vals)), 4)
                    row_out[f"{f}_std"] = round(float(np.std(vals)), 4)
                    row_out[f"{f}_min"] = round(float(np.min(vals)), 4)
                    row_out[f"{f}_max"] = round(float(np.max(vals)), 4)
                else:
                    row_out[f"{f}_mean"] = 0.0
                    row_out[f"{f}_std"] = 0.0
                    row_out[f"{f}_min"] = 0.0
                    row_out[f"{f}_max"] = 0.0
            rows_out.append(row_out)

        if not rows_out:
            print("WARNING: No scenario summary rows to write.")
            return

        fpath = out_dir / "scenario_summary.csv"
        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=header)
            writer.writeheader()
            for row in rows_out:
                writer.writerow(row)
        print(f"Saved scenario_summary.csv ({len(rows_out)} rows)")
    except Exception as e:
        print(f"WARNING: Failed to write scenario_summary.csv: {e}")


def write_parameters_used_csv(out_dir: pathlib.Path) -> None:
    """Write parameters_used.csv — one row per parameter."""
    try:
        header = ["name", "value", "unit", "source", "description"]
        rows_out = []
        for name, meta in MODEL_PROFILE["parameters"].items():
            rows_out.append({
                "name": name,
                "value": meta["value"],
                "unit": meta.get("unit", ""),
                "source": meta.get("source", ""),
                "description": meta.get("description", ""),
            })

        if not rows_out:
            print("WARNING: No parameter rows to write.")
            return

        fpath = out_dir / "parameters_used.csv"
        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=header)
            writer.writeheader()
            for row in rows_out:
                writer.writerow(row)
        print(f"Saved parameters_used.csv ({len(rows_out)} rows)")
    except Exception as e:
        print(f"WARNING: Failed to write parameters_used.csv: {e}")


# =============================================================================
# SUMMARY JSON
# =============================================================================

def write_summary_json(all_rows: List[Dict], out_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    try:
        summary = {
            "title": MODEL_PROFILE["title"],
            "simulation_years": f"{MODEL_PROFILE['sim_start_year']}-{MODEL_PROFILE['sim_end_year']}",
            "total_rows": len(all_rows),
            "scenarios": [],
        }

        for scen_info in MODEL_PROFILE["scenarios"]:
            scen_label = scen_info["label"]
            s_rows = [r for r in all_rows if r["scenario"] == scen_label]
            if not s_rows:
                continue

            # Annual totals for FY2025 (or nearest available)
            fy25 = [r for r in s_rows if r["fiscal_year"] == 2025]
            annual_sales = sum(r["total_net_sales"] for r in fy25) if fy25 else 0.0
            annual_ni = sum(r["net_income"] for r in fy25) if fy25 else 0.0
            avg_gm = float(np.mean([r["gross_margin_pct"] for r in fy25])) if fy25 else 0.0
            avg_eps = float(np.mean([r["eps_diluted"] for r in fy25])) * 4 if fy25 else 0.0

            summary["scenarios"].append({
                "label": scen_label,
                "fy2025_total_net_sales_bn": round(annual_sales, 2),
                "fy2025_net_income_bn": round(annual_ni, 2),
                "fy2025_avg_gross_margin_pct": round(avg_gm, 2),
                "fy2025_annual_eps_usd": round(avg_eps, 2),
                "param_overrides": scen_info["param_overrides"],
            })

        fpath = out_dir / "summary.json"
        with open(fpath, "w") as f:
            json.dump(summary, f, indent=2)
        print("Saved summary.json")
    except Exception as e:
        print(f"WARNING: Failed to write summary.json: {e}")


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Apple 10-K Financial Simulator — FY2021-FY2028"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # -------------------------------------------------------------------------
    # Run all scenarios
    # -------------------------------------------------------------------------
    print("Running simulations for all scenarios...")
    all_rows = run_all_scenarios()
    print(f"Generated {len(all_rows)} total quarterly rows across all scenarios.")

    # -------------------------------------------------------------------------
    # Write CSV files
    # -------------------------------------------------------------------------
    write_simulation_outputs_csv(all_rows, out_dir)
    write_scenario_summary_csv(all_rows, out_dir)
    write_parameters_used_csv(out_dir)

    # -------------------------------------------------------------------------
    # Write summary JSON
    # -------------------------------------------------------------------------
    write_summary_json(all_rows, out_dir)

    # -------------------------------------------------------------------------
    # Generate figures
    # -------------------------------------------------------------------------
    print("Generating figures...")
    fig1_revenue_by_product_line(all_rows, out_dir)
    fig2_geographic_revenue_mix(all_rows, out_dir)
    fig3_gross_margin_scenarios(all_rows, out_dir)
    fig4_quarterly_seasonality(all_rows, out_dir)
    fig5_tariff_impact_on_earnings(out_dir)
    fig6_services_vs_products_revenue(all_rows, out_dir)
    fig7_eps_and_buyback_effect(all_rows, out_dir)
    fig8_rd_and_sga_opex(all_rows, out_dir)

    print("\nSimulation complete. All files saved to:", out_dir.resolve())


if __name__ == "__main__":
    main()