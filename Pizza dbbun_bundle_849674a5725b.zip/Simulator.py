# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T13:21:19.854744Z
# Run ID    : 0f7045e2-834b-4e54-a833-392a0c6ebe99
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Pizza: History, Varieties, and Global Market Dynamics
======================================================
Simulator based on:
  "Pizza: History, Varieties, and Global Market Dynamics"

Models global pizza market growth, regional diffusion, style competition,
cheese production scaling, and daily consumption adoption S-curves.
Anchored to 2017 market data: $128B world, $44B US, 76,000 US pizzerias.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "title": "Pizza: History, Varieties, and Global Market Dynamics",
    "parameters": {
        "world_market_2017_usd":        {"value": 128.0,     "unit": "billion USD",            "source": "extracted",  "description": "Total world pizza market size in 2017"},
        "us_market_2017_usd":           {"value": 44.0,      "unit": "billion USD",            "source": "extracted",  "description": "US pizza market size in 2017"},
        "us_pizzeria_count_2017":        {"value": 76000.0,   "unit": "count",                  "source": "extracted",  "description": "Number of pizzerias in the US as of 2017"},
        "us_daily_consumption_fraction": {"value": 0.13,      "unit": "fraction",               "source": "extracted",  "description": "Fraction of US population aged 2+ consuming pizza on any given day"},
        "us_cheese_production_1997":     {"value": 1000000.0, "unit": "metric tons",            "source": "extracted",  "description": "Annual pizza cheese production in the US in 1997"},
        "europe_cheese_production_1997": {"value": 100000.0,  "unit": "metric tons",            "source": "extracted",  "description": "Annual pizza cheese production in Europe in 1997"},
        "buenos_aires_annual_pizzas_2015":{"value":14000000.0,"unit": "count",                  "source": "extracted",  "description": "Estimated annual pizza consumption in Buenos Aires in 2015"},
        "sodium_per_pizza_mg":           {"value": 5100.0,    "unit": "mg",                     "source": "extracted",  "description": "Average sodium content per 14-inch fast-food pizza per USDA"},
        "first_us_pizzeria_year":        {"value": 1905.0,    "unit": "year CE",                "source": "extracted",  "description": "Year Lombardi's opened as first US pizzeria in New York City"},
        "pizza_word_first_recorded_year":{"value": 997.0,     "unit": "year CE",                "source": "extracted",  "description": "Year the word pizza was first recorded"},
        "neapolitan_tsg_year":           {"value": 2009.0,    "unit": "year CE",                "source": "extracted",  "description": "Year Neapolitan pizza received EU TSG status"},
        "unesco_recognition_year":       {"value": 2017.0,    "unit": "year CE",                "source": "extracted",  "description": "Year UNESCO listed Neapolitan pizza-making as intangible cultural heritage"},
        "num_regional_styles":           {"value": 8.0,       "unit": "count",                  "source": "extracted",  "description": "Number of distinct major North American regional pizza styles"},
        "market_growth_rate_baseline":   {"value": 0.04,      "unit": "fraction per year",      "source": "assumed",    "description": "Assumed baseline annual growth rate for global pizza market"},
        "diffusion_rate":                {"value": 0.03,      "unit": "fraction per year",      "source": "assumed",    "description": "Rate at which pizza adoption spreads per year"},
        "pizzeria_revenue_avg":          {"value": 578947.0,  "unit": "USD per pizzeria/year",  "source": "extracted",  "description": "Average revenue per US pizzeria ($44B / 76000)"},
        "simulation_start_year":         {"value": 1900.0,    "unit": "year CE",                "source": "assumed",    "description": "Start year for modern market simulation"},
        "simulation_end_year":           {"value": 2030.0,    "unit": "year CE",                "source": "assumed",    "description": "End year for market projection simulation"},
        "italy_market_fraction":         {"value": 0.15,      "unit": "fraction",               "source": "assumed",    "description": "Assumed fraction of world market attributable to Italy"},
        "rest_of_world_market_fraction": {"value": 0.51,      "unit": "fraction",               "source": "assumed",    "description": "Fraction of world market outside US and Italy"},
    },
    "scenarios": [
        {"label": "baseline_global_2017",      "param_overrides": {"world_market_2017_usd": 128.0, "us_market_2017_usd": 44.0, "us_pizzeria_count_2017": 76000.0, "market_growth_rate_baseline": 0.04}},
        {"label": "high_growth_projection",    "param_overrides": {"market_growth_rate_baseline": 0.07, "diffusion_rate": 0.05}},
        {"label": "low_growth_stagnation",     "param_overrides": {"market_growth_rate_baseline": 0.015, "diffusion_rate": 0.01}},
        {"label": "regional_style_competition","param_overrides": {"num_regional_styles": 8.0, "market_growth_rate_baseline": 0.04}},
        {"label": "historical_diffusion_timeline", "param_overrides": {"simulation_start_year": 1800.0, "diffusion_rate": 0.025, "market_growth_rate_baseline": 0.05}},
        {"label": "cheese_production_scaling", "param_overrides": {"us_cheese_production_1997": 1000000.0, "europe_cheese_production_1997": 100000.0, "market_growth_rate_baseline": 0.04}},
    ],
    "state_variable_ranges": {
        "market_size_usd":          (0.0, 300.0),
        "pizzeria_count":           (0.0, 200000.0),
        "daily_consumption_fraction":(0.0, 1.0),
        "regional_style_share":     (0.0, 1.0),
        "cheese_production":        (0.0, 5000000.0),
        "sodium_content":           (1000.0, 10000.0),
        "annual_pizzas_consumed":   (0.0, 500000000.0),
        "market_growth_rate":       (0.0, 0.2),
        "style_diversity_index":    (0.0, 4.0),
    }
}

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────
REGIONS = ["US", "Italy", "Argentina", "Europe_excl_Italy", "Rest_of_World"]

REGION_MARKET_FRACTIONS_2017 = {
    "US":               44.0 / 128.0,
    "Italy":            0.15,
    "Argentina":        0.05,
    "Europe_excl_Italy":0.15,
    "Rest_of_World":    1.0 - 44.0/128.0 - 0.15 - 0.05 - 0.15,
}

REGION_POPULATION = {
    "US": 330e6,
    "Italy": 60e6,
    "Argentina": 45e6,
    "Europe_excl_Italy": 380e6,
    "Rest_of_World": 6500e6,
}

REGION_SATURATION_CONSUMPTION = {
    "US": 0.13,
    "Italy": 0.15,
    "Argentina": 0.17,
    "Europe_excl_Italy": 0.10,
    "Rest_of_World": 0.06,
}

REGION_ENTRY_YEAR = {
    "US": 1905,
    "Italy": 997,
    "Argentina": 1890,
    "Europe_excl_Italy": 1950,
    "Rest_of_World": 1970,
}

# Pizza styles with first-attested year
STYLES = {
    "Neapolitan":  {"first_year": 1734, "premium": 0.012},
    "New_York":    {"first_year": 1905, "premium": 0.015},
    "Chicago":     {"first_year": 1940, "premium": 0.008},
    "California":  {"first_year": 1980, "premium": 0.018},
    "Detroit":     {"first_year": 1946, "premium": 0.014},
    "New_Haven":   {"first_year": 1925, "premium": 0.006},
    "St_Louis":    {"first_year": 1945, "premium": 0.004},
    "Sicilian":    {"first_year": 1800, "premium": 0.007},
    "Argentine":   {"first_year": 1890, "premium": 0.009},
}

# Style attribute matrix  (thin_crust, thick_crust, tomato_sauce, no_cheese, pan_baked, wood_fired, fried, specialty_cheese, oblong_shape)
STYLE_ATTRIBUTES = {
    #                  thin thick tom  no_ch pan  wood  fried spec  obl
    "Neapolitan":    [  1,   0,    1,    0,   0,    1,    0,    0,   0],
    "New_York":      [  1,   0,    1,    0,   0,    0,    0,    0,   0],
    "Chicago":       [  0,   1,    1,    0,   1,    0,    0,    0,   0],
    "California":    [  1,   0,    1,    0,   0,    1,    0,    1,   0],
    "Detroit":       [  0,   1,    1,    0,   1,    0,    0,    1,   0],
    "New_Haven":     [  1,   0,    1,    0,   0,    1,    0,    1,   1],
    "St_Louis":      [  1,   0,    1,    0,   0,    0,    0,    1,   0],
    "Sicilian":      [  0,   1,    1,    0,   1,    0,    0,    1,   0],
    "Argentine":     [  0,   1,    1,    0,   1,    0,    0,    1,   0],
    "Pizza_fritta":  [  0,   0,    1,    0,   0,    0,    1,    0,   0],
    "Margherita":    [  1,   0,    1,    0,   0,    1,    0,    0,   0],
    "Marinara":      [  1,   0,    1,    1,   0,    1,    0,    0,   0],
    "Capricciosa":   [  1,   0,    1,    0,   0,    1,    0,    1,   0],
}

ATTRIBUTE_NAMES = ["thin_crust", "thick_crust", "tomato_sauce", "no_cheese",
                   "pan_baked", "wood_fired", "fried", "specialty_cheese", "oblong_shape"]

# First-attested years for histogram
STYLE_FIRST_ATTESTED = {
    "Marinara": 1734, "Margherita": 1889, "Capricciosa": 1937,
    "New_Haven": 1925, "New_York": 1905, "Chicago": 1943,
    "Detroit": 1946, "St_Louis": 1945, "California": 1980,
    "Colorado": 1973, "Windsor": 1955, "Pizza_fritta": 1940,
    "Neapolitan": 1734, "Sicilian": 1860, "Argentine": 1890,
}

SODIUM_CONTENT_MG = 5100.0


# ─────────────────────────────────────────────────────────────────────────────
# HELPER: get scenario params with overrides applied
# ─────────────────────────────────────────────────────────────────────────────
def get_params(scenario: Dict) -> Dict:
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    params.update(scenario.get("param_overrides", {}))
    return params


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


# ─────────────────────────────────────────────────────────────────────────────
# CORE SIMULATION FOR ONE SCENARIO
# ─────────────────────────────────────────────────────────────────────────────
def run_scenario(scenario: Dict, scenario_idx: int) -> List[Dict]:
    np.random.seed(scenario_idx)
    params = get_params(scenario)
    label = scenario["label"]

    start_year = int(params["simulation_start_year"])
    end_year   = int(params["simulation_end_year"])
    growth_rate = clamp(params["market_growth_rate_baseline"], 0.0, 0.2)
    diffusion_k = clamp(params["diffusion_rate"], 0.0, 0.2)

    world_2017  = params["world_market_2017_usd"]
    us_2017     = params["us_market_2017_usd"]
    us_piz_2017 = params["us_pizzeria_count_2017"]

    years = list(range(start_year, end_year + 1))
    n_years = len(years)

    # ── Market sizes (back-projected from 2017) ────────────────────────────
    market_size = {}   # region -> array
    for region in REGIONS:
        frac = REGION_MARKET_FRACTIONS_2017[region]
        base_2017 = world_2017 * frac
        arr = np.zeros(n_years)
        for i, yr in enumerate(years):
            delta = yr - 2017
            val = base_2017 * ((1.0 + growth_rate) ** delta)
            arr[i] = clamp(val, 0.0, 300.0)
        market_size[region] = arr

    # World market
    world_market = np.zeros(n_years)
    for i in range(n_years):
        world_market[i] = clamp(sum(market_size[r][i] for r in REGIONS), 0.0, 300.0)

    # ── Pizzeria count (US only, scaled from 2017) ─────────────────────────
    pizzeria_count = np.zeros(n_years)
    for i, yr in enumerate(years):
        delta = yr - 2017
        pc = us_piz_2017 * ((1.0 + growth_rate) ** delta)
        pizzeria_count[i] = clamp(pc, 0.0, 200000.0)

    # ── Cheese production ─────────────────────────────────────────────────
    us_cheese_1997 = params["us_cheese_production_1997"]
    eu_cheese_1997 = params["europe_cheese_production_1997"]
    europe_market_2017 = world_2017 * (REGION_MARKET_FRACTIONS_2017["Italy"] +
                                        REGION_MARKET_FRACTIONS_2017["Europe_excl_Italy"])

    cheese_us = np.zeros(n_years)
    cheese_eu = np.zeros(n_years)
    for i, yr in enumerate(years):
        # Scale relative to 1997 using US market ratio
        us_mkt_i = market_size["US"][i]
        # US market in 1997 (back from 2017)
        us_mkt_1997 = us_2017 / ((1.0 + 0.04) ** (2017 - 1997))
        us_ratio = us_mkt_i / max(us_mkt_1997, 0.01)
        cheese_us[i] = clamp(us_cheese_1997 * (us_ratio ** 0.9), 0.0, 5000000.0)

        eu_mkt_i = market_size["Italy"][i] + market_size["Europe_excl_Italy"][i]
        eu_mkt_1997 = europe_market_2017 / ((1.0 + 0.04) ** (2017 - 1997))
        eu_ratio = eu_mkt_i / max(eu_mkt_1997, 0.01)
        cheese_eu[i] = clamp(eu_cheese_1997 * (eu_ratio ** 0.9), 0.0, 5000000.0)

    # ── Daily consumption (logistic S-curve) ──────────────────────────────
    consumption = {}   # region -> array
    for region in REGIONS:
        sat = REGION_SATURATION_CONSUMPTION[region]
        entry = REGION_ENTRY_YEAR[region]
        arr = np.zeros(n_years)
        C = 0.001
        for i, yr in enumerate(years):
            if yr < entry:
                arr[i] = clamp(0.0005 + (yr - (entry - 50)) * 0.00001, 0.0, sat * 0.05)
            else:
                dC = diffusion_k * C * (sat - C)
                C = clamp(C + dC, 0.0, sat)
                arr[i] = C
        consumption[region] = arr

    # ── Annual pizzas consumed ────────────────────────────────────────────
    annual_pizzas = {}
    avg_pizza_per_occasion = 0.25
    ba_correction = 1.82  # correction factor for Buenos Aires
    for region in REGIONS:
        pop = REGION_POPULATION[region]
        corr = ba_correction if region == "Argentina" else 1.0
        arr = np.zeros(n_years)
        for i in range(n_years):
            c_frac = consumption[region][i]
            val = pop * c_frac * 365.0 / avg_pizza_per_occasion * corr
            arr[i] = clamp(val, 0.0, 500000000.0)
        annual_pizzas[region] = arr

    # ── Style market share competition ────────────────────────────────────
    style_names = list(STYLES.keys())
    n_styles = len(style_names)
    style_shares = {s: np.zeros(n_years) for s in style_names}
    style_diversity = np.zeros(n_years)

    # raw shares start at equal value when style enters
    raw_shares = {s: 0.0 for s in style_names}

    for i, yr in enumerate(years):
        # activate styles that have entered by this year
        for s in style_names:
            if yr >= STYLES[s]["first_year"] and raw_shares[s] == 0.0:
                raw_shares[s] = 1.0  # equal entry share

        # update raw shares
        for s in style_names:
            if raw_shares[s] > 0.0:
                r_s = growth_rate + STYLES[s]["premium"]
                raw_shares[s] *= (1.0 + r_s)

        total_raw = sum(raw_shares.values())
        if total_raw > 0:
            for s in style_names:
                style_shares[s][i] = clamp(raw_shares[s] / total_raw, 0.0, 1.0)
        else:
            for s in style_names:
                style_shares[s][i] = 0.0

        # Shannon diversity
        H = 0.0
        for s in style_names:
            sh = style_shares[s][i]
            if sh > 1e-12:
                H -= sh * math.log(sh)
        style_diversity[i] = clamp(H, 0.0, 4.0)

    # ── Sodium content (slight variation) ─────────────────────────────────
    sodium_arr = np.zeros(n_years)
    for i in range(n_years):
        noise = np.random.normal(0, 50.0)
        sodium_arr[i] = clamp(SODIUM_CONTENT_MG + noise, 1000.0, 10000.0)

    # ── Build output rows ─────────────────────────────────────────────────
    rows = []
    for i, yr in enumerate(years):
        for ri, region in enumerate(REGIONS):
            for si, style in enumerate(style_names):
                mkt = market_size[region][i]
                pc  = pizzeria_count[i] * REGION_MARKET_FRACTIONS_2017[region]
                pc  = clamp(pc, 0.0, 200000.0)
                avg_rev = (mkt * 1e9 / max(pc, 1.0)) if pc > 0 else 578947.0
                avg_rev = clamp(avg_rev, 0.0, 5e9)

                cheese = cheese_us[i] if region == "US" else (
                    cheese_eu[i] if region in ("Italy", "Europe_excl_Italy") else
                    clamp(eu_cheese_1997 * 0.1 * ((1.0 + growth_rate) ** (yr - 1997)), 0.0, 5000000.0)
                )

                annual_piz_mil = annual_pizzas[region][i] / 1e6

                attr = STYLE_ATTRIBUTES.get(style, [0]*9)

                row = {
                    "scenario_label":                 label,
                    "year":                           yr,
                    "region":                         region,
                    "market_size_usd_billion":        round(mkt, 4),
                    "pizzeria_count":                 round(pc, 1),
                    "daily_consumption_fraction":     round(clamp(consumption[region][i], 0.0, 1.0), 6),
                    "annual_pizzas_consumed_millions":round(annual_piz_mil, 4),
                    "cheese_production_metric_tons":  round(cheese, 1),
                    "regional_style":                 style,
                    "style_market_share":             round(style_shares[style][i], 6),
                    "style_first_attested_year":      STYLES[style]["first_year"],
                    "style_has_thin_crust":           attr[0],
                    "style_has_thick_crust":          attr[1],
                    "style_has_tomato_sauce":         attr[2],
                    "style_has_no_cheese":            attr[3],
                    "style_is_pan_baked":             attr[4],
                    "style_is_fried":                 attr[6],
                    "sodium_content_mg":              round(sodium_arr[i], 1),
                    "market_growth_rate":             round(growth_rate, 4),
                    "style_diversity_index":          round(style_diversity[i], 6),
                    "pizzeria_avg_revenue_usd":       round(avg_rev, 2),
                }
                rows.append(row)

    return rows, {
        "years": years,
        "world_market": world_market,
        "market_size": market_size,
        "pizzeria_count": pizzeria_count,
        "cheese_us": cheese_us,
        "cheese_eu": cheese_eu,
        "consumption": consumption,
        "annual_pizzas": annual_pizzas,
        "style_shares": style_shares,
        "style_diversity": style_diversity,
        "style_names": style_names,
        "growth_rate": growth_rate,
        "label": label,
    }


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE GENERATION
# ─────────────────────────────────────────────────────────────────────────────

SCENARIO_COLORS = {
    "baseline_global_2017":       "steelblue",
    "high_growth_projection":     "tomato",
    "low_growth_stagnation":      "olive",
    "regional_style_competition": "purple",
    "historical_diffusion_timeline": "darkorange",
    "cheese_production_scaling":  "seagreen",
}

SCENARIO_LS = {
    "baseline_global_2017":       "-",
    "high_growth_projection":     "--",
    "low_growth_stagnation":      ":",
    "regional_style_competition": "-.",
    "historical_diffusion_timeline": (0, (3,1,1,1)),
    "cheese_production_scaling":  (0, (5,2)),
}


def save_fig(fig, path):
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def fig1_market_size(all_results, out_dir):
    """Global and US Pizza Market Size Over Time."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(13, 5))
        ax_world, ax_us = axes

        plot_scenarios = ["baseline_global_2017", "high_growth_projection", "low_growth_stagnation"]

        for res in all_results:
            lbl = res["label"]
            if lbl not in plot_scenarios:
                continue
            yrs = np.array(res["years"])
            # World
            w = res["world_market"]
            mask = yrs >= 2017
            assert len(yrs[mask]) == len(w[mask])
            if np.any(mask):
                ax_world.plot(yrs[mask], w[mask],
                              color=SCENARIO_COLORS.get(lbl, "gray"),
                              ls=SCENARIO_LS.get(lbl, "-"),
                              lw=2, label=lbl.replace("_", " "))
            # US
            u = res["market_size"]["US"]
            assert len(yrs[mask]) == len(u[mask])
            if np.any(mask):
                ax_us.plot(yrs[mask], u[mask],
                           color=SCENARIO_COLORS.get(lbl, "gray"),
                           ls=SCENARIO_LS.get(lbl, "-"),
                           lw=2, label=lbl.replace("_", " "))

        ax_world.set_title("World Pizza Market Size (2017–2030)")
        ax_world.set_xlabel("Year")
        ax_world.set_ylabel("Market Size (billion USD)")
        ax_world.legend(fontsize=8)
        ax_world.grid(True, alpha=0.3)

        ax_us.set_title("US Pizza Market Size (2017–2030)")
        ax_us.set_xlabel("Year")
        ax_us.set_ylabel("Market Size (billion USD)")
        ax_us.legend(fontsize=8)
        ax_us.grid(True, alpha=0.3)

        fig.suptitle("Global and US Pizza Market Size Over Time (2017–2030)", fontsize=13, fontweight="bold")
        plt.tight_layout()
        save_fig(fig, out_dir / "fig1_market_size.png")
        print("  fig1 saved.")
    except Exception as e:
        print(f"  WARNING fig1 failed: {e}")


def fig2_pizzeria_count(all_results, out_dir):
    """US Pizzeria Count Growth Projection."""
    try:
        fig, ax = plt.subplots(figsize=(9, 5))
        plot_scenarios = ["baseline_global_2017", "high_growth_projection", "low_growth_stagnation"]

        for res in all_results:
            lbl = res["label"]
            if lbl not in plot_scenarios:
                continue
            yrs = np.array(res["years"])
            pc  = res["pizzeria_count"]
            mask = yrs >= 2017
            x_plot = yrs[mask]
            y_plot = pc[mask]
            assert len(x_plot) == len(y_plot)
            if len(x_plot) > 0:
                ax.plot(x_plot, y_plot,
                        color=SCENARIO_COLORS.get(lbl, "gray"),
                        ls=SCENARIO_LS.get(lbl, "-"),
                        lw=2, label=lbl.replace("_", " "))

        ax.axhline(76000, color="black", ls="--", alpha=0.5, label="2017 baseline (76,000)")
        ax.set_title("US Pizzeria Count Growth Projection (2017–2030)", fontsize=13, fontweight="bold")
        ax.set_xlabel("Year")
        ax.set_ylabel("Number of Pizzerias")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        save_fig(fig, out_dir / "fig2_pizzeria_count.png")
        print("  fig2 saved.")
    except Exception as e:
        print(f"  WARNING fig2 failed: {e}")


def fig3_annual_consumption(all_results, out_dir):
    """Historical Pizza Diffusion: Annual Consumption by Region."""
    try:
        # Use the historical_diffusion_timeline scenario for best coverage
        res = None
        for r in all_results:
            if r["label"] == "historical_diffusion_timeline":
                res = r
                break
        if res is None:
            res = all_results[0]

        fig, ax = plt.subplots(figsize=(11, 6))
        yrs = np.array(res["years"])
        regions_to_plot = ["Italy", "US", "Argentina", "Rest_of_World"]
        colors_r = ["green", "steelblue", "gold", "coral"]

        for region, color in zip(regions_to_plot, colors_r):
            ap = res["annual_pizzas"][region] / 1e6  # in millions
            assert len(yrs) == len(ap)
            # Only plot positive values for log scale
            valid = ap > 0.001
            if np.any(valid):
                ax.plot(yrs[valid], ap[valid], color=color, lw=2, label=region.replace("_", " "))

        ax.set_yscale("log")
        ax.set_title("Historical Pizza Diffusion: Annual Consumption by Region", fontsize=13, fontweight="bold")
        ax.set_xlabel("Year")
        ax.set_ylabel("Annual Pizzas Consumed (millions, log scale)")
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3, which="both")

        # Annotate key milestones
        for yr_ann, txt in [(1905, "First US\nPizzeria"), (2015, "BA: 14M\npizzas")]:
            if yr_ann in list(yrs):
                idx = list(yrs).index(yr_ann)
                ax.axvline(yr_ann, color="gray", ls=":", alpha=0.6)
                ax.text(yr_ann + 1, ax.get_ylim()[0] * 3, txt, fontsize=7, color="gray")

        plt.tight_layout()
        save_fig(fig, out_dir / "fig3_annual_consumption.png")
        print("  fig3 saved.")
    except Exception as e:
        print(f"  WARNING fig3 failed: {e}")


def fig4_style_emergence_histogram(out_dir):
    """Histogram of pizza style first-attested years."""
    try:
        fig, ax = plt.subplots(figsize=(9, 5))
        years_fa = np.array(list(STYLE_FIRST_ATTESTED.values()))
        bins = np.arange(1700, 2010, 10)
        counts, edges = np.histogram(years_fa, bins=bins)
        x_centers = (edges[:-1] + edges[1:]) / 2

        assert len(x_centers) == len(counts)
        ax.bar(x_centers, counts, width=9, color="saddlebrown", alpha=0.75, edgecolor="black", lw=0.5)
        ax.set_title("Distribution of Pizza Style Emergence Years", fontsize=13, fontweight="bold")
        ax.set_xlabel("Decade")
        ax.set_ylabel("Number of Distinct Pizza Styles")
        ax.grid(True, alpha=0.3, axis="y")

        # Annotate waves
        ax.axvspan(1700, 1760, alpha=0.1, color="orange", label="Italian origination wave")
        ax.axvspan(1940, 1990, alpha=0.1, color="blue",   label="N. American innovation burst")
        ax.legend(fontsize=8)
        plt.tight_layout()
        save_fig(fig, out_dir / "fig4_style_emergence.png")
        print("  fig4 saved.")
    except Exception as e:
        print(f"  WARNING fig4 failed: {e}")


def fig5_style_market_share(all_results, out_dir):
    """Regional pizza style market share competition over time."""
    try:
        # Use regional_style_competition if available, else baseline
        res = None
        for r in all_results:
            if r["label"] == "regional_style_competition":
                res = r
                break
        if res is None:
            res = all_results[0]

        fig, ax = plt.subplots(figsize=(12, 6))
        yrs = np.array(res["years"])
        mask = yrs >= 1950
        x_plot = yrs[mask]

        cmap = plt.cm.get_cmap("tab10", len(res["style_names"]))
        for si, style in enumerate(res["style_names"]):
            shares = res["style_shares"][style][mask]
            assert len(x_plot) == len(shares)
            ax.plot(x_plot, shares, color=cmap(si), lw=1.8,
                    label=style.replace("_", " "), alpha=0.85)
            ax.scatter(x_plot[::10], shares[::10], color=cmap(si), s=15, zorder=3)

        ax.set_title("Simulated Regional Pizza Style Market Share Competition", fontsize=13, fontweight="bold")
        ax.set_xlabel("Year")
        ax.set_ylabel("Fractional Market Share")
        ax.legend(fontsize=7, ncol=3, loc="upper left")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        save_fig(fig, out_dir / "fig5_style_shares.png")
        print("  fig5 saved.")
    except Exception as e:
        print(f"  WARNING fig5 failed: {e}")


def fig6_cheese_production(all_results, out_dir):
    """Cheese production scaling US vs Europe."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        ax2 = ax.twinx()

        plot_scenarios = ["baseline_global_2017", "high_growth_projection", "low_growth_stagnation"]

        for res in all_results:
            lbl = res["label"]
            if lbl not in plot_scenarios:
                continue
            yrs = np.array(res["years"])
            mask = yrs >= 1997
            x_plot = yrs[mask]
            cu = res["cheese_us"][mask]
            ce = res["cheese_eu"][mask]
            assert len(x_plot) == len(cu)
            assert len(x_plot) == len(ce)
            if len(x_plot) == 0:
                continue
            color = SCENARIO_COLORS.get(lbl, "gray")
            ls    = SCENARIO_LS.get(lbl, "-")
            ax.plot(x_plot, cu / 1e6, color=color, ls=ls, lw=2,
                    label=f"US {lbl.replace('_',' ')}")
            ax2.plot(x_plot, ce / 1e3, color=color, ls="--", lw=1.5,
                     alpha=0.7)

        ax.set_title("Pizza Cheese Production Scaling: US vs Europe (1997–2030)", fontsize=12, fontweight="bold")
        ax.set_xlabel("Year")
        ax.set_ylabel("US Cheese Production (million metric tons)", color="steelblue")
        ax2.set_ylabel("Europe Cheese Production (thousand metric tons)", color="tomato")
        ax.tick_params(axis="y", labelcolor="steelblue")
        ax2.tick_params(axis="y", labelcolor="tomato")
        ax.legend(fontsize=7, loc="upper left")
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        save_fig(fig, out_dir / "fig6_cheese_production.png")
        print("  fig6 saved.")
    except Exception as e:
        print(f"  WARNING fig6 failed: {e}")


def fig7_attribute_heatmap(out_dir):
    """Regional pizza style attribute matrix heatmap."""
    try:
        styles_list = list(STYLE_ATTRIBUTES.keys())
        n_styles = len(styles_list)
        n_attrs  = len(ATTRIBUTE_NAMES)
        matrix   = np.zeros((n_styles, n_attrs))
        for i, style in enumerate(styles_list):
            matrix[i] = STYLE_ATTRIBUTES[style]

        fig, ax = plt.subplots(figsize=(12, 7))
        im = ax.imshow(matrix, cmap="YlOrBr", aspect="auto", vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, label="Attribute Present (1) / Absent (0)")

        ax.set_xticks(range(n_attrs))
        ax.set_xticklabels(ATTRIBUTE_NAMES, rotation=40, ha="right", fontsize=9)
        ax.set_yticks(range(n_styles))
        ax.set_yticklabels([s.replace("_", " ") for s in styles_list], fontsize=9)
        ax.set_title("Regional Pizza Style Attribute Matrix", fontsize=13, fontweight="bold")
        ax.set_xlabel("Pizza Attribute")
        ax.set_ylabel("Pizza Style")

        # grid lines
        for x in np.arange(-0.5, n_attrs, 1):
            ax.axvline(x, color="white", lw=0.5)
        for y in np.arange(-0.5, n_styles, 1):
            ax.axhline(y, color="white", lw=0.5)

        plt.tight_layout()
        save_fig(fig, out_dir / "fig7_attribute_heatmap.png")
        print("  fig7 saved.")
    except Exception as e:
        print(f"  WARNING fig7 failed: {e}")


def fig8_daily_consumption(all_results, out_dir):
    """Daily pizza consumption fraction vs. market maturity (S-curves)."""
    try:
        # Use baseline scenario
        res = None
        for r in all_results:
            if r["label"] == "baseline_global_2017":
                res = r
                break
        if res is None:
            res = all_results[0]

        fig, ax = plt.subplots(figsize=(10, 6))
        yrs = np.array(res["years"])

        regions_plot = ["US", "Argentina", "Rest_of_World"]
        region_labels = ["US (mature, 13% sat.)", "Argentina (high density, 17% sat.)", "Developing Market (6% sat.)"]
        colors_p = ["steelblue", "gold", "coral"]

        for region, label_r, color in zip(regions_plot, region_labels, colors_p):
            entry = REGION_ENTRY_YEAR[region]
            mask  = yrs >= entry
            x_rel = yrs[mask] - entry  # years since entry
            c_vals = res["consumption"][region][mask]
            assert len(x_rel) == len(c_vals)
            if len(x_rel) > 0:
                ax.plot(x_rel, c_vals, color=color, lw=2.2, label=label_r)

        ax.set_title("Daily Pizza Consumption Fraction vs. Market Maturity", fontsize=13, fontweight="bold")
        ax.set_xlabel("Years Since First Significant Market Entry")
        ax.set_ylabel("Fraction of Population Consuming Pizza Daily")
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0, 0.22)
        plt.tight_layout()
        save_fig(fig, out_dir / "fig8_daily_consumption.png")
        print("  fig8 saved.")
    except Exception as e:
        print(f"  WARNING fig8 failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# CSV WRITERS
# ─────────────────────────────────────────────────────────────────────────────
FIELDNAMES = [
    "scenario_label", "year", "region",
    "market_size_usd_billion", "pizzeria_count", "daily_consumption_fraction",
    "annual_pizzas_consumed_millions", "cheese_production_metric_tons",
    "regional_style", "style_market_share", "style_first_attested_year",
    "style_has_thin_crust", "style_has_thick_crust", "style_has_tomato_sauce",
    "style_has_no_cheese", "style_is_pan_baked", "style_is_fried",
    "sodium_content_mg", "market_growth_rate", "style_diversity_index",
    "pizzeria_avg_revenue_usd",
]


def write_simulation_outputs(all_rows: List[Dict], out_dir: pathlib.Path):
    path = out_dir / "simulation_outputs.csv"
    if not all_rows:
        print("  WARNING: no rows to write to simulation_outputs.csv")
        return
    try:
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({k: row.get(k, "") for k in FIELDNAMES})
        print(f"  simulation_outputs.csv written ({len(all_rows)} rows).")
    except Exception as e:
        print(f"  WARNING: simulation_outputs.csv write failed: {e}")


def write_scenario_summary(all_results_data, out_dir: pathlib.Path):
    path = out_dir / "scenario_summary.csv"
    summaries = []
    for res in all_results_data:
        lbl = res["label"]
        wm  = res["world_market"]
        pc  = res["pizzeria_count"]
        cu  = res["cheese_us"]
        us_cons = res["consumption"]["US"]
        div = res["style_diversity"]

        summaries.append({
            "scenario_label": lbl,
            "growth_rate": round(res["growth_rate"], 4),
            "world_market_mean_bn_usd": round(float(np.mean(wm)), 4),
            "world_market_std_bn_usd":  round(float(np.std(wm)), 4),
            "world_market_min_bn_usd":  round(float(np.min(wm)), 4),
            "world_market_max_bn_usd":  round(float(np.max(wm)), 4),
            "pizzeria_count_mean":      round(float(np.mean(pc)), 1),
            "pizzeria_count_max":       round(float(np.max(pc)), 1),
            "cheese_us_mean_mt":        round(float(np.mean(cu)), 1),
            "cheese_us_max_mt":         round(float(np.max(cu)), 1),
            "us_consumption_final":     round(float(us_cons[-1]), 6),
            "style_diversity_mean":     round(float(np.mean(div)), 4),
            "style_diversity_final":    round(float(div[-1]), 4),
        })

    if not summaries:
        print("  WARNING: no data for scenario_summary.csv")
        return
    try:
        fields = list(summaries[0].keys())
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(summaries)
        print(f"  scenario_summary.csv written ({len(summaries)} rows).")
    except Exception as e:
        print(f"  WARNING: scenario_summary.csv write failed: {e}")


def write_parameters_used(out_dir: pathlib.Path):
    path = out_dir / "parameters_used.csv"
    rows = []
    for name, meta in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name":        name,
            "value":       meta["value"],
            "unit":        meta["unit"],
            "source":      meta["source"],
            "description": meta["description"],
        })
    if not rows:
        print("  WARNING: no parameters to write.")
        return
    try:
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
            writer.writeheader()
            writer.writerows(rows)
        print(f"  parameters_used.csv written ({len(rows)} rows).")
    except Exception as e:
        print(f"  WARNING: parameters_used.csv write failed: {e}")


def write_summary_json(all_results_data, out_dir: pathlib.Path):
    path = out_dir / "summary.json"
    summary = {"title": MODEL_PROFILE["title"], "scenarios": []}
    for res in all_results_data:
        wm   = res["world_market"]
        pc   = res["pizzeria_count"]
        entry = {
            "label": res["label"],
            "growth_rate": res["growth_rate"],
            "world_market_2017_bn_usd": 128.0,
            "world_market_final_bn_usd": round(float(wm[-1]), 2),
            "pizzeria_count_final": round(float(pc[-1]), 0),
            "us_daily_consumption_final": round(float(res["consumption"]["US"][-1]), 6),
            "style_diversity_final": round(float(res["style_diversity"][-1]), 4),
        }
        summary["scenarios"].append(entry)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(f"  summary.json written.")
    except Exception as e:
        print(f"  WARNING: summary.json write failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Pizza Market and Diffusion Simulator"
    )
    parser.add_argument("--output", default="./sim_outputs",
                        help="Output directory for all generated files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    all_rows = []
    all_results_data = []

    print("\n=== Running scenarios ===")
    for idx, scenario in enumerate(MODEL_PROFILE["scenarios"]):
        label = scenario["label"]
        print(f"  [{idx}] {label} ...")
        rows, result_data = run_scenario(scenario, idx)
        all_rows.extend(rows)
        all_results_data.append(result_data)
        print(f"       {len(rows)} rows generated.")

    print("\n=== Writing CSV files ===")
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(all_results_data, out_dir)
    write_parameters_used(out_dir)

    print("\n=== Writing JSON summary ===")
    write_summary_json(all_results_data, out_dir)

    print("\n=== Generating figures ===")
    fig1_market_size(all_results_data, out_dir)
    fig2_pizzeria_count(all_results_data, out_dir)
    fig3_annual_consumption(all_results_data, out_dir)
    fig4_style_emergence_histogram(out_dir)
    fig5_style_market_share(all_results_data, out_dir)
    fig6_cheese_production(all_results_data, out_dir)
    fig7_attribute_heatmap(out_dir)
    fig8_daily_consumption(all_results_data, out_dir)

    print("\n=== Simulation complete ===")
    print(f"All files saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()