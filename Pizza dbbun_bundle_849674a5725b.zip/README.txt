================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 0f7045e2-834b-4e54-a833-392a0c6ebe99
    Generated   : 2026-04-28  13:21:19 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Pizza: History, Varieties, and Global Market Dynamics

    CATEGORIES
    ----------
    Social Sciences, Financial, Demographic, Agriculture, Other

    KEYWORDS
    --------
    pizza market dynamics, regional food diffusion, cultural adoption S-curve, food industry economics, pizza style diversity

    ABSTRACT
    --------
    This simulator models the global pizza market and cultural diffusion dynamics based on documented historical milestones, market statistics, and regional variety data. It reproduces market growth trajectories anchored to the 2017 global ($128B) and US ($44B) pizza market figures, simulates logistic adoption curves for daily consumption fractions across regions, and tracks competitive market share evolution among nine major regional pizza styles from their first-attested dates to 2030. The simulator generates synthetic time-series data for market size, pizzeria counts, cheese production, and style diversity under three growth scenarios (baseline, high-growth, stagnation), producing both a comprehensive CSV dataset and eight publication-quality figures. Researchers studying food economics, cultural diffusion, and regional market dynamics can use this tool to explore adoption lifecycle patterns, scenario-test market projections, and visualize the comparative emergence of pizza varieties across culinary traditions.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Pizza.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    market_size_usd, pizzeria_count, daily_consumption_fraction, regional_style_share, adoption_year, cheese_production, sodium_content, annual_pizzas_consumed, market_growth_rate, style_diversity_index

    SCENARIOS  (6 total)
    ---------------------------------
        1. baseline_global_2017 — Reproduce the 2017 global and US market snapshot with known figures: $128B world, $44B US, 76000 pizzerias, 13% daily consumption
2. high_growth_projection — Optimistic scenario with 7% annual market growth, modeling accelerated global pizza adoption driven by delivery platforms and frozen pizza expansion
3. low_growth_stagnation — Conservative scenario with 1.5% annual growth reflecting market saturation in developed countries and health-conscious consumption trends
4. regional_style_competition — Simulate market share competition among 8 major regional styles (Neapolitan, New York, Chicago, California, Detroit, New Haven, St. Louis, Sicilian) with differential growth rates
5. historical_diffusion_timeline — Trace pizza's geographic spread from Naples (997 AD) through US adoption (1905) to global dominance (2017), modeling cumulative market penetration over time
6. cheese_production_scaling — Model cheese production scaling from 1997 baseline (1M metric tons US, 100K Europe) under different market growth assumptions to 2030

    PARAMETERS
    ----------
    20 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This source covers the comprehensive history, cultural origins, preparation methods, regional varieties, and global market economics of pizza, from its ancient flatbread precursors in Naples, Italy, to its current status as a worldwide $128 billion industry.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.