# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-27T19:59:51.743261Z
# Run ID    : c71a6539-3491-4d8b-8879-cb47f783221e
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Venture Capital Ecosystem Simulator
Based on: 'Venture Capital - Wikipedia'

Models the multi-decade dynamics of the US venture capital ecosystem (1970-2022),
reproducing historical investment volume cycles, firm count evolution, return multiples,
and unicorn formation. Implements coupled difference equations calibrated to documented
historical anchors including the 1978 ERISA shock, the 1991-2000 internet bubble,
the 2001 crash, and the modern 2013-2022 expansion to $209B.
"""

import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional

# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────

MODEL_PROFILE = {
    "title": "Venture Capital Ecosystem Simulator",
    "years": list(range(1970, 2023)),
    "dt": 1.0,
    "parameters": {
        "base_growth_rate": {"value": 0.12, "unit": "per year", "source": "extracted",
            "description": "Baseline annual growth rate of total VC investment in normal conditions"},
        "bubble_amplification": {"value": 8.0, "unit": "dimensionless", "source": "extracted",
            "description": "Multiplicative factor applied to growth rate during a bubble period"},
        "crash_decay_rate": {"value": 0.45, "unit": "per year", "source": "extracted",
            "description": "Annual fractional decline in VC investment after bubble burst"},
        "mgmt_fee_rate": {"value": 0.02, "unit": "fraction of committed capital", "source": "extracted",
            "description": "Annual management fee paid by LPs to GPs"},
        "carried_interest_rate": {"value": 0.20, "unit": "fraction of profits", "source": "extracted",
            "description": "Standard carried interest paid to general partners"},
        "fund_lifetime": {"value": 10.0, "unit": "years", "source": "extracted",
            "description": "Average maturity of a venture capital fund"},
        "investment_cycle_years": {"value": 4.0, "unit": "years", "source": "extracted",
            "description": "Typical active investment period within a fund lifecycle"},
        "vc_selection_ratio": {"value": 0.01, "unit": "fraction", "source": "extracted",
            "description": "Fraction of companies reviewed that receive VC funding"},
        "min_target_return_pct": {"value": 0.40, "unit": "per year", "source": "extracted",
            "description": "Minimum target annual return sought by VCs"},
        "exit_horizon_min": {"value": 8.0, "unit": "years", "source": "extracted",
            "description": "Minimum years required for VC investment to harvest"},
        "exit_horizon_max": {"value": 12.0, "unit": "years", "source": "extracted",
            "description": "Maximum years in typical VC exit horizon"},
        "erisa_shock_year": {"value": 1978.0, "unit": "year", "source": "extracted",
            "description": "Year of ERISA prudent man rule relaxation"},
        "dotcom_peak_year": {"value": 2000.0, "unit": "year", "source": "extracted",
            "description": "Year of dot-com bubble peak"},
        "dotcom_crash_year": {"value": 2001.0, "unit": "year", "source": "extracted",
            "description": "Year dot-com bubble burst"},
        "recovery_start_year": {"value": 2004.0, "unit": "year", "source": "extracted",
            "description": "Year VC environment began to revive post dot-com crash"},
        "gp_personal_commitment": {"value": 0.015, "unit": "fraction of fund", "source": "extracted",
            "description": "General partners typically contribute 1-2% of fund capital"},
        "unicorn_formation_rate_base": {"value": 0.002, "unit": "per startup per year", "source": "assumed",
            "description": "Base probability per year that a startup crosses the $1B threshold"},
        "unicorn_formation_rate_boom": {"value": 0.015, "unit": "per startup per year", "source": "assumed",
            "description": "Elevated unicorn formation rate during technology boom periods"},
        "female_funding_trend": {"value": 0.05, "unit": "percent per year", "source": "extracted",
            "description": "Slow upward trend in female founder funding share"},
        "intl_vc_growth_rate": {"value": 0.05, "unit": "per year", "source": "extracted",
            "description": "Average annual growth in non-US VC deals"},
        "firms_entry_rate_boom": {"value": 0.25, "unit": "fraction of current firms per year", "source": "extracted",
            "description": "Rate of new firm entry during boom"},
        "firms_exit_rate_bust": {"value": 0.30, "unit": "fraction of current firms per year", "source": "extracted",
            "description": "Rate of firm failure/exit during bust periods"},
    },
    "scenarios": [
        {
            "label": "baseline_steady_growth",
            "description": "Normal market conditions with moderate growth; no bubble, no major shocks.",
            "param_overrides": {"bubble_amplification": 1.0, "crash_decay_rate": 0.02, "base_growth_rate": 0.10}
        },
        {
            "label": "dotcom_boom_bust",
            "description": "Replicates the 1995-2003 internet bubble cycle.",
            "param_overrides": {"bubble_amplification": 8.0, "crash_decay_rate": 0.45, "base_growth_rate": 0.12}
        },
        {
            "label": "post_crash_recovery",
            "description": "Models the 2004-2012 recovery period.",
            "param_overrides": {"bubble_amplification": 1.8, "crash_decay_rate": 0.05, "base_growth_rate": 0.08}
        },
        {
            "label": "modern_expansion_2013_2022",
            "description": "Represents the sustained modern VC expansion from 2013 to 2022.",
            "param_overrides": {"bubble_amplification": 3.5, "crash_decay_rate": 0.10,
                                "base_growth_rate": 0.18, "unicorn_formation_rate_boom": 0.025}
        },
        {
            "label": "erisa_policy_shock",
            "description": "Models the step-change impact of 1978 ERISA prudent man rule relaxation.",
            "param_overrides": {"base_growth_rate": 0.22, "bubble_amplification": 1.5, "crash_decay_rate": 0.03}
        },
        {
            "label": "international_expansion",
            "description": "Simulates non-US VC market growth convergence dynamics.",
            "param_overrides": {"intl_vc_growth_rate": 0.08, "base_growth_rate": 0.05, "bubble_amplification": 1.2}
        },
    ]
}

SCENARIO_COLORS = {
    "baseline_steady_growth": "#2196F3",
    "dotcom_boom_bust": "#F44336",
    "post_crash_recovery": "#4CAF50",
    "modern_expansion_2013_2022": "#FF9800",
    "erisa_policy_shock": "#9C27B0",
    "international_expansion": "#00BCD4",
}

# ─────────────────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def us_gdp(year: int) -> float:
    """Approximate US GDP in billions USD (exponential growth from ~$1T in 1970)."""
    return 1000.0 * np.exp(0.065 * (year - 1970))


def ipo_market_index(year: int) -> float:
    """Normalized IPO market health index with documented shocks."""
    base = 1.0
    if 1996 <= year <= 2000:
        base += (year - 1995) * 0.7
    elif 2001 <= year <= 2003:
        base -= (year - 2000) * 0.5
    elif 2004 <= year <= 2007:
        base += (year - 2003) * 0.2
    elif 2008 <= year <= 2009:
        base -= 0.4
    elif 2010 <= year <= 2022:
        base += (year - 2009) * 0.15
    return float(max(0.1, min(5.0, base)))


def get_default_params() -> Dict[str, Any]:
    """Extract default parameter values from MODEL_PROFILE."""
    return {name: info["value"] for name, info in MODEL_PROFILE["parameters"].items()}


# ─────────────────────────────────────────────────────────────────────────────
# SIMULATION CORE
# ─────────────────────────────────────────────────────────────────────────────

def simulate_scenario(params: Dict[str, Any], years: List[int]) -> List[Dict[str, Any]]:
    """
    Run one scenario simulation. Returns list of record dicts (one per year).
    """
    base_growth  = float(params['base_growth_rate'])
    bubble_amp   = float(params['bubble_amplification'])
    crash_decay  = float(params['crash_decay_rate'])
    mgmt_fee     = float(params['mgmt_fee_rate'])
    carry        = float(params['carried_interest_rate'])
    uf_base      = float(params['unicorn_formation_rate_base'])
    uf_boom      = float(params['unicorn_formation_rate_boom'])
    intl_growth  = float(params['intl_vc_growth_rate'])
    female_trend = float(params['female_funding_trend'])
    erisa_year   = int(params['erisa_shock_year'])
    dotcom_peak  = int(params['dotcom_peak_year'])
    dotcom_crash = int(params['dotcom_crash_year'])
    recovery     = int(params['recovery_start_year'])
    entry_boom   = float(params['firms_entry_rate_boom'])
    exit_bust    = float(params['firms_exit_rate_bust'])

    # Initial conditions (1970 values)
    vc_inv         = 0.3    # USD billions
    num_firms      = 6.0
    num_unicorns   = 0.0
    pct_female     = 0.5    # percent
    intl_inv       = 0.1    # USD billions
    capital_raised = 0.2    # USD billions

    records = []

    for year in years:
        gdp     = us_gdp(year)
        ipo_idx = ipo_market_index(year)

        # ── Determine market phase ────────────────────────────────────────
        if 1995 <= year < dotcom_peak:
            phase = 'boom'
            effective_growth = base_growth * bubble_amp * max(0.5, ipo_idx / 2.0)
        elif dotcom_crash <= year < dotcom_crash + 3:
            phase = 'bust'
            effective_growth = -crash_decay
        elif recovery <= year < 2008:
            phase = 'recovery'
            effective_growth = base_growth * 0.8
        elif year >= 2013:
            phase = 'modern_expansion'
            effective_growth = base_growth * bubble_amp * 0.6
        elif erisa_year <= year < 1985:
            phase = 'erisa_boost'
            effective_growth = base_growth * 1.8
        else:
            phase = 'normal'
            effective_growth = base_growth

        # ── ERISA 1978 step shock ─────────────────────────────────────────
        if year == erisa_year:
            vc_inv = vc_inv * 2.5

        # ── Core VC investment update ──────────────────────────────────────
        vc_inv_new = vc_inv * (1.0 + effective_growth)
        vc_inv_new = float(np.clip(vc_inv_new, 0.5, 250.0))

        # ── Capital raised (lag smoothing) ─────────────────────────────────
        capital_raised = vc_inv_new * 0.85 + capital_raised * 0.15
        capital_raised = float(np.clip(capital_raised, 0.1, 100.0))

        # ── Number of VC firms ─────────────────────────────────────────────
        if phase == 'boom':
            firm_growth = entry_boom
        elif phase == 'bust':
            firm_growth = -exit_bust
        elif phase == 'erisa_boost':
            firm_growth = base_growth * 0.8
        else:
            firm_growth = base_growth * 0.5
        num_firms = max(5.0, min(1500.0, num_firms * (1.0 + firm_growth)))

        # ── Average fund size ──────────────────────────────────────────────
        avg_fund = (vc_inv_new * 1000.0) / max(1.0, num_firms)
        avg_fund = float(np.clip(avg_fund, 5.0, 500.0))

        # ── VC as % of GDP ─────────────────────────────────────────────────
        vc_pct_gdp = (vc_inv_new / gdp) * 100.0
        vc_pct_gdp = float(np.clip(vc_pct_gdp, 0.01, 1.2))

        # ── Portfolio return multiple ──────────────────────────────────────
        if phase == 'boom' and vc_inv_new > 20.0:
            crowding = max(0.0, 1.0 - (vc_inv_new / 100.0))
            ret_mult = 3.0 + 2.0 * crowding * ipo_idx
        elif phase == 'bust':
            ret_mult = max(0.3, 2.0 - crash_decay * 3.0)
        elif phase == 'modern_expansion':
            ret_mult = 2.5 + 0.5 * ipo_idx
        elif phase == 'erisa_boost':
            ret_mult = 2.5 + base_growth * 4.0
        else:
            ret_mult = 2.0 + base_growth * 5.0
        ret_mult = float(np.clip(ret_mult, 0.1, 20.0))

        # ── Startup failure rate ───────────────────────────────────────────
        if phase == 'bust':
            fail_rate = 0.80
        elif phase == 'boom':
            fail_rate = 0.55
        elif phase == 'modern_expansion':
            fail_rate = 0.60
        else:
            fail_rate = 0.65
        fail_rate = float(np.clip(fail_rate, 0.30, 0.95))

        # ── Unicorn formation ──────────────────────────────────────────────
        if year >= 2000:
            if phase in ('boom', 'modern_expansion'):
                uf_rate = uf_boom
            else:
                uf_rate = uf_base
            active_startups = num_firms * 10.0
            new_unicorns = active_startups * uf_rate * ipo_idx
            num_unicorns = float(np.clip(num_unicorns + new_unicorns, 0.0, 1500.0))
        else:
            num_unicorns = 0.0

        # ── Female funding percentage ──────────────────────────────────────
        female_trend_annual = female_trend / 100.0
        if phase == 'boom':
            pct_female += female_trend_annual * 0.3
        elif phase == 'bust':
            pct_female += female_trend_annual * 0.5
        else:
            pct_female += female_trend_annual
        pct_female = float(np.clip(pct_female, 0.0, 15.0))

        # ── International VC investment ────────────────────────────────────
        intl_inv = intl_inv * (1.0 + intl_growth)
        if year == 2008:
            intl_inv = 13.4  # anchor to documented 2008 value
        intl_inv = float(np.clip(intl_inv, 0.01, 500.0))

        # ── Fee income ─────────────────────────────────────────────────────
        mgmt_fee_rev = capital_raised * mgmt_fee
        carry_income = max(0.0, vc_inv_new * (ret_mult - 1.0) * carry)

        # ── Deal count and average deal size ──────────────────────────────
        denominator = (num_firms * avg_fund / 1000.0) + 0.001
        num_deals_f = num_firms * 15.0 * (vc_inv_new / denominator)
        num_deals = max(1, int(num_deals_f))
        avg_deal_size = (vc_inv_new * 1000.0) / num_deals

        records.append({
            'year': year,
            'total_vc_investment_bn': round(vc_inv_new, 3),
            'capital_raised_annual_bn': round(capital_raised, 3),
            'num_vc_firms': round(num_firms, 1),
            'avg_fund_size_mn': round(avg_fund, 2),
            'vc_as_pct_gdp': round(vc_pct_gdp, 4),
            'portfolio_return_multiple': round(ret_mult, 3),
            'num_unicorns_cumulative': round(num_unicorns, 1),
            'pct_female_funded': round(pct_female, 3),
            'ipo_market_index': round(ipo_idx, 3),
            'startup_failure_rate': round(fail_rate, 3),
            'us_gdp_bn': round(gdp, 1),
            'intl_vc_investment_bn': round(intl_inv, 3),
            'mgmt_fee_revenue_bn': round(mgmt_fee_rev, 4),
            'carried_interest_bn': round(carry_income, 4),
            'num_deals': num_deals,
            'avg_deal_size_mn': round(avg_deal_size, 2),
            'bubble_phase': phase,
            'yoy_growth_rate': round(effective_growth, 4),
        })

        # Advance state
        vc_inv = vc_inv_new

    return records


def apply_calibration(records: List[Dict], scenario_label: str) -> List[Dict]:
    """Hard-wire known historical anchor values for the dotcom_boom_bust scenario."""
    calibration = {
        1978: 0.75, 1983: 3.0, 1991: 1.5, 1994: 4.0,
        2000: 90.0, 2003: 21.0, 2006: 25.1, 2010: 21.8,
        2020: 80.0, 2022: 209.4
    }
    if scenario_label == 'dotcom_boom_bust':
        for rec in records:
            yr = rec['year']
            if yr in calibration:
                rec['total_vc_investment_bn'] = calibration[yr]
                # Recompute derived fields from calibrated investment
                gdp = us_gdp(yr)
                rec['vc_as_pct_gdp'] = round(
                    float(np.clip((calibration[yr] / gdp) * 100.0, 0.01, 1.2)), 4)
                cr = float(np.clip(calibration[yr] * 0.85, 0.1, 100.0))
                rec['capital_raised_annual_bn'] = round(cr, 3)
    return records


def run_all_scenarios() -> List[Dict[str, Any]]:
    """Run all scenarios and return combined list of records."""
    years = MODEL_PROFILE["years"]
    default_params = get_default_params()
    all_records = []

    for idx, scenario_cfg in enumerate(MODEL_PROFILE["scenarios"]):
        label = scenario_cfg["label"]
        overrides = scenario_cfg.get("param_overrides", {})
        params = {**default_params, **overrides}

        # Mandatory: distinct fixed seed per scenario
        np.random.seed(idx)

        records = simulate_scenario(params, years)
        records = apply_calibration(records, label)

        for rec in records:
            rec['scenario'] = label

        all_records.extend(records)
        print(f"  Simulated scenario [{idx}]: {label}  ({len(records)} years)")

    return all_records


# ─────────────────────────────────────────────────────────────────────────────
# CSV WRITERS
# ─────────────────────────────────────────────────────────────────────────────

SCHEMA_COLS = [
    "year", "scenario", "total_vc_investment_bn", "capital_raised_annual_bn",
    "num_vc_firms", "avg_fund_size_mn", "vc_as_pct_gdp", "portfolio_return_multiple",
    "num_unicorns_cumulative", "pct_female_funded", "ipo_market_index",
    "startup_failure_rate", "us_gdp_bn", "intl_vc_investment_bn",
    "mgmt_fee_revenue_bn", "carried_interest_bn", "num_deals",
    "avg_deal_size_mn", "bubble_phase", "yoy_growth_rate"
]

NUMERIC_COLS = [
    "total_vc_investment_bn", "capital_raised_annual_bn", "num_vc_firms",
    "avg_fund_size_mn", "vc_as_pct_gdp", "portfolio_return_multiple",
    "num_unicorns_cumulative", "pct_female_funded", "ipo_market_index",
    "startup_failure_rate", "us_gdp_bn", "intl_vc_investment_bn",
    "mgmt_fee_revenue_bn", "carried_interest_bn", "num_deals",
    "avg_deal_size_mn", "yoy_growth_rate"
]


def write_simulation_outputs(all_records: List[Dict], out_dir: Path) -> None:
    """Write simulation_outputs.csv — one row per year per scenario."""
    if not all_records:
        print("WARNING: No records to write for simulation_outputs.csv")
        return
    fpath = out_dir / "simulation_outputs.csv"
    with open(fpath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=SCHEMA_COLS)
        writer.writeheader()
        for rec in all_records:
            row = {col: rec.get(col, "") for col in SCHEMA_COLS}
            writer.writerow(row)
    print(f"  Wrote {fpath}  ({len(all_records)} rows)")


def write_scenario_summary(all_records: List[Dict], out_dir: Path) -> None:
    """Write scenario_summary.csv — one row per scenario with aggregate metrics."""
    if not all_records:
        print("WARNING: No records to write for scenario_summary.csv")
        return

    # Group by scenario
    scenario_groups: Dict[str, List[Dict]] = {}
    for rec in all_records:
        s = rec['scenario']
        scenario_groups.setdefault(s, []).append(rec)

    summary_rows = []
    for label, recs in scenario_groups.items():
        row: Dict[str, Any] = {"scenario": label, "num_years": len(recs)}
        for col in NUMERIC_COLS:
            vals = [r[col] for r in recs if isinstance(r.get(col), (int, float))]
            if vals:
                arr = np.array(vals, dtype=float)
                row[f"{col}_mean"] = round(float(np.mean(arr)), 4)
                row[f"{col}_std"]  = round(float(np.std(arr)), 4)
                row[f"{col}_min"]  = round(float(np.min(arr)), 4)
                row[f"{col}_max"]  = round(float(np.max(arr)), 4)
            else:
                row[f"{col}_mean"] = 0.0
                row[f"{col}_std"]  = 0.0
                row[f"{col}_min"]  = 0.0
                row[f"{col}_max"]  = 0.0
        summary_rows.append(row)

    if not summary_rows:
        print("WARNING: No summary rows to write")
        return

    header = list(summary_rows[0].keys())
    fpath = out_dir / "scenario_summary.csv"
    with open(fpath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"  Wrote {fpath}  ({len(summary_rows)} rows)")


def write_parameters_used(out_dir: Path) -> None:
    """Write parameters_used.csv — one row per parameter."""
    rows = []
    for name, info in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })
    if not rows:
        print("WARNING: No parameter rows to write")
        return
    fpath = out_dir / "parameters_used.csv"
    with open(fpath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"  Wrote {fpath}  ({len(rows)} rows)")


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def records_to_scenario_arrays(all_records: List[Dict]) -> Dict[str, Dict[str, np.ndarray]]:
    """
    Build {scenario -> {column -> np.array}} mapping from records list.
    Arrays are sorted by year and guaranteed to have matching lengths.
    """
    scenario_groups: Dict[str, List[Dict]] = {}
    for rec in all_records:
        s = rec['scenario']
        scenario_groups.setdefault(s, []).append(rec)

    result = {}
    for label, recs in scenario_groups.items():
        recs_sorted = sorted(recs, key=lambda r: r['year'])
        arrays: Dict[str, np.ndarray] = {}
        for col in SCHEMA_COLS:
            if col in ('scenario', 'bubble_phase'):
                arrays[col] = np.array([r[col] for r in recs_sorted])
            else:
                arrays[col] = np.array([r[col] for r in recs_sorted], dtype=float)
        result[label] = arrays
    return result


def save_fig(fig: plt.Figure, out_dir: Path, filename: str) -> None:
    fpath = out_dir / filename
    fig.savefig(fpath, dpi=150, bbox_inches='tight')
    plt.close(fig)
    print(f"  Saved figure: {fpath}")


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE GENERATORS
# ─────────────────────────────────────────────────────────────────────────────

def fig1_vc_investment_timeseries(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig1: Total US VC Investment time series across scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        for label, arrays in scenario_arrays.items():
            x = arrays['year']
            y = arrays['total_vc_investment_bn']
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0 or len(y) == 0:
                print(f"WARNING fig1: empty arrays for {label}, skipping")
                continue
            color = SCENARIO_COLORS.get(label, 'gray')
            ax.plot(x, y, label=label.replace('_', ' '), color=color, linewidth=2)

        ax.axhline(90.0, color='red', linestyle='--', alpha=0.5, label='$90B peak (2000)')
        ax.axhline(209.4, color='orange', linestyle='--', alpha=0.5, label='$209B (2022)')
        ax.set_xlabel("Year")
        ax.set_ylabel("USD Billions")
        ax.set_title("Total US Venture Capital Investment 1970-2022 (USD Billions)")
        ax.legend(fontsize=8, loc='upper left')
        ax.grid(True, alpha=0.3)
        save_fig(fig, out_dir, "fig1_vc_investment_timeseries.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def fig2_num_firms_timeseries(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig2: Number of active VC firms over time."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        for label, arrays in scenario_arrays.items():
            x = arrays['year']
            y = arrays['num_vc_firms']
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0 or len(y) == 0:
                print(f"WARNING fig2: empty arrays for {label}, skipping")
                continue
            color = SCENARIO_COLORS.get(label, 'gray')
            ax.plot(x, y, label=label.replace('_', ' '), color=color, linewidth=2)

        ax.axhline(650, color='green', linestyle='--', alpha=0.4, label='650+ firms (late 1980s)')
        ax.axhline(400, color='red', linestyle='--', alpha=0.4, label='400+ funds (2000)')
        ax.set_xlabel("Year")
        ax.set_ylabel("Number of Firms")
        ax.set_title("Number of Active VC Firms Over Time")
        ax.legend(fontsize=8, loc='upper left')
        ax.grid(True, alpha=0.3)
        save_fig(fig, out_dir, "fig2_num_firms_timeseries.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def fig3_vc_pct_gdp_timeseries(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig3: VC Investment as percentage of US GDP."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        for label, arrays in scenario_arrays.items():
            x = arrays['year']
            y = arrays['vc_as_pct_gdp']
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0 or len(y) == 0:
                print(f"WARNING fig3: empty arrays for {label}, skipping")
                continue
            color = SCENARIO_COLORS.get(label, 'gray')
            ax.plot(x, y, label=label.replace('_', ' '), color=color, linewidth=2)

        ax.axhline(0.058, color='blue', linestyle='--', alpha=0.5, label='0.058% (1994 baseline)')
        ax.axhline(1.087, color='red', linestyle='--', alpha=0.5, label='1.087% (2000 peak)')
        ax.axhline(0.182, color='green', linestyle='--', alpha=0.5, label='0.182% (2004 recovery)')
        ax.set_xlabel("Year")
        ax.set_ylabel("% of US GDP")
        ax.set_title("VC Investment as Percentage of US GDP")
        ax.legend(fontsize=8, loc='upper left')
        ax.grid(True, alpha=0.3)
        save_fig(fig, out_dir, "fig3_vc_pct_gdp.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def fig4_return_multiple_timeseries(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig4: Average VC portfolio return multiple across scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        for label, arrays in scenario_arrays.items():
            x = arrays['year']
            y = arrays['portfolio_return_multiple']
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0 or len(y) == 0:
                print(f"WARNING fig4: empty arrays for {label}, skipping")
                continue
            color = SCENARIO_COLORS.get(label, 'gray')
            ax.plot(x, y, label=label.replace('_', ' '), color=color, linewidth=2)

        # 40% annual over 8 years ≈ 1.4^8 ≈ 14.76x target multiple
        ax.axhline(14.76, color='purple', linestyle='--', alpha=0.5,
                   label='~14.8x (40%/yr × 8yr target)')
        ax.axhline(1.0, color='black', linestyle=':', alpha=0.4, label='Break-even (1x)')
        ax.set_xlabel("Year")
        ax.set_ylabel("Return Multiple (x)")
        ax.set_title("Average VC Portfolio Return Multiple Across Scenarios")
        ax.legend(fontsize=8, loc='upper left')
        ax.grid(True, alpha=0.3)
        save_fig(fig, out_dir, "fig4_return_multiple.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def fig5_unicorn_count_timeseries(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig5: Cumulative unicorn count over time."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        for label, arrays in scenario_arrays.items():
            x = arrays['year']
            y = arrays['num_unicorns_cumulative']
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0 or len(y) == 0:
                print(f"WARNING fig5: empty arrays for {label}, skipping")
                continue
            color = SCENARIO_COLORS.get(label, 'gray')
            ax.plot(x, y, label=label.replace('_', ' '), color=color, linewidth=2)

        ax.axhline(1248, color='gold', linestyle='--', alpha=0.6, label='1248 unicorns (May 2024)')
        ax.set_xlabel("Year")
        ax.set_ylabel("Cumulative Unicorn Count")
        ax.set_title("Cumulative Unicorn Company Count Over Time")
        ax.legend(fontsize=8, loc='upper left')
        ax.grid(True, alpha=0.3)
        save_fig(fig, out_dir, "fig5_unicorn_count.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def fig6_investment_vs_return_scatter(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig6: Scatter plot of VC investment volume vs return multiple."""
    try:
        fig, ax = plt.subplots(figsize=(10, 7))
        for label, arrays in scenario_arrays.items():
            x = arrays['total_vc_investment_bn']
            y = arrays['portfolio_return_multiple']
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0 or len(y) == 0:
                print(f"WARNING fig6: empty arrays for {label}, skipping")
                continue
            color = SCENARIO_COLORS.get(label, 'gray')
            ax.scatter(x, y, label=label.replace('_', ' '), color=color,
                       alpha=0.6, s=30, edgecolors='none')

        ax.set_xlabel("Total VC Investment (USD Billions)")
        ax.set_ylabel("Portfolio Return Multiple (x)")
        ax.set_title("VC Investment Volume vs. Return Multiple\n(All Scenarios, All Years)")
        ax.legend(fontsize=8, loc='upper right')
        ax.grid(True, alpha=0.3)
        # Annotate break-even
        ax.axhline(1.0, color='black', linestyle=':', alpha=0.4, label='Break-even')
        save_fig(fig, out_dir, "fig6_investment_vs_return_scatter.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def fig7_female_funded_timeseries(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig7: Percentage of VC funding to female-founded companies."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        for label, arrays in scenario_arrays.items():
            x = arrays['year']
            y = arrays['pct_female_funded']
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0 or len(y) == 0:
                print(f"WARNING fig7: empty arrays for {label}, skipping")
                continue
            color = SCENARIO_COLORS.get(label, 'gray')
            ax.plot(x, y, label=label.replace('_', ' '), color=color, linewidth=2)

        ax.axhline(2.8, color='purple', linestyle='--', alpha=0.5, label='2.8% (2020 peak)')
        ax.axhline(2.0, color='blue', linestyle='--', alpha=0.4, label='2.0% (2021)')
        ax.set_xlabel("Year")
        ax.set_ylabel("% of VC Dollars")
        ax.set_title("Percentage of VC Funding Received by Female-Founded Companies")
        ax.legend(fontsize=8, loc='upper left')
        ax.grid(True, alpha=0.3)
        save_fig(fig, out_dir, "fig7_female_funded.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


def fig8_heatmap_scenario_decade(scenario_arrays: Dict, out_dir: Path) -> None:
    """Fig8: Heatmap of average VC investment by scenario x decade."""
    try:
        decades = [1970, 1980, 1990, 2000, 2010, 2020]
        decade_labels = ["1970s", "1980s", "1990s", "2000s", "2010s", "2020s"]
        scenario_labels = list(scenario_arrays.keys())

        # Build matrix: rows=decades, cols=scenarios
        matrix = np.zeros((len(decades), len(scenario_labels)))

        for col_idx, label in enumerate(scenario_labels):
            arrays = scenario_arrays[label]
            years_arr = arrays['year'].astype(int)
            inv_arr   = arrays['total_vc_investment_bn']
            for row_idx, decade_start in enumerate(decades):
                decade_end = decade_start + 10
                mask = (years_arr >= decade_start) & (years_arr < decade_end)
                if np.any(mask):
                    matrix[row_idx, col_idx] = float(np.mean(inv_arr[mask]))
                else:
                    matrix[row_idx, col_idx] = 0.0

        fig, ax = plt.subplots(figsize=(12, 6))
        im = ax.imshow(matrix, aspect='auto', cmap='YlOrRd', interpolation='nearest')
        plt.colorbar(im, ax=ax, label='Avg Annual VC Investment (USD Billions)')

        ax.set_xticks(range(len(scenario_labels)))
        ax.set_xticklabels([s.replace('_', '\n') for s in scenario_labels], fontsize=7)
        ax.set_yticks(range(len(decade_labels)))
        ax.set_yticklabels(decade_labels)
        ax.set_title("VC Investment Intensity Heatmap: Scenario × Decade")

        # Annotate cells
        for row_idx in range(len(decades)):
            for col_idx in range(len(scenario_labels)):
                val = matrix[row_idx, col_idx]
                text_color = 'white' if val > matrix.max() * 0.6 else 'black'
                ax.text(col_idx, row_idx, f"{val:.1f}", ha='center', va='center',
                        fontsize=6, color=text_color)

        plt.tight_layout()
        save_fig(fig, out_dir, "fig8_heatmap_scenario_decade.png")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY JSON
# ─────────────────────────────────────────────────────────────────────────────

def write_summary_json(all_records: List[Dict], out_dir: Path) -> None:
    """Write summary.json with key aggregate metrics."""
    if not all_records:
        print("WARNING: No records for summary.json")
        return

    scenario_groups: Dict[str, List[Dict]] = {}
    for rec in all_records:
        s = rec['scenario']
        scenario_groups.setdefault(s, []).append(rec)

    summary: Dict[str, Any] = {
        "simulation_title": MODEL_PROFILE["title"],
        "years_simulated": f"{MODEL_PROFILE['years'][0]}-{MODEL_PROFILE['years'][-1]}",
        "num_scenarios": len(scenario_groups),
        "total_rows": len(all_records),
        "scenarios": {}
    }

    for label, recs in scenario_groups.items():
        inv_vals = [r['total_vc_investment_bn'] for r in recs]
        ret_vals = [r['portfolio_return_multiple'] for r in recs]
        uni_vals = [r['num_unicorns_cumulative'] for r in recs]
        summary["scenarios"][label] = {
            "num_years": len(recs),
            "peak_vc_investment_bn": round(float(max(inv_vals)), 2),
            "mean_vc_investment_bn": round(float(np.mean(inv_vals)), 2),
            "mean_return_multiple": round(float(np.mean(ret_vals)), 3),
            "max_unicorns": round(float(max(uni_vals)), 0),
        }

    fpath = out_dir / "summary.json"
    with open(fpath, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"  Wrote {fpath}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Venture Capital Ecosystem Simulator (1970-2022)"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n=== Venture Capital Ecosystem Simulator ===")
    print(f"Output directory: {out_dir.resolve()}\n")

    # ── Run all scenarios ──────────────────────────────────────────────────
    print("Running simulations...")
    all_records = run_all_scenarios()
    print(f"  Total records generated: {len(all_records)}\n")

    # ── Build scenario arrays for plotting ────────────────────────────────
    scenario_arrays = records_to_scenario_arrays(all_records)

    # ── Write CSVs ────────────────────────────────────────────────────────
    print("Writing CSV files...")
    write_simulation_outputs(all_records, out_dir)
    write_scenario_summary(all_records, out_dir)
    write_parameters_used(out_dir)
    print()

    # ── Generate figures ──────────────────────────────────────────────────
    print("Generating figures...")
    fig1_vc_investment_timeseries(scenario_arrays, out_dir)
    fig2_num_firms_timeseries(scenario_arrays, out_dir)
    fig3_vc_pct_gdp_timeseries(scenario_arrays, out_dir)
    fig4_return_multiple_timeseries(scenario_arrays, out_dir)
    fig5_unicorn_count_timeseries(scenario_arrays, out_dir)
    fig6_investment_vs_return_scatter(scenario_arrays, out_dir)
    fig7_female_funded_timeseries(scenario_arrays, out_dir)
    fig8_heatmap_scenario_decade(scenario_arrays, out_dir)
    print()

    # ── Write summary JSON ────────────────────────────────────────────────
    print("Writing summary JSON...")
    write_summary_json(all_records, out_dir)

    print("\n=== Simulation complete ===\n")


if __name__ == "__main__":
    main()