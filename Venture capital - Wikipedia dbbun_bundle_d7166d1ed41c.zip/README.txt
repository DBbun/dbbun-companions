================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : c71a6539-3491-4d8b-8879-cb47f783221e
    Generated   : 2026-04-27  19:59:51 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Venture Capital - Wikipedia

    CATEGORIES
    ----------
    Financial, Social Sciences, Computational Intelligence

    KEYWORDS
    --------
    venture capital, startup financing, private equity, investment dynamics, dot-com bubble

    ABSTRACT
    --------
    This simulator models the multi-decade dynamics of the US venture capital ecosystem, reproducing historical investment volume cycles, firm count evolution, return multiples, and unicorn formation from 1970 to 2022. It implements coupled difference equations calibrated to documented historical anchors including the 1978 ERISA shock, the 1991-2000 internet bubble (investment growth from $1.5B to $90B), the 2001 crash, and the modern 2013-2022 expansion to $209B. Six distinct scenarios spanning steady growth, bubble-bust, policy shock, and international expansion allow systematic comparison of how macroeconomic conditions, regulatory changes, and market sentiment shape VC industry structure. Researchers, educators, and financial analysts can use the synthetic dataset and publication-quality figures to study feedback loops between capital availability, firm entry/exit, and investment returns without requiring proprietary fund-level data.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Venture capital - Wikipedia.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    total_vc_investment, num_vc_firms, avg_fund_size, vc_as_pct_gdp, portfolio_return_multiple, num_unicorns, pct_female_funded, ipo_market_index, startup_failure_rate, capital_raised_annual

    SCENARIOS  (6 total)
    ---------------------------------
        1. baseline_steady_growth — Normal market conditions with moderate growth from 1970 to 1990; no bubble, no major shocks. Models organic industry expansion from ~$3B to ~$4B over a decade.
2. dotcom_boom_bust — Replicates the 1995-2003 internet bubble cycle: rapid capital inflow from $1.5B in 1991 to $90B in 2000, followed by catastrophic crash to ~$21B trough by 2003, then gradual recovery.
3. post_crash_recovery — Models the 2004-2012 recovery period with moderate reinvestment driven by Web 2.0 and mobile technology trends; investment stabilizes in $20-30B range.
4. modern_expansion_2013_2022 — Represents the sustained modern VC expansion from $6.4B in Q1 2013 to $209.4B in 2022, fueled by unicorn proliferation and global expansion; includes 2022 brief pullback.
5. erisa_policy_shock — Models the step-change impact of 1978 ERISA prudent man rule relaxation which opened pension fund capital to VC, causing first major fundraising year (~$750M) and subsequent industry scaling.
6. international_expansion — Simulates non-US VC market growth at 5% per year from a 2008 base of $13.4B internationally vs $28.8B in the US, showing convergence dynamics over 20 years.

    PARAMETERS
    ----------
    22 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This source covers the history, structure, financing stages, and investment dynamics of the venture capital (VC) industry, including fund mechanics, compensation structures, geographic trends, and historical capital deployment from the 1970s through the 2020s.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.