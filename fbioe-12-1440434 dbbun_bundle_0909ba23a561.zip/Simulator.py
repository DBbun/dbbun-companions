# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-24T20:46:24.905665Z
# Run ID    : 03534bef-90f9-481f-b154-df950a93cd03
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Cellular Potts Model Simulator for Chondrocyte Spheroid Formation
=================================================================
Papers:
  1. "In silico Cellular Potts Model of Chondrocyte Spheroid Formation from
     Longitudinal Depth Zones of Bovine Articular Cartilage"
  2. "Zone-specific chondrocyte behavior, ECM production, and gene expression
     in articular cartilage spheroid formation"

Simulates bovine articular cartilage chondrocyte spheroid formation across
three depth zones (Surface SZ, Middle MZ, Deep DZ) over 14 days (3120 MCS).
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "V_cell_target": {"value": 30.0, "unit": "voxels^3", "source": "extracted",
                          "description": "Target volume of cell for all zones"},
        "V_cell_init": {"value": 27.0, "unit": "voxels^3", "source": "extracted",
                        "description": "Initial volume of cell at simulation start"},
        "V_A": {"value": 20.0, "unit": "voxels^3", "source": "extracted",
                "description": "Volume threshold above which action is triggered"},
        "vg_SZ": {"value": 0.08, "unit": "voxels^3/MCS", "source": "extracted",
                  "description": "Growth speed of SZ cells"},
        "vg_MZ": {"value": 0.06, "unit": "voxels^3/MCS", "source": "extracted",
                  "description": "Growth speed of MZ cells"},
        "vg_DZ": {"value": 0.06, "unit": "voxels^3/MCS", "source": "extracted",
                  "description": "Growth speed of DZ cells"},
        "P_mitosis": {"value": 0.01, "unit": "probability", "source": "extracted",
                      "description": "Probability of mitosis when V_cell > V_A"},
        "V_death": {"value": 60.0, "unit": "voxels^3", "source": "extracted",
                    "description": "Cell volume above which cell is deleted"},
        "P_ECMst_SZ": {"value": 0.032, "unit": "probability", "source": "extracted",
                       "description": "Probability of ECMst production per MCS for SZ"},
        "P_ECMst_MZ": {"value": 0.0067, "unit": "probability", "source": "extracted",
                       "description": "Probability of ECMst production per MCS for MZ"},
        "P_ECMst_DZ": {"value": 0.03, "unit": "probability", "source": "extracted",
                       "description": "Probability of ECMst production per MCS for DZ"},
        "P_ECMv_SZ": {"value": 0.032, "unit": "probability", "source": "extracted",
                      "description": "Probability of ECMv production per MCS for SZ"},
        "P_ECMv_MZ": {"value": 0.093, "unit": "probability", "source": "extracted",
                      "description": "Probability of ECMv production per MCS for MZ"},
        "P_ECMv_DZ": {"value": 0.083, "unit": "probability", "source": "extracted",
                      "description": "Probability of ECMv production per MCS for DZ"},
        "V_ECM_init": {"value": 30.0, "unit": "voxels^3", "source": "extracted",
                       "description": "Initial volume of new ECM object"},
        "vd_SZ": {"value": 0.003, "unit": "voxels^3/MCS", "source": "extracted",
                  "description": "ECM decay speed for SZ"},
        "vd_MZ": {"value": 0.027, "unit": "voxels^3/MCS", "source": "extracted",
                  "description": "ECM decay speed for MZ"},
        "vd_DZ": {"value": 0.097, "unit": "voxels^3/MCS", "source": "extracted",
                  "description": "ECM decay speed for DZ"},
        "V_ECM_delete": {"value": 3.0, "unit": "voxels^3", "source": "extracted",
                         "description": "ECM volume below which object is deleted"},
        "lambda_vol": {"value": 10.0, "unit": "a.u.", "source": "extracted",
                       "description": "Volume constraint magnitude in CPM Hamiltonian"},
        "T_m": {"value": 37.0, "unit": "dimensionless", "source": "extracted",
                "description": "CPM temperature parameter"},
        "J_med_med": {"value": 0.0, "unit": "energy", "source": "extracted",
                      "description": "Contact energy medium-medium"},
        "J_cell_cell_SZ": {"value": 5.0, "unit": "energy", "source": "extracted",
                           "description": "Contact energy cell-cell in SZ"},
        "J_cell_cell_MZ": {"value": 2.5, "unit": "energy", "source": "extracted",
                           "description": "Contact energy cell-cell in MZ"},
        "J_cell_cell_DZ": {"value": 2.5, "unit": "energy", "source": "extracted",
                           "description": "Contact energy cell-cell in DZ"},
        "J_med_cell": {"value": 5.0, "unit": "energy", "source": "extracted",
                       "description": "Contact energy medium-cell"},
        "J_med_ECM_SZ": {"value": 20.0, "unit": "energy", "source": "extracted",
                         "description": "Contact energy medium-ECM in SZ"},
        "J_med_ECM_MZ": {"value": 2.5, "unit": "energy", "source": "extracted",
                         "description": "Contact energy medium-ECM in MZ"},
        "J_med_ECM_DZ": {"value": 2.5, "unit": "energy", "source": "extracted",
                         "description": "Contact energy medium-ECM in DZ"},
        "J_cell_ECM": {"value": 10.0, "unit": "energy", "source": "extracted",
                       "description": "Contact energy cell-ECM"},
        "J_ECM_ECM": {"value": 10.0, "unit": "energy", "source": "extracted",
                      "description": "Contact energy ECM-ECM"},
        "MCS_per_day": {"value": 224.0, "unit": "MCS/day", "source": "extracted",
                        "description": "MCS per simulation day"},
        "N_cells_init": {"value": 500.0, "unit": "count", "source": "assumed",
                         "description": "Initial number of cells per zone"},
        "DNA_per_cell": {"value": 1.0, "unit": "ng", "source": "assumed",
                         "description": "Conversion cell count to DNA ng/well"},
        "S_GAG_per_ECMv_voxel": {"value": 0.003, "unit": "ug/voxel^3", "source": "assumed",
                                  "description": "Conversion ECMv volume to S-GAG ug/well"},
        "RQ_noise_sigma": {"value": 0.15, "unit": "a.u.", "source": "assumed",
                           "description": "Lognormal noise sigma for RQ gene expression"},
        "total_MCS": {"value": 3120.0, "unit": "MCS", "source": "extracted",
                      "description": "Total simulation duration (14 days)"},
        "V_ECM_production_cost": {"value": 10.0, "unit": "voxels^3", "source": "extracted",
                                   "description": "Volume removed from parent on ECM production"},
    },
    "scenarios": [
        {
            "label": "SZ_surface_zone",
            "description": "Surface zone: high growth, high J_cc, low ECMv, low decay",
            "param_overrides": {"vg": 0.08, "P_ECMst": 0.032, "P_ECMv": 0.032,
                                "vd": 0.003, "J_cell_cell": 5.0, "J_med_ECM": 20.0}
        },
        {
            "label": "MZ_middle_zone",
            "description": "Middle zone: moderate growth, low ECMst, high ECMv, moderate decay",
            "param_overrides": {"vg": 0.06, "P_ECMst": 0.0067, "P_ECMv": 0.093,
                                "vd": 0.027, "J_cell_cell": 2.5, "J_med_ECM": 2.5}
        },
        {
            "label": "DZ_deep_zone",
            "description": "Deep zone: moderate growth, high ECMst, high ECMv, very high decay",
            "param_overrides": {"vg": 0.06, "P_ECMst": 0.03, "P_ECMv": 0.083,
                                "vd": 0.097, "J_cell_cell": 2.5, "J_med_ECM": 2.5}
        },
        {
            "label": "SZ_vs_DZ_Col1a1_high",
            "description": "DZ with elevated Col1a1 expression",
            "param_overrides": {"vg": 0.06, "P_ECMst": 0.03, "P_ECMv": 0.083,
                                "vd": 0.097, "J_cell_cell": 2.5, "J_med_ECM": 2.5,
                                "RQ_Col1a1_base": 40.0}
        },
        {
            "label": "Mmp13_DZ_elevated",
            "description": "DZ Mmp13 scenario: RQ_Mmp13 grows to ~32x SZ by day 14",
            "param_overrides": {"vd": 0.097, "P_ECMst": 0.03, "P_ECMv": 0.083,
                                "RQ_Mmp13_day14_DZ": 32.2}
        },
    ]
}

# ============================================================
# ZONE BASE PARAMETERS
# ============================================================
ZONE_BASE_PARAMS = {
    "SZ": {"vg": 0.08, "P_ECMst": 0.032, "P_ECMv": 0.032, "vd": 0.003,
           "J_cell_cell": 5.0, "J_med_ECM": 20.0},
    "MZ": {"vg": 0.06, "P_ECMst": 0.0067, "P_ECMv": 0.093, "vd": 0.027,
           "J_cell_cell": 2.5, "J_med_ECM": 2.5},
    "DZ": {"vg": 0.06, "P_ECMst": 0.03, "P_ECMv": 0.083, "vd": 0.097,
           "J_cell_cell": 2.5, "J_med_ECM": 2.5},
}

# Gene expression base RQ by zone at day 7 (ratios from paper Fig 4b)
# Format: {gene: {zone: base_rq_at_day7}}
GENE_RQ_DAY7 = {
    "Col2a1": {"SZ": 1.0, "MZ": 2.8, "DZ": 2.5},
    "Col1a1": {"SZ": 1.0, "MZ": 0.2, "DZ": 0.9},
    "Mmp13":  {"SZ": 1.0, "MZ": 9.1, "DZ": 32.2},
    "Cdh2":   {"SZ": 1.0, "MZ": 2.4, "DZ": 3.8},
    "ItgaV":  {"SZ": 1.0, "MZ": 1.0, "DZ": 1.0},
    "Acan":   {"SZ": 1.0, "MZ": 2.0, "DZ": 1.8},
    "Csgalnact1": {"SZ": 1.0, "MZ": 1.5, "DZ": 1.3},
    "Has2":   {"SZ": 1.0, "MZ": 1.8, "DZ": 1.6},
    "Pcna":   {"SZ": 1.0, "MZ": 1.2, "DZ": 1.1},
}

# Constants
V_CELL_INIT = 27.0
V_CELL_TARGET = 30.0
V_A = 20.0
V_DEATH = 60.0
V_ECM_INIT = 30.0
V_ECM_DELETE = 3.0
V_ECM_PRODUCTION_COST = 10.0
P_MITOSIS = 0.01
LAMBDA_VOL = 10.0
T_M = 37.0
J_MED_CELL = 5.0
J_CELL_ECM = 10.0
J_ECM_ECM = 10.0
MCS_PER_DAY = 224
TOTAL_MCS = 3120
N_CELLS_INIT = 500
DNA_PER_CELL = 1.0
S_GAG_PER_ECMv_VOXEL = 0.003
RQ_NOISE_SIGMA = 0.15
N_REPLICATES = 3  # Reduced for speed
# Record every day
RECORD_DAYS = list(range(0, 15))  # days 0..14
RECORD_MCS = [d * MCS_PER_DAY for d in RECORD_DAYS]


# ============================================================
# DATA CLASSES
# ============================================================
@dataclass
class Cell:
    volume: float
    target_volume: float
    zone: str

    def __post_init__(self):
        self.volume = max(0.0, min(120.0, self.volume))
        self.target_volume = max(20.0, min(60.0, self.target_volume))


@dataclass
class ECMObject:
    volume: float
    ecm_type: str  # 'ECMst' or 'ECMv'
    zone: str
    decay_rate: float

    def __post_init__(self):
        self.volume = max(0.0, min(60.0, self.volume))


# ============================================================
# GENE EXPRESSION MODEL
# ============================================================
def compute_rq(gene: str, zone: str, day: float, params: dict, rng: np.random.RandomState) -> float:
    """Compute RQ for a gene at a given day with lognormal noise."""
    # Get base value at day 7
    base_day7 = GENE_RQ_DAY7.get(gene, {}).get(zone, 1.0)

    # Override if scenario specifies
    if gene == "Col1a1" and "RQ_Col1a1_base" in params:
        base_day7 = params["RQ_Col1a1_base"] * GENE_RQ_DAY7["Col1a1"].get(zone, 1.0)

    if gene == "Mmp13" and "RQ_Mmp13_day14_DZ" in params and zone == "DZ":
        # Scale so DZ reaches target at day 14
        target_day14 = params["RQ_Mmp13_day14_DZ"]
        if day <= 7:
            base_day7_mmp = GENE_RQ_DAY7["Mmp13"]["DZ"]
            frac = day / 7.0 if day > 0 else 0.1
            base_val = 1.0 + (base_day7_mmp - 1.0) * frac
        else:
            base_day7_mmp = GENE_RQ_DAY7["Mmp13"]["DZ"]
            frac = (day - 7.0) / 7.0
            base_val = base_day7_mmp + (target_day14 - base_day7_mmp) * frac
        noise = rng.lognormal(0.0, RQ_NOISE_SIGMA)
        return max(0.0, base_val * noise)

    # Temporal interpolation: rises from 1.0 at day 1 to base_day7 at day 7, then plateaus
    if day <= 0:
        t_val = 1.0
    elif day <= 1:
        t_val = 1.0
    elif day <= 7:
        frac = (day - 1.0) / 6.0
        t_val = 1.0 + (base_day7 - 1.0) * frac
    else:
        # Plateau slightly beyond day 7
        t_val = base_day7

    # For Mmp13 DZ, exponential rise to day 14
    if gene == "Mmp13" and zone == "DZ":
        if day > 7:
            frac = (day - 7.0) / 7.0
            t_val = base_day7 + (GENE_RQ_DAY7["Mmp13"]["DZ"] * 3.54 - base_day7) * frac

    noise = rng.lognormal(0.0, RQ_NOISE_SIGMA)
    result = max(0.0, t_val * noise)
    return result


# ============================================================
# HAMILTONIAN COMPUTATION
# ============================================================
def compute_hamiltonian(cells: List[Cell], ecm_objects: List[ECMObject],
                        params: dict) -> Tuple[float, float, float]:
    """Compute CPM Hamiltonian energy (mean-field approximation)."""
    J_cc = params["J_cell_cell"]
    J_mECM = params["J_med_ECM"]
    k_neighbors = 12  # mean-field neighbors in 3D

    n_cells = len(cells)
    n_ecm = len(ecm_objects)

    # H_contact approximation using mean-field
    # Each cell has k_neighbors contacts split between cells and ECM/medium
    # Fraction of cell-cell contacts = n_cells / (n_cells + n_ecm + 1)
    total_agents = n_cells + n_ecm + 1  # +1 for medium
    frac_cell = n_cells / max(total_agents, 1)
    frac_ecm = n_ecm / max(total_agents, 1)
    frac_med = 1.0 - frac_cell - frac_ecm

    H_contact = 0.0
    # Cell-cell contacts
    H_contact += n_cells * k_neighbors * frac_cell * J_cc
    # Cell-medium contacts
    H_contact += n_cells * k_neighbors * frac_med * J_MED_CELL
    # Cell-ECM contacts
    H_contact += n_cells * k_neighbors * frac_ecm * J_CELL_ECM
    # ECM-ECM contacts
    H_contact += n_ecm * k_neighbors * frac_ecm * J_ECM_ECM
    # ECM-medium contacts
    H_contact += n_ecm * k_neighbors * frac_med * J_mECM

    # Scale to avoid giant numbers
    H_contact *= 0.5  # each pair counted twice

    # H_volume
    H_volume = 0.0
    for c in cells:
        H_volume += LAMBDA_VOL * (c.volume - c.target_volume) ** 2
    for e in ecm_objects:
        H_volume += LAMBDA_VOL * (e.volume - V_ECM_INIT) ** 2

    H_total = H_contact + H_volume
    return H_contact, H_volume, H_total


# ============================================================
# SIMULATION CLASS
# ============================================================
class Simulation:
    def __init__(self, zone: str, params: dict, seed: int):
        self.zone = zone
        self.params = params
        self.seed = seed
        self.rng = np.random.RandomState(seed)
        self.mcs = 0

        # Initialize cells
        self.cells: List[Cell] = []
        for _ in range(N_CELLS_INIT):
            v = V_CELL_INIT + self.rng.uniform(-1.0, 1.0)
            v = max(0.0, min(120.0, v))
            self.cells.append(Cell(volume=v, target_volume=V_CELL_TARGET, zone=zone))

        self.ecm_objects: List[ECMObject] = []
        self.records: List[dict] = []

    def step(self) -> dict:
        """Execute one MCS and return event counts."""
        vg = self.params["vg"]
        P_ECMst = self.params["P_ECMst"]
        P_ECMv = self.params["P_ECMv"]
        vd = self.params["vd"]

        mitosis_events = 0
        ecmst_events = 0
        ecmv_events = 0
        ecm_deletion_events = 0
        cell_death_events = 0

        new_cells = []
        dead_cell_indices = []

        for i, cell in enumerate(self.cells):
            # Growth
            cell.volume += vg
            cell.volume = max(0.0, min(120.0, cell.volume))

            # Death check
            if cell.volume > V_DEATH:
                dead_cell_indices.append(i)
                cell_death_events += 1
                continue

            # Action check
            if cell.volume > V_A:
                r = self.rng.uniform(0.0, 1.0)
                if r < P_MITOSIS:
                    # Mitosis
                    new_vol = cell.volume / 2.0
                    new_vol = max(0.0, min(120.0, new_vol))
                    cell.volume = new_vol
                    daughter = Cell(volume=new_vol, target_volume=V_CELL_TARGET, zone=self.zone)
                    new_cells.append(daughter)
                    mitosis_events += 1
                elif r < P_MITOSIS + P_ECMst:
                    # ECMst production
                    cost = min(V_ECM_PRODUCTION_COST, cell.volume - 1.0)
                    cell.volume = max(1.0, cell.volume - cost)
                    ecm_obj = ECMObject(volume=V_ECM_INIT, ecm_type="ECMst",
                                       zone=self.zone, decay_rate=vd)
                    self.ecm_objects.append(ecm_obj)
                    ecmst_events += 1
                elif r < P_MITOSIS + P_ECMst + P_ECMv:
                    # ECMv production
                    cost = min(V_ECM_PRODUCTION_COST, cell.volume - 1.0)
                    cell.volume = max(1.0, cell.volume - cost)
                    ecm_obj = ECMObject(volume=V_ECM_INIT, ecm_type="ECMv",
                                       zone=self.zone, decay_rate=vd)
                    self.ecm_objects.append(ecm_obj)
                    ecmv_events += 1

        # Remove dead cells (in reverse order)
        for i in sorted(dead_cell_indices, reverse=True):
            self.cells.pop(i)

        # Add new daughter cells
        self.cells.extend(new_cells)

        # ECM decay
        surviving_ecm = []
        for ecm in self.ecm_objects:
            ecm.volume -= vd
            ecm.volume = max(0.0, ecm.volume)
            if ecm.volume < V_ECM_DELETE:
                ecm_deletion_events += 1
            else:
                surviving_ecm.append(ecm)
        self.ecm_objects = surviving_ecm

        self.mcs += 1

        return {
            "mitosis_events": mitosis_events,
            "ecmst_events": ecmst_events,
            "ecmv_events": ecmv_events,
            "ecm_deletion_events": ecm_deletion_events,
            "cell_death_events": cell_death_events,
        }

    def get_state(self, events: dict, day: float, rq_rng: np.random.RandomState) -> dict:
        """Collect current state metrics."""
        n_cells = len(self.cells)
        n_ecmst = sum(1 for e in self.ecm_objects if e.ecm_type == "ECMst")
        n_ecmv = sum(1 for e in self.ecm_objects if e.ecm_type == "ECMv")

        cell_vols = np.array([c.volume for c in self.cells]) if self.cells else np.array([0.0])
        total_cell_vol = float(np.sum(cell_vols))
        mean_cell_vol = float(np.mean(cell_vols))
        std_cell_vol = float(np.std(cell_vols)) if len(cell_vols) > 1 else 0.0

        ecmst_vols = [e.volume for e in self.ecm_objects if e.ecm_type == "ECMst"]
        ecmv_vols = [e.volume for e in self.ecm_objects if e.ecm_type == "ECMv"]
        total_ecmst_vol = sum(ecmst_vols) if ecmst_vols else 0.0
        total_ecmv_vol = sum(ecmv_vols) if ecmv_vols else 0.0

        dna = n_cells * DNA_PER_CELL
        dna = max(400.0, min(1500.0, dna))
        sgag = total_ecmv_vol * S_GAG_PER_ECMv_VOXEL
        sgag = max(0.0, min(15.0, sgag))
        sgag_per_dna = sgag / dna if dna > 0 else 0.0
        sgag_per_dna = max(0.0, min(12.0, sgag_per_dna))

        H_contact, H_volume, H_total = compute_hamiltonian(
            self.cells, self.ecm_objects, self.params)

        # Gene expression
        genes = ["Col2a1", "Col1a1", "Mmp13", "Cdh2", "ItgaV",
                 "Acan", "Csgalnact1", "Has2", "Pcna"]
        rq_vals = {}
        for g in genes:
            rq_vals[g] = compute_rq(g, self.zone, day, self.params, rq_rng)

        state = {
            "zone": self.zone,
            "MCS": self.mcs,
            "day": day,
            "N_cells": n_cells,
            "N_ECMst": n_ecmst,
            "N_ECMv": n_ecmv,
            "total_cell_volume": total_cell_vol,
            "total_ECMst_volume": total_ecmst_vol,
            "total_ECMv_volume": total_ecmv_vol,
            "DNA_ng_per_well": dna,
            "S_GAG_ug_per_well": sgag,
            "S_GAG_per_DNA_ug_per_ng": sgag_per_dna,
            "H_contact": H_contact,
            "H_volume": H_volume,
            "H_total": H_total,
            "RQ_Acan": rq_vals["Acan"],
            "RQ_Csgalnact1": rq_vals["Csgalnact1"],
            "RQ_Has2": rq_vals["Has2"],
            "RQ_Col2a1": rq_vals["Col2a1"],
            "RQ_Col1a1": rq_vals["Col1a1"],
            "RQ_Mmp13": rq_vals["Mmp13"],
            "RQ_Pcna": rq_vals["Pcna"],
            "RQ_Cdh2": rq_vals["Cdh2"],
            "RQ_ItgaV": rq_vals["ItgaV"],
            "mean_cell_volume": mean_cell_vol,
            "std_cell_volume": std_cell_vol,
            "mitosis_events_this_step": events.get("mitosis_events", 0),
            "ECMst_production_events_this_step": events.get("ecmst_events", 0),
            "ECMv_production_events_this_step": events.get("ecmv_events", 0),
            "ECM_deletion_events_this_step": events.get("ecm_deletion_events", 0),
            "cell_death_events_this_step": events.get("cell_death_events", 0),
        }
        return state

    def run(self, scenario_label: str, replicate_id: int, sim_id: str) -> List[dict]:
        """Run full simulation and return records at day intervals."""
        records = []
        rq_rng = np.random.RandomState(self.seed + 1000)

        # Record initial state (MCS=0, day=0)
        events_zero = {k: 0 for k in ["mitosis_events", "ecmst_events", "ecmv_events",
                                       "ecm_deletion_events", "cell_death_events"]}
        state = self.get_state(events_zero, 0.0, rq_rng)
        state["simulation_id"] = sim_id
        state["scenario_label"] = scenario_label
        state["replicate_id"] = replicate_id
        records.append(state)

        record_set = set(RECORD_MCS[1:])  # skip 0, already recorded

        for mcs in range(1, TOTAL_MCS + 1):
            events = self.step()

            if mcs in record_set:
                day = mcs / MCS_PER_DAY
                day = min(14.0, day)
                state = self.get_state(events, day, rq_rng)
                state["simulation_id"] = sim_id
                state["scenario_label"] = scenario_label
                state["replicate_id"] = replicate_id
                records.append(state)

        return records


# ============================================================
# RUN ALL SCENARIOS
# ============================================================
def run_all_scenarios() -> List[dict]:
    """Run all scenarios and collect all records."""
    all_records = []
    scenarios = MODEL_PROFILE["scenarios"]

    for sc_idx, scenario in enumerate(scenarios):
        label = scenario["label"]
        overrides = scenario["param_overrides"]
        print(f"  Scenario {sc_idx}: {label}")

        # Determine zone from scenario label
        if "SZ" in label and "DZ" not in label:
            zone = "SZ"
        elif "MZ" in label:
            zone = "MZ"
        else:
            zone = "DZ"

        # Build params from zone base + overrides
        base = dict(ZONE_BASE_PARAMS[zone])
        params = dict(base)
        # Apply overrides
        for k, v in overrides.items():
            if k in params:
                params[k] = v
            else:
                # Extra scenario-specific params
                params[k] = v

        np.random.seed(sc_idx)

        for rep in range(N_REPLICATES):
            seed = sc_idx * 100 + rep
            sim_id = f"{label}_rep{rep}"
            sim = Simulation(zone=zone, params=params, seed=seed)
            records = sim.run(scenario_label=label, replicate_id=rep, sim_id=sim_id)
            all_records.extend(records)
            print(f"    Replicate {rep}: {len(records)} records, "
                  f"final N_cells={records[-1]['N_cells']}")

    return all_records


# ============================================================
# FIGURE GENERATION
# ============================================================
def generate_figures(all_records: List[dict], output_dir: pathlib.Path):
    """Generate all 10 figures."""
    # Convert to structured arrays for easy access
    # Group by scenario_label and day
    scenarios_labels = list(dict.fromkeys(r["scenario_label"] for r in all_records))
    zones_in_data = ["SZ", "MZ", "DZ"]

    # Helper: get records for scenario + day
    def get_vals(scenario: str, day_val: float, field: str) -> List[float]:
        return [r[field] for r in all_records
                if r["scenario_label"] == scenario and abs(r["day"] - day_val) < 0.1]

    # Map scenario to zone for the first 3 scenarios
    scenario_zone_map = {
        "SZ_surface_zone": "SZ",
        "MZ_middle_zone": "MZ",
        "DZ_deep_zone": "DZ",
    }
    main_scenarios = ["SZ_surface_zone", "MZ_middle_zone", "DZ_deep_zone"]
    zone_colors = {"SZ": "steelblue", "MZ": "gray", "DZ": "black"}
    days_list = list(range(0, 15))

    # ---------------------------------------------------------
    # FIG 1: Cell Count over Time
    # ---------------------------------------------------------
    try:
        fig, ax = plt.subplots(figsize=(8, 5))
        for sc in main_scenarios:
            zone = scenario_zone_map[sc]
            x_days = np.array(days_list, dtype=float)
            y_mean = np.zeros(len(days_list))
            y_std = np.zeros(len(days_list))
            for i, d in enumerate(days_list):
                vals = get_vals(sc, float(d), "N_cells")
                if vals:
                    y_mean[i] = np.mean(vals)
                    y_std[i] = np.std(vals)
            assert len(x_days) == len(y_mean), "Array length mismatch fig1"
            if len(x_days) > 0:
                ax.plot(x_days, y_mean, label=zone, color=zone_colors[zone], linewidth=2)
                ax.fill_between(x_days, y_mean - y_std, y_mean + y_std,
                                alpha=0.2, color=zone_colors[zone])
        ax.set_xlabel("Day")
        ax.set_ylabel("N_cells (DNA proxy, ng/well)")
        ax.set_title("Cell Count (DNA proxy) Over Time by Zone")
        ax.legend()
        ax.set_xlim(0, 14)
        plt.tight_layout()
        fig.savefig(output_dir / "fig1_cell_count_over_time.png", dpi=100)
        plt.close(fig)
        print("  Saved fig1")
    except Exception as e:
        print(f"  WARNING fig1 failed: {e}")

    # ---------------------------------------------------------
    # FIG 2: S-GAG over Time
    # ---------------------------------------------------------
    try:
        fig, ax = plt.subplots(figsize=(8, 5))
        for sc in main_scenarios:
            zone = scenario_zone_map[sc]
            x_days = np.array(days_list, dtype=float)
            y_mean = np.zeros(len(days_list))
            y_std = np.zeros(len(days_list))
            for i, d in enumerate(days_list):
                vals = get_vals(sc, float(d), "S_GAG_ug_per_well")
                if vals:
                    y_mean[i] = np.mean(vals)
                    y_std[i] = np.std(vals)
            assert len(x_days) == len(y_mean), "Array length mismatch fig2"
            ax.plot(x_days, y_mean, label=zone, color=zone_colors[zone], linewidth=2)
            ax.fill_between(x_days, y_mean - y_std, y_mean + y_std,
                            alpha=0.2, color=zone_colors[zone])
        ax.set_xlabel("Day")
        ax.set_ylabel("S-GAG (ug/well)")
        ax.set_title("S-GAG Content Over Time by Zone")
        ax.legend()
        ax.set_xlim(0, 14)
        plt.tight_layout()
        fig.savefig(output_dir / "fig2_SGAG_over_time.png", dpi=100)
        plt.close(fig)
        print("  Saved fig2")
    except Exception as e:
        print(f"  WARNING fig2 failed: {e}")

    # ---------------------------------------------------------
    # FIG 3: S-GAG/DNA Ratio
    # ---------------------------------------------------------
    try:
        fig, ax = plt.subplots(figsize=(8, 5))
        for sc in main_scenarios:
            zone = scenario_zone_map[sc]
            x_days = np.array(days_list, dtype=float)
            y_mean = np.zeros(len(days_list))
            y_std = np.zeros(len(days_list))
            for i, d in enumerate(days_list):
                vals = get_vals(sc, float(d), "S_GAG_per_DNA_ug_per_ng")
                if vals:
                    y_mean[i] = np.mean(vals)
                    y_std[i] = np.std(vals)
            assert len(x_days) == len(y_mean), "Array length mismatch fig3"
            ax.plot(x_days, y_mean, label=zone, color=zone_colors[zone], linewidth=2)
            ax.fill_between(x_days, y_mean - y_std, y_mean + y_std,
                            alpha=0.2, color=zone_colors[zone])
        ax.set_xlabel("Day")
        ax.set_ylabel("S-GAG/DNA (ug/ng)")
        ax.set_title("S-GAG/DNA Ratio Over Time by Zone")
        ax.legend()
        ax.set_xlim(0, 14)
        plt.tight_layout()
        fig.savefig(output_dir / "fig3_SGAG_DNA_ratio.png", dpi=100)
        plt.close(fig)
        print("  Saved fig3")
    except Exception as e:
        print(f"  WARNING fig3 failed: {e}")

    # ---------------------------------------------------------
    # FIG 4: ECMv Count Over Time
    # ---------------------------------------------------------
    try:
        fig, ax = plt.subplots(figsize=(8, 5))
        for sc in main_scenarios:
            zone = scenario_zone_map[sc]
            x_days = np.array(days_list, dtype=float)
            y_mean = np.zeros(len(days_list))
            y_std = np.zeros(len(days_list))
            for i, d in enumerate(days_list):
                vals = get_vals(sc, float(d), "N_ECMv")
                if vals:
                    y_mean[i] = np.mean(vals)
                    y_std[i] = np.std(vals)
            assert len(x_days) == len(y_mean), "Array length mismatch fig4"
            ax.plot(x_days, y_mean, label=zone, color=zone_colors[zone], linewidth=2)
            ax.fill_between(x_days, y_mean - y_std, y_mean + y_std,
                            alpha=0.2, color=zone_colors[zone])
        ax.set_xlabel("Day")
        ax.set_ylabel("N_ECMv (count)")
        ax.set_title("ECMv Object Count Over Time by Zone")
        ax.legend()
        ax.set_xlim(0, 14)
        plt.tight_layout()
        fig.savefig(output_dir / "fig4_ECM_counts_over_time.png", dpi=100)
        plt.close(fig)
        print("  Saved fig4")
    except Exception as e:
        print(f"  WARNING fig4 failed: {e}")

    # ---------------------------------------------------------
    # FIG 5: ECMst Count Over Time
    # ---------------------------------------------------------
    try:
        fig, ax = plt.subplots(figsize=(8, 5))
        for sc in main_scenarios:
            zone = scenario_zone_map[sc]
            x_days = np.array(days_list, dtype=float)
            y_mean = np.zeros(len(days_list))
            y_std = np.zeros(len(days_list))
            for i, d in enumerate(days_list):
                vals = get_vals(sc, float(d), "N_ECMst")
                if vals:
                    y_mean[i] = np.mean(vals)
                    y_std[i] = np.std(vals)
            assert len(x_days) == len(y_mean), "Array length mismatch fig5"
            ax.plot(x_days, y_mean, label=zone, color=zone_colors[zone], linewidth=2)
            ax.fill_between(x_days, y_mean - y_std, y_mean + y_std,
                            alpha=0.2, color=zone_colors[zone])
        ax.set_xlabel("Day")
        ax.set_ylabel("N_ECMst (count)")
        ax.set_title("ECMst Object Count Over Time by Zone")
        ax.legend()
        ax.set_xlim(0, 14)
        plt.tight_layout()
        fig.savefig(output_dir / "fig5_ECMst_counts_over_time.png", dpi=100)
        plt.close(fig)
        print("  Saved fig5")
    except Exception as e:
        print(f"  WARNING fig5 failed: {e}")

    # ---------------------------------------------------------
    # FIG 6: Gene Expression RQ multi-panel
    # ---------------------------------------------------------
    try:
        genes_to_plot = ["Col2a1", "Col1a1", "Mmp13", "Cdh2", "ItgaV"]
        rq_field_map = {
            "Col2a1": "RQ_Col2a1",
            "Col1a1": "RQ_Col1a1",
            "Mmp13": "RQ_Mmp13",
            "Cdh2": "RQ_Cdh2",
            "ItgaV": "RQ_ItgaV",
        }
        fig, axes = plt.subplots(1, 5, figsize=(18, 4))
        plot_days = [1, 2, 7, 14]
        x_pos = np.arange(len(plot_days))
        width = 0.25

        for gi, gene in enumerate(genes_to_plot):
            ax = axes[gi]
            field = rq_field_map[gene]
            for si, sc in enumerate(main_scenarios):
                zone = scenario_zone_map[sc]
                y_vals = np.zeros(len(plot_days))
                y_errs = np.zeros(len(plot_days))
                for di, d in enumerate(plot_days):
                    vals = get_vals(sc, float(d), field)
                    if vals:
                        y_vals[di] = np.mean(vals)
                        y_errs[di] = np.std(vals)
                offset = (si - 1) * width
                bars = ax.bar(x_pos + offset, y_vals, width,
                              label=zone, color=zone_colors[zone],
                              yerr=y_errs, capsize=3, alpha=0.8)
            ax.set_title(gene)
            ax.set_xticks(x_pos)
            ax.set_xticklabels([f"D{d}" for d in plot_days])
            ax.set_ylabel("RQ")
            if gi == 0:
                ax.legend(fontsize=7)
        fig.suptitle("Gene Expression RQ by Zone and Day")
        plt.tight_layout()
        fig.savefig(output_dir / "fig6_gene_expression_RQ.png", dpi=100)
        plt.close(fig)
        print("  Saved fig6")
    except Exception as e:
        print(f"  WARNING fig6 failed: {e}")

    # ---------------------------------------------------------
    # FIG 7: Cell Volume Distribution histogram
    # ---------------------------------------------------------
    try:
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        check_days = [7, 14]
        for di, check_day in enumerate(check_days):
            ax = axes[di]
            for sc in main_scenarios:
                zone = scenario_zone_map[sc]
                vols = get_vals(sc, float(check_day), "mean_cell_volume")
                if vols:
                    ax.hist(vols, bins=20, alpha=0.5, label=zone,
                            color=zone_colors[zone], density=True)
            ax.axvline(x=V_A, color="red", linestyle="--", label=f"V_A={V_A}")
            ax.axvline(x=V_DEATH, color="darkred", linestyle="--", label=f"V_death={V_DEATH}")
            ax.set_title(f"Cell Volume Distribution at Day {check_day}")
            ax.set_xlabel("Mean Cell Volume (voxels^3)")
            ax.set_ylabel("Density")
            ax.legend(fontsize=7)
        plt.tight_layout()
        fig.savefig(output_dir / "fig7_cell_volume_distribution.png", dpi=100)
        plt.close(fig)
        print("  Saved fig7")
    except Exception as e:
        print(f"  WARNING fig7 failed: {e}")

    # ---------------------------------------------------------
    # FIG 8: Spheroid Morphology Heatmap
    # ---------------------------------------------------------
    try:
        heatmap_days = [1, 2, 4, 7, 11, 14]
        heatmap_zones = ["SZ_surface_zone", "MZ_middle_zone", "DZ_deep_zone"]
        zone_labels = ["SZ", "MZ", "DZ"]
        data_matrix = np.zeros((3, len(heatmap_days)))

        for zi, sc in enumerate(heatmap_zones):
            for di, d in enumerate(heatmap_days):
                vals = get_vals(sc, float(d), "total_cell_volume")
                if vals:
                    data_matrix[zi, di] = np.mean(vals)

        fig, ax = plt.subplots(figsize=(10, 4))
        im = ax.imshow(data_matrix, aspect="auto", cmap="viridis")
        ax.set_xticks(range(len(heatmap_days)))
        ax.set_xticklabels([f"Day {d}" for d in heatmap_days])
        ax.set_yticks(range(3))
        ax.set_yticklabels(zone_labels)
        ax.set_title("Simulated Spheroid Size (Total Cell Volume) Heatmap: Zone x Day")
        plt.colorbar(im, ax=ax, label="Total Cell Volume (voxels^3)")
        plt.tight_layout()
        fig.savefig(output_dir / "fig8_spheroid_morphology_heatmap.png", dpi=100)
        plt.close(fig)
        print("  Saved fig8")
    except Exception as e:
        print(f"  WARNING fig8 failed: {e}")

    # ---------------------------------------------------------
    # FIG 9: Hamiltonian Energy over MCS
    # ---------------------------------------------------------
    try:
        fig, ax = plt.subplots(figsize=(8, 5))
        for sc in main_scenarios:
            zone = scenario_zone_map[sc]
            # Get all MCS points for this scenario
            sc_records = [r for r in all_records if r["scenario_label"] == sc]
            # Average across replicates at each MCS
            mcs_vals_set = sorted(set(r["MCS"] for r in sc_records))
            x_mcs = np.array(mcs_vals_set, dtype=float)
            y_h = np.zeros(len(x_mcs))
            for i, mcs_val in enumerate(mcs_vals_set):
                htots = [r["H_total"] for r in sc_records if r["MCS"] == mcs_val]
                y_h[i] = np.mean(htots) if htots else 0.0
            assert len(x_mcs) == len(y_h), "Array length mismatch fig9"
            if len(x_mcs) > 0:
                ax.plot(x_mcs, y_h, label=zone, color=zone_colors[zone], linewidth=2)
        ax.set_xlabel("MCS")
        ax.set_ylabel("H_total (energy)")
        ax.set_title("Total CPM Hamiltonian Energy Over MCS by Zone")
        ax.legend()
        plt.tight_layout()
        fig.savefig(output_dir / "fig9_hamiltonian_energy.png", dpi=100)
        plt.close(fig)
        print("  Saved fig9")
    except Exception as e:
        print(f"  WARNING fig9 failed: {e}")

    # ---------------------------------------------------------
    # FIG 10: Zone ratio comparison
    # ---------------------------------------------------------
    try:
        genes_ratio = ["Acan", "Csgalnact1", "Has2", "Col2a1", "Col1a1",
                       "Mmp13", "Pcna", "Cdh2", "ItgaV"]
        rq_field_all = {
            "Acan": "RQ_Acan", "Csgalnact1": "RQ_Csgalnact1", "Has2": "RQ_Has2",
            "Col2a1": "RQ_Col2a1", "Col1a1": "RQ_Col1a1", "Mmp13": "RQ_Mmp13",
            "Pcna": "RQ_Pcna", "Cdh2": "RQ_Cdh2", "ItgaV": "RQ_ItgaV"
        }
        fig, ax = plt.subplots(figsize=(12, 5))
        x_pos = np.arange(len(genes_ratio))
        width = 0.35

        mz_ratios = np.zeros(len(genes_ratio))
        dz_ratios = np.zeros(len(genes_ratio))

        for gi, gene in enumerate(genes_ratio):
            field = rq_field_all[gene]
            sz_vals = get_vals("SZ_surface_zone", 7.0, field)
            mz_vals = get_vals("MZ_middle_zone", 7.0, field)
            dz_vals = get_vals("DZ_deep_zone", 7.0, field)
            sz_mean = np.mean(sz_vals) if sz_vals else 1.0
            mz_mean = np.mean(mz_vals) if mz_vals else 1.0
            dz_mean = np.mean(dz_vals) if dz_vals else 1.0
            mz_ratios[gi] = mz_mean / sz_mean if sz_mean > 0 else 1.0
            dz_ratios[gi] = dz_mean / sz_mean if sz_mean > 0 else 1.0

        ax.bar(x_pos - width / 2, mz_ratios, width, label="MZ/SZ", color="gray", alpha=0.8)
        ax.bar(x_pos + width / 2, dz_ratios, width, label="DZ/SZ", color="black", alpha=0.8)
        ax.set_yscale("log")
        ax.set_xticks(x_pos)
        ax.set_xticklabels(genes_ratio, rotation=30, ha="right")
        ax.set_ylabel("RQ Ratio (log scale)")
        ax.set_title("MZ/SZ and DZ/SZ Gene Expression Ratios at Day 7")
        ax.legend()
        ax.axhline(y=1.0, color="red", linestyle="--", alpha=0.5)
        plt.tight_layout()
        fig.savefig(output_dir / "fig10_zone_ratio_comparison.png", dpi=100)
        plt.close(fig)
        print("  Saved fig10")
    except Exception as e:
        print(f"  WARNING fig10 failed: {e}")


# ============================================================
# CSV / JSON OUTPUT
# ============================================================
def save_simulation_outputs(all_records: List[dict], output_dir: pathlib.Path):
    """Save simulation_outputs.csv."""
    if not all_records:
        print("  WARNING: No records to save")
        return

    fieldnames = [
        "simulation_id", "zone", "MCS", "day", "N_cells", "N_ECMst", "N_ECMv",
        "total_cell_volume", "total_ECMst_volume", "total_ECMv_volume",
        "DNA_ng_per_well", "S_GAG_ug_per_well", "S_GAG_per_DNA_ug_per_ng",
        "H_contact", "H_volume", "H_total",
        "RQ_Acan", "RQ_Csgalnact1", "RQ_Has2",
        "RQ_Col2a1", "RQ_Col1a1", "RQ_Mmp13", "RQ_Pcna", "RQ_Cdh2", "RQ_ItgaV",
        "mean_cell_volume", "std_cell_volume",
        "mitosis_events_this_step", "ECMst_production_events_this_step",
        "ECMv_production_events_this_step", "ECM_deletion_events_this_step",
        "cell_death_events_this_step", "scenario_label", "replicate_id"
    ]

    out_path = output_dir / "simulation_outputs.csv"
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for rec in all_records:
            writer.writerow(rec)
    print(f"  Saved simulation_outputs.csv ({len(all_records)} rows)")


def save_scenario_summary(all_records: List[dict], output_dir: pathlib.Path):
    """Save scenario_summary.csv with one row per scenario."""
    if not all_records:
        print("  WARNING: No records for scenario summary")
        return

    scenarios_labels = list(dict.fromkeys(r["scenario_label"] for r in all_records))
    numeric_fields = [
        "N_cells", "N_ECMst", "N_ECMv", "total_cell_volume",
        "DNA_ng_per_well", "S_GAG_ug_per_well", "S_GAG_per_DNA_ug_per_ng",
        "H_total", "RQ_Col2a1", "RQ_Col1a1", "RQ_Mmp13", "RQ_Cdh2", "RQ_ItgaV",
        "mean_cell_volume", "mitosis_events_this_step"
    ]

    rows = []
    for sc in scenarios_labels:
        sc_recs = [r for r in all_records if r["scenario_label"] == sc]
        row = {"scenario_label": sc, "n_records": len(sc_recs)}
        for fld in numeric_fields:
            vals = [r[fld] for r in sc_recs if fld in r]
            if vals:
                arr = np.array(vals, dtype=float)
                row[f"{fld}_mean"] = float(np.mean(arr))
                row[f"{fld}_std"] = float(np.std(arr))
                row[f"{fld}_min"] = float(np.min(arr))
                row[f"{fld}_max"] = float(np.max(arr))
        rows.append(row)

    if not rows:
        print("  WARNING: No scenario summary rows")
        return

    fieldnames = list(rows[0].keys())
    out_path = output_dir / "scenario_summary.csv"
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    print(f"  Saved scenario_summary.csv ({len(rows)} rows)")


def save_parameters_used(output_dir: pathlib.Path):
    """Save parameters_used.csv."""
    params = MODEL_PROFILE["parameters"]
    rows = []
    for name, info in params.items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })

    if not rows:
        print("  WARNING: No parameters to save")
        return

    out_path = output_dir / "parameters_used.csv"
    with open(out_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    print(f"  Saved parameters_used.csv ({len(rows)} rows)")


def save_summary_json(all_records: List[dict], output_dir: pathlib.Path):
    """Save summary.json with aggregate metrics."""
    if not all_records:
        summary = {"error": "no records"}
    else:
        scenarios_labels = list(dict.fromkeys(r["scenario_label"] for r in all_records))
        summary = {
            "total_records": len(all_records),
            "scenarios": scenarios_labels,
            "total_MCS": TOTAL_MCS,
            "MCS_per_day": MCS_PER_DAY,
            "N_cells_init": N_CELLS_INIT,
            "n_replicates": N_REPLICATES,
        }

        # Per-scenario final day stats
        scenario_stats = {}
        for sc in scenarios_labels:
            final_recs = [r for r in all_records
                          if r["scenario_label"] == sc and abs(r["day"] - 14.0) < 0.1]
            if final_recs:
                scenario_stats[sc] = {
                    "final_N_cells_mean": float(np.mean([r["N_cells"] for r in final_recs])),
                    "final_S_GAG_mean": float(np.mean([r["S_GAG_ug_per_well"] for r in final_recs])),
                    "final_H_total_mean": float(np.mean([r["H_total"] for r in final_recs])),
                    "final_RQ_Mmp13_mean": float(np.mean([r["RQ_Mmp13"] for r in final_recs])),
                }
        summary["scenario_stats"] = scenario_stats

    out_path = output_dir / "summary.json"
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"  Saved summary.json")


# ============================================================
# MAIN
# ============================================================
def main():
    parser = argparse.ArgumentParser(
        description="CPM Chondrocyte Spheroid Simulator")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for results")
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=== CPM Chondrocyte Spheroid Simulator ===")
    print(f"Output directory: {output_dir}")

    print("\nRunning simulations...")
    all_records = run_all_scenarios()
    print(f"Total records collected: {len(all_records)}")

    print("\nGenerating figures...")
    generate_figures(all_records, output_dir)

    print("\nSaving CSV outputs...")
    save_simulation_outputs(all_records, output_dir)
    save_scenario_summary(all_records, output_dir)
    save_parameters_used(output_dir)

    print("\nSaving summary JSON...")
    save_summary_json(all_records, output_dir)

    print("\n=== Simulation complete ===")


if __name__ == "__main__":
    main()