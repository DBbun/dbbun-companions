================================================================
      DBbun LLC — Executable Publication Layer
      Simulator Bundle  |  paper_to_simulator_builder v3.4.0
      ================================================================
      Vendor      : DBbun LLC  |  dbbun.com
      CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
      Run ID      : 03534bef-90f9-481f-b154-df950a93cd03
      Generated   : 2026-04-24  20:46:24 UTC
      © 2024-2025 DBbun LLC. All rights reserved.
      ================================================================

      TITLE
      -----
      In silico Cellular Potts Model of Chondrocyte Spheroid Formation from Longitudinal Depth Zones of Bovine Articular Cartilage
Zone-specific chondrocyte behavior, ECM production, and gene expression in articular cartilage spheroid formation

      CATEGORIES
      ----------
      Biomedical and Health Sciences, Computational Intelligence, Agent-based Simulation, Biophysiological Signals

      KEYWORDS
      --------
      Cellular Potts Model, chondrocyte spheroid, articular cartilage, extracellular matrix, Monte Carlo simulation, zone-specific differentiation, in silico tissue engineering, ECM production and decay, Mmp13 matrix metalloproteinase, bovine cartilage depth zone

      ABSTRACT
      --------
      This simulator implements a Cellular Potts Model (CPM) of bovine articular cartilage chondrocyte spheroid formation across three depth zones — surface (SZ), middle (MZ), and deep (DZ) — over 14 days (3120 Monte Carlo Steps). Each chondrocyte agent grows, divides, and produces zone-specific structural (ECMst) or volumetric (ECMv) extracellular matrix governed by probabilities derived from experimental gene expression data (Col1a1, Col2a1, Mmp13, Cdh2, ItgaV). ECM decay rates are set from Mmp13 expression ratios, resulting in DZ spheroids with rapid ECM turnover and compact SZ spheroids with persistent ECM. The simulator reproduces published experimental trends including DNA content accumulation, S-GAG production, S-GAG/DNA ratios, and zone-specific morphological differences visible in brightfield and confocal microscopy. Researchers and bioengineers can use this tool to explore how zone-specific molecular signatures govern self-organization, test hypotheses about cartilage repair strategies, and generate training data for machine learning models of tissue morphogenesis.

      DATA FORMAT
      -----------
      CSV, PNG, JSON

      SOURCE FILES
      ------------
      Screenshot 2026-04-24 164025.png
Screenshot 2026-04-24 163945.png
Screenshot 2026-04-24 163931.png
Screenshot 2026-04-24 163925.png
Screenshot 2026-04-24 163918.png
Screenshot 2026-04-24 163909.png
Screenshot 2026-04-24 163902.png

      SIMULATION BACKEND
      ------------------
      agent_based

      STATE VARIABLES
      ---------------
      cell_volume, cell_target_volume, ecm_volume, N_cells, N_ECMst, N_ECMv, DNA_content, S_GAG_content, S_GAG_per_DNA, MCS, day, zone, RQ_Col2a1, RQ_Col1a1, RQ_Mmp13, RQ_Cdh2, RQ_ItgaV

      SCENARIOS  (5 total)
      ---------------------------------
          1. SZ_surface_zone — Surface zone chondrocytes: high growth rate (0.08), high J_cell_cell (5.0), low ECMv probability (3.2%), low Mmp13/vd (0.003), forming compact spheroids
  2. MZ_middle_zone — Middle zone chondrocytes: moderate growth (0.06), low ECMst (0.67%), high ECMv (9.3%), moderate Mmp13/vd (0.027), forming dispersed clusters
  3. DZ_deep_zone — Deep zone chondrocytes: moderate growth (0.06), high ECMst (3.0%), high ECMv (8.3%), very high Mmp13/vd (0.097), ECM rapidly degraded, loose clusters
  4. SZ_vs_DZ_Col1a1_high — Deep zone scenario with elevated Col1a1 expression (RQ~40-80 at day 14) relative to SZ, consistent with observed gene ratio DZ/SZ=0.9
  5. Mmp13_DZ_elevated — Deep zone Mmp13 scenario: RQ_Mmp13 grows to ~32x SZ by day 14, causing rapid ECM decay, mimicking the statistically significant DZ Mmp13 elevation

      PARAMETERS
      ----------
      39 parameters (see simulation_spec.json for full list with units and sources)

      FIGURES PLANNED
      ---------------
      fig1_cell_count_over_time, fig2_SGAG_over_time, fig3_SGAG_DNA_ratio, fig4_ECM_counts_over_time, fig5_ECMst_counts_over_time, fig6_gene_expression_RQ, fig7_cell_volume_distribution, fig8_spheroid_morphology_heatmap, fig9_hamiltonian_energy, fig10_zone_ratio_comparison

      DOMAIN SUMMARY
      --------------
      A Cellular Potts Model (CPM) simulation of bovine articular cartilage chondrocyte spheroid formation across three depth zones (Surface SZ, Middle MZ, Deep DZ), capturing cell growth, mitosis, ECM production (structural ECMst and volumetric ECMv), ECM decay, and zone-specific gene expression (Col2a1, Col1a1, Mmp13, Cdh2, ItgaV) over 14 days (3120 Monte Carlo Steps).

      FILES IN THIS BUNDLE
      --------------------
      Simulator.py          — runnable document-specific simulator (Python)
      Spec.json    — full analysis spec with DBbun provenance (JSON)
      Documentation.pdf       — auto-generated simulator documentation (PDF)
      README.txt                  — this file
      NOTICE.txt              — legal ownership notice
      sim_outputs/            — CSV datasets, PNG figures, summary.json
        simulation_outputs.csv      — full per-step simulation rows
        scenario_summary.csv        — one row per scenario with aggregate KPIs
        parameters_used.csv         — reproducibility / parameter provenance table
        summary.json                — key aggregate metrics
        *.png                       — publication-quality figures

      INSTRUCTIONS
      ------------
      Requirements:
          pip install numpy matplotlib

      Run with defaults:
          python Simulator.py

      Specify output directory:
          python Simulator.py --output ./my_results

      The simulator is self-contained — no API key or network access needed.
      All parameters are embedded in MODEL_PROFILE at the top of the script
      and can be edited directly to explore sensitivity or extend scenarios.

      See NOTICE.txt for full legal and licensing terms.