# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-05-19T13:20:07.531649Z
# Run ID    : 89e19409-7fe7-4829-b3a6-0eacc810ddfc
#
# © 2026 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
PHercParis4 Vesuvius Challenge CT Tile: Synthetic Companion Simulator for Carbonized Herculaneum Papyrus Ink Visibility Exploration
DBbun-PHercParis4 Exploratory Synthetic Companion: Workflow Documentation and Parameter Sensitivity for Vesuvius-Style CT-Derived Papyrus Imaging

Synthetic companion simulator for the PHerc.Paris.4 CT tile from the Vesuvius Challenge.
Generates synthetic CT-like intensity fields, extracts patches, computes statistics,
and saves figures, CSVs, and a summary JSON for five imaging scenarios.
All output is explicitly synthetic and experimental.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "parameters": {
        "voxel_size_um": {"value": 7.91, "unit": "micrometers", "source": "extracted",
                          "description": "Isotropic voxel size of the CT volume for PHerc.Paris.4"},
        "beam_energy_keV": {"value": 54.0, "unit": "keV", "source": "extracted",
                            "description": "X-ray beam energy used during CT acquisition of PHerc.Paris.4"},
        "tile_size_px": {"value": 64, "unit": "pixels", "source": "extracted",
                         "description": "Side length of square image patches (tile64)"},
        "stride_px": {"value": 16, "unit": "pixels", "source": "extracted",
                      "description": "Stride for sliding-window patch extraction (stride16)"},
        "scale_factor": {"value": 0.20, "unit": "fraction", "source": "extracted",
                         "description": "Image scale reduction factor (20%)"},
        "H": {"value": 512, "unit": "pixels", "source": "assumed",
              "description": "Synthetic tile height in pixels"},
        "W": {"value": 400, "unit": "pixels", "source": "assumed",
              "description": "Synthetic tile width in pixels"},
        "papyrus_bg_mean": {"value": 0.35, "unit": "a.u.", "source": "assumed",
                            "description": "Mean normalized intensity of carbonized papyrus background"},
        "papyrus_bg_std": {"value": 0.06, "unit": "a.u.", "source": "assumed",
                           "description": "Standard deviation of papyrus background intensity"},
        "ink_intensity_offset": {"value": 0.28, "unit": "a.u.", "source": "assumed",
                                 "description": "Additive offset above papyrus background mean for ink-candidate regions"},
        "ink_stroke_width_px": {"value": 3.5, "unit": "pixels", "source": "assumed",
                                "description": "Approximate half-width of simulated ink brushstrokes"},
        "ink_density": {"value": 0.18, "unit": "fraction", "source": "assumed",
                        "description": "Fraction of image pixels assigned as ink-candidate regions"},
        "void_intensity_mean": {"value": 0.05, "unit": "a.u.", "source": "assumed",
                                "description": "Mean intensity of void or missing-material regions"},
        "num_stroke_seeds": {"value": 120, "unit": "count", "source": "assumed",
                             "description": "Number of random seed points for ink brushstroke centerlines"},
        "brushstroke_length_px": {"value": 18.0, "unit": "pixels", "source": "assumed",
                                  "description": "Mean length of each synthetic brushstroke segment"},
        "gaussian_blur_sigma": {"value": 1.2, "unit": "pixels", "source": "assumed",
                                "description": "Sigma for Gaussian smoothing applied to synthesized ink regions"},
        "texture_sigma": {"value": 3.0, "unit": "pixels", "source": "assumed",
                          "description": "Sigma for Gaussian blur creating papyrus fiber texture"},
        "baseline_noise_std": {"value": 0.02, "unit": "a.u.", "source": "assumed",
                               "description": "Standard deviation of additive Gaussian noise in the baseline scenario"},
        "high_noise_std": {"value": 0.08, "unit": "a.u.", "source": "assumed",
                           "description": "Elevated noise standard deviation for the high-noise scenario"},
        "low_contrast_scale": {"value": 0.35, "unit": "a.u.", "source": "assumed",
                               "description": "Contrast scale factor for low-contrast scenario"},
        "damage_fraction_damaged": {"value": 0.25, "unit": "fraction", "source": "assumed",
                                    "description": "Fraction of tile overwritten with void/damaged material"},
        "snr_threshold_dB": {"value": 6.0, "unit": "dB", "source": "assumed",
                             "description": "Minimum patch SNR threshold below which ink detection is unreliable"},
    },
    "scenarios": [
        {"label": "baseline", "noise_level": 0.02, "contrast_scale": 1.0, "damage_fraction": 0.0},
        {"label": "higher_noise", "noise_level": 0.08, "contrast_scale": 1.0, "damage_fraction": 0.0},
        {"label": "lower_contrast", "noise_level": 0.02, "contrast_scale": 0.35, "damage_fraction": 0.0},
        {"label": "damaged_region", "noise_level": 0.03, "contrast_scale": 1.0, "damage_fraction": 0.25},
        {"label": "parameter_sensitivity", "noise_level": 0.05, "contrast_scale": 0.7, "damage_fraction": 0.0},
    ],
    "sensitivity_sweep": {
        "contrast_values": list(np.linspace(0.1, 2.0, 12).tolist()),
        "noise_values": list(np.linspace(0.005, 0.15, 12).tolist()),
    },
}

# ─────────────────────────────────────────────────────────────────────────────
# SIMULATION FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def _gaussian_blur_2d(arr: np.ndarray, sigma: float) -> np.ndarray:
    """Pure-numpy separable Gaussian blur (avoids scipy dependency)."""
    if sigma <= 0:
        return arr.copy()
    radius = int(math.ceil(3 * sigma))
    k = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-0.5 * (k / sigma) ** 2)
    kernel /= kernel.sum()
    # convolve rows
    padded = np.pad(arr, ((0, 0), (radius, radius)), mode="reflect")
    blurred = np.zeros_like(arr, dtype=np.float64)
    for i, w in enumerate(kernel):
        blurred += w * padded[:, i: i + arr.shape[1]]
    # convolve cols
    padded2 = np.pad(blurred, ((radius, radius), (0, 0)), mode="reflect")
    out = np.zeros_like(arr, dtype=np.float64)
    for i, w in enumerate(kernel):
        out += w * padded2[i: i + arr.shape[0], :]
    return out


def make_background(H: int, W: int, bg_mean: float = 0.35, bg_std: float = 0.06,
                    texture_sigma: float = 3.0, rng: np.random.RandomState = None) -> np.ndarray:
    raw = rng.normal(bg_mean, bg_std, (H, W)).astype(np.float64)
    textured = _gaussian_blur_2d(raw, texture_sigma)
    mu = textured.mean()
    sd = textured.std()
    if sd < 1e-10:
        sd = 1e-10
    textured = (textured - mu) / sd * bg_std + bg_mean
    return np.clip(textured, 0.0, 1.0)


def make_ink_field(H: int, W: int, num_seeds: int = 120, stroke_len: float = 18.0,
                   stroke_width: float = 3.5, blur_sigma: float = 1.2,
                   rng: np.random.RandomState = None) -> np.ndarray:
    ink_raw = np.zeros((H, W), dtype=np.float64)
    x_grid = np.arange(W, dtype=np.float64)
    y_grid = np.arange(H, dtype=np.float64)
    XX, YY = np.meshgrid(x_grid, y_grid)

    for _ in range(num_seeds):
        x0 = rng.uniform(0.1 * W, 0.9 * W)
        y0 = rng.uniform(0.05 * H, 0.95 * H)
        theta = rng.uniform(-math.pi / 12, math.pi / 12)
        length = rng.normal(stroke_len, stroke_len * 0.3)
        length = max(4.0, float(length))
        num_blobs = max(4, int(length // 2))
        for t in np.linspace(0.0, length, num=num_blobs):
            cx = float(np.clip(x0 + t * math.cos(theta), 0, W - 1))
            cy = float(np.clip(y0 + t * math.sin(theta), 0, H - 1))
            blob = np.exp(-((XX - cx) ** 2 + (YY - cy) ** 2) / (2.0 * stroke_width ** 2))
            ink_raw += blob

    ink_field = _gaussian_blur_2d(ink_raw, blur_sigma)
    max_val = ink_field.max()
    if max_val < 1e-10:
        max_val = 1e-10
    ink_field = ink_field / max_val
    return np.clip(ink_field, 0.0, 1.0)


def make_fragment_mask(H: int, W: int, rng: np.random.RandomState = None) -> np.ndarray:
    cy, cx = H // 2, W // 2
    ry, rx = H * 0.48, W * 0.46
    Y, X = np.ogrid[:H, :W]
    theta_map = np.arctan2(Y - cy, X - cx)
    radial_noise = np.zeros((H, W), dtype=np.float64)
    for k in range(2, 8):
        amp = rng.uniform(5.0, 15.0)
        phase = rng.uniform(0.0, 2.0 * math.pi)
        radial_noise += amp * np.sin(k * theta_map + phase)
    dist = np.sqrt(((Y - cy) / ry) ** 2 + ((X - cx) / rx) ** 2)
    denom = math.sqrt(H ** 2 + W ** 2) * 0.5
    threshold = 1.0 + radial_noise / denom
    mask = (dist < threshold).astype(np.float32)
    return mask


def apply_damage(tile: np.ndarray, damage_fraction: float, void_mean: float = 0.05,
                 rng: np.random.RandomState = None) -> Tuple[np.ndarray, np.ndarray]:
    H, W = tile.shape
    damage_mask = np.zeros((H, W), dtype=bool)
    if damage_fraction <= 0.0:
        return tile.copy(), damage_mask

    center_y = rng.uniform(0.0, H)
    center_x = rng.uniform(0.0, W)
    target_area = damage_fraction * H * W
    radius = math.sqrt(target_area / math.pi)
    Y, X = np.ogrid[:H, :W]
    dist = np.sqrt((Y - center_y) ** 2 + (X - center_x) ** 2)
    damage_mask = dist < radius

    tile_out = tile.copy()
    n_damaged = int(damage_mask.sum())
    if n_damaged > 0:
        vals = rng.normal(void_mean, 0.01, n_damaged)
        vals = np.clip(vals, 0.0, 0.15)
        tile_out[damage_mask] = vals
    return tile_out, damage_mask


def composite_tile(bg: np.ndarray, ink_field: np.ndarray, fragment_mask: np.ndarray,
                   contrast_scale: float, ink_density: float = 0.18, ink_offset: float = 0.28,
                   noise_std: float = 0.02, rng: np.random.RandomState = None) -> Tuple[np.ndarray, np.ndarray]:
    ink_thresh = float(np.percentile(ink_field, (1.0 - ink_density) * 100.0))
    ink_binary = (ink_field >= ink_thresh).astype(np.float32)
    ink_component = contrast_scale * ink_offset * ink_field * ink_binary
    interior = np.clip(bg + ink_component, 0.0, 1.0)
    tile = fragment_mask * interior + (1.0 - fragment_mask) * 0.10
    noise = rng.normal(0.0, noise_std, tile.shape)
    tile = np.clip(tile + noise, 0.0, 1.0)
    return tile.astype(np.float32), ink_binary


def sigmoid(x: float) -> float:
    try:
        return 1.0 / (1.0 + math.exp(-x))
    except OverflowError:
        return 0.0 if x < 0 else 1.0


def sigmoid_arr(arr: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(arr, -500, 500)))


def extract_patches(tile: np.ndarray, ink_binary: np.ndarray, fragment_mask: np.ndarray,
                    scenario_label: str, noise_level: float, contrast_scale: float,
                    damage_fraction: float,
                    tile_size: int = 64, stride: int = 16,
                    voxel_size_um: float = 7.91, beam_energy_keV: float = 54.0) -> List[dict]:
    H, W = tile.shape
    records = []
    patch_idx = 0
    for row in range(0, H - tile_size + 1, stride):
        for col in range(0, W - tile_size + 1, stride):
            patch = tile[row: row + tile_size, col: col + tile_size]
            mask_patch = ink_binary[row: row + tile_size, col: col + tile_size]
            fmask_patch = fragment_mask[row: row + tile_size, col: col + tile_size]

            mean_int = float(patch.mean())
            std_int = float(patch.std())
            min_int = float(patch.min())
            max_int = float(patch.max())

            denom_contrast = max_int + min_int + 1e-8
            local_contrast = float(np.clip((max_int - min_int) / denom_contrast, 0.0, 1.0))

            ink_frac = float(mask_patch.mean())
            ink_frac = float(np.clip(ink_frac, 0.0, 1.0))

            ink_pixels = patch[mask_patch == 1]
            bg_pixels = patch[mask_patch == 0]

            if len(ink_pixels) > 0:
                ink_mean = float(ink_pixels.mean())
            else:
                ink_mean = mean_int

            if len(bg_pixels) > 1:
                bg_std_patch = float(bg_pixels.std())
            else:
                bg_std_patch = float(std_int)

            if bg_std_patch < 1e-8:
                bg_std_patch = 1e-8

            snr_raw = 20.0 * math.log10(max(ink_mean, 1e-8) / bg_std_patch)
            patch_snr = float(np.clip(snr_raw, 0.0, 40.0))

            ink_prob = float(np.clip(sigmoid((local_contrast - 0.70) / 0.10), 0.0, 1.0))

            binary_mask_sum = float(mask_patch.sum())
            void_frac = float(np.clip((patch < 0.10).mean(), 0.0, 1.0))
            papyrus_frac = float(np.clip(((patch >= 0.10) & (mask_patch == 0)).mean(), 0.0, 1.0))
            is_valid = (void_frac < 0.5) and (float(fmask_patch.mean()) > 0.6)

            records.append({
                "scenario": scenario_label,
                "patch_index": patch_idx,
                "patch_row": row,
                "patch_col": col,
                "tile_size_px": tile_size,
                "stride_px": stride,
                "voxel_size_um": voxel_size_um,
                "beam_energy_keV": beam_energy_keV,
                "noise_level": noise_level,
                "contrast_scale": contrast_scale,
                "damage_fraction": damage_fraction,
                "mean_intensity": round(mean_int, 6),
                "std_intensity": round(std_int, 6),
                "min_intensity": round(min_int, 6),
                "max_intensity": round(max_int, 6),
                "local_contrast": round(local_contrast, 6),
                "ink_fraction_gt": round(ink_frac, 6),
                "patch_snr_dB": round(patch_snr, 4),
                "ink_probability_mean": round(ink_prob, 6),
                "binary_mask_sum": int(binary_mask_sum),
                "void_fraction": round(void_frac, 6),
                "papyrus_fraction": round(papyrus_frac, 6),
                "is_valid_patch": int(is_valid),
            })
            patch_idx += 1
    return records


def run_scenario(label: str, noise_level: float, contrast_scale: float,
                 damage_fraction: float, scenario_index: int,
                 H: int = 512, W: int = 400) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[dict]]:
    """Run a single scenario and return (tile, ink_binary, fragment_mask, patch_records)."""
    np.random.seed(scenario_index)
    rng = np.random.RandomState(scenario_index)

    bg = make_background(H, W, rng=rng)
    ink_field = make_ink_field(H, W, rng=rng)
    fragment_mask = make_fragment_mask(H, W, rng=rng)

    tile, ink_binary = composite_tile(bg, ink_field, fragment_mask,
                                      contrast_scale=contrast_scale,
                                      noise_std=noise_level, rng=rng)

    if damage_fraction > 0.0:
        tile, _ = apply_damage(tile, damage_fraction, rng=rng)

    records = extract_patches(tile, ink_binary, fragment_mask,
                               scenario_label=label,
                               noise_level=noise_level,
                               contrast_scale=contrast_scale,
                               damage_fraction=damage_fraction)
    return tile, ink_binary, fragment_mask, records


def compute_sensitivity_surface(H: int = 512, W: int = 400) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute SNR surface over contrast_scale x noise_level grid."""
    contrast_values = np.linspace(0.1, 2.0, 12)
    noise_values = np.linspace(0.005, 0.15, 12)
    snr_surface = np.zeros((12, 12), dtype=np.float64)

    # Generate base fields once with fixed seed
    base_rng = np.random.RandomState(99)
    bg = make_background(H, W, rng=base_rng)
    ink_field = make_ink_field(H, W, rng=base_rng)
    fragment_mask = make_fragment_mask(H, W, rng=base_rng)

    for i, cs in enumerate(contrast_values):
        for j, nl in enumerate(noise_values):
            sweep_rng = np.random.RandomState(1000 + i * 12 + j)
            tile, ink_binary = composite_tile(bg, ink_field, fragment_mask,
                                              contrast_scale=float(cs),
                                              noise_std=float(nl), rng=sweep_rng)
            records = extract_patches(tile, ink_binary, fragment_mask,
                                      scenario_label="sweep",
                                      noise_level=float(nl),
                                      contrast_scale=float(cs),
                                      damage_fraction=0.0)
            snr_vals = [r["patch_snr_dB"] for r in records if r["is_valid_patch"] == 1]
            if snr_vals:
                snr_surface[j, i] = float(np.mean(snr_vals))
            else:
                snr_surface[j, i] = 0.0

    return snr_surface, contrast_values, noise_values


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE GENERATION
# ─────────────────────────────────────────────────────────────────────────────

def save_fig(fig: plt.Figure, path: pathlib.Path) -> None:
    fig.savefig(str(path), dpi=150, bbox_inches="tight")
    plt.close(fig)


def fig1_baseline_tile(tile: np.ndarray, out_dir: pathlib.Path) -> None:
    try:
        fig, ax = plt.subplots(figsize=(8, 10))
        im = ax.imshow(tile, cmap="gray", vmin=0, vmax=1, aspect="equal", origin="upper")
        ax.set_title("Baseline Scenario: Synthetic CT Tile Intensity Field\n"
                     "(PHerc.Paris.4 companion, 7.91 µm / 54 keV)", fontsize=12)
        ax.set_xlabel("pixel_x")
        ax.set_ylabel("pixel_y")
        plt.colorbar(im, ax=ax, label="Voxel Intensity (a.u.)")
        save_fig(fig, out_dir / "fig1_baseline_tile.png")
        print("Saved fig1")
    except Exception as e:
        print(f"Warning: fig1 failed: {e}")


def fig2_binary_mask_patch(tile: np.ndarray, ink_binary: np.ndarray, out_dir: pathlib.Path) -> None:
    try:
        H, W = tile.shape
        tile_size = 64
        # Select a patch with moderate ink density
        best_row, best_col = 0, 0
        best_score = -1.0
        for row in range(0, H - tile_size + 1, 16):
            for col in range(0, W - tile_size + 1, 16):
                m = ink_binary[row: row + tile_size, col: col + tile_size].mean()
                score = -abs(m - 0.18)
                if score > best_score:
                    best_score = score
                    best_row, best_col = row, col

        patch = tile[best_row: best_row + tile_size, best_col: best_col + tile_size]
        mask_patch = ink_binary[best_row: best_row + tile_size, best_col: best_col + tile_size]

        fig, axes = plt.subplots(1, 2, figsize=(10, 5))
        axes[0].imshow(patch, cmap="gray", vmin=0, vmax=1, aspect="equal")
        axes[0].set_title(f"Patch ({best_row},{best_col})\nIntensity Field", fontsize=10)
        axes[0].set_xlabel("pixel_x")
        axes[0].set_ylabel("pixel_y")

        axes[1].imshow(mask_patch, cmap="binary", vmin=0, vmax=1, aspect="equal")
        axes[1].set_title("Binary Ground-Truth\nInk Mask", fontsize=10)
        axes[1].set_xlabel("pixel_x")
        axes[1].set_ylabel("pixel_y")

        fig.suptitle("Baseline Scenario: Binary Ground-Truth Ink Mask (64×64 Patch)", fontsize=12)
        plt.tight_layout()
        save_fig(fig, out_dir / "fig2_binary_mask_patch.png")
        print("Saved fig2")
    except Exception as e:
        print(f"Warning: fig2 failed: {e}")


def fig3_higher_noise_tile(tile: np.ndarray, out_dir: pathlib.Path) -> None:
    try:
        fig, ax = plt.subplots(figsize=(8, 10))
        im = ax.imshow(tile, cmap="gray", vmin=0, vmax=1, aspect="equal", origin="upper")
        ax.set_title("Higher Noise Scenario: Synthetic CT Tile with Elevated Acquisition Noise\n"
                     "(noise_std=0.08)", fontsize=12)
        ax.set_xlabel("pixel_x")
        ax.set_ylabel("pixel_y")
        plt.colorbar(im, ax=ax, label="Voxel Intensity (a.u.)")
        save_fig(fig, out_dir / "fig3_higher_noise_tile.png")
        print("Saved fig3")
    except Exception as e:
        print(f"Warning: fig3 failed: {e}")


def fig4_lower_contrast_tile(tile: np.ndarray, out_dir: pathlib.Path) -> None:
    try:
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        im0 = axes[0].imshow(tile, cmap="gray", vmin=0, vmax=1, aspect="equal", origin="upper")
        axes[0].set_title("Lower Contrast Tile\n(contrast_scale=0.35)", fontsize=10)
        axes[0].set_xlabel("pixel_x")
        axes[0].set_ylabel("pixel_y")
        plt.colorbar(im0, ax=axes[0], label="Intensity")

        # Local contrast map via sliding window approximation using block means
        block = 16
        H, W = tile.shape
        lc_map = np.zeros_like(tile)
        for r in range(0, H, block):
            for c in range(0, W, block):
                blk = tile[r: min(r + block, H), c: min(c + block, W)]
                mn, mx = float(blk.min()), float(blk.max())
                lc = (mx - mn) / (mx + mn + 1e-8)
                lc_map[r: min(r + block, H), c: min(c + block, W)] = lc

        im1 = axes[1].imshow(lc_map, cmap="hot", vmin=0, vmax=0.5, aspect="equal", origin="upper")
        axes[1].set_title("Local Contrast Map\n(Michelson, 16px blocks)", fontsize=10)
        axes[1].set_xlabel("pixel_x")
        axes[1].set_ylabel("pixel_y")
        plt.colorbar(im1, ax=axes[1], label="Local Contrast")

        fig.suptitle("Lower Contrast Scenario: Synthetic CT Tile with Reduced Ink Visibility", fontsize=12)
        plt.tight_layout()
        save_fig(fig, out_dir / "fig4_lower_contrast_tile.png")
        print("Saved fig4")
    except Exception as e:
        print(f"Warning: fig4 failed: {e}")


def fig5_damaged_region_tile(tile: np.ndarray, out_dir: pathlib.Path) -> None:
    try:
        fig, ax = plt.subplots(figsize=(8, 10))
        im = ax.imshow(tile, cmap="gray", vmin=0, vmax=1, aspect="equal", origin="upper")
        ax.set_title("Damaged Region Scenario: Synthetic CT Tile with 25% Void/Loss Area\n"
                     "(damage_fraction=0.25, noise=0.03)", fontsize=12)
        ax.set_xlabel("pixel_x")
        ax.set_ylabel("pixel_y")
        plt.colorbar(im, ax=ax, label="Voxel Intensity (a.u.)")
        save_fig(fig, out_dir / "fig5_damaged_region_tile.png")
        print("Saved fig5")
    except Exception as e:
        print(f"Warning: fig5 failed: {e}")


def fig6_snr_surface(snr_surface: np.ndarray, contrast_values: np.ndarray,
                     noise_values: np.ndarray, out_dir: pathlib.Path) -> None:
    try:
        assert snr_surface.shape == (12, 12), "SNR surface shape mismatch"
        fig, ax = plt.subplots(figsize=(9, 7))
        im = ax.imshow(snr_surface, aspect="auto", origin="lower",
                       extent=[contrast_values[0], contrast_values[-1],
                                noise_values[0], noise_values[-1]],
                       cmap="hot", vmin=float(snr_surface.min()), vmax=float(snr_surface.max()))
        plt.colorbar(im, ax=ax, label="Mean Patch SNR (dB)")
        # Contour at SNR=6 dB
        try:
            cs = ax.contour(contrast_values, noise_values, snr_surface,
                            levels=[6.0], colors=["cyan"], linestyles=["--"])
            ax.clabel(cs, fmt="SNR=6 dB", fontsize=9)
        except Exception as ce:
            print(f"  Contour warning: {ce}")
        ax.set_xlabel("contrast_scale")
        ax.set_ylabel("noise_level")
        ax.set_title("Parameter Sensitivity: Mean Patch SNR vs Contrast Scale and Noise Level", fontsize=11)
        save_fig(fig, out_dir / "fig6_snr_surface.png")
        print("Saved fig6")
    except Exception as e:
        print(f"Warning: fig6 failed: {e}")


def fig7_intensity_histograms(tiles_by_scenario: Dict[str, np.ndarray], out_dir: pathlib.Path) -> None:
    try:
        colors = ["steelblue", "tomato", "forestgreen", "darkorange", "purple"]
        fig, ax = plt.subplots(figsize=(10, 6))
        for idx, (label, tile) in enumerate(tiles_by_scenario.items()):
            flat = tile.flatten()
            if len(flat) == 0:
                continue
            color = colors[idx % len(colors)]
            ax.hist(flat, bins=80, range=(0, 1), density=True, alpha=0.45,
                    color=color, label=label, edgecolor="none")
        ax.axvline(0.05, color="gray", linestyle=":", linewidth=1, label="void ~0.05")
        ax.axvline(0.35, color="black", linestyle=":", linewidth=1, label="papyrus bg ~0.35")
        ax.axvline(0.63, color="gold", linestyle=":", linewidth=1, label="ink ~0.63")
        ax.set_xlabel("Voxel Intensity (a.u.)")
        ax.set_ylabel("Normalized Pixel Count (density)")
        ax.set_title("All Scenarios: Voxel Intensity Distribution Comparison", fontsize=12)
        ax.legend(fontsize=9)
        save_fig(fig, out_dir / "fig7_intensity_histograms.png")
        print("Saved fig7")
    except Exception as e:
        print(f"Warning: fig7 failed: {e}")


def fig8_patch_snr_lines(records_by_scenario: Dict[str, List[dict]], out_dir: pathlib.Path) -> None:
    try:
        colors = ["steelblue", "tomato", "forestgreen", "darkorange", "purple"]
        fig, ax = plt.subplots(figsize=(12, 5))
        for idx, (label, records) in enumerate(records_by_scenario.items()):
            if not records:
                continue
            x_arr = np.array([r["patch_index"] for r in records], dtype=np.float64)
            y_arr = np.array([r["patch_snr_dB"] for r in records], dtype=np.float64)
            assert len(x_arr) == len(y_arr), f"Length mismatch for {label}"
            if len(x_arr) == 0:
                continue
            color = colors[idx % len(colors)]
            ax.plot(x_arr, y_arr, color=color, alpha=0.7, linewidth=0.8, label=label)
        ax.axhline(6.0, color="red", linestyle="--", linewidth=1.2, label="SNR threshold (6 dB)")
        ax.set_xlabel("patch_index")
        ax.set_ylabel("patch_snr_dB")
        ax.set_title("All Scenarios: Patch-Level SNR Across Extracted 64×64 Tiles", fontsize=12)
        ax.legend(fontsize=9)
        ax.set_ylim(0, 42)
        save_fig(fig, out_dir / "fig8_patch_snr_lines.png")
        print("Saved fig8")
    except Exception as e:
        print(f"Warning: fig8 failed: {e}")


def fig9_contrast_vs_ink_prob(baseline_records: List[dict], out_dir: pathlib.Path) -> None:
    try:
        if not baseline_records:
            print("Warning: fig9 skipped — no baseline records")
            return
        lc = np.array([r["local_contrast"] for r in baseline_records], dtype=np.float64)
        ip = np.array([r["ink_probability_mean"] for r in baseline_records], dtype=np.float64)
        ifr = np.array([r["ink_fraction_gt"] for r in baseline_records], dtype=np.float64)
        assert len(lc) == len(ip) == len(ifr), "Array length mismatch in fig9"
        if len(lc) == 0:
            print("Warning: fig9 skipped — empty arrays")
            return
        fig, ax = plt.subplots(figsize=(8, 6))
        sc = ax.scatter(lc, ip, c=ifr, cmap="viridis", alpha=0.6, s=20,
                        vmin=0, vmax=1)
        plt.colorbar(sc, ax=ax, label="Ground-truth ink fraction")
        ax.set_xlabel("local_contrast")
        ax.set_ylabel("ink_probability_mean")
        ax.set_title("Baseline Scenario: Local Contrast vs Ink Probability per 64×64 Patch", fontsize=11)
        save_fig(fig, out_dir / "fig9_contrast_vs_ink_prob.png")
        print("Saved fig9")
    except Exception as e:
        print(f"Warning: fig9 failed: {e}")


def fig10_snr_vs_contrast(snr_surface: np.ndarray, contrast_values: np.ndarray,
                          noise_values: np.ndarray, out_dir: pathlib.Path) -> None:
    try:
        # Fixed noise_level=0.05 → find nearest index
        target_noise = 0.05
        j_fixed = int(np.argmin(np.abs(noise_values - target_noise)))
        snr_row = snr_surface[j_fixed, :]  # shape (12,)

        assert len(contrast_values) == len(snr_row), "Length mismatch in fig10"
        if len(contrast_values) == 0:
            print("Warning: fig10 skipped — empty arrays")
            return

        # Also compute std across noise axis for error bars
        snr_std = snr_surface.std(axis=0)

        fig, ax = plt.subplots(figsize=(9, 5))
        ax.errorbar(contrast_values, snr_row, yerr=snr_std,
                    fmt="-o", color="steelblue", ecolor="lightblue",
                    capsize=3, linewidth=1.5, markersize=5)
        ax.axhline(6.0, color="red", linestyle="--", linewidth=1.2, label="SNR threshold (6 dB)")
        ax.axvline(1.0, color="green", linestyle="--", linewidth=1.2, label="baseline (cs=1.0)")
        ax.set_xlabel("contrast_scale")
        ax.set_ylabel("Mean Patch SNR (dB)")
        ax.set_title(f"Parameter Sensitivity: Mean Patch SNR vs Contrast Scale\n"
                     f"(noise_level≈{noise_values[j_fixed]:.3f})", fontsize=11)
        ax.legend(fontsize=9)
        ax.set_ylim(0, 42)
        save_fig(fig, out_dir / "fig10_snr_vs_contrast.png")
        print("Saved fig10")
    except Exception as e:
        print(f"Warning: fig10 failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# CSV / JSON WRITERS
# ─────────────────────────────────────────────────────────────────────────────

SCHEMA_COLS = [
    "scenario", "patch_index", "patch_row", "patch_col",
    "tile_size_px", "stride_px", "voxel_size_um", "beam_energy_keV",
    "noise_level", "contrast_scale", "damage_fraction",
    "mean_intensity", "std_intensity", "min_intensity", "max_intensity",
    "local_contrast", "ink_fraction_gt", "patch_snr_dB",
    "ink_probability_mean", "binary_mask_sum",
    "void_fraction", "papyrus_fraction", "is_valid_patch",
]


def write_simulation_outputs(all_records: List[dict], out_dir: pathlib.Path) -> None:
    path = out_dir / "simulation_outputs.csv"
    if not all_records:
        print("Warning: no records to write to simulation_outputs.csv")
        return
    try:
        with open(str(path), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=SCHEMA_COLS)
            writer.writeheader()
            for r in all_records:
                writer.writerow({col: r.get(col, "") for col in SCHEMA_COLS})
        print(f"Saved simulation_outputs.csv ({len(all_records)} rows)")
    except Exception as e:
        print(f"Warning: simulation_outputs.csv write failed: {e}")


def write_scenario_summary(records_by_scenario: Dict[str, List[dict]], out_dir: pathlib.Path) -> None:
    path = out_dir / "scenario_summary.csv"
    metric_vars = ["mean_intensity", "std_intensity", "min_intensity", "max_intensity",
                   "local_contrast", "ink_fraction_gt", "patch_snr_dB",
                   "ink_probability_mean", "void_fraction", "papyrus_fraction"]
    header = ["scenario", "n_patches", "n_valid"]
    for v in metric_vars:
        for stat in ["mean", "std", "min", "max"]:
            header.append(f"{v}_{stat}")

    rows = []
    for label, records in records_by_scenario.items():
        if not records:
            continue
        row = {"scenario": label, "n_patches": len(records),
               "n_valid": sum(r["is_valid_patch"] for r in records)}
        for v in metric_vars:
            vals = np.array([r[v] for r in records], dtype=np.float64)
            row[f"{v}_mean"] = round(float(vals.mean()), 6)
            row[f"{v}_std"] = round(float(vals.std()), 6)
            row[f"{v}_min"] = round(float(vals.min()), 6)
            row[f"{v}_max"] = round(float(vals.max()), 6)
        rows.append(row)

    if not rows:
        print("Warning: no scenario summary data to write")
        return
    try:
        with open(str(path), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=header)
            writer.writeheader()
            for r in rows:
                writer.writerow(r)
        print(f"Saved scenario_summary.csv ({len(rows)} rows)")
    except Exception as e:
        print(f"Warning: scenario_summary.csv write failed: {e}")


def write_parameters_used(out_dir: pathlib.Path) -> None:
    path = out_dir / "parameters_used.csv"
    header = ["name", "value", "unit", "source", "description"]
    rows = []
    for name, info in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })
    if not rows:
        print("Warning: no parameter rows to write")
        return
    try:
        with open(str(path), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=header)
            writer.writeheader()
            for r in rows:
                writer.writerow(r)
        print(f"Saved parameters_used.csv ({len(rows)} rows)")
    except Exception as e:
        print(f"Warning: parameters_used.csv write failed: {e}")


def write_summary_json(records_by_scenario: Dict[str, List[dict]],
                       snr_surface: np.ndarray, out_dir: pathlib.Path) -> None:
    path = out_dir / "summary.json"
    summary = {
        "title": "PHercParis4 Vesuvius Challenge CT Tile Synthetic Companion Simulator",
        "voxel_size_um": 7.91,
        "beam_energy_keV": 54.0,
        "tile_size_px": 64,
        "stride_px": 16,
        "image_H": 512,
        "image_W": 400,
        "scenarios": {},
        "sensitivity_sweep": {
            "snr_surface_mean": round(float(snr_surface.mean()), 4),
            "snr_surface_max": round(float(snr_surface.max()), 4),
            "snr_surface_min": round(float(snr_surface.min()), 4),
        }
    }
    for label, records in records_by_scenario.items():
        if not records:
            continue
        snr_vals = np.array([r["patch_snr_dB"] for r in records], dtype=np.float64)
        contrast_vals = np.array([r["local_contrast"] for r in records], dtype=np.float64)
        valid_count = sum(r["is_valid_patch"] for r in records)
        summary["scenarios"][label] = {
            "n_patches": len(records),
            "n_valid_patches": int(valid_count),
            "mean_snr_dB": round(float(snr_vals.mean()), 4),
            "std_snr_dB": round(float(snr_vals.std()), 4),
            "min_snr_dB": round(float(snr_vals.min()), 4),
            "max_snr_dB": round(float(snr_vals.max()), 4),
            "mean_local_contrast": round(float(contrast_vals.mean()), 4),
            "noise_level": records[0]["noise_level"],
            "contrast_scale": records[0]["contrast_scale"],
            "damage_fraction": records[0]["damage_fraction"],
        }
    try:
        with open(str(path), "w") as f:
            json.dump(summary, f, indent=2)
        print(f"Saved summary.json")
    except Exception as e:
        print(f"Warning: summary.json write failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="PHercParis4 Vesuvius Challenge CT Tile Synthetic Companion Simulator"
    )
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    H = int(MODEL_PROFILE["parameters"]["H"]["value"])
    W = int(MODEL_PROFILE["parameters"]["W"]["value"])
    scenarios = MODEL_PROFILE["scenarios"]

    tiles_by_scenario: Dict[str, np.ndarray] = {}
    records_by_scenario: Dict[str, List[dict]] = {}
    all_records: List[dict] = []

    # ── Run all scenarios ──
    for idx, sc in enumerate(scenarios):
        label = sc["label"]
        noise_level = sc["noise_level"]
        contrast_scale = sc["contrast_scale"]
        damage_fraction = sc["damage_fraction"]
        print(f"\nRunning scenario [{idx}]: {label}  "
              f"noise={noise_level}, contrast={contrast_scale}, damage={damage_fraction}")
        tile, ink_binary, fragment_mask, records = run_scenario(
            label, noise_level, contrast_scale, damage_fraction,
            scenario_index=idx, H=H, W=W
        )
        tiles_by_scenario[label] = tile
        records_by_scenario[label] = records
        all_records.extend(records)
        print(f"  Extracted {len(records)} patches; "
              f"valid={sum(r['is_valid_patch'] for r in records)}")

        # Per-scenario figures
        if label == "baseline":
            fig1_baseline_tile(tile, out_dir)
            fig2_binary_mask_patch(tile, ink_binary, out_dir)
        elif label == "higher_noise":
            fig3_higher_noise_tile(tile, out_dir)
        elif label == "lower_contrast":
            fig4_lower_contrast_tile(tile, out_dir)
        elif label == "damaged_region":
            fig5_damaged_region_tile(tile, out_dir)

    # ── Parameter sensitivity sweep ──
    print("\nRunning parameter sensitivity sweep (12×12 grid)…")
    snr_surface, contrast_values, noise_values = compute_sensitivity_surface(H=H, W=W)
    print(f"  SNR surface: min={snr_surface.min():.2f}, max={snr_surface.max():.2f} dB")

    # ── Multi-scenario figures ──
    fig6_snr_surface(snr_surface, contrast_values, noise_values, out_dir)
    fig7_intensity_histograms(tiles_by_scenario, out_dir)
    fig8_patch_snr_lines(records_by_scenario, out_dir)
    fig9_contrast_vs_ink_prob(records_by_scenario.get("baseline", []), out_dir)
    fig10_snr_vs_contrast(snr_surface, contrast_values, noise_values, out_dir)

    # ── Write CSVs ──
    print("\nWriting CSV files…")
    write_simulation_outputs(all_records, out_dir)
    write_scenario_summary(records_by_scenario, out_dir)
    write_parameters_used(out_dir)

    # ── Write JSON summary ──
    print("Writing summary JSON…")
    write_summary_json(records_by_scenario, snr_surface, out_dir)

    print(f"\nAll outputs saved to: {out_dir.resolve()}")
    print("Simulator complete.")


if __name__ == "__main__":
    main()