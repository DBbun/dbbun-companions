================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : b9cbfcff-c42b-45ab-8837-3f7d8abb761e
    Generated   : 2026-04-28  16:54:39 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Homeowner Association

    CATEGORIES
    ----------
    Social Sciences, Financial, Demographic

    KEYWORDS
    --------
    homeowner association, property value premium, HOA governance, reserve fund dynamics, assessment delinquency

    ABSTRACT
    --------
    This simulator models the financial, governance, and socioeconomic dynamics of homeowner associations (HOAs) using a monthly time-step agent-based framework. It reproduces key empirically documented phenomena including the 4% average HOA property value premium reported in the 2019 Journal of Labor Economics, the interplay between reserve fund adequacy and amenity quality, and feedback loops between board misconduct, homeowner satisfaction, and delinquency rates. Six scenarios spanning well-governed HOAs, underfunded reserves, board misconduct, economic stress, upscale communities, and embezzlement events generate synthetic datasets capturing the full range of HOA outcomes described in the source. Researchers, urban planners, and HOA board members can use the simulator to test financial strategies, evaluate governance policies, and understand how specific decisions propagate into property values and community welfare over a 10-year horizon.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Homeowner_association.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    n_homes, n_members, operating_fund, reserve_fund, monthly_assessment, compliance_rate, delinquency_rate, avg_property_value, hoa_premium, satisfaction_index, board_misconduct_level, special_assessment_triggered, amenity_quality, litigation_cost, time_months, n_foreclosures, tax_vote_support, reserve_funding_ratio

    SCENARIOS  (6 total)
    ---------------------------------
        1. baseline_well_governed — Well-governed HOA with adequate reserves, low delinquency, low misconduct, stable amenities and typical 4% property premium
2. underfunded_reserves — HOA with chronically low reserve contributions leading to amenity decay, special assessments, and eroding property premium
3. high_misconduct_board — HOA board with elevated misconduct probability, high litigation costs, low member satisfaction, and declining property values
4. high_delinquency_economic_stress — Economic downturn scenario with elevated delinquency, reduced assessment income, special assessments triggered, and increased foreclosures
5. large_premium_hoa — Upscale HOA with high amenity quality, high assessments, strong governance, producing an above-average property value premium up to 8%
6. embezzlement_event — HOA that experiences a major embezzlement event mid-simulation, causing reserve fund collapse, special assessment, and satisfaction drop

    PARAMETERS
    ----------
    28 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9

    DOMAIN SUMMARY
    --------------
    This source covers the structure, governance, financial dynamics, historical development, and socioeconomic effects of homeowner associations (HOAs) in the United States and internationally, including membership growth, assessment economics, property value premiums, and board governance patterns.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.