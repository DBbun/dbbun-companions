# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T16:54:39.511805Z
# Run ID    : b9cbfcff-c42b-45ab-8837-3f7d8abb761e
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
HOA Simulator - Monthly Time-Step Agent-Based Model

Based on: "Homeowner Association" - covering structure, governance, financial dynamics,
historical development, and socioeconomic effects of homeowner associations (HOAs)
in the United States and internationally.

Key empirical references:
- 2019 Journal of Labor Economics: HOA homes average 4% ($13,500) premium over non-HOA
- Community Associations Institute (2010): 24.8M HOA homes, 62M residents in US
- California HOA law: board can levy special assessment up to 5% of annual budget without member vote
"""

import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional

# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "name": "HOA Agent-Based Simulator",
    "domain": "Homeowner Association Governance and Financial Dynamics",
    "backend": "agent_based",
    "time_unit": "months",
    "simulation_months": 120,
    "parameters": {
        "annual_operating_budget_per_home": {"value": 2400.0, "unit": "USD/home/year", "source": "assumed",
            "description": "Annual operating expenditure per home for common area maintenance and services"},
        "reserve_contribution_rate": {"value": 80.0, "unit": "USD/home/month", "source": "assumed",
            "description": "Monthly per-home contribution to reserve fund"},
        "hoa_property_premium_base": {"value": 0.04, "unit": "fraction", "source": "extracted",
            "description": "Base HOA property value premium above comparable non-HOA homes, from 2019 Journal of Labor Economics"},
        "hoa_dollar_premium": {"value": 13500.0, "unit": "USD", "source": "extracted",
            "description": "Dollar value of HOA property premium from 2019 study"},
        "us_hoa_homes_2010": {"value": 24800000.0, "unit": "homes", "source": "extracted",
            "description": "Number of American homes governed by HOAs in 2010 per Community Associations Institute"},
        "us_hoa_residents_2010": {"value": 62000000.0, "unit": "persons", "source": "extracted",
            "description": "Number of US residents in HOAs in 2010 per Community Associations Institute"},
        "special_assessment_threshold_ca": {"value": 0.05, "unit": "fraction", "source": "extracted",
            "description": "California threshold: board can impose special assessment without member vote only if <= 5% of annual budget"},
        "fine_trigger_probability": {"value": 0.03, "unit": "probability/month", "source": "assumed",
            "description": "Monthly probability that any single homeowner receives a violation notice"},
        "fine_amount_avg": {"value": 150.0, "unit": "USD", "source": "assumed",
            "description": "Average fine amount per CC&R violation"},
        "delinquency_base_rate": {"value": 0.05, "unit": "fraction", "source": "assumed",
            "description": "Baseline fraction of homeowners delinquent on assessments in normal conditions"},
        "property_value_growth_base": {"value": 0.03, "unit": "fraction/year", "source": "assumed",
            "description": "Annual baseline appreciation rate for home values in HOA community"},
        "non_hoa_property_growth_base": {"value": 0.025, "unit": "fraction/year", "source": "assumed",
            "description": "Annual baseline appreciation rate for comparable non-HOA homes"},
        "misconduct_probability": {"value": 0.02, "unit": "probability/month", "source": "assumed",
            "description": "Monthly probability of a board misconduct event occurring"},
        "satisfaction_amenity_weight": {"value": 0.40, "unit": "a.u.", "source": "assumed",
            "description": "Weight of amenity quality in homeowner satisfaction calculation"},
        "satisfaction_governance_weight": {"value": 0.35, "unit": "a.u.", "source": "assumed",
            "description": "Weight of governance quality in homeowner satisfaction calculation"},
        "satisfaction_financial_weight": {"value": 0.25, "unit": "a.u.", "source": "assumed",
            "description": "Weight of financial stability (reserve ratio) in homeowner satisfaction calculation"},
        "amenity_decay_rate": {"value": 0.005, "unit": "fraction/month", "source": "assumed",
            "description": "Monthly fractional decay in amenity quality if reserve fund is underfunded"},
        "amenity_maintenance_threshold": {"value": 0.50, "unit": "fraction", "source": "assumed",
            "description": "Reserve funding ratio below which amenity quality begins to decay"},
        "litigation_base_probability": {"value": 0.01, "unit": "probability/month", "source": "assumed",
            "description": "Monthly probability of a homeowner-initiated lawsuit against HOA"},
        "litigation_cost_per_event": {"value": 25000.0, "unit": "USD", "source": "assumed",
            "description": "Average legal cost per litigation event"},
        "foreclosure_delinquency_threshold": {"value": 0.10, "unit": "fraction", "source": "assumed",
            "description": "Delinquency rate above which HOA may initiate foreclosure proceedings"},
        "tax_vote_hoa_penalty": {"value": 0.15, "unit": "fraction", "source": "extracted",
            "description": "Reduction in municipal tax vote support among HOA members vs non-HOA residents"},
        "simulation_months": {"value": 120.0, "unit": "months", "source": "assumed",
            "description": "Total simulation duration"},
        "n_homes_init": {"value": 250.0, "unit": "homes", "source": "assumed",
            "description": "Initial number of homes in HOA community"},
        "reserve_target_per_home": {"value": 5000.0, "unit": "USD/home", "source": "assumed",
            "description": "Fully funded reserve target per home for capital replacement"},
        "assessment_increase_rate": {"value": 0.05, "unit": "fraction/year", "source": "assumed",
            "description": "Annual fractional increase in monthly assessment when operating fund falls below threshold"},
        "embezzlement_probability": {"value": 0.02, "unit": "probability/year", "source": "assumed",
            "description": "Annual probability of significant embezzlement event occurring in HOA"},
        "embezzlement_amount_fraction": {"value": 0.20, "unit": "fraction", "source": "assumed",
            "description": "Fraction of reserve fund lost in an embezzlement event"},
    },
    "scenarios": [
        {
            "label": "baseline_well_governed",
            "description": "Well-governed HOA with adequate reserves, low delinquency, low misconduct",
            "param_overrides": {
                "monthly_assessment": 300.0, "delinquency_base_rate": 0.05,
                "misconduct_probability": 0.01, "reserve_contribution_rate": 80.0,
                "hoa_property_premium_base": 0.04
            }
        },
        {
            "label": "underfunded_reserves",
            "description": "HOA with chronically low reserve contributions",
            "param_overrides": {
                "reserve_contribution_rate": 30.0, "monthly_assessment": 180.0,
                "amenity_decay_rate": 0.012, "amenity_maintenance_threshold": 0.50,
                "hoa_property_premium_base": 0.02
            }
        },
        {
            "label": "high_misconduct_board",
            "description": "HOA board with elevated misconduct probability and high litigation costs",
            "param_overrides": {
                "misconduct_probability": 0.08, "litigation_base_probability": 0.04,
                "litigation_cost_per_event": 40000.0, "satisfaction_governance_weight": 0.50,
                "hoa_property_premium_base": 0.02
            }
        },
        {
            "label": "high_delinquency_economic_stress",
            "description": "Economic downturn scenario with elevated delinquency",
            "param_overrides": {
                "delinquency_base_rate": 0.18, "property_value_growth_base": -0.02,
                "non_hoa_property_growth_base": -0.025, "monthly_assessment": 300.0,
                "fine_trigger_probability": 0.06
            }
        },
        {
            "label": "large_premium_hoa",
            "description": "Upscale HOA with high amenity quality and strong governance",
            "param_overrides": {
                "monthly_assessment": 700.0, "reserve_contribution_rate": 200.0,
                "hoa_property_premium_base": 0.08, "amenity_quality": 0.95,
                "misconduct_probability": 0.005, "delinquency_base_rate": 0.02
            }
        },
        {
            "label": "embezzlement_event",
            "description": "HOA that experiences a major embezzlement event mid-simulation",
            "param_overrides": {
                "embezzlement_probability": 1.0, "embezzlement_amount_fraction": 0.40,
                "monthly_assessment": 300.0, "reserve_contribution_rate": 80.0
            }
        },
    ]
}

# Default initial state values
INIT_STATE = {
    "n_homes": 250.0,
    "n_members": 250.0,
    "operating_fund": 125000.0,
    "reserve_fund": 250000.0,
    "monthly_assessment": 300.0,
    "compliance_rate": 0.90,
    "delinquency_rate": 0.05,
    "avg_property_value": 350000.0,
    "hoa_premium": 0.04,
    "satisfaction_index": 0.65,
    "board_misconduct_level": 0.10,
    "special_assessment_triggered": 0.0,
    "amenity_quality": 0.75,
    "litigation_cost": 0.0,
    "time_months": 0.0,
    "n_foreclosures": 0.0,
    "tax_vote_support": 0.45,
    "reserve_funding_ratio": 0.70,
}

# Variable ranges for clamping
VAR_RANGES = {
    "n_homes": (10, 5000),
    "n_members": (10, 5000),
    "operating_fund": (0, 5000000),
    "reserve_fund": (0, 10000000),
    "monthly_assessment": (50, 2000),
    "compliance_rate": (0.0, 1.0),
    "delinquency_rate": (0.0, 1.0),
    "avg_property_value": (50000, 3000000),
    "hoa_premium": (0.0, 0.20),
    "satisfaction_index": (0.0, 1.0),
    "board_misconduct_level": (0.0, 1.0),
    "special_assessment_triggered": (0.0, 1.0),
    "amenity_quality": (0.0, 1.0),
    "litigation_cost": (0.0, 5000000),
    "n_foreclosures": (0.0, 500.0),
    "tax_vote_support": (0.0, 1.0),
    "reserve_funding_ratio": (0.0, 2.0),
}

SCENARIO_COLORS = [
    '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b'
]


def build_params(scenario_overrides: Dict[str, Any]) -> Dict[str, Any]:
    """Build parameter dict from defaults plus scenario overrides."""
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    params.update(scenario_overrides)
    return params


def run_scenario(scenario: Dict[str, Any], scenario_index: int) -> List[Dict[str, Any]]:
    """Run a single HOA scenario simulation and return list of row dicts."""
    np.random.seed(scenario_index)
    label = scenario["label"]
    overrides = scenario["param_overrides"]
    params = build_params(overrides)

    sim_months = int(MODEL_PROFILE["simulation_months"])

    # Initialize state variables
    n_homes = float(INIT_STATE["n_homes"])
    n_members = float(INIT_STATE["n_members"])
    operating_fund = float(INIT_STATE["operating_fund"])
    reserve_fund = float(INIT_STATE["reserve_fund"])
    monthly_assessment = float(overrides.get("monthly_assessment", INIT_STATE["monthly_assessment"]))
    compliance_rate = float(INIT_STATE["compliance_rate"])
    delinquency_rate = float(overrides.get("delinquency_base_rate", INIT_STATE["delinquency_rate"]))
    avg_property_value = float(INIT_STATE["avg_property_value"])
    board_misconduct_level = float(INIT_STATE["board_misconduct_level"])
    amenity_quality = float(overrides.get("amenity_quality", INIT_STATE["amenity_quality"]))
    satisfaction_index = float(INIT_STATE["satisfaction_index"])
    litigation_cost_cumulative = float(INIT_STATE["litigation_cost"])
    n_foreclosures_cumulative = float(INIT_STATE["n_foreclosures"])

    # Derived
    reserve_target = n_homes * params["reserve_target_per_home"]
    reserve_funding_ratio = reserve_fund / reserve_target if reserve_target > 0 else 0.0
    non_hoa_property_value = avg_property_value / (1.0 + params["hoa_property_premium_base"])

    # Params
    annual_op_budget_per_home = params["annual_operating_budget_per_home"]
    reserve_contribution_rate = params["reserve_contribution_rate"]
    hoa_premium_base = params["hoa_property_premium_base"]
    fine_trigger_prob = params["fine_trigger_probability"]
    fine_amount_avg = params["fine_amount_avg"]
    delinquency_base_rate = params["delinquency_base_rate"]
    prop_growth_base = params["property_value_growth_base"]
    non_hoa_growth_base = params["non_hoa_property_growth_base"]
    misconduct_prob = params["misconduct_probability"]
    sat_amenity_w = params["satisfaction_amenity_weight"]
    sat_gov_w = params["satisfaction_governance_weight"]
    sat_fin_w = params["satisfaction_financial_weight"]
    amenity_decay_rate = params["amenity_decay_rate"]
    amenity_maint_thresh = params["amenity_maintenance_threshold"]
    lit_base_prob = params["litigation_base_probability"]
    lit_cost_per_event = params["litigation_cost_per_event"]
    foreclosure_thresh = params["foreclosure_delinquency_threshold"]
    tax_vote_penalty = params["tax_vote_hoa_penalty"]
    assessment_increase_rate = params["assessment_increase_rate"]
    embezzlement_prob = params["embezzlement_probability"]
    embezzlement_frac = params["embezzlement_amount_fraction"]

    # Normalize satisfaction weights so they sum to 1
    total_w = sat_amenity_w + sat_gov_w + sat_fin_w
    if total_w > 0:
        sat_amenity_w /= total_w
        sat_gov_w /= total_w
        sat_fin_w /= total_w

    hoa_monthly_growth = (1.0 + prop_growth_base) ** (1.0 / 12.0) - 1.0
    non_hoa_monthly_growth = (1.0 + non_hoa_growth_base) ** (1.0 / 12.0) - 1.0

    results = []

    for t in range(sim_months):
        # Reset per-step flags
        special_assessment_triggered = 0
        special_assessment_amount = 0.0
        embezzlement_event = 0

        # STEP 1: Income Collection
        n_paying = n_members * (1.0 - delinquency_rate)
        monthly_assessment_income = n_paying * monthly_assessment
        fine_revenue = n_members * fine_trigger_prob * (1.0 - compliance_rate) * fine_amount_avg
        fine_revenue = max(0.0, fine_revenue)
        total_income = monthly_assessment_income + fine_revenue

        # STEP 2: Expense Calculation
        monthly_operating_expense = n_homes * (annual_op_budget_per_home / 12.0)
        reserve_contribution = n_paying * reserve_contribution_rate
        total_expense = monthly_operating_expense

        # STEP 3: Fund Updates
        operating_fund += total_income - total_expense
        reserve_fund += reserve_contribution
        reserve_target = n_homes * params["reserve_target_per_home"]
        reserve_funding_ratio = reserve_fund / reserve_target if reserve_target > 0 else 0.0
        reserve_funding_ratio = max(0.0, min(2.0, reserve_funding_ratio))

        # STEP 4: Special Assessment Logic
        if operating_fund < 0:
            shortfall = abs(operating_fund)
            max_board_assessment = 0.05 * (annual_op_budget_per_home * n_homes)
            if shortfall <= max_board_assessment:
                special_assessment_amount = shortfall / max(n_members, 1)
                operating_fund += shortfall
                special_assessment_triggered = 1
            else:
                vote_passes = np.random.random() < 0.60
                if vote_passes:
                    operating_fund += shortfall
                    special_assessment_amount = shortfall / max(n_members, 1)
                    special_assessment_triggered = 1

        operating_fund = max(0.0, min(5000000.0, operating_fund))

        # STEP 5: Embezzlement Event (checked every month, with annual rate)
        if t % 12 == 0:
            monthly_embez_prob = embezzlement_prob / 12.0
            if np.random.random() < monthly_embez_prob:
                loss = reserve_fund * embezzlement_frac
                reserve_fund = max(0.0, reserve_fund - loss)
                board_misconduct_level = min(1.0, board_misconduct_level + 0.30)
                embezzlement_event = 1
            else:
                embezzlement_event = 0
        else:
            embezzlement_event = 0

        # STEP 6: Board Misconduct Update
        if np.random.random() < misconduct_prob:
            board_misconduct_level = min(1.0, board_misconduct_level + 0.05)
        else:
            board_misconduct_level = max(0.0, board_misconduct_level - 0.01)

        # STEP 7: Litigation
        lit_prob = lit_base_prob + 0.5 * board_misconduct_level
        if np.random.random() < lit_prob:
            litigation_cost_cumulative = min(5000000.0, litigation_cost_cumulative + lit_cost_per_event)
            operating_fund = max(0.0, operating_fund - lit_cost_per_event)

        # STEP 8: Amenity Quality Update
        reserve_funding_ratio = reserve_fund / reserve_target if reserve_target > 0 else 0.0
        reserve_funding_ratio = max(0.0, min(2.0, reserve_funding_ratio))
        if reserve_funding_ratio < amenity_maint_thresh:
            amenity_quality = max(0.0, amenity_quality - amenity_decay_rate)
        else:
            amenity_quality = min(1.0, amenity_quality + 0.002)

        # STEP 9: Compliance and Delinquency Update
        delinquency_target = (delinquency_base_rate
                              + 0.10 * (1.0 - satisfaction_index)
                              + 0.05 * (1.0 - amenity_quality))
        delinquency_target = max(0.0, min(1.0, delinquency_target))
        delinquency_rate = 0.90 * delinquency_rate + 0.10 * delinquency_target
        delinquency_rate = max(0.0, min(1.0, delinquency_rate))
        compliance_rate = max(0.0, min(1.0, 1.0 - delinquency_rate - fine_trigger_prob * 0.5))

        # STEP 10: Foreclosure Logic
        if delinquency_rate > foreclosure_thresh:
            new_foreclosures = int(n_members * (delinquency_rate - foreclosure_thresh) * 0.01)
            n_foreclosures_cumulative = min(500.0, n_foreclosures_cumulative + new_foreclosures)

        # STEP 11: Property Value Update
        effective_premium = hoa_premium_base * amenity_quality * (1.0 - board_misconduct_level)
        effective_premium = max(0.0, min(0.20, effective_premium))
        non_hoa_property_value *= (1.0 + non_hoa_monthly_growth)
        avg_property_value = non_hoa_property_value * (1.0 + effective_premium)
        avg_property_value = max(50000.0, min(3000000.0, avg_property_value))
        hoa_premium_fraction = effective_premium

        # STEP 12: Satisfaction Index Update
        governance_score = 1.0 - board_misconduct_level
        financial_score = min(1.0, reserve_funding_ratio)
        satisfaction_index = (
            sat_amenity_w * amenity_quality
            + sat_gov_w * governance_score
            + sat_fin_w * financial_score
        )
        satisfaction_index = max(0.0, min(1.0, satisfaction_index))

        # STEP 13: Municipal Tax Vote Support
        tax_vote_support = max(0.0, min(1.0, 0.55 - tax_vote_penalty + 0.10 * (1.0 - satisfaction_index)))

        # STEP 14: Assessment Adjustment (annual)
        if t % 12 == 0 and t > 0:
            if operating_fund < (monthly_operating_expense * 3.0):
                monthly_assessment = min(2000.0, monthly_assessment * (1.0 + assessment_increase_rate))

        # Clamp all values
        operating_fund = max(0.0, min(5000000.0, operating_fund))
        reserve_fund = max(0.0, min(10000000.0, reserve_fund))
        reserve_funding_ratio = max(0.0, min(2.0, reserve_funding_ratio))
        board_misconduct_level = max(0.0, min(1.0, board_misconduct_level))
        amenity_quality = max(0.0, min(1.0, amenity_quality))
        delinquency_rate = max(0.0, min(1.0, delinquency_rate))
        compliance_rate = max(0.0, min(1.0, compliance_rate))
        satisfaction_index = max(0.0, min(1.0, satisfaction_index))
        n_foreclosures_cumulative = max(0.0, min(500.0, n_foreclosures_cumulative))
        litigation_cost_cumulative = max(0.0, min(5000000.0, litigation_cost_cumulative))
        monthly_assessment = max(50.0, min(2000.0, monthly_assessment))
        avg_property_value = max(50000.0, min(3000000.0, avg_property_value))
        hoa_premium_fraction = max(0.0, min(0.20, hoa_premium_fraction))
        tax_vote_support = max(0.0, min(1.0, tax_vote_support))

        # STEP 15: Record output row
        row = {
            "scenario": label,
            "time_months": t,
            "n_homes": n_homes,
            "n_members": n_members,
            "operating_fund_usd": operating_fund,
            "reserve_fund_usd": reserve_fund,
            "reserve_funding_ratio": reserve_funding_ratio,
            "monthly_assessment_usd": monthly_assessment,
            "total_monthly_income_usd": total_income,
            "total_monthly_operating_expense_usd": total_expense,
            "compliance_rate": compliance_rate,
            "delinquency_rate": delinquency_rate,
            "avg_property_value_usd": avg_property_value,
            "non_hoa_property_value_usd": non_hoa_property_value,
            "hoa_premium_fraction": hoa_premium_fraction,
            "satisfaction_index": satisfaction_index,
            "board_misconduct_level": board_misconduct_level,
            "amenity_quality": amenity_quality,
            "special_assessment_triggered": special_assessment_triggered,
            "special_assessment_amount_usd": special_assessment_amount,
            "litigation_cost_cumulative_usd": litigation_cost_cumulative,
            "n_foreclosures_cumulative": n_foreclosures_cumulative,
            "tax_vote_support_fraction": tax_vote_support,
            "fine_revenue_monthly_usd": fine_revenue,
            "embezzlement_event": embezzlement_event,
            "reserve_target_usd": reserve_target,
        }
        results.append(row)

    return results


def run_all_scenarios() -> List[Dict[str, Any]]:
    """Run all scenarios and return combined results."""
    all_results = []
    scenarios = MODEL_PROFILE["scenarios"]
    for idx, scenario in enumerate(scenarios):
        print(f"  Running scenario {idx+1}/{len(scenarios)}: {scenario['label']}")
        rows = run_scenario(scenario, scenario_index=idx)
        all_results.extend(rows)
    return all_results


def compute_scenario_summary(all_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Compute per-scenario aggregate metrics."""
    scenarios = MODEL_PROFILE["scenarios"]
    scenario_labels = [s["label"] for s in scenarios]
    numeric_vars = [
        "operating_fund_usd", "reserve_fund_usd", "reserve_funding_ratio",
        "monthly_assessment_usd", "compliance_rate", "delinquency_rate",
        "avg_property_value_usd", "hoa_premium_fraction", "satisfaction_index",
        "board_misconduct_level", "amenity_quality", "litigation_cost_cumulative_usd",
        "n_foreclosures_cumulative", "tax_vote_support_fraction"
    ]

    summary_rows = []
    for label in scenario_labels:
        rows = [r for r in all_results if r["scenario"] == label]
        if not rows:
            continue
        summary = {"scenario": label}
        for var in numeric_vars:
            vals = np.array([r[var] for r in rows])
            summary[f"{var}_mean"] = float(np.mean(vals))
            summary[f"{var}_std"] = float(np.std(vals))
            summary[f"{var}_min"] = float(np.min(vals))
            summary[f"{var}_max"] = float(np.max(vals))
        # Final period values
        final_row = rows[-1]
        summary["final_operating_fund_usd"] = final_row["operating_fund_usd"]
        summary["final_reserve_fund_usd"] = final_row["reserve_fund_usd"]
        summary["final_reserve_funding_ratio"] = final_row["reserve_funding_ratio"]
        summary["final_satisfaction_index"] = final_row["satisfaction_index"]
        summary["final_amenity_quality"] = final_row["amenity_quality"]
        summary["final_delinquency_rate"] = final_row["delinquency_rate"]
        summary["final_avg_property_value_usd"] = final_row["avg_property_value_usd"]
        summary["final_hoa_premium_fraction"] = final_row["hoa_premium_fraction"]
        summary["final_board_misconduct_level"] = final_row["board_misconduct_level"]
        summary["total_litigation_cost_usd"] = final_row["litigation_cost_cumulative_usd"]
        summary["total_foreclosures"] = final_row["n_foreclosures_cumulative"]
        summary["n_special_assessments"] = sum(1 for r in rows if r["special_assessment_triggered"] == 1)
        summary["n_embezzlement_events"] = sum(1 for r in rows if r["embezzlement_event"] == 1)
        summary_rows.append(summary)
    return summary_rows


def save_simulation_outputs(all_results: List[Dict[str, Any]], output_dir: Path) -> None:
    """Save primary simulation outputs CSV."""
    if not all_results:
        print("WARNING: No results to write to simulation_outputs.csv")
        return
    fieldnames = list(all_results[0].keys())
    filepath = output_dir / "simulation_outputs.csv"
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(all_results)
        print(f"  Saved: {filepath}")
    except Exception as e:
        print(f"WARNING: Failed to write simulation_outputs.csv: {e}")


def save_scenario_summary(summary_rows: List[Dict[str, Any]], output_dir: Path) -> None:
    """Save scenario summary CSV."""
    if not summary_rows:
        print("WARNING: No summary rows to write.")
        return
    fieldnames = list(summary_rows[0].keys())
    filepath = output_dir / "scenario_summary.csv"
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(summary_rows)
        print(f"  Saved: {filepath}")
    except Exception as e:
        print(f"WARNING: Failed to write scenario_summary.csv: {e}")


def save_parameters_used(output_dir: Path) -> None:
    """Save parameters used CSV."""
    filepath = output_dir / "parameters_used.csv"
    rows = []
    for name, info in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })
    if not rows:
        print("WARNING: No parameter rows to write.")
        return
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
            writer.writeheader()
            writer.writerows(rows)
        print(f"  Saved: {filepath}")
    except Exception as e:
        print(f"WARNING: Failed to write parameters_used.csv: {e}")


def save_summary_json(summary_rows: List[Dict[str, Any]], all_results: List[Dict[str, Any]], output_dir: Path) -> None:
    """Save summary JSON."""
    filepath = output_dir / "summary.json"
    metrics = {}
    for row in summary_rows:
        label = row["scenario"]
        metrics[label] = {
            "final_satisfaction_index": row.get("final_satisfaction_index", 0),
            "final_reserve_funding_ratio": row.get("final_reserve_funding_ratio", 0),
            "final_amenity_quality": row.get("final_amenity_quality", 0),
            "final_delinquency_rate": row.get("final_delinquency_rate", 0),
            "total_litigation_cost_usd": row.get("total_litigation_cost_usd", 0),
            "total_foreclosures": row.get("total_foreclosures", 0),
            "n_special_assessments": row.get("n_special_assessments", 0),
        }
    summary_json = {
        "model": MODEL_PROFILE["name"],
        "simulation_months": MODEL_PROFILE["simulation_months"],
        "n_scenarios": len(MODEL_PROFILE["scenarios"]),
        "total_rows": len(all_results),
        "scenario_metrics": metrics,
    }
    try:
        with open(filepath, "w") as f:
            json.dump(summary_json, f, indent=2)
        print(f"  Saved: {filepath}")
    except Exception as e:
        print(f"WARNING: Failed to write summary.json: {e}")


def get_scenario_data(all_results: List[Dict[str, Any]], label: str) -> Dict[str, np.ndarray]:
    """Extract arrays for a specific scenario."""
    rows = [r for r in all_results if r["scenario"] == label]
    if not rows:
        return {}
    keys = rows[0].keys()
    return {k: np.array([r[k] for r in rows]) for k in keys}


def generate_figures(all_results: List[Dict[str, Any]], output_dir: Path) -> None:
    """Generate all figures from the figure plan."""
    scenarios = MODEL_PROFILE["scenarios"]
    scenario_labels = [s["label"] for s in scenarios]
    colors = SCENARIO_COLORS

    # Pre-extract scenario data
    scenario_data = {}
    for label in scenario_labels:
        scenario_data[label] = get_scenario_data(all_results, label)

    # ── FIG 1: Operating Fund Over Time ─────────────────────────────────────
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["time_months"]
            y = d["operating_fund_usd"]
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) > 0:
                ax.plot(x, y / 1000.0, label=label.replace("_", " "), color=colors[idx], linewidth=2)
                plotted = True
        if plotted:
            ax.set_xlabel("Time (months)")
            ax.set_ylabel("Operating Fund Balance ($ thousands)")
            ax.set_title("HOA Operating Fund Balance Over Time by Scenario")
            ax.legend(fontsize=8, loc="upper left")
            ax.grid(True, alpha=0.3)
            ax.axhline(0, color='black', linewidth=0.8, linestyle='--')
            plt.tight_layout()
            fig.savefig(output_dir / "fig1_operating_fund.png", dpi=150)
            print("  Saved: fig1_operating_fund.png")
        else:
            print("WARNING: fig1 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")
        plt.close('all')

    # ── FIG 2: Reserve Fund Over Time ────────────────────────────────────────
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["time_months"]
            y = d["reserve_fund_usd"]
            assert len(x) == len(y)
            if len(x) > 0:
                ax.plot(x, y / 1000.0, label=label.replace("_", " "), color=colors[idx], linewidth=2)
                plotted = True
        if plotted:
            # Draw 50% reserve target reference line (using baseline n_homes and reserve_target)
            n_homes = 250
            reserve_target_per_home = MODEL_PROFILE["parameters"]["reserve_target_per_home"]["value"]
            reserve_target = n_homes * reserve_target_per_home
            half_target = 0.5 * reserve_target / 1000.0
            ax.axhline(half_target, color='red', linewidth=1.5, linestyle='--',
                       label=f'50% Reserve Target ({half_target:.0f}k)')
            ax.set_xlabel("Time (months)")
            ax.set_ylabel("Reserve Fund Balance ($ thousands)")
            ax.set_title("HOA Reserve Fund Balance Over Time by Scenario")
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / "fig2_reserve_fund.png", dpi=150)
            print("  Saved: fig2_reserve_fund.png")
        else:
            print("WARNING: fig2 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")
        plt.close('all')

    # ── FIG 3: Average Property Value vs Non-HOA Baseline ───────────────────
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["time_months"]
            y_hoa = d["avg_property_value_usd"]
            y_non = d["non_hoa_property_value_usd"]
            assert len(x) == len(y_hoa) == len(y_non)
            if len(x) > 0:
                ax.plot(x, y_hoa / 1000.0, label=f"{label.replace('_',' ')} HOA",
                        color=colors[idx], linewidth=2)
                ax.plot(x, y_non / 1000.0, color=colors[idx], linewidth=1.2,
                        linestyle='--', alpha=0.6)
                plotted = True
        if plotted:
            ax.set_xlabel("Time (months)")
            ax.set_ylabel("Property Value ($ thousands)")
            ax.set_title("Average HOA Home Value Over Time Compared to Non-HOA Baseline")
            ax.legend(fontsize=7, loc="upper left", ncol=2)
            ax.grid(True, alpha=0.3)
            # Add annotation
            ax.text(0.98, 0.05, "Solid = HOA | Dashed = Non-HOA",
                    transform=ax.transAxes, ha='right', fontsize=8, color='gray')
            plt.tight_layout()
            fig.savefig(output_dir / "fig3_property_values.png", dpi=150)
            print("  Saved: fig3_property_values.png")
        else:
            print("WARNING: fig3 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")
        plt.close('all')

    # ── FIG 4: Satisfaction Index Over Time ──────────────────────────────────
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["time_months"]
            y = d["satisfaction_index"]
            assert len(x) == len(y)
            if len(x) > 0:
                ax.plot(x, y, label=label.replace("_", " "), color=colors[idx], linewidth=2)
                plotted = True
        if plotted:
            ax.axhline(0.65, color='gray', linewidth=1.0, linestyle=':', label='Baseline init (0.65)')
            ax.set_xlabel("Time (months)")
            ax.set_ylabel("Satisfaction Index (0=dissatisfied, 1=satisfied)")
            ax.set_title("Homeowner Satisfaction Index Over Time by Scenario")
            ax.set_ylim(0, 1)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / "fig4_satisfaction.png", dpi=150)
            print("  Saved: fig4_satisfaction.png")
        else:
            print("WARNING: fig4 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")
        plt.close('all')

    # ── FIG 5: Delinquency Rate Over Time ────────────────────────────────────
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["time_months"]
            y = d["delinquency_rate"]
            assert len(x) == len(y)
            if len(x) > 0:
                ax.plot(x, y * 100.0, label=label.replace("_", " "), color=colors[idx], linewidth=2)
                plotted = True
        if plotted:
            foreclosure_thresh = MODEL_PROFILE["parameters"]["foreclosure_delinquency_threshold"]["value"]
            ax.axhline(foreclosure_thresh * 100.0, color='red', linewidth=1.5, linestyle='--',
                       label=f'Foreclosure threshold ({foreclosure_thresh*100:.0f}%)')
            ax.set_xlabel("Time (months)")
            ax.set_ylabel("Delinquency Rate (%)")
            ax.set_title("Assessment Delinquency Rate Over Time by Scenario")
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / "fig5_delinquency.png", dpi=150)
            print("  Saved: fig5_delinquency.png")
        else:
            print("WARNING: fig5 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")
        plt.close('all')

    # ── FIG 6: Amenity Quality Over Time ─────────────────────────────────────
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["time_months"]
            y = d["amenity_quality"]
            assert len(x) == len(y)
            if len(x) > 0:
                ax.plot(x, y, label=label.replace("_", " "), color=colors[idx], linewidth=2)
                plotted = True
        if plotted:
            ax.set_xlabel("Time (months)")
            ax.set_ylabel("Amenity Quality Index (0=poor, 1=excellent)")
            ax.set_title("Amenity Quality Index Over Time by Scenario")
            ax.set_ylim(0, 1.05)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / "fig6_amenity_quality.png", dpi=150)
            print("  Saved: fig6_amenity_quality.png")
        else:
            print("WARNING: fig6 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")
        plt.close('all')

    # ── FIG 7: Cumulative Litigation Costs Over Time ──────────────────────────
    try:
        fig, ax = plt.subplots(figsize=(12, 6))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["time_months"]
            y = d["litigation_cost_cumulative_usd"]
            assert len(x) == len(y)
            if len(x) > 0:
                ax.plot(x, y / 1000.0, label=label.replace("_", " "), color=colors[idx], linewidth=2)
                plotted = True
        if plotted:
            ax.set_xlabel("Time (months)")
            ax.set_ylabel("Cumulative Litigation Cost ($ thousands)")
            ax.set_title("Cumulative Litigation Costs Over Time by Scenario")
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / "fig7_litigation_costs.png", dpi=150)
            print("  Saved: fig7_litigation_costs.png")
        else:
            print("WARNING: fig7 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")
        plt.close('all')

    # ── FIG 8: Scatter - Satisfaction vs Reserve Funding Ratio ───────────────
    try:
        fig, ax = plt.subplots(figsize=(10, 7))
        plotted = False
        for idx, label in enumerate(scenario_labels):
            d = scenario_data.get(label, {})
            if not d:
                continue
            x = d["reserve_funding_ratio"]
            y = d["satisfaction_index"]
            assert len(x) == len(y)
            if len(x) > 0:
                ax.scatter(x, y, label=label.replace("_", " "), color=colors[idx],
                           alpha=0.5, s=15, edgecolors='none')
                plotted = True
        if plotted:
            amenity_thresh = MODEL_PROFILE["parameters"]["amenity_maintenance_threshold"]["value"]
            ax.axvline(amenity_thresh, color='red', linewidth=1.5, linestyle='--',
                       label=f'Critical threshold ({amenity_thresh})')
            ax.set_xlabel("Reserve Funding Ratio")
            ax.set_ylabel("Satisfaction Index")
            ax.set_title("Homeowner Satisfaction vs. Reserve Funding Ratio\n(All Scenarios, All Time Steps)")
            ax.set_xlim(0, 2.0)
            ax.set_ylim(0, 1.0)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / "fig8_satisfaction_vs_reserve.png", dpi=150)
            print("  Saved: fig8_satisfaction_vs_reserve.png")
        else:
            print("WARNING: fig8 - no data to plot")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")
        plt.close('all')

    # ── FIG 9: Heatmap of Key Metrics at End of Simulation ───────────────────
    try:
        metrics_display = [
            ("final_operating_fund_usd", "Operating Fund", True, 0, 500000),
            ("final_reserve_funding_ratio", "Reserve Funding Ratio", True, 0, 1.5),
            ("final_hoa_premium_fraction", "HOA Premium", True, 0, 0.1),
            ("final_amenity_quality", "Amenity Quality", True, 0, 1),
            ("final_satisfaction_index", "Satisfaction Index", True, 0, 1),
            ("final_delinquency_rate", "Delinquency Rate", False, 0, 0.3),
            ("total_litigation_cost_usd", "Litigation Cost", False, 0, 500000),
            ("final_board_misconduct_level", "Board Misconduct", False, 0, 1),
        ]

        # Rebuild summary for heatmap
        summary_rows_local = compute_scenario_summary(all_results)
        if not summary_rows_local:
            print("WARNING: fig9 - no summary data available")
            return

        n_metrics = len(metrics_display)
        n_scenarios = len(scenario_labels)
        heatmap_data = np.zeros((n_metrics, n_scenarios))

        for j, label in enumerate(scenario_labels):
            row_dict = next((r for r in summary_rows_local if r["scenario"] == label), None)
            if row_dict is None:
                continue
            for i, (field_name, _, higher_is_better, vmin, vmax) in enumerate(metrics_display):
                raw_val = row_dict.get(field_name, 0.0)
                span = vmax - vmin if (vmax - vmin) > 0 else 1
                norm_val = (raw_val - vmin) / span
                norm_val = max(0.0, min(1.0, norm_val))
                # For metrics where lower is better, invert so that green = good
                if not higher_is_better:
                    norm_val = 1.0 - norm_val
                heatmap_data[i, j] = norm_val

        fig, ax = plt.subplots(figsize=(13, 6))
        cmap = plt.cm.RdYlGn
        im = ax.imshow(heatmap_data, cmap=cmap, vmin=0, vmax=1, aspect='auto')

        ax.set_xticks(np.arange(n_scenarios))
        ax.set_xticklabels([l.replace("_", "\n") for l in scenario_labels], fontsize=8)
        metric_labels = [m[1] for m in metrics_display]
        ax.set_yticks(np.arange(n_metrics))
        ax.set_yticklabels(metric_labels, fontsize=9)

        # Add value annotations
        for i in range(n_metrics):
            for j, label in enumerate(scenario_labels):
                row_dict = next((r for r in summary_rows_local if r["scenario"] == label), None)
                if row_dict is None:
                    continue
                field_name = metrics_display[i][0]
                raw_val = row_dict.get(field_name, 0.0)
                if abs(raw_val) >= 100000:
                    txt = f"${raw_val/1000:.0f}k"
                elif abs(raw_val) < 1:
                    txt = f"{raw_val:.2f}"
                else:
                    txt = f"{raw_val:.1f}"
                ax.text(j, i, txt, ha='center', va='center', fontsize=7, color='black')

        plt.colorbar(im, ax=ax, label='Performance (green=good, red=poor)')
        ax.set_title("Summary Heatmap of Key HOA Performance Metrics at End of Simulation")
        plt.tight_layout()
        fig.savefig(output_dir / "fig9_summary_heatmap.png", dpi=150)
        print("  Saved: fig9_summary_heatmap.png")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig9 failed: {e}")
        plt.close('all')


def main():
    parser = argparse.ArgumentParser(description="HOA Agent-Based Simulator")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all generated files")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    print("\n=== Running HOA Scenarios ===")
    all_results = run_all_scenarios()
    print(f"Total simulation rows generated: {len(all_results)}")

    print("\n=== Computing Scenario Summary ===")
    summary_rows = compute_scenario_summary(all_results)

    print("\n=== Saving CSV Files ===")
    save_simulation_outputs(all_results, output_dir)
    save_scenario_summary(summary_rows, output_dir)
    save_parameters_used(output_dir)

    print("\n=== Saving summary.json ===")
    save_summary_json(summary_rows, all_results, output_dir)

    print("\n=== Generating Figures ===")
    generate_figures(all_results, output_dir)

    print("\n=== Simulation Complete ===")
    print(f"All outputs written to: {output_dir.resolve()}")

    # Print brief scenario comparison
    print("\n--- Scenario Final-State Summary ---")
    for row in summary_rows:
        label = row["scenario"]
        sat = row.get("final_satisfaction_index", 0)
        rfr = row.get("final_reserve_funding_ratio", 0)
        delinq = row.get("final_delinquency_rate", 0)
        lit = row.get("total_litigation_cost_usd", 0)
        print(f"  {label:<35} satisfaction={sat:.3f} | reserve_ratio={rfr:.3f} | "
              f"delinquency={delinq:.3f} | litigation=${lit:,.0f}")


if __name__ == "__main__":
    main()