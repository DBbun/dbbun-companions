# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-24T12:33:45.684156Z
# Run ID    : 49b82705-f83b-41a5-a305-c94cfe25f942
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Agent-Based Networking Event Simulator
Inspired by: Charles Hotel Networking Event Group Photo - April 24, 2026

This simulator models emergent social dynamics of professional networking events
using an agent-based framework. Each agent represents an event attendee with a
unique personality profile, position, and social energy level.
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Any

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ─────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "parameters": {
        "n_agents": 80,
        "event_duration": 120.0,
        "dt": 1.0,
        "venue_width": 20.0,
        "venue_height": 15.0,
        "interaction_radius": 2.0,
        "base_connection_prob": 0.3,
        "group_formation_prob": 0.25,
        "energy_decay_rate": 0.008,
        "movement_speed": 0.5,
        "bar_attraction_strength": 0.4,
        "mean_conversation_duration": 8.0,
        "n_hotspots": 4,
        "extrovert_fraction": 0.55,
        "seed": 42,
    },
    "hotspots": [
        {"x": 18.0, "y": 7.0,  "weight_key": "bar_attraction_strength"},
        {"x": 10.0, "y": 1.0,  "weight": 0.30},
        {"x": 1.0,  "y": 7.0,  "weight": 0.20},
        {"x": 5.0,  "y": 13.0, "weight": 0.15},
    ],
    "scenarios": [
        {
            "label": "small_intimate_gathering",
            "description": "Small group of 20 agents over 60 minutes",
            "param_overrides": {
                "n_agents": 20,
                "event_duration": 60.0,
                "base_connection_prob": 0.45,
                "interaction_radius": 3.0,
            },
        },
        {
            "label": "medium_networking_event",
            "description": "Moderate crowd of 80 agents over 120 minutes",
            "param_overrides": {
                "n_agents": 80,
                "event_duration": 120.0,
                "base_connection_prob": 0.3,
                "interaction_radius": 2.0,
            },
        },
        {
            "label": "large_conference_mixer",
            "description": "Large event with 200 agents over 180 minutes",
            "param_overrides": {
                "n_agents": 200,
                "event_duration": 180.0,
                "base_connection_prob": 0.18,
                "interaction_radius": 1.5,
            },
        },
        {
            "label": "high_extrovert_crowd",
            "description": "Medium event where 85% of agents are extroverts",
            "param_overrides": {
                "n_agents": 80,
                "extrovert_fraction": 0.85,
                "base_connection_prob": 0.42,
                "group_formation_prob": 0.4,
            },
        },
        {
            "label": "high_introvert_crowd",
            "description": "Medium event where only 20% of agents are extroverts",
            "param_overrides": {
                "n_agents": 80,
                "extrovert_fraction": 0.20,
                "base_connection_prob": 0.15,
                "group_formation_prob": 0.1,
            },
        },
    ],
}

SCENARIO_COLORS = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]

# ─────────────────────────────────────────────────────────────
# AGENT DATACLASS
# ─────────────────────────────────────────────────────────────
@dataclass
class Agent:
    agent_id: int
    x: float
    y: float
    introversion_score: float
    energy: float = 1.0
    connections: int = 0
    conversation_time: float = 0.0
    in_group: bool = False
    conversation_timer: float = 0.0
    group_size: int = 1
    connection_set: set = field(default_factory=set)


# ─────────────────────────────────────────────────────────────
# SIMULATION CORE
# ─────────────────────────────────────────────────────────────
def build_params(scenario_idx: int) -> Dict[str, Any]:
    """Build parameter dict for a given scenario by applying overrides."""
    base = dict(MODEL_PROFILE["parameters"])
    overrides = MODEL_PROFILE["scenarios"][scenario_idx]["param_overrides"]
    base.update(overrides)
    return base


def get_hotspot_weights(params: Dict[str, Any]) -> List[Tuple[float, float, float]]:
    """Return list of (x, y, weight) for hotspots."""
    result = []
    for hs in MODEL_PROFILE["hotspots"]:
        w = hs.get("weight", params.get(hs.get("weight_key", ""), 0.4))
        result.append((hs["x"], hs["y"], w))
    return result


def compute_group_sizes(agents: List[Agent], interaction_radius: float):
    """Flood-fill clustering: assign group_size to each agent."""
    n = len(agents)
    in_group_flags = np.array([a.in_group for a in agents], dtype=bool)
    xs = np.array([a.x for a in agents])
    ys = np.array([a.y for a in agents])

    visited = np.zeros(n, dtype=bool)
    cluster_id = np.full(n, -1, dtype=int)
    cluster_sizes = []
    cid = 0

    for i in range(n):
        if not in_group_flags[i] or visited[i]:
            continue
        # BFS
        queue = [i]
        members = []
        while queue:
            cur = queue.pop()
            if visited[cur]:
                continue
            visited[cur] = True
            cluster_id[cur] = cid
            members.append(cur)
            # find neighbors in group
            dists = np.sqrt((xs - xs[cur])**2 + (ys - ys[cur])**2)
            neighbors = np.where(
                (dists <= interaction_radius) & in_group_flags & (~visited)
            )[0]
            queue.extend(neighbors.tolist())
        cluster_sizes.append(len(members))
        cid += 1

    # Assign group_size
    for i, agent in enumerate(agents):
        if cluster_id[i] >= 0:
            sz = cluster_sizes[cluster_id[i]]
            agent.group_size = int(np.clip(sz, 1, 10))
        else:
            agent.group_size = 1


def run_scenario(scenario_idx: int) -> List[Dict]:
    """Run one scenario and return list of row dicts."""
    np.random.seed(scenario_idx)

    params = build_params(scenario_idx)
    scenario_label = MODEL_PROFILE["scenarios"][scenario_idx]["label"]

    n_agents = int(params["n_agents"])
    event_duration = float(params["event_duration"])
    dt = float(params["dt"])
    venue_width = float(params["venue_width"])
    venue_height = float(params["venue_height"])
    interaction_radius = float(params["interaction_radius"])
    base_connection_prob = float(params["base_connection_prob"])
    group_formation_prob = float(params["group_formation_prob"])
    energy_decay_rate = float(params["energy_decay_rate"])
    movement_speed = float(params["movement_speed"])
    mean_conv_dur = float(params["mean_conversation_duration"])
    extrovert_fraction = float(params["extrovert_fraction"])

    hotspots = get_hotspot_weights(params)
    total_hs_weight = sum(w for _, _, w in hotspots)
    hs_weights_norm = np.array([w for _, _, w in hotspots])
    hs_weights_norm = hs_weights_norm / hs_weights_norm.sum()

    # Adjust introversion distribution based on extrovert_fraction
    # extrovert_fraction = fraction with introversion < 0.4
    # We use beta(2,2) as base, but scale to match extrovert_fraction roughly
    agents = []
    for i in range(n_agents):
        x = np.random.uniform(0, venue_width)
        y = np.random.uniform(0, venue_height)
        # Sample introversion: use beta(2,2) then adjust
        raw = np.random.beta(2, 2)
        raw = float(np.clip(raw, 0.0, 1.0))
        # Bias introversion toward extrovert or introvert based on fraction
        if np.random.random() < extrovert_fraction:
            # extrovert: introversion in [0, 0.4]
            intro = raw * 0.4
        else:
            # introvert: introversion in [0.4, 1.0]
            intro = 0.4 + raw * 0.6
        intro = float(np.clip(intro, 0.0, 1.0))
        agents.append(Agent(
            agent_id=i,
            x=x,
            y=y,
            introversion_score=intro,
        ))

    rows = []
    run_id = scenario_idx
    time_steps = np.arange(0.0, event_duration + dt * 0.5, dt)

    for t_idx, t in enumerate(time_steps):
        # ── Energy decay & social boost ──
        for agent in agents:
            social_boost = 0.003 * (1.0 - agent.introversion_score) * float(agent.in_group)
            agent.energy -= energy_decay_rate * dt
            agent.energy += social_boost * dt
            agent.energy = float(np.clip(agent.energy, 0.0, 1.0))

        # ── Movement ──
        for agent in agents:
            if agent.conversation_timer <= 0 or not agent.in_group:
                r = np.random.random()
                if r < total_hs_weight * agent.energy:
                    hs_idx = np.random.choice(len(hotspots), p=hs_weights_norm)
                    tx, ty = hotspots[hs_idx][0], hotspots[hs_idx][1]
                else:
                    tx = np.random.uniform(0, venue_width)
                    ty = np.random.uniform(0, venue_height)

                dx = tx - agent.x
                dy = ty - agent.y
                dist = np.sqrt(dx**2 + dy**2) + 1e-9
                step = min(movement_speed * dt, dist)
                factor = (1.0 - 0.5 * agent.introversion_score)
                agent.x += (dx / dist) * step * factor
                agent.y += (dy / dist) * step * factor
                agent.x = float(np.clip(agent.x, 0.0, venue_width))
                agent.y = float(np.clip(agent.y, 0.0, venue_height))

        # ── Interaction Detection ──
        xs = np.array([a.x for a in agents])
        ys = np.array([a.y for a in agents])

        for i in range(n_agents):
            for j in range(i + 1, n_agents):
                dij = np.sqrt((xs[i] - xs[j])**2 + (ys[i] - ys[j])**2)
                if dij <= interaction_radius:
                    p_connect = (base_connection_prob
                                 * agents[i].energy
                                 * agents[j].energy
                                 * (1.0 - agents[i].introversion_score * 0.5)
                                 * (1.0 - agents[j].introversion_score * 0.5))
                    if np.random.random() < p_connect * dt:
                        # New connection
                        if j not in agents[i].connection_set:
                            agents[i].connections = int(np.clip(agents[i].connections + 1, 0, 30))
                            agents[j].connections = int(np.clip(agents[j].connections + 1, 0, 30))
                            agents[i].connection_set.add(j)
                            agents[j].connection_set.add(i)

                        # Form conversational group
                        agents[i].in_group = True
                        agents[j].in_group = True
                        agents[i].conversation_timer = np.random.exponential(mean_conv_dur)
                        agents[j].conversation_timer = np.random.exponential(mean_conv_dur)
                        agents[i].conversation_time = float(np.clip(
                            agents[i].conversation_time + dt, 0.0, 120.0))
                        agents[j].conversation_time = float(np.clip(
                            agents[j].conversation_time + dt, 0.0, 120.0))

                        # Group expansion
                        if np.random.random() < group_formation_prob:
                            nearby = []
                            for k in range(n_agents):
                                if k == i or k == j:
                                    continue
                                dk = np.sqrt((xs[k] - xs[i])**2 + (ys[k] - ys[i])**2)
                                if dk < 2 * interaction_radius and not agents[k].in_group:
                                    nearby.append((dk, k))
                            if nearby:
                                nearby.sort(key=lambda x: x[0])
                                k = nearby[0][1]
                                agents[k].in_group = True
                                agents[k].connections = int(np.clip(agents[k].connections + 1, 0, 30))
                                agents[i].connections = int(np.clip(agents[i].connections + 1, 0, 30))
                                agents[k].conversation_timer = np.random.exponential(mean_conv_dur)

        # ── Conversation timer decay ──
        for agent in agents:
            if agent.conversation_timer > 0:
                agent.conversation_timer -= dt
            else:
                agent.in_group = False

        # ── Compute group sizes ──
        compute_group_sizes(agents, interaction_radius)

        # ── Record state ──
        for agent in agents:
            rows.append({
                "scenario": scenario_label,
                "run_id": run_id,
                "agent_id": agent.agent_id,
                "time_elapsed": round(float(t), 4),
                "x_pos": round(float(np.clip(agent.x, 0.0, 20.0)), 4),
                "y_pos": round(float(np.clip(agent.y, 0.0, 15.0)), 4),
                "connections": int(np.clip(agent.connections, 0, 30)),
                "conversation_time": round(float(np.clip(agent.conversation_time, 0.0, 120.0)), 4),
                "energy_level": round(float(np.clip(agent.energy, 0.0, 1.0)), 6),
                "group_size": int(np.clip(agent.group_size, 1, 10)),
                "in_group": int(agent.in_group),
                "introversion_score": round(float(np.clip(agent.introversion_score, 0.0, 1.0)), 6),
                "n_agents": n_agents,
                "event_duration": event_duration,
                "base_connection_prob": base_connection_prob,
                "extrovert_fraction": extrovert_fraction,
            })

    print(f"  Scenario '{scenario_label}' complete: {len(rows)} rows recorded.")
    return rows


# ─────────────────────────────────────────────────────────────
# FIGURE GENERATION
# ─────────────────────────────────────────────────────────────
def generate_figures(all_rows: List[Dict], output_dir: pathlib.Path):
    """Generate all 6 figures and save as PNG."""
    scenarios = [s["label"] for s in MODEL_PROFILE["scenarios"]]

    # Pre-compute aggregates per scenario per time step
    # Group data by scenario and time
    scenario_time_data: Dict[str, Dict[float, Dict[str, List]]] = {}
    scenario_final_data: Dict[str, Dict[str, List]] = {}
    scenario_all_data: Dict[str, Dict[str, List]] = {}

    for row in all_rows:
        sc = row["scenario"]
        t = row["time_elapsed"]
        if sc not in scenario_time_data:
            scenario_time_data[sc] = {}
            scenario_all_data[sc] = {
                "connections": [], "energy_level": [], "group_size": [],
                "introversion_score": [], "x_pos": [], "y_pos": [], "in_group": []
            }
        if t not in scenario_time_data[sc]:
            scenario_time_data[sc][t] = {
                "connections": [], "energy_level": [], "group_size": [],
                "introversion_score": [], "x_pos": [], "y_pos": []
            }
        for key in ["connections", "energy_level", "group_size",
                    "introversion_score", "x_pos", "y_pos"]:
            scenario_time_data[sc][t][key].append(row[key])
        for key in ["connections", "energy_level", "group_size",
                    "introversion_score", "x_pos", "y_pos", "in_group"]:
            scenario_all_data[sc][key].append(row[key])

    # Final time step per scenario
    for sc in scenarios:
        if sc not in scenario_time_data:
            continue
        max_t = max(scenario_time_data[sc].keys())
        scenario_final_data[sc] = scenario_time_data[sc][max_t]

    # ─── Figure 1: Cumulative Mean Connections Over Time ───
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, sc in enumerate(scenarios):
            if sc not in scenario_time_data:
                continue
            times_sorted = sorted(scenario_time_data[sc].keys())
            mean_conns = np.array([
                np.mean(scenario_time_data[sc][t]["connections"]) for t in times_sorted
            ])
            t_arr = np.array(times_sorted)
            assert len(t_arr) == len(mean_conns), f"Length mismatch fig1 {sc}"
            if len(t_arr) == 0:
                print(f"Warning fig1: empty arrays for {sc}, skipping")
                continue
            ax.plot(t_arr, mean_conns, label=sc, color=SCENARIO_COLORS[idx], linewidth=2)
            plotted = True
        if plotted:
            ax.set_xlabel("Time Elapsed (minutes)", fontsize=12)
            ax.set_ylabel("Mean Connections Per Agent", fontsize=12)
            ax.set_title("Cumulative Mean Connections Per Agent Over Event Duration", fontsize=13)
            ax.legend(fontsize=9)
            ax.set_xlim(left=0)
            ax.set_ylim(bottom=0)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(output_dir / "fig1_mean_connections_over_time.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"Warning: fig1 failed: {e}")
        plt.close('all')

    # ─── Figure 2: Distribution of Total Connections at Event End ───
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        bins = np.arange(0, 32, 1)
        for idx, sc in enumerate(scenarios):
            if sc not in scenario_final_data:
                continue
            conns = np.array(scenario_final_data[sc]["connections"])
            if len(conns) == 0:
                print(f"Warning fig2: empty data for {sc}, skipping")
                continue
            ax.hist(conns, bins=bins, alpha=0.5, label=sc,
                    color=SCENARIO_COLORS[idx], edgecolor='black', linewidth=0.5)
            plotted = True
        if plotted:
            ax.set_xlabel("Number of Connections", fontsize=12)
            ax.set_ylabel("Agent Count", fontsize=12)
            ax.set_title("Distribution of Total Connections Per Agent at Event End", fontsize=13)
            ax.legend(fontsize=9)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(output_dir / "fig2_connection_distribution.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"Warning: fig2 failed: {e}")
        plt.close('all')

    # ─── Figure 3: Introversion Score vs Total Connections ───
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, sc in enumerate(scenarios):
            if sc not in scenario_final_data:
                continue
            intro = np.array(scenario_final_data[sc]["introversion_score"])
            conns = np.array(scenario_final_data[sc]["connections"])
            if len(intro) == 0 or len(conns) == 0:
                print(f"Warning fig3: empty data for {sc}, skipping")
                continue
            assert len(intro) == len(conns), f"Length mismatch fig3 {sc}"
            ax.scatter(intro, conns, alpha=0.45, label=sc,
                       color=SCENARIO_COLORS[idx], s=20, edgecolors='none')
            plotted = True
        if plotted:
            ax.set_xlabel("Introversion Score (0=Extrovert, 1=Introvert)", fontsize=12)
            ax.set_ylabel("Total Connections Made", fontsize=12)
            ax.set_title("Personality Score vs. Total Connections Made", fontsize=13)
            ax.legend(fontsize=9)
            ax.set_xlim(0, 1)
            ax.set_ylim(bottom=0)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(output_dir / "fig3_personality_vs_connections.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"Warning: fig3 failed: {e}")
        plt.close('all')

    # ─── Figure 4: Heatmap of Agent Density (Medium Event) ───
    try:
        medium_sc = "medium_networking_event"
        if medium_sc in scenario_all_data:
            fig, ax = plt.subplots(figsize=(10, 7))
            x_data = np.array(scenario_all_data[medium_sc]["x_pos"])
            y_data = np.array(scenario_all_data[medium_sc]["y_pos"])
            if len(x_data) > 0 and len(y_data) > 0:
                assert len(x_data) == len(y_data), "Length mismatch fig4"
                H, xedges, yedges = np.histogram2d(
                    x_data, y_data,
                    bins=[40, 30],
                    range=[[0, 20], [0, 15]]
                )
                H_norm = H / (H.max() + 1e-9)
                im = ax.imshow(
                    H_norm.T, origin='lower',
                    extent=[0, 20, 0, 15],
                    aspect='auto',
                    cmap='hot',
                    interpolation='bilinear'
                )
                plt.colorbar(im, ax=ax, label="Normalized Visit Frequency")
                # Mark hotspots
                hs_info = [(18, 7, "Bar"), (10, 1, "Food"), (1, 7, "Entrance"), (5, 13, "Seating")]
                for hx, hy, hl in hs_info:
                    ax.scatter(hx, hy, s=120, marker='*', color='cyan',
                               zorder=5, edgecolors='white', linewidths=0.5)
                    ax.text(hx + 0.3, hy + 0.3, hl, color='cyan', fontsize=9, fontweight='bold')
                ax.set_xlabel("X Position (meters)", fontsize=12)
                ax.set_ylabel("Y Position (meters)", fontsize=12)
                ax.set_title("Agent Density Heatmap - Venue Space Utilization (Medium Event)", fontsize=13)
                ax.set_xlim(0, 20)
                ax.set_ylim(0, 15)
                plt.tight_layout()
                plt.savefig(output_dir / "fig4_venue_heatmap.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning fig4: medium_networking_event data not found, skipping")
    except Exception as e:
        print(f"Warning: fig4 failed: {e}")
        plt.close('all')

    # ─── Figure 5: Mean Group Size Over Time ───
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, sc in enumerate(scenarios):
            if sc not in scenario_time_data:
                continue
            times_sorted = sorted(scenario_time_data[sc].keys())
            mean_gs = np.array([
                np.mean(scenario_time_data[sc][t]["group_size"]) for t in times_sorted
            ])
            std_gs = np.array([
                np.std(scenario_time_data[sc][t]["group_size"]) for t in times_sorted
            ])
            t_arr = np.array(times_sorted)
            assert len(t_arr) == len(mean_gs) == len(std_gs), f"Length mismatch fig5 {sc}"
            if len(t_arr) == 0:
                print(f"Warning fig5: empty arrays for {sc}, skipping")
                continue
            color = SCENARIO_COLORS[idx]
            ax.plot(t_arr, mean_gs, label=sc, color=color, linewidth=2)
            ax.fill_between(t_arr,
                            np.clip(mean_gs - std_gs, 1, 10),
                            np.clip(mean_gs + std_gs, 1, 10),
                            color=color, alpha=0.15)
            plotted = True
        if plotted:
            ax.set_xlabel("Time Elapsed (minutes)", fontsize=12)
            ax.set_ylabel("Mean Conversational Group Size", fontsize=12)
            ax.set_title("Mean Conversational Group Size Over Time by Scenario", fontsize=13)
            ax.legend(fontsize=9)
            ax.set_xlim(left=0)
            ax.set_ylim(1, 10)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(output_dir / "fig5_group_size_over_time.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"Warning: fig5 failed: {e}")
        plt.close('all')

    # ─── Figure 6: Mean Energy Level Decay ───
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, sc in enumerate(scenarios):
            if sc not in scenario_time_data:
                continue
            times_sorted = sorted(scenario_time_data[sc].keys())
            mean_energy = np.array([
                np.mean(scenario_time_data[sc][t]["energy_level"]) for t in times_sorted
            ])
            t_arr = np.array(times_sorted)
            assert len(t_arr) == len(mean_energy), f"Length mismatch fig6 {sc}"
            if len(t_arr) == 0:
                print(f"Warning fig6: empty arrays for {sc}, skipping")
                continue
            ax.plot(t_arr, mean_energy, label=sc, color=SCENARIO_COLORS[idx], linewidth=2)
            plotted = True
        if plotted:
            ax.set_xlabel("Time Elapsed (minutes)", fontsize=12)
            ax.set_ylabel("Mean Agent Energy Level", fontsize=12)
            ax.set_title("Mean Agent Energy Level Decay Over Event Duration", fontsize=13)
            ax.legend(fontsize=9)
            ax.set_xlim(left=0)
            ax.set_ylim(0, 1)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(output_dir / "fig6_energy_decay.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"Warning: fig6 failed: {e}")
        plt.close('all')

    print("Figure generation complete.")


# ─────────────────────────────────────────────────────────────
# CSV WRITING
# ─────────────────────────────────────────────────────────────
SCHEMA_COLS = [
    "scenario", "run_id", "agent_id", "time_elapsed",
    "x_pos", "y_pos", "connections", "conversation_time",
    "energy_level", "group_size", "in_group", "introversion_score",
    "n_agents", "event_duration", "base_connection_prob", "extrovert_fraction"
]


def write_simulation_outputs(all_rows: List[Dict], output_dir: pathlib.Path):
    """Write simulation_outputs.csv — one row per agent per time step."""
    if not all_rows:
        print("Warning: No rows to write for simulation_outputs.csv")
        return
    filepath = output_dir / "simulation_outputs.csv"
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=SCHEMA_COLS)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({col: row[col] for col in SCHEMA_COLS})
        print(f"Wrote {len(all_rows)} rows to simulation_outputs.csv")
    except Exception as e:
        print(f"Warning: Failed to write simulation_outputs.csv: {e}")


def write_scenario_summary(all_rows: List[Dict], output_dir: pathlib.Path):
    """Write scenario_summary.csv — one row per scenario with aggregate metrics."""
    if not all_rows:
        print("Warning: No rows to write for scenario_summary.csv")
        return

    # Group by scenario, only use final time step
    scenario_final: Dict[str, Dict[str, List]] = {}
    scenario_max_t: Dict[str, float] = {}

    # First find max_t per scenario
    for row in all_rows:
        sc = row["scenario"]
        t = row["time_elapsed"]
        if sc not in scenario_max_t or t > scenario_max_t[sc]:
            scenario_max_t[sc] = t

    for row in all_rows:
        sc = row["scenario"]
        if abs(row["time_elapsed"] - scenario_max_t[sc]) < 0.01:
            if sc not in scenario_final:
                scenario_final[sc] = {
                    "connections": [], "conversation_time": [], "energy_level": [],
                    "group_size": [], "introversion_score": [], "in_group": []
                }
            for key in scenario_final[sc]:
                scenario_final[sc][key].append(row[key])

    state_vars = ["connections", "conversation_time", "energy_level",
                  "group_size", "introversion_score", "in_group"]
    summary_cols = ["scenario"]
    for sv in state_vars:
        for stat in ["mean", "std", "min", "max"]:
            summary_cols.append(f"{sv}_{stat}")
    summary_cols += ["n_agents", "event_duration", "base_connection_prob", "extrovert_fraction"]

    filepath = output_dir / "scenario_summary.csv"
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=summary_cols)
            writer.writeheader()
            for sc in [s["label"] for s in MODEL_PROFILE["scenarios"]]:
                if sc not in scenario_final:
                    continue
                fd = scenario_final[sc]
                row_out = {"scenario": sc}
                for sv in state_vars:
                    arr = np.array(fd[sv], dtype=float)
                    row_out[f"{sv}_mean"] = round(float(np.mean(arr)), 4)
                    row_out[f"{sv}_std"] = round(float(np.std(arr)), 4)
                    row_out[f"{sv}_min"] = round(float(np.min(arr)), 4)
                    row_out[f"{sv}_max"] = round(float(np.max(arr)), 4)
                # Get params from first row of this scenario
                sc_rows = [r for r in all_rows if r["scenario"] == sc]
                if sc_rows:
                    r0 = sc_rows[0]
                    row_out["n_agents"] = r0["n_agents"]
                    row_out["event_duration"] = r0["event_duration"]
                    row_out["base_connection_prob"] = r0["base_connection_prob"]
                    row_out["extrovert_fraction"] = r0["extrovert_fraction"]
                writer.writerow(row_out)
        print("Wrote scenario_summary.csv")
    except Exception as e:
        print(f"Warning: Failed to write scenario_summary.csv: {e}")


def write_parameters_used(output_dir: pathlib.Path):
    """Write parameters_used.csv."""
    param_meta = [
        ("n_agents", 80.0, "count", "assumed", "Total number of attendees at the networking event"),
        ("event_duration", 120.0, "minutes", "assumed", "Total duration of the networking event"),
        ("dt", 1.0, "minutes", "assumed", "Simulation time step"),
        ("venue_width", 20.0, "meters", "assumed", "Width of the venue floor space"),
        ("venue_height", 15.0, "meters", "assumed", "Height of the venue floor space"),
        ("interaction_radius", 2.0, "meters", "assumed", "Distance within which two agents can initiate a conversation"),
        ("base_connection_prob", 0.3, "probability", "assumed", "Base probability per time step that two agents within radius form a new connection"),
        ("group_formation_prob", 0.25, "probability", "assumed", "Probability per step that a dyadic conversation expands to include a third agent"),
        ("energy_decay_rate", 0.008, "per minute", "assumed", "Rate at which agent social energy depletes over time"),
        ("movement_speed", 0.5, "meters per minute", "assumed", "Average movement speed of an agent between conversations"),
        ("bar_attraction_strength", 0.4, "a.u.", "assumed", "Relative attractiveness of the bar area as a congregation point"),
        ("mean_conversation_duration", 8.0, "minutes", "assumed", "Mean duration of a single conversation episode"),
        ("n_hotspots", 4.0, "count", "assumed", "Number of attraction hotspots in the venue"),
        ("extrovert_fraction", 0.55, "fraction", "assumed", "Fraction of agents with introversion_score below 0.4"),
        ("seed", 42.0, "a.u.", "assumed", "Random seed for reproducibility"),
    ]
    filepath = output_dir / "parameters_used.csv"
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "value", "unit", "source", "description"])
            for row in param_meta:
                writer.writerow(row)
        print("Wrote parameters_used.csv")
    except Exception as e:
        print(f"Warning: Failed to write parameters_used.csv: {e}")


def write_summary_json(all_rows: List[Dict], output_dir: pathlib.Path):
    """Write summary.json with key aggregate metrics."""
    if not all_rows:
        print("Warning: No data for summary.json")
        return

    summary = {"scenarios": {}, "overall": {}}

    scenario_max_t: Dict[str, float] = {}
    for row in all_rows:
        sc = row["scenario"]
        t = row["time_elapsed"]
        if sc not in scenario_max_t or t > scenario_max_t[sc]:
            scenario_max_t[sc] = t

    all_final_conns = []
    for sc_info in MODEL_PROFILE["scenarios"]:
        sc = sc_info["label"]
        final_rows = [
            r for r in all_rows
            if r["scenario"] == sc and abs(r["time_elapsed"] - scenario_max_t.get(sc, -1)) < 0.01
        ]
        if not final_rows:
            continue
        conns = [r["connections"] for r in final_rows]
        energies = [r["energy_level"] for r in final_rows]
        group_sizes = [r["group_size"] for r in final_rows]
        all_final_conns.extend(conns)
        summary["scenarios"][sc] = {
            "n_agents": final_rows[0]["n_agents"],
            "event_duration": final_rows[0]["event_duration"],
            "mean_connections": round(float(np.mean(conns)), 3),
            "max_connections": int(np.max(conns)),
            "mean_final_energy": round(float(np.mean(energies)), 4),
            "mean_final_group_size": round(float(np.mean(group_sizes)), 3),
            "total_rows_recorded": len([r for r in all_rows if r["scenario"] == sc]),
        }

    if all_final_conns:
        summary["overall"]["mean_connections_all_scenarios"] = round(float(np.mean(all_final_conns)), 3)
        summary["overall"]["total_rows"] = len(all_rows)
        summary["overall"]["n_scenarios"] = len(MODEL_PROFILE["scenarios"])

    filepath = output_dir / "summary.json"
    try:
        with open(filepath, "w") as f:
            json.dump(summary, f, indent=2)
        print("Wrote summary.json")
    except Exception as e:
        print(f"Warning: Failed to write summary.json: {e}")


# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(
        description="Agent-Based Networking Event Simulator — Charles Hotel 2026"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    all_rows: List[Dict] = []

    # Run all scenarios
    for scenario_idx, scenario_info in enumerate(MODEL_PROFILE["scenarios"]):
        print(f"\nRunning scenario {scenario_idx}: {scenario_info['label']}")
        rows = run_scenario(scenario_idx)
        all_rows.extend(rows)

    print(f"\nTotal rows collected: {len(all_rows)}")

    # Write CSVs
    print("\nWriting CSV files...")
    write_simulation_outputs(all_rows, output_dir)
    write_scenario_summary(all_rows, output_dir)
    write_parameters_used(output_dir)

    # Write JSON summary
    print("\nWriting summary.json...")
    write_summary_json(all_rows, output_dir)

    # Generate figures
    print("\nGenerating figures...")
    generate_figures(all_rows, output_dir)

    print(f"\nAll outputs saved to: {output_dir.resolve()}")
    print("Simulation complete.")


if __name__ == "__main__":
    main()