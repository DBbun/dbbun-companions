================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 49b82705-f83b-41a5-a305-c94cfe25f942
    Generated   : 2026-04-24  12:33:45 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Charles Hotel Networking Event Group Photo - April 24, 2026

    CATEGORIES
    ----------
    Social Sciences, Agent-Based Modeling, Other

    KEYWORDS
    --------
    networking event, agent-based social simulation, professional connections, group dynamics, social energy

    ABSTRACT
    --------
    This simulator models the emergent social dynamics of professional networking events using an agent-based framework inspired by a group photograph taken at the Charles Hotel on April 24, 2026. Each agent represents an event attendee with a unique personality profile (introversion score), initial position, and social energy level that decays over the event duration. Agents move through a spatially explicit venue toward hotspots (bar, food area, entrance, seating), form conversational dyads and groups based on proximity and personality, and accumulate professional connections over time. The simulator reproduces well-documented phenomena from social science including power-law-like degree distributions, hotspot congregation effects, group size peaking at mid-event, and personality-driven differential connection rates. Researchers, educators, and event planners can use this tool to test hypotheses about venue design, attendee composition, and event duration on networking outcomes.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Charles-Hotel-Networking-Event-Group-Pic-April-24-2026.JPEG

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    agent_id, x_pos, y_pos, connections, conversation_time, energy_level, group_size, introversion_score, time_elapsed, in_group

    SCENARIOS  (5 total)
    ---------------------------------
        1. small_intimate_gathering — Small group of 20 agents over 60 minutes, representing a quiet early-evening event with low crowd density and high per-capita connection rate
2. medium_networking_event — Moderate crowd of 80 agents over 120 minutes, representing the observed Charles Hotel event with balanced extrovert/introvert mix
3. large_conference_mixer — Large event with 200 agents over 180 minutes, representing a major conference networking session with higher crowd density and reduced individual connection probability
4. high_extrovert_crowd — Medium event where 85% of agents are extroverts, leading to rapid group formation and higher average connections per person
5. high_introvert_crowd — Medium event where only 20% of agents are extroverts, resulting in slower connection rates, smaller group sizes, and more dyadic conversations

    PARAMETERS
    ----------
    15 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6

    DOMAIN SUMMARY
    --------------
    A casual group photograph taken at a professional networking event held at the Charles Hotel on April 24, 2026, depicting four individuals socializing in a dimly lit bar/lounge setting. No quantitative scientific content, equations, or experimental data are present.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.