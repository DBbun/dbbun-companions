================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 69186a56-a705-48c0-9215-bbc50f0d9b23
    Generated   : 2026-04-23  15:49:41 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Adverse outcome pathways as a tool for the design of testing strategies to support the safety assessment of emerging advanced materials at the nanoscale

    CATEGORIES
    ----------
    Biomedical and Health Sciences, Health, Sensors, Computational Intelligence, Machine Learning

    KEYWORDS
    --------
    adverse outcome pathway, nanotoxicology, lung fibrosis, nanomaterial inhalation toxicity, alternative testing strategies

    ABSTRACT
    --------
    This simulator models the Adverse Outcome Pathway (AOP) cascade framework for nanomaterial inhalation toxicity, implementing coupled ordinary differential equations that describe the sequential activation of molecular initiating events (MIE), intermediate key events (KE), and adverse outcomes (AO) for lung fibrosis, emphysema, and related pathologies. The simulator faithfully reproduces the mechanistic cascade described in AOP 173 (lung fibrosis) and AOP 1.25 (emphysema), including the three overrepresented cross-cutting key events (oxidative stress, inflammation, cytotoxicity), positive ROS feedback loops, threshold effects, and the near-irreversibility of downstream AOs. Seven scenarios spanning different nanomaterial types (carbon nanotubes, metal oxide nanoparticles, carbon black) and exposure regimes (low/medium/high dose, short/chronic/post-exposure recovery) generate synthetic datasets that mirror patterns observed in experimental nanotoxicology studies. Researchers can use the simulator to explore how nanomaterial properties and exposure conditions determine AO severity, educators can demonstrate AOP cascade logic interactively, and regulatory scientists can prototype testing strategies by identifying the most sensitive upstream KE biomarkers for early hazard detection before irreversible adverse outcomes develop.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    12989_2020_Article_344.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    MIE, KE1_inflam_mediators, KE2_leukocyte_recruit, KE3_membrane_integrity, KE4_Th2_signaling, KE5_fibroblast_prolif, KE6_collagen_deposition, AO_fibrosis, KE3b_proteinase_imbalance, KE4b_alveolar_destruction, KE5b_alveolar_enlargement, AO_emphysema, oxidative_stress, cytotoxicity, tissue_injury, dose_burden, clearance

    SCENARIOS  (7 total)
    ---------------------------------
        1. Low_Dose_Short_Exposure — Low nanomaterial dose (0.2 a.u.) with short exposure duration (7 days), representing sub-threshold occupational exposure. Expect minimal KE activation and no significant AO.
2. Medium_Dose_Repeated_Exposure — Medium nanomaterial dose (1.0 a.u.) with 28-day repeated exposure, representing typical sub-chronic inhalation study. Expect moderate KE activation and early-stage fibrosis and emphysema signals.
3. High_Dose_Chronic_Exposure — High nanomaterial dose (3.0 a.u.) with 90-day chronic exposure. Expect full cascade activation, tissue injury, and significant fibrosis and emphysema AO levels.
4. CNT_High_Aspect_Ratio — Carbon nanotube scenario: high aspect ratio modifier amplifies fibrosis pathway (KE4-KE6) by 1.8x, matching experimental evidence that CNTs preferentially induce fibrosis. Medium dose, 28-day exposure.
5. Metal_Oxide_NP — Metal oxide nanoparticle scenario (e.g. cadmium, aluminum oxide): metal_oxide_modifier amplifies ROS and inflammatory KEs by 1.6x, driving both fibrosis and emphysema pathways. Medium dose, 28-day exposure.
6. Carbon_Black_Emphysema — Carbon black / ultrafine particle scenario associated with emphysema accumulation in dendritic cells (from cigarette-smoke derived carbon black evidence). Lower fibrosis modifier, higher emphysema pathway weight. High dose, 90-day exposure.
7. Post_Exposure_Recovery — After 28-day medium-dose exposure, simulate 150-day post-exposure period with no further dosing to observe KE decay, AO irreversibility (fibrosis persists, inflammation resolves), reflecting clinical observations.

    PARAMETERS
    ----------
    32 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7

    DOMAIN SUMMARY
    --------------
    This review covers the Adverse Outcome Pathway (AOP) framework applied to nanotoxicology, specifically describing mechanistic cascades from molecular initiating events through key biological events to adverse outcomes (lung fibrosis, emphysema, acute lung toxicity, lung cancer, atherosclerotic plaque formation) induced by inhaled nanomaterials, and how AOPs can guide alternative testing strategies.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.