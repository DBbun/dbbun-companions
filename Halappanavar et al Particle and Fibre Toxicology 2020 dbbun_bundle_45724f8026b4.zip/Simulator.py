# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-23T15:49:41.084563Z
# Run ID    : 69186a56-a705-48c0-9215-bbc50f0d9b23
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Adverse Outcome Pathway (AOP) Cascade Simulator for Nanomaterial Inhalation Toxicity

Paper: "Adverse outcome pathways as a tool for the design of testing strategies to support
the safety assessment of emerging advanced materials at the nanoscale"

Implements ODE-based AOP cascade for lung fibrosis (AOP 173) and emphysema (AOP 1.25),
with cross-cutting key events (oxidative stress, cytotoxicity, tissue injury) and
nanomaterial-type-specific modifiers across 7 exposure scenarios.
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.collections import LineCollection

# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "parameters": {
        "exposure_dose": {"value": 1.0, "unit": "a.u.", "source": "assumed",
                          "description": "Nominal nanomaterial exposure dose"},
        "exposure_duration": {"value": 28.0, "unit": "days", "source": "assumed",
                              "description": "Duration of repeated nanomaterial inhalation exposure"},
        "clearance_rate": {"value": 0.05, "unit": "day^-1", "source": "assumed",
                           "description": "Rate of nanomaterial clearance from lung"},
        "k_MIE_activation": {"value": 0.3, "unit": "day^-1", "source": "assumed",
                             "description": "Rate constant for MIE activation"},
        "k_KE1_activation": {"value": 0.4, "unit": "day^-1", "source": "assumed",
                             "description": "Rate constant for pro-inflammatory mediator secretion"},
        "k_KE2_activation": {"value": 0.35, "unit": "day^-1", "source": "assumed",
                             "description": "Rate constant for leukocyte recruitment"},
        "k_KE3_activation": {"value": 0.25, "unit": "day^-1", "source": "assumed",
                             "description": "Rate constant for membrane integrity loss"},
        "k_KE4_activation": {"value": 0.2, "unit": "day^-1", "source": "assumed",
                             "description": "Rate constant for Th2 signaling activation"},
        "k_KE5_activation": {"value": 0.15, "unit": "day^-1", "source": "assumed",
                             "description": "Rate constant for fibroblast proliferation"},
        "k_KE6_activation": {"value": 0.12, "unit": "day^-1", "source": "assumed",
                             "description": "Rate constant for collagen deposition"},
        "k_AO_fibrosis": {"value": 0.1, "unit": "day^-1", "source": "assumed",
                          "description": "Rate constant for fibrosis AO accumulation"},
        "k_KE3b_activation": {"value": 0.28, "unit": "day^-1", "source": "assumed",
                              "description": "Rate constant for proteinase-antiproteinase imbalance"},
        "k_KE4b_activation": {"value": 0.22, "unit": "day^-1", "source": "assumed",
                              "description": "Rate constant for alveolar wall destruction"},
        "k_KE5b_activation": {"value": 0.18, "unit": "day^-1", "source": "assumed",
                              "description": "Rate constant for alveolar space enlargement"},
        "k_AO_emphysema": {"value": 0.12, "unit": "day^-1", "source": "assumed",
                           "description": "Rate constant for emphysema AO accumulation"},
        "k_ROS": {"value": 0.45, "unit": "day^-1", "source": "assumed",
                  "description": "ROS production rate"},
        "k_cytotox": {"value": 0.3, "unit": "day^-1", "source": "assumed",
                      "description": "Cytotoxicity induction rate"},
        "k_tissue_injury": {"value": 0.25, "unit": "day^-1", "source": "assumed",
                            "description": "Tissue injury rate"},
        "ROS_feedback_gain": {"value": 0.3, "unit": "a.u.", "source": "assumed",
                              "description": "Positive feedback gain from ROS to KE1"},
        "decay_rate_KE": {"value": 0.05, "unit": "day^-1", "source": "assumed",
                          "description": "Baseline decay rate for intermediate KEs"},
        "decay_rate_AO": {"value": 0.01, "unit": "day^-1", "source": "assumed",
                          "description": "Very slow decay rate of irreversible AOs"},
        "threshold_MIE": {"value": 0.1, "unit": "a.u.", "source": "assumed",
                          "description": "Minimum MIE activation level needed to initiate KE cascade"},
        "n_hill": {"value": 2.0, "unit": "dimensionless", "source": "assumed",
                   "description": "Hill coefficient for sigmoidal dose-response"},
        "EC50": {"value": 0.5, "unit": "a.u.", "source": "assumed",
                 "description": "Half-maximal effective concentration for Hill-function"},
        "high_aspect_ratio_modifier": {"value": 1.0, "unit": "dimensionless", "source": "extracted",
                                       "description": "Modifier for high aspect ratio nanomaterials"},
        "metal_oxide_modifier": {"value": 1.0, "unit": "dimensionless", "source": "extracted",
                                 "description": "Modifier for metal oxide nanoparticles"},
        "carbon_black_modifier": {"value": 0.8, "unit": "dimensionless", "source": "extracted",
                                  "description": "Modifier for carbon-black-type nanoparticles"},
        "num_studies_reviewed": {"value": 191.0, "unit": "count", "source": "extracted",
                                 "description": "Number of nanotoxicology studies reviewed"},
        "num_nanomaterials": {"value": 45.0, "unit": "count", "source": "extracted",
                              "description": "Number of distinct nanomaterials"},
        "num_endpoints": {"value": 60.0, "unit": "count", "source": "extracted",
                          "description": "Number of inflammation-associated endpoints"},
        "simulation_time": {"value": 180.0, "unit": "days", "source": "assumed",
                            "description": "Total simulation time"},
        "dt": {"value": 0.5, "unit": "days", "source": "assumed",
               "description": "Numerical integration time step"},
    },
    "scenarios": [
        {
            "label": "Low_Dose_Short_Exposure",
            "param_overrides": {"exposure_dose": 0.2, "exposure_duration": 7.0,
                                "high_aspect_ratio_modifier": 1.0, "metal_oxide_modifier": 1.0}
        },
        {
            "label": "Medium_Dose_Repeated_Exposure",
            "param_overrides": {"exposure_dose": 1.0, "exposure_duration": 28.0,
                                "high_aspect_ratio_modifier": 1.0, "metal_oxide_modifier": 1.0}
        },
        {
            "label": "High_Dose_Chronic_Exposure",
            "param_overrides": {"exposure_dose": 3.0, "exposure_duration": 90.0,
                                "high_aspect_ratio_modifier": 1.0, "metal_oxide_modifier": 1.0}
        },
        {
            "label": "CNT_High_Aspect_Ratio",
            "param_overrides": {"exposure_dose": 1.0, "exposure_duration": 28.0,
                                "high_aspect_ratio_modifier": 1.8, "metal_oxide_modifier": 1.0}
        },
        {
            "label": "Metal_Oxide_NP",
            "param_overrides": {"exposure_dose": 1.0, "exposure_duration": 28.0,
                                "high_aspect_ratio_modifier": 1.0, "metal_oxide_modifier": 1.6}
        },
        {
            "label": "Carbon_Black_Emphysema",
            "param_overrides": {"exposure_dose": 2.0, "exposure_duration": 90.0,
                                "high_aspect_ratio_modifier": 0.5, "metal_oxide_modifier": 0.8,
                                "carbon_black_modifier": 1.5}
        },
        {
            "label": "Post_Exposure_Recovery",
            "param_overrides": {"exposure_dose": 1.0, "exposure_duration": 28.0,
                                "simulation_time": 180.0}
        },
    ]
}

# ─────────────────────────────────────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────

def hill(x: float, EC50: float = 0.5, n: float = 2.0) -> float:
    """Hill activation function: x^n / (x^n + EC50^n)"""
    xn = max(x, 0.0) ** n
    return xn / (xn + EC50 ** n)


def gate(x: float, threshold: float = 0.1) -> float:
    """Threshold gate: linear ramp below threshold, 1 above."""
    if x >= threshold:
        return 1.0
    return x / threshold


def get_params(scenario_overrides: Dict[str, Any]) -> Dict[str, float]:
    """Build parameter dict from defaults + scenario overrides."""
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    params.update(scenario_overrides)
    return params


def clip_state(state: np.ndarray) -> np.ndarray:
    """Clip state variables to their valid ranges."""
    s = state.copy()
    # indices 0..14 are [0,1] variables; index 15 is dose_burden [0,10]; index 16 is clearance [0,1]
    for i in range(15):
        s[i] = max(0.0, min(1.0, s[i]))
    s[15] = max(0.0, min(10.0, s[15]))  # dose_burden
    s[16] = max(0.0, min(1.0, s[16]))   # clearance
    return s


# State vector indices
IDX = {
    'MIE': 0,
    'KE1': 1,
    'KE2': 2,
    'KE3': 3,
    'KE4': 4,
    'KE5': 5,
    'KE6': 6,
    'AO_fibrosis': 7,
    'KE3b': 8,
    'KE4b': 9,
    'KE5b': 10,
    'AO_emphysema': 11,
    'oxidative_stress': 12,
    'cytotoxicity': 13,
    'tissue_injury': 14,
    'dose_burden': 15,
    'clearance': 16,
}


def derivatives(state: np.ndarray, t: float, params: Dict[str, float]) -> np.ndarray:
    """Compute ODE derivatives for the AOP cascade system."""
    p = params
    s = state

    MIE = s[IDX['MIE']]
    KE1 = s[IDX['KE1']]
    KE2 = s[IDX['KE2']]
    KE3 = s[IDX['KE3']]
    KE4 = s[IDX['KE4']]
    KE5 = s[IDX['KE5']]
    KE6 = s[IDX['KE6']]
    AO_f = s[IDX['AO_fibrosis']]
    KE3b = s[IDX['KE3b']]
    KE4b = s[IDX['KE4b']]
    KE5b = s[IDX['KE5b']]
    AO_e = s[IDX['AO_emphysema']]
    ROS = s[IDX['oxidative_stress']]
    cytotox = s[IDX['cytotoxicity']]
    t_inj = s[IDX['tissue_injury']]
    dose_burden = s[IDX['dose_burden']]

    EC50 = p['EC50']
    n = p['n_hill']
    dKE = p['decay_rate_KE']
    dAO = p['decay_rate_AO']

    # Exposure active flag
    is_active = 1.0 if t <= p['exposure_duration'] else 0.0

    # ── Dose burden ──────────────────────────────────────────────────────────
    d_dose = p['exposure_dose'] * is_active - p['clearance_rate'] * dose_burden
    clearance_val = p['clearance_rate'] * dose_burden

    # ── MIE ──────────────────────────────────────────────────────────────────
    MIE_input = hill(dose_burden / 5.0, EC50, n)
    d_MIE = p['k_MIE_activation'] * MIE_input * (1 - MIE) - dKE * MIE

    # ── Oxidative stress (ROS) ───────────────────────────────────────────────
    ROS_drive = p['metal_oxide_modifier'] * (0.6 * MIE + 0.4 * KE2)
    d_ROS = p['k_ROS'] * hill(ROS_drive, EC50, n) * (1 - ROS) - dKE * ROS

    # ── KE1: pro-inflammatory mediators ─────────────────────────────────────
    KE1_input = gate(MIE, p['threshold_MIE']) * (0.7 * MIE + p['ROS_feedback_gain'] * ROS)
    KE1_input = min(KE1_input, 1.0)
    d_KE1 = p['k_KE1_activation'] * hill(KE1_input, EC50, n) * (1 - KE1) - dKE * KE1

    # ── KE2: leukocyte recruitment ───────────────────────────────────────────
    d_KE2 = p['k_KE2_activation'] * hill(KE1, EC50, n) * (1 - KE2) - dKE * KE2

    # ── Cytotoxicity ─────────────────────────────────────────────────────────
    cytotox_drive = 0.5 * ROS + 0.5 * KE1
    d_cytotox = p['k_cytotox'] * hill(cytotox_drive, EC50, n) * (1 - cytotox) - dKE * cytotox

    # ── Tissue injury ─────────────────────────────────────────────────────────
    injury_drive = 0.5 * cytotox + 0.3 * KE1 + 0.2 * KE2
    d_tinj = p['k_tissue_injury'] * hill(injury_drive, EC50, n) * (1 - t_inj) - dAO * t_inj

    # ── Fibrosis pathway ─────────────────────────────────────────────────────
    inflam_combined = 0.5 * KE1 + 0.5 * KE2

    d_KE3 = p['k_KE3_activation'] * hill(inflam_combined, EC50, n) * (1 - KE3) - dKE * KE3

    d_KE4 = (p['k_KE4_activation'] * p['high_aspect_ratio_modifier']
             * hill(KE3, EC50, n) * (1 - KE4) - dKE * KE4)

    d_KE5 = (p['k_KE5_activation'] * p['high_aspect_ratio_modifier']
             * hill(KE4, EC50, n) * (1 - KE5) - dAO * KE5)

    d_KE6 = p['k_KE6_activation'] * hill(KE5, EC50, n) * (1 - KE6) - dAO * KE6

    d_AOf = p['k_AO_fibrosis'] * hill(KE6, EC50, n) * (1 - AO_f) - dAO * 0.1 * AO_f

    # ── Emphysema pathway ─────────────────────────────────────────────────────
    d_KE3b = (p['k_KE3b_activation'] * p['carbon_black_modifier']
              * hill(inflam_combined, EC50, n) * (1 - KE3b) - dKE * KE3b)

    d_KE4b = p['k_KE4b_activation'] * hill(KE3b, EC50, n) * (1 - KE4b) - dAO * KE4b

    d_KE5b = p['k_KE5b_activation'] * hill(KE4b, EC50, n) * (1 - KE5b) - dAO * KE5b

    d_AOe = p['k_AO_emphysema'] * hill(KE5b, EC50, n) * (1 - AO_e) - dAO * 0.1 * AO_e

    dstate = np.zeros(17)
    dstate[IDX['MIE']] = d_MIE
    dstate[IDX['KE1']] = d_KE1
    dstate[IDX['KE2']] = d_KE2
    dstate[IDX['KE3']] = d_KE3
    dstate[IDX['KE4']] = d_KE4
    dstate[IDX['KE5']] = d_KE5
    dstate[IDX['KE6']] = d_KE6
    dstate[IDX['AO_fibrosis']] = d_AOf
    dstate[IDX['KE3b']] = d_KE3b
    dstate[IDX['KE4b']] = d_KE4b
    dstate[IDX['KE5b']] = d_KE5b
    dstate[IDX['AO_emphysema']] = d_AOe
    dstate[IDX['oxidative_stress']] = d_ROS
    dstate[IDX['cytotoxicity']] = d_cytotox
    dstate[IDX['tissue_injury']] = d_tinj
    dstate[IDX['dose_burden']] = d_dose
    dstate[IDX['clearance']] = clearance_val - s[IDX['clearance']]  # track instantaneous

    return dstate


def run_simulation(params: Dict[str, float], seed: int = 0) -> List[Dict[str, Any]]:
    """Run the AOP ODE simulation using RK4 integration."""
    np.random.seed(seed)

    dt = params['dt']
    sim_time = params['simulation_time']
    n_steps = int(round(sim_time / dt))

    state = np.zeros(17)

    records = []

    for step in range(n_steps + 1):
        t = step * dt

        # Clip state
        state = clip_state(state)

        # Record
        is_active = 1 if t <= params['exposure_duration'] else 0
        rec = {
            'time_days': t,
            'dose_burden': state[IDX['dose_burden']],
            'clearance': max(0.0, min(1.0, params['clearance_rate'] * state[IDX['dose_burden']])),
            'MIE': state[IDX['MIE']],
            'KE1_inflam_mediators': state[IDX['KE1']],
            'KE2_leukocyte_recruit': state[IDX['KE2']],
            'KE3_membrane_integrity': state[IDX['KE3']],
            'KE4_Th2_signaling': state[IDX['KE4']],
            'KE5_fibroblast_prolif': state[IDX['KE5']],
            'KE6_collagen_deposition': state[IDX['KE6']],
            'AO_fibrosis': state[IDX['AO_fibrosis']],
            'KE3b_proteinase_imbalance': state[IDX['KE3b']],
            'KE4b_alveolar_destruction': state[IDX['KE4b']],
            'KE5b_alveolar_enlargement': state[IDX['KE5b']],
            'AO_emphysema': state[IDX['AO_emphysema']],
            'oxidative_stress': state[IDX['oxidative_stress']],
            'cytotoxicity': state[IDX['cytotoxicity']],
            'tissue_injury': state[IDX['tissue_injury']],
            'is_exposure_active': is_active,
        }
        records.append(rec)

        if step < n_steps:
            # RK4 integration
            k1 = derivatives(state, t, params)
            k2 = derivatives(clip_state(state + dt / 2 * k1), t + dt / 2, params)
            k3 = derivatives(clip_state(state + dt / 2 * k2), t + dt / 2, params)
            k4 = derivatives(clip_state(state + dt * k3), t + dt, params)
            state = state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

    return records


def run_dose_sweep(base_params: Dict[str, float], n_doses: int = 50) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Sweep exposure dose and return dose, peak fibrosis AO, peak emphysema AO arrays."""
    doses = np.logspace(-2, 1, n_doses)
    peak_fibrosis = np.zeros(n_doses)
    peak_emphysema = np.zeros(n_doses)

    for i, dose in enumerate(doses):
        p = base_params.copy()
        p['exposure_dose'] = dose
        p['exposure_duration'] = 28.0
        records = run_simulation(p, seed=99)
        fibrosis_vals = [r['AO_fibrosis'] for r in records]
        emphysema_vals = [r['AO_emphysema'] for r in records]
        peak_fibrosis[i] = max(fibrosis_vals) if fibrosis_vals else 0.0
        peak_emphysema[i] = max(emphysema_vals) if emphysema_vals else 0.0

    return doses, peak_fibrosis, peak_emphysema


def hill_curve(dose: np.ndarray, AO_max: float, EC50_dose: float, n: float) -> np.ndarray:
    """Analytical Hill curve for fitted dose-response."""
    dn = dose ** n
    return AO_max * dn / (dn + EC50_dose ** n)


# ─────────────────────────────────────────────────────────────────────────────
# SIMULATION RUNNER
# ─────────────────────────────────────────────────────────────────────────────

def run_all_scenarios() -> Tuple[List[Dict[str, Any]], Dict[str, List[Dict[str, Any]]]]:
    """Run all scenarios; return combined records list and per-scenario records dict."""
    all_records = []
    scenario_records = {}

    for idx, scenario in enumerate(MODEL_PROFILE["scenarios"]):
        label = scenario["label"]
        params = get_params(scenario["param_overrides"])
        records = run_simulation(params, seed=idx)

        # Annotate with scenario metadata
        for rec in records:
            rec['scenario'] = label
            rec['exposure_dose'] = params['exposure_dose']
            rec['exposure_duration'] = params['exposure_duration']
            rec['high_aspect_ratio_modifier'] = params['high_aspect_ratio_modifier']
            rec['metal_oxide_modifier'] = params['metal_oxide_modifier']
            rec['carbon_black_modifier'] = params['carbon_black_modifier']

        all_records.extend(records)
        scenario_records[label] = records

    return all_records, scenario_records


# ─────────────────────────────────────────────────────────────────────────────
# CSV WRITERS
# ─────────────────────────────────────────────────────────────────────────────

DATASET_SCHEMA = [
    "scenario", "time_days", "exposure_dose", "exposure_duration",
    "high_aspect_ratio_modifier", "metal_oxide_modifier", "carbon_black_modifier",
    "dose_burden", "clearance", "MIE", "KE1_inflam_mediators", "KE2_leukocyte_recruit",
    "KE3_membrane_integrity", "KE4_Th2_signaling", "KE5_fibroblast_prolif",
    "KE6_collagen_deposition", "AO_fibrosis", "KE3b_proteinase_imbalance",
    "KE4b_alveolar_destruction", "KE5b_alveolar_enlargement", "AO_emphysema",
    "oxidative_stress", "cytotoxicity", "tissue_injury", "is_exposure_active"
]

STATE_VARS = [
    "MIE", "KE1_inflam_mediators", "KE2_leukocyte_recruit", "KE3_membrane_integrity",
    "KE4_Th2_signaling", "KE5_fibroblast_prolif", "KE6_collagen_deposition", "AO_fibrosis",
    "KE3b_proteinase_imbalance", "KE4b_alveolar_destruction", "KE5b_alveolar_enlargement",
    "AO_emphysema", "oxidative_stress", "cytotoxicity", "tissue_injury",
    "dose_burden", "clearance"
]


def write_simulation_outputs(all_records: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv with one row per (scenario, time_step)."""
    if not all_records:
        print("WARNING: No simulation records to write.")
        return
    path = out_dir / "simulation_outputs.csv"
    with open(path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA, extrasaction='ignore')
        writer.writeheader()
        for rec in all_records:
            row = {k: rec.get(k, 0.0) for k in DATASET_SCHEMA}
            writer.writerow(row)
    print(f"Saved {path}")


def write_scenario_summary(scenario_records: Dict[str, List[Dict[str, Any]]], out_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv with aggregate metrics per scenario."""
    if not scenario_records:
        print("WARNING: No scenario records for summary.")
        return

    summary_vars = ["MIE", "KE1_inflam_mediators", "KE2_leukocyte_recruit",
                    "KE3_membrane_integrity", "KE4_Th2_signaling", "KE5_fibroblast_prolif",
                    "KE6_collagen_deposition", "AO_fibrosis", "KE3b_proteinase_imbalance",
                    "KE4b_alveolar_destruction", "KE5b_alveolar_enlargement", "AO_emphysema",
                    "oxidative_stress", "cytotoxicity", "tissue_injury"]

    fieldnames = ["scenario", "exposure_dose", "exposure_duration",
                  "high_aspect_ratio_modifier", "metal_oxide_modifier", "carbon_black_modifier"]
    for sv in summary_vars:
        for stat in ["mean", "std", "min", "max"]:
            fieldnames.append(f"{sv}_{stat}")
    fieldnames += ["peak_AO_fibrosis", "peak_AO_emphysema", "peak_oxidative_stress",
                   "peak_tissue_injury", "n_timesteps"]

    path = out_dir / "scenario_summary.csv"
    with open(path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for label, records in scenario_records.items():
            if not records:
                continue
            row = {"scenario": label}
            row["exposure_dose"] = records[0].get("exposure_dose", 0)
            row["exposure_duration"] = records[0].get("exposure_duration", 0)
            row["high_aspect_ratio_modifier"] = records[0].get("high_aspect_ratio_modifier", 1.0)
            row["metal_oxide_modifier"] = records[0].get("metal_oxide_modifier", 1.0)
            row["carbon_black_modifier"] = records[0].get("carbon_black_modifier", 0.8)
            for sv in summary_vars:
                vals = np.array([r[sv] for r in records if sv in r])
                if len(vals) > 0:
                    row[f"{sv}_mean"] = float(np.mean(vals))
                    row[f"{sv}_std"] = float(np.std(vals))
                    row[f"{sv}_min"] = float(np.min(vals))
                    row[f"{sv}_max"] = float(np.max(vals))
                else:
                    row[f"{sv}_mean"] = 0.0
                    row[f"{sv}_std"] = 0.0
                    row[f"{sv}_min"] = 0.0
                    row[f"{sv}_max"] = 0.0
            row["peak_AO_fibrosis"] = max(r["AO_fibrosis"] for r in records)
            row["peak_AO_emphysema"] = max(r["AO_emphysema"] for r in records)
            row["peak_oxidative_stress"] = max(r["oxidative_stress"] for r in records)
            row["peak_tissue_injury"] = max(r["tissue_injury"] for r in records)
            row["n_timesteps"] = len(records)
            writer.writerow(row)
    print(f"Saved {path}")


def write_parameters_used(out_dir: pathlib.Path) -> None:
    """Write parameters_used.csv with one row per parameter."""
    path = out_dir / "parameters_used.csv"
    with open(path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        for name, info in MODEL_PROFILE["parameters"].items():
            writer.writerow({
                "name": name,
                "value": info["value"],
                "unit": info["unit"],
                "source": info["source"],
                "description": info["description"]
            })
    print(f"Saved {path}")


def write_summary_json(scenario_records: Dict[str, List[Dict[str, Any]]], out_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    summary = {}
    for label, records in scenario_records.items():
        if not records:
            continue
        summary[label] = {
            "peak_AO_fibrosis": float(max(r["AO_fibrosis"] for r in records)),
            "peak_AO_emphysema": float(max(r["AO_emphysema"] for r in records)),
            "peak_MIE": float(max(r["MIE"] for r in records)),
            "peak_oxidative_stress": float(max(r["oxidative_stress"] for r in records)),
            "peak_tissue_injury": float(max(r["tissue_injury"] for r in records)),
            "final_AO_fibrosis": float(records[-1]["AO_fibrosis"]),
            "final_AO_emphysema": float(records[-1]["AO_emphysema"]),
            "n_timesteps": len(records),
            "exposure_dose": float(records[0].get("exposure_dose", 0)),
            "exposure_duration": float(records[0].get("exposure_duration", 0)),
        }
    path = out_dir / "summary.json"
    with open(path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"Saved {path}")


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE GENERATION
# ─────────────────────────────────────────────────────────────────────────────

def extract_series(records: List[Dict], key: str) -> np.ndarray:
    """Extract a named field from records into a numpy array."""
    return np.array([r[key] for r in records])


def generate_fig1(scenario_records: Dict[str, List[Dict]], out_dir: pathlib.Path) -> None:
    """Fig1: AOP 173 lung fibrosis sequential cascade for Medium_Dose_Repeated_Exposure."""
    try:
        label = "Medium_Dose_Repeated_Exposure"
        records = scenario_records.get(label, [])
        if not records:
            print(f"WARNING fig1: No records for {label}")
            return

        time_arr = extract_series(records, 'time_days')
        variables = [
            ('MIE', 'MIE', '#1f77b4'),
            ('KE1_inflam_mediators', 'KE1: Inflam. Mediators', '#ff7f0e'),
            ('KE2_leukocyte_recruit', 'KE2: Leukocyte Recruit.', '#2ca02c'),
            ('KE3_membrane_integrity', 'KE3: Membrane Integrity Loss', '#d62728'),
            ('KE4_Th2_signaling', 'KE4: Th2 Signaling', '#9467bd'),
            ('KE5_fibroblast_prolif', 'KE5: Fibroblast Prolif.', '#8c564b'),
            ('KE6_collagen_deposition', 'KE6: Collagen Deposition', '#e377c2'),
            ('AO_fibrosis', 'AO: Fibrosis', '#7f7f7f'),
        ]

        fig, ax = plt.subplots(figsize=(12, 7))
        exposure_end = records[0].get('exposure_duration', 28.0)

        for var_key, var_label, color in variables:
            y = extract_series(records, var_key)
            assert len(time_arr) == len(y), f"Array length mismatch for {var_key}"
            if len(time_arr) > 0 and len(y) > 0:
                ax.plot(time_arr, y, label=var_label, color=color, linewidth=2)

        ax.axvline(x=exposure_end, color='black', linestyle='--', linewidth=1.5,
                   label=f'End of Exposure (Day {int(exposure_end)})')
        ax.set_xlabel('Time (days)', fontsize=13)
        ax.set_ylabel('Activation Level (a.u.)', fontsize=13)
        ax.set_title('AOP 173 Lung Fibrosis: Sequential Key Event Cascade Over Time\n(Medium Dose, 28-day Exposure)',
                     fontsize=14)
        ax.legend(fontsize=10, loc='upper left')
        ax.set_xlim(0, time_arr[-1] if len(time_arr) > 0 else 180)
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(out_dir / "fig1_aop173_fibrosis_cascade.png", dpi=300, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig1_aop173_fibrosis_cascade.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def generate_fig2(scenario_records: Dict[str, List[Dict]], out_dir: pathlib.Path) -> None:
    """Fig2: Dose-response dynamics of fibrosis and emphysema AOs across exposure scenarios."""
    try:
        dose_scenarios = [
            ("Low_Dose_Short_Exposure", "Low Dose (0.2 a.u., 7d)", '#1f77b4'),
            ("Medium_Dose_Repeated_Exposure", "Medium Dose (1.0 a.u., 28d)", '#ff7f0e'),
            ("High_Dose_Chronic_Exposure", "High Dose (3.0 a.u., 90d)", '#d62728'),
        ]

        fig, ax = plt.subplots(figsize=(12, 7))

        for label, display_label, color in dose_scenarios:
            records = scenario_records.get(label, [])
            if not records:
                print(f"WARNING fig2: No records for {label}")
                continue
            time_arr = extract_series(records, 'time_days')
            fib_arr = extract_series(records, 'AO_fibrosis')
            emp_arr = extract_series(records, 'AO_emphysema')
            assert len(time_arr) == len(fib_arr) == len(emp_arr)
            if len(time_arr) > 0:
                ax.plot(time_arr, fib_arr, color=color, linewidth=2,
                        linestyle='-', label=f'Fibrosis - {display_label}')
                ax.plot(time_arr, emp_arr, color=color, linewidth=2,
                        linestyle='--', label=f'Emphysema - {display_label}')

        ax.set_xlabel('Time (days)', fontsize=13)
        ax.set_ylabel('Adverse Outcome Level (a.u.)', fontsize=13)
        ax.set_title('Dose-Response Dynamics of Fibrosis and Emphysema AOs Across Exposure Scenarios',
                     fontsize=13)
        ax.legend(fontsize=9, loc='upper left')
        ax.set_ylim(0, 1.05)
        ax.set_xlim(0, 180)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(out_dir / "fig2_dose_response_AOs.png", dpi=300, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig2_dose_response_AOs.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def generate_fig3(scenario_records: Dict[str, List[Dict]], out_dir: pathlib.Path) -> None:
    """Fig3: Cross-cutting KEs (oxidative stress, cytotoxicity, tissue injury) across nanomaterial types."""
    try:
        nm_scenarios = [
            ("Medium_Dose_Repeated_Exposure", "Generic Medium Dose", '#1f77b4'),
            ("CNT_High_Aspect_Ratio", "CNT High Aspect Ratio", '#ff7f0e'),
            ("Metal_Oxide_NP", "Metal Oxide NP", '#d62728'),
            ("Carbon_Black_Emphysema", "Carbon Black", '#2ca02c'),
        ]

        fig, axes = plt.subplots(3, 1, figsize=(12, 12), sharex=True)
        cross_vars = [
            ('oxidative_stress', 'Oxidative Stress (ROS)', axes[0]),
            ('cytotoxicity', 'Cytotoxicity', axes[1]),
            ('tissue_injury', 'Tissue Injury', axes[2]),
        ]

        for label, display_label, color in nm_scenarios:
            records = scenario_records.get(label, [])
            if not records:
                print(f"WARNING fig3: No records for {label}")
                continue
            time_arr = extract_series(records, 'time_days')
            for var_key, var_title, ax in cross_vars:
                y = extract_series(records, var_key)
                assert len(time_arr) == len(y)
                if len(time_arr) > 0:
                    ax.plot(time_arr, y, color=color, linewidth=2, label=display_label)

        for var_key, var_title, ax in cross_vars:
            ax.set_ylabel(f'{var_title} (a.u.)', fontsize=12)
            ax.set_ylim(0, 1.05)
            ax.set_xlim(0, 180)
            ax.grid(True, alpha=0.3)
            ax.axhline(y=0.5, color='gray', linestyle=':', linewidth=1, alpha=0.7, label='Tipping Point (0.5)')
            ax.legend(fontsize=9, loc='upper right')

        axes[2].set_xlabel('Time (days)', fontsize=13)
        fig.suptitle('Cross-Cutting KEs: Oxidative Stress, Cytotoxicity, and Tissue Injury\nAcross Nanomaterial Types',
                     fontsize=14)
        fig.tight_layout()
        fig.savefig(out_dir / "fig3_crosscutting_KEs.png", dpi=300, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig3_crosscutting_KEs.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def generate_fig4(scenario_records: Dict[str, List[Dict]], out_dir: pathlib.Path) -> None:
    """Fig4: Heatmap of max activation of KEs and AOs across all scenarios."""
    try:
        row_vars = [
            ('MIE', 'MIE'),
            ('KE1_inflam_mediators', 'KE1: Inflam. Mediators'),
            ('KE2_leukocyte_recruit', 'KE2: Leukocyte Recruit.'),
            ('KE3_membrane_integrity', 'KE3: Membrane Integrity'),
            ('KE4_Th2_signaling', 'KE4: Th2 Signaling'),
            ('KE5_fibroblast_prolif', 'KE5: Fibroblast Prolif.'),
            ('KE6_collagen_deposition', 'KE6: Collagen Deposition'),
            ('AO_fibrosis', 'AO: Fibrosis'),
            ('KE3b_proteinase_imbalance', 'KE3b: Proteinase Imbalance'),
            ('KE4b_alveolar_destruction', 'KE4b: Alveolar Destruction'),
            ('KE5b_alveolar_enlargement', 'KE5b: Alveolar Enlargement'),
            ('AO_emphysema', 'AO: Emphysema'),
            ('oxidative_stress', 'Oxidative Stress (ROS)'),
            ('cytotoxicity', 'Cytotoxicity'),
            ('tissue_injury', 'Tissue Injury'),
        ]

        scenario_labels = [s["label"] for s in MODEL_PROFILE["scenarios"]]
        short_labels = [
            "Low Dose\nShort", "Med Dose\nRepeated", "High Dose\nChronic",
            "CNT\nHigh AR", "Metal\nOxide NP", "Carbon\nBlack", "Post-Exp\nRecovery"
        ]

        n_vars = len(row_vars)
        n_scenarios = len(scenario_labels)
        heat_data = np.zeros((n_vars, n_scenarios))

        for j, label in enumerate(scenario_labels):
            records = scenario_records.get(label, [])
            if not records:
                continue
            for i, (var_key, _) in enumerate(row_vars):
                vals = [r[var_key] for r in records if var_key in r]
                heat_data[i, j] = max(vals) if vals else 0.0

        fig, ax = plt.subplots(figsize=(13, 9))
        im = ax.imshow(heat_data, cmap='RdBu_r', aspect='auto', vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, label='Peak Activation (a.u.)', shrink=0.8)

        ax.set_xticks(range(n_scenarios))
        ax.set_xticklabels(short_labels, fontsize=10)
        ax.set_yticks(range(n_vars))
        ax.set_yticklabels([v[1] for v in row_vars], fontsize=10)
        ax.set_title('AOP Network Heatmap: Maximum Activation of Key Events and AOs Across All Scenarios',
                     fontsize=12, pad=10)

        # Annotate cells
        for i in range(n_vars):
            for j in range(n_scenarios):
                val = heat_data[i, j]
                text_color = 'white' if val > 0.6 else 'black'
                ax.text(j, i, f"{val:.2f}", ha='center', va='center',
                        fontsize=8, color=text_color)

        fig.tight_layout()
        fig.savefig(out_dir / "fig4_heatmap_KEs_AOs.png", dpi=300, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig4_heatmap_KEs_AOs.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def generate_fig5(scenario_records: Dict[str, List[Dict]], out_dir: pathlib.Path) -> None:
    """Fig5: Post-exposure recovery - AO irreversibility vs KE resolution."""
    try:
        label = "Post_Exposure_Recovery"
        records = scenario_records.get(label, [])
        if not records:
            print(f"WARNING fig5: No records for {label}")
            return

        time_arr = extract_series(records, 'time_days')
        exposure_end = records[0].get('exposure_duration', 28.0)

        plot_vars = [
            ('MIE', 'MIE (upstream)', '#1f77b4', '-'),
            ('KE1_inflam_mediators', 'KE1: Inflam. Mediators', '#ff7f0e', '-'),
            ('KE2_leukocyte_recruit', 'KE2: Leukocyte Recruit.', '#2ca02c', '-'),
            ('KE5_fibroblast_prolif', 'KE5: Fibroblast Prolif.', '#9467bd', '--'),
            ('KE6_collagen_deposition', 'KE6: Collagen Deposition', '#8c564b', '--'),
            ('AO_fibrosis', 'AO: Fibrosis (irreversible)', '#d62728', '-'),
            ('AO_emphysema', 'AO: Emphysema (irreversible)', '#e377c2', '-'),
        ]

        fig, ax = plt.subplots(figsize=(12, 7))

        for var_key, var_label, color, ls in plot_vars:
            y = extract_series(records, var_key)
            assert len(time_arr) == len(y)
            if len(time_arr) > 0:
                ax.plot(time_arr, y, color=color, linestyle=ls, linewidth=2, label=var_label)

        ax.axvline(x=exposure_end, color='black', linestyle='--', linewidth=1.5,
                   label=f'End of Exposure (Day {int(exposure_end)})')
        ax.fill_betweenx([0, 1.05], 0, exposure_end, alpha=0.05, color='orange',
                         label='Exposure Period')

        ax.set_xlabel('Time (days)', fontsize=13)
        ax.set_ylabel('Activation Level (a.u.)', fontsize=13)
        ax.set_title('Post-Exposure Recovery: AO Irreversibility vs. KE Resolution After 28-day Exposure',
                     fontsize=13)
        ax.legend(fontsize=10, loc='center right')
        ax.set_xlim(0, time_arr[-1] if len(time_arr) > 0 else 180)
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3)
        fig.tight_layout()
        fig.savefig(out_dir / "fig5_post_exposure_recovery.png", dpi=300, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig5_post_exposure_recovery.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def generate_fig6(out_dir: pathlib.Path) -> None:
    """Fig6: Dose-AO relationship Hill-function sigmoidal response."""
    try:
        base_params = get_params({})
        base_params['exposure_duration'] = 28.0

        # Generic sweep
        doses_generic, pf_generic, pe_generic = run_dose_sweep(base_params, n_doses=50)

        # CNT sweep
        cnt_params = base_params.copy()
        cnt_params['high_aspect_ratio_modifier'] = 1.8
        doses_cnt, pf_cnt, _ = run_dose_sweep(cnt_params, n_doses=50)

        # Metal oxide sweep
        mo_params = base_params.copy()
        mo_params['metal_oxide_modifier'] = 1.6
        doses_mo, pf_mo, pe_mo = run_dose_sweep(mo_params, n_doses=50)

        # Carbon black sweep
        cb_params = base_params.copy()
        cb_params['carbon_black_modifier'] = 1.5
        cb_params['high_aspect_ratio_modifier'] = 0.5
        doses_cb, _, pe_cb = run_dose_sweep(cb_params, n_doses=50)

        # Verify arrays
        assert len(doses_generic) == len(pf_generic) == len(pe_generic)
        assert len(doses_cnt) == len(pf_cnt)
        assert len(doses_mo) == len(pf_mo) == len(pe_mo)
        assert len(doses_cb) == len(pe_cb)

        # Fit Hill curves for generic
        dose_fine = np.logspace(-2, 1, 200)
        AO_max_f = max(pf_generic) if max(pf_generic) > 0 else 1.0
        AO_max_e = max(pe_generic) if max(pe_generic) > 0 else 1.0
        n_fit = base_params['n_hill']
        EC50_fit = 1.0  # approximate EC50 for dose-level
        hill_f_fit = hill_curve(dose_fine, AO_max_f, EC50_fit, n_fit)
        hill_e_fit = hill_curve(dose_fine, AO_max_e, EC50_fit, n_fit)

        fig, ax = plt.subplots(figsize=(10, 7))

        # Scatter points
        ax.scatter(doses_generic, pf_generic, marker='o', color='steelblue', s=40,
                   alpha=0.7, label='Fibrosis AO (Generic)', zorder=5)
        ax.scatter(doses_generic, pe_generic, marker='^', color='steelblue', s=40,
                   alpha=0.7, label='Emphysema AO (Generic)', zorder=5)
        ax.scatter(doses_cnt, pf_cnt, marker='o', color='#1f77b4', s=60,
                   alpha=0.8, label='Fibrosis AO (CNT)', zorder=6)
        ax.scatter(doses_mo, pf_mo, marker='o', color='#ff7f0e', s=60,
                   alpha=0.8, label='Fibrosis AO (Metal Oxide)', zorder=6)
        ax.scatter(doses_mo, pe_mo, marker='^', color='#ff7f0e', s=60,
                   alpha=0.8, label='Emphysema AO (Metal Oxide)', zorder=6)
        ax.scatter(doses_cb, pe_cb, marker='^', color='#2ca02c', s=60,
                   alpha=0.8, label='Emphysema AO (Carbon Black)', zorder=6)

        # Fitted Hill curves
        ax.plot(dose_fine, hill_f_fit, color='steelblue', linestyle='-', linewidth=2,
                label='Hill fit - Fibrosis', alpha=0.8)
        ax.plot(dose_fine, hill_e_fit, color='steelblue', linestyle='--', linewidth=2,
                label='Hill fit - Emphysema', alpha=0.8)

        ax.set_xscale('log')
        ax.set_xlabel('Exposure Dose (a.u., log scale)', fontsize=13)
        ax.set_ylabel('Peak AO Level (a.u.)', fontsize=13)
        ax.set_title('Dose-AO Relationship: Hill-Function Sigmoidal Response\nfor Fibrosis and Emphysema',
                     fontsize=13)
        ax.legend(fontsize=9, loc='upper left')
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3, which='both')
        fig.tight_layout()
        fig.savefig(out_dir / "fig6_dose_AO_hill_curve.png", dpi=300, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig6_dose_AO_hill_curve.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def generate_fig7(scenario_records: Dict[str, List[Dict]], out_dir: pathlib.Path) -> None:
    """Fig7: KE1 vs AO_fibrosis phase portrait across scenarios."""
    try:
        scenario_colors = {
            "Low_Dose_Short_Exposure": '#1f77b4',
            "Medium_Dose_Repeated_Exposure": '#ff7f0e',
            "High_Dose_Chronic_Exposure": '#d62728',
            "CNT_High_Aspect_Ratio": '#9467bd',
            "Metal_Oxide_NP": '#2ca02c',
            "Carbon_Black_Emphysema": '#8c564b',
            "Post_Exposure_Recovery": '#e377c2',
        }

        fig, ax = plt.subplots(figsize=(10, 8))

        legend_handles = []
        for label, records in scenario_records.items():
            if not records:
                continue
            ke1_arr = extract_series(records, 'KE1_inflam_mediators')
            ao_arr = extract_series(records, 'AO_fibrosis')
            time_arr = extract_series(records, 'time_days')

            assert len(ke1_arr) == len(ao_arr) == len(time_arr)

            if len(ke1_arr) < 2:
                continue

            color = scenario_colors.get(label, 'gray')
            t_max = time_arr[-1] if len(time_arr) > 0 else 180.0

            # Create colored segments with time as color
            points = np.array([ke1_arr, ao_arr]).T.reshape(-1, 1, 2)
            segments = np.concatenate([points[:-1], points[1:]], axis=1)
            t_norm = time_arr[:-1] / t_max if t_max > 0 else time_arr[:-1]

            # Use a single color but vary alpha to show time progression
            n_pts = len(ke1_arr)
            for i in range(0, n_pts - 1, max(1, n_pts // 50)):
                alpha = 0.3 + 0.7 * (i / (n_pts - 1))
                ax.plot(ke1_arr[i:i+2], ao_arr[i:i+2], color=color,
                        alpha=alpha, linewidth=1.5)

            # Plot start and end markers
            ax.scatter([ke1_arr[0]], [ao_arr[0]], color=color, marker='o', s=60, zorder=8)
            ax.scatter([ke1_arr[-1]], [ao_arr[-1]], color=color, marker='s', s=60, zorder=8)

            # Legend proxy
            import matplotlib.lines as mlines
            handle = mlines.Line2D([], [], color=color, linewidth=2, label=label.replace('_', ' '))
            legend_handles.append(handle)

        ax.set_xlabel('KE1: Pro-inflammatory Mediators (a.u.)', fontsize=13)
        ax.set_ylabel('AO: Fibrosis (a.u.)', fontsize=13)
        ax.set_title('Key Event Relationship (KER): KE1 vs Fibrosis AO Phase Portrait\nAcross Scenarios',
                     fontsize=13)
        ax.legend(handles=legend_handles, fontsize=9, loc='upper left')
        ax.set_xlim(0, 1.05)
        ax.set_ylim(0, 1.05)
        ax.grid(True, alpha=0.3)
        ax.text(0.98, 0.02, 'o = start, □ = end', transform=ax.transAxes,
                fontsize=9, ha='right', va='bottom', color='gray')
        fig.tight_layout()
        fig.savefig(out_dir / "fig7_KER_phase_portrait.png", dpi=300, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig7_KER_phase_portrait.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="AOP Cascade Simulator for Nanomaterial Inhalation Toxicity"
    )
    parser.add_argument('--output', type=str, default='./sim_outputs',
                        help='Output directory for all results (default: ./sim_outputs)')
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # ── Run all scenarios ──────────────────────────────────────────────────
    print("\nRunning all scenarios...")
    all_records, scenario_records = run_all_scenarios()
    print(f"Total simulation records: {len(all_records)}")

    # ── Write CSV files ────────────────────────────────────────────────────
    print("\nWriting CSV files...")
    write_simulation_outputs(all_records, out_dir)
    write_scenario_summary(scenario_records, out_dir)
    write_parameters_used(out_dir)

    # ── Write JSON summary ─────────────────────────────────────────────────
    print("\nWriting summary JSON...")
    write_summary_json(scenario_records, out_dir)

    # ── Generate figures ───────────────────────────────────────────────────
    print("\nGenerating figures...")
    generate_fig1(scenario_records, out_dir)
    generate_fig2(scenario_records, out_dir)
    generate_fig3(scenario_records, out_dir)
    generate_fig4(scenario_records, out_dir)
    generate_fig5(scenario_records, out_dir)
    generate_fig6(out_dir)
    generate_fig7(scenario_records, out_dir)

    print(f"\nAll outputs saved to: {out_dir.resolve()}")
    print("Simulation complete.")


if __name__ == "__main__":
    main()