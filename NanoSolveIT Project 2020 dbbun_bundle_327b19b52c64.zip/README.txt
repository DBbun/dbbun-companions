================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 87f00992-7236-4ea3-88d6-cf919da53967
    Generated   : 2026-04-23  16:24:26 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    NanoSolveIT Project: Driving nanoinformatics research to develop innovative and integrated tools for in silico nanosafety assessment

    CATEGORIES
    ----------
    Biomedical and Health Sciences, Machine Learning, Sensors, Health, Computational Intelligence

    KEYWORDS
    --------
    nanoinformatics, QSAR, nanotoxicology, physicochemical properties, nanomaterial safety

    ABSTRACT
    --------
    This simulator implements a quantitative nanoinformatics framework inspired by the NanoSolveIT project, generating synthetic datasets and figures that reproduce key relationships between engineered nanomaterial (NM) physicochemical descriptors and toxicity endpoints. The simulator models how core size, surface charge (zeta potential), band gap, crystallinity, dissolution rate, and aspect ratio collectively determine EC50 and cell viability using QSAR-style weighted combination models and Hill equation dose-response curves. Seven experimental scenarios spanning metal oxide size series, surface coating effects, crystallinity phase transitions, protein corona formation, and CNT aspect ratio toxicity are covered, producing ~16,000 synthetic data rows and 8 publication-quality figures. Researchers, students, and regulatory scientists can use the simulator to explore how individual physicochemical descriptors drive NM hazard, to benchmark nanoinformatics models, and to understand the sensitivity of risk predictions to data quality and material properties without requiring experimental access to nanomaterial libraries.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    NanoSolveIT Project 2020.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    core_size_nm, hydrodynamic_diameter_nm, zeta_potential_mV, surface_area_m2g, band_gap_eV, dissolution_rate, aspect_ratio, surface_coating_charge, crystallinity_index, ROS_production, protein_corona_score, cell_viability_pct, EC50_mgL, dose_mgL, exposure_time_h, data_quality_score

    SCENARIOS  (7 total)
    ---------------------------------
        1. Metal_Oxide_Size_Series — Sweep core size from 5 to 60 nm for ZnO, CuO, TiO2, CeO2 NMs with neutral coating; mirrors the Modern metal oxide NPs dataset with 12 sizes between 5-60 nm and 24 NMs
2. Surface_Coating_Effect — Compare uncoated, positively-coated, negatively-coated, and PEG-coated NMs (NanoSolutions panel of 30 industrial NMs with surface variants); fixed size 20nm, varying zeta potential and coating
3. Crystallinity_Phase_Effect — Vary crystallinity index from 0 (amorphous) to 1 (fully crystalline) for SiO2 and TiO2, reflecting the known amorphous-low toxicity vs crystalline-high toxicity distinction for quartz and anatase/rutile TiO2
4. Dose_Response_Multi_NM — Generate dose-response curves (cell viability vs dose) for 6 representative NM types (ZnO, CuO, Ag, TiO2, SiO2, Au) across 10 dose levels, mimicking cytotoxicity data from NanoTEST and NanoMILE datasets
5. Protein_Corona_Effect — Model how protein corona formation (varying surface area and surface charge) modulates effective toxicity and cellular attachment, inspired by Walkey et al. 105 gold NMs corona fingerprint study
6. Data_Quality_Impact — Simulate how data quality score (0-5 composite) affects model prediction uncertainty, reflecting Ha et al. and Trinh et al. scoring framework; datasets with scores below threshold show higher prediction variance
7. CNT_Aspect_Ratio_Pulmonary — Vary CNT aspect ratio from 1 to 100 and simulate pulmonary toxicity EC50 changes, reflecting Gernand et al. finding that CNT length/diameter and aggregate size are main drivers of pulmonary toxicity

    PARAMETERS
    ----------
    17 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    The NanoSolveIT project develops computational nanoinformatics tools and integrated approaches for in silico safety assessment of engineered nanomaterials (NMs), linking physicochemical properties (size, surface charge, band gap, crystallinity) to toxicity endpoints using QSAR/ML models, multi-scale modelling, and curated NM datasets from projects like NanoMILE, NANoREG, NanoFASE, and eNanoMapper.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.