# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-23T16:24:26.691863Z
# Run ID    : 87f00992-7236-4ea3-88d6-cf919da53967
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
NanoSolveIT Nanoinformatics Simulator
======================================
Implements the quantitative nanoinformatics framework from:
  "NanoSolveIT Project: Driving nanoinformatics research to develop
   innovative and integrated tools for in silico nanosafety assessment"

Generates synthetic NM datasets, QSAR-based toxicity predictions, dose-response
curves, and publication-quality figures across seven experimental scenarios.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ---------------------------------------------------------------------------
# MODEL PROFILE
# ---------------------------------------------------------------------------
MODEL_PROFILE = {
    "parameters": {
        "w_zeta": 0.35,
        "w_size": 0.25,
        "w_bandgap": 0.20,
        "w_crystallinity": 0.10,
        "w_dissolution": 0.10,
        "hill_n": 2.0,
        "EC50_size_ref": 20.0,
        "EC50_base_mgL": 10.0,
        "corona_surface_weight": 0.6,
        "corona_size_weight": 0.4,
        "ROS_bandgap_threshold": 3.2,
        "max_agglomeration_factor": 10.0,
        "data_reliability_threshold": 3.0,
        "n_NMs_per_type": 30,
        "enthalpy_cation_scale": -0.05,
        "aspect_toxicity_exp": 0.5,
        "noise_std": 0.05,
    },
    "material_properties": {
        "ZnO":  {"band_gap_eV": 3.37, "dissolution_rate_base": 0.70, "density_g_cm3": 5.6,  "enthalpy_cation_eV": -3.6},
        "CuO":  {"band_gap_eV": 1.50, "dissolution_rate_base": 0.50, "density_g_cm3": 6.3,  "enthalpy_cation_eV": -3.1},
        "TiO2": {"band_gap_eV": 3.20, "dissolution_rate_base": 0.05, "density_g_cm3": 4.2,  "enthalpy_cation_eV": -9.4},
        "CeO2": {"band_gap_eV": 3.50, "dissolution_rate_base": 0.03, "density_g_cm3": 7.2,  "enthalpy_cation_eV": -10.0},
        "SiO2": {"band_gap_eV": 9.00, "dissolution_rate_base": 0.10, "density_g_cm3": 2.2,  "enthalpy_cation_eV": -4.7},
        "Ag":   {"band_gap_eV": 0.00, "dissolution_rate_base": 0.30, "density_g_cm3": 10.5, "enthalpy_cation_eV": -2.6},
        "Au":   {"band_gap_eV": 0.00, "dissolution_rate_base": 0.01, "density_g_cm3": 19.3, "enthalpy_cation_eV": -0.5},
        "CNT":  {"band_gap_eV": 0.00, "dissolution_rate_base": 0.01, "density_g_cm3": 2.1,  "enthalpy_cation_eV": -0.1},
    },
    "coating_zeta_ranges": {
        "positive": (10.0,  50.0),
        "negative": (-50.0, -10.0),
        "PEG":      (-10.0,  5.0),
        "uncoated": (-30.0, 10.0),
    },
    "scenarios": [
        {
            "label": "Metal_Oxide_Size_Series",
            "description": "Sweep core size 5-60 nm for ZnO, CuO, TiO2, CeO2 with neutral coating",
            "param_overrides": {
                "w_size": 0.35,
                "EC50_size_ref": 20.0,
                "surface_coating_charge": 0.0,
                "crystallinity_index": 0.7,
            },
        },
        {
            "label": "Surface_Coating_Effect",
            "description": "Compare uncoated, positive, negative, PEG coatings at fixed 20 nm size",
            "param_overrides": {
                "core_size_nm": 20.0,
                "w_zeta": 0.45,
                "EC50_base_mgL": 10.0,
            },
        },
        {
            "label": "Crystallinity_Phase_Effect",
            "description": "Vary crystallinity 0-1 for SiO2 and TiO2",
            "param_overrides": {
                "w_crystallinity": 0.30,
                "core_size_nm": 20.0,
                "zeta_potential_mV": -15.0,
            },
        },
        {
            "label": "Dose_Response_Multi_NM",
            "description": "Dose-response curves for ZnO, CuO, Ag, TiO2, SiO2, Au",
            "param_overrides": {
                "hill_n": 2.0,
                "exposure_time_h": 24.0,
            },
        },
        {
            "label": "Protein_Corona_Effect",
            "description": "Corona formation modulates toxicity for Au NMs",
            "param_overrides": {
                "w_zeta": 0.20,
                "corona_surface_weight": 0.7,
                "corona_size_weight": 0.3,
            },
        },
        {
            "label": "Data_Quality_Impact",
            "description": "Data quality score affects prediction uncertainty",
            "param_overrides": {
                "data_reliability_threshold": 3.0,
                "noise_std": 0.15,
            },
        },
        {
            "label": "CNT_Aspect_Ratio_Pulmonary",
            "description": "CNT aspect ratio 1-100 and pulmonary EC50",
            "param_overrides": {
                "w_zeta": 0.10,
                "aspect_toxicity_exp": 0.7,
                "w_size": 0.20,
            },
        },
    ],
}

# ---------------------------------------------------------------------------
# HELPER UTILITIES
# ---------------------------------------------------------------------------

def get_params(scenario_idx: int) -> dict:
    """Return merged parameter dict for a given scenario index."""
    p = dict(MODEL_PROFILE["parameters"])
    overrides = MODEL_PROFILE["scenarios"][scenario_idx]["param_overrides"]
    p.update(overrides)
    return p


def clip_val(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def compute_ROS(band_gap_eV: float, crystallinity_index: float,
                ROS_bandgap_threshold: float, noise_std: float) -> float:
    ros = math.exp(-((band_gap_eV - ROS_bandgap_threshold) ** 2) / (2 * 1.0 ** 2)) * crystallinity_index
    ros += np.random.normal(0, noise_std)
    return clip_val(ros, 0.0, 1.0)


def compute_corona(zeta_potential_mV: float, surface_area_m2g: float,
                   corona_surface_weight: float, corona_size_weight: float,
                   noise_std: float) -> float:
    zeta_norm = (zeta_potential_mV + 60.0) / 120.0
    sa_norm = clip_val(surface_area_m2g / 500.0, 0.0, 1.0)
    score = corona_surface_weight * (1.0 - abs(zeta_norm - 0.5) * 2.0) + corona_size_weight * sa_norm
    score += np.random.normal(0, noise_std)
    return clip_val(score, 0.0, 1.0)


def compute_EC50(core_size_nm: float, zeta_potential_mV: float,
                 ROS_production: float, crystallinity_index: float,
                 dissolution_rate: float, aspect_ratio: float,
                 p: dict) -> float:
    w_size = p["w_size"]
    w_zeta = p["w_zeta"]
    w_bandgap = p["w_bandgap"]
    w_crystallinity = p["w_crystallinity"]
    w_dissolution = p["w_dissolution"]
    aspect_toxicity_exp = p["aspect_toxicity_exp"]
    EC50_base_mgL = p["EC50_base_mgL"]
    noise_std = p["noise_std"]

    size_contrib = w_size * (1.0 - clip_val(core_size_nm / 100.0, 0.0, 1.0))
    zeta_contrib = w_zeta * clip_val(zeta_potential_mV / 60.0, -1.0, 1.0)
    bandgap_contrib = w_bandgap * ROS_production
    crystal_contrib = w_crystallinity * crystallinity_index
    dissolution_contrib = w_dissolution * dissolution_rate

    remaining_w = 1.0 - w_size - w_zeta - w_bandgap - w_crystallinity - w_dissolution
    remaining_w = max(0.0, remaining_w)
    aspect_contrib = remaining_w * (aspect_ratio ** aspect_toxicity_exp / 100.0)

    toxicity_index = (size_contrib + zeta_contrib + bandgap_contrib +
                      crystal_contrib + dissolution_contrib + aspect_contrib)
    toxicity_index += np.random.normal(0, noise_std)
    toxicity_index = clip_val(toxicity_index, 0.0, 1.0)

    log_EC50 = math.log10(max(EC50_base_mgL, 0.001)) - 3.0 * toxicity_index
    EC50 = 10.0 ** log_EC50
    return clip_val(EC50, 0.01, 1000.0)


def compute_viability(dose_mgL: float, EC50_mgL: float,
                      hill_n: float, noise_std: float) -> float:
    if EC50_mgL <= 0:
        return 0.0
    v = 100.0 / (1.0 + (dose_mgL / EC50_mgL) ** hill_n)
    v += np.random.normal(0, noise_std * 10.0)
    return clip_val(v, 0.0, 100.0)


def classify_toxicity(EC50_mgL: float) -> str:
    if EC50_mgL < 1.0:
        return "High"
    elif EC50_mgL < 10.0:
        return "Medium"
    return "Low"


def sample_coating():
    coatings = ["uncoated", "positive", "negative", "PEG"]
    return np.random.choice(coatings)


def sample_zeta(coating: str) -> float:
    lo, hi = MODEL_PROFILE["coating_zeta_ranges"][coating]
    return np.random.uniform(lo, hi)


def coating_to_charge(coating: str) -> float:
    mapping = {"positive": 1.0, "negative": -1.0, "PEG": 0.0, "uncoated": 0.0}
    return mapping.get(coating, 0.0)


def sample_agglomeration_factor(max_agg: float) -> float:
    ag = np.random.lognormal(mean=1.5, sigma=0.5)
    return clip_val(ag, 1.0, max_agg)


def data_quality_scores():
    """Sample source and method scores with realistic skew."""
    # Weighted toward moderate quality
    src_probs = [0.10, 0.20, 0.40, 0.30]  # 0,1,2,3
    method_probs = [0.20, 0.45, 0.35]      # 0,1,2
    src = int(np.random.choice([0, 1, 2, 3], p=src_probs))
    method = int(np.random.choice([0, 1, 2], p=method_probs))
    return src, method


# ---------------------------------------------------------------------------
# SCENARIO SIMULATION FUNCTIONS
# ---------------------------------------------------------------------------

def simulate_scenario(scenario_idx: int) -> List[dict]:
    """Run a single scenario and return list of row dicts."""
    np.random.seed(scenario_idx)
    scenario_cfg = MODEL_PROFILE["scenarios"][scenario_idx]
    label = scenario_cfg["label"]
    p = get_params(scenario_idx)

    mat_props = MODEL_PROFILE["material_properties"]
    dose_array = np.logspace(-3, 3, 20)  # 0.001 to 1000 mg/L

    rows = []
    nm_counter = 0

    # -----------------------------------------------------------------------
    # Scenario-specific population generation
    # -----------------------------------------------------------------------
    if label == "Metal_Oxide_Size_Series":
        materials = ["ZnO", "CuO", "TiO2", "CeO2"]
        sizes = np.logspace(np.log10(5), np.log10(60), 30)
        for mat in materials:
            mp = mat_props[mat]
            for size in sizes:
                nm_counter += 1
                nm_id = f"{label}_{mat}_{nm_counter:04d}"
                coating = "uncoated"
                zeta = sample_zeta(coating)
                density = mp["density_g_cm3"]
                sa = clip_val(6000.0 / (density * size), 1.0, 500.0)
                agg_f = sample_agglomeration_factor(p["max_agglomeration_factor"])
                hydro = clip_val(size * agg_f, 5.0, 1000.0)
                bg = mp["band_gap_eV"] + np.random.normal(0, 0.1)
                bg = clip_val(bg, 0.0, 10.0)
                diss = clip_val(mp["dissolution_rate_base"] + np.random.normal(0, 0.05), 0.0, 1.0)
                cryst = clip_val(float(p.get("crystallinity_index", np.random.uniform(0.3, 0.9))), 0.0, 1.0)
                ar = 1.0
                ros = compute_ROS(bg, cryst, p["ROS_bandgap_threshold"], p["noise_std"])
                corona = compute_corona(zeta, sa, p["corona_surface_weight"], p["corona_size_weight"], p["noise_std"])
                ec50 = compute_EC50(size, zeta, ros, cryst, diss, ar, p)
                src_s, meth_s = data_quality_scores()
                dqs = clip_val(float(src_s + meth_s), 0.0, 5.0)
                for dose in dose_array:
                    viab = compute_viability(dose, ec50, p["hill_n"], p["noise_std"])
                    rows.append({
                        "nm_id": nm_id, "material_type": mat, "scenario": label,
                        "core_size_nm": round(size, 4),
                        "hydrodynamic_diameter_nm": round(hydro, 4),
                        "zeta_potential_mV": round(zeta, 4),
                        "surface_area_m2g": round(sa, 4),
                        "band_gap_eV": round(bg, 4),
                        "dissolution_rate": round(diss, 4),
                        "aspect_ratio": round(ar, 4),
                        "surface_coating_charge": coating_to_charge(coating),
                        "surface_coating_label": coating,
                        "crystallinity_index": round(cryst, 4),
                        "ROS_production": round(ros, 4),
                        "protein_corona_score": round(corona, 4),
                        "metallic_impurity_level": "low",
                        "dose_mgL": round(float(dose), 6),
                        "exposure_time_h": p.get("exposure_time_h", 24.0),
                        "cell_viability_pct": round(viab, 4),
                        "EC50_mgL": round(ec50, 4),
                        "data_quality_score": round(dqs, 2),
                        "pchem_source_score": src_s,
                        "pchem_method_score": meth_s,
                        "predicted_toxicity_class": classify_toxicity(ec50),
                        "enthalpy_cation_eV": mp["enthalpy_cation_eV"],
                    })

    elif label == "Surface_Coating_Effect":
        materials = ["ZnO", "CuO", "TiO2", "SiO2"]
        coatings = ["uncoated", "positive", "negative", "PEG"]
        core_size = float(p.get("core_size_nm", 20.0))
        for mat in materials:
            mp = mat_props[mat]
            for coating in coatings:
                for _ in range(30):
                    nm_counter += 1
                    nm_id = f"{label}_{mat}_{coating}_{nm_counter:04d}"
                    zeta = sample_zeta(coating)
                    density = mp["density_g_cm3"]
                    sa = clip_val(6000.0 / (density * core_size), 1.0, 500.0)
                    agg_f = sample_agglomeration_factor(p["max_agglomeration_factor"])
                    hydro = clip_val(core_size * agg_f, 5.0, 1000.0)
                    bg = clip_val(mp["band_gap_eV"] + np.random.normal(0, 0.1), 0.0, 10.0)
                    diss = clip_val(mp["dissolution_rate_base"] + np.random.normal(0, 0.05), 0.0, 1.0)
                    cryst = clip_val(np.random.uniform(0.3, 0.9), 0.0, 1.0)
                    ar = 1.0
                    ros = compute_ROS(bg, cryst, p["ROS_bandgap_threshold"], p["noise_std"])
                    corona = compute_corona(zeta, sa, p["corona_surface_weight"], p["corona_size_weight"], p["noise_std"])
                    ec50 = compute_EC50(core_size, zeta, ros, cryst, diss, ar, p)
                    src_s, meth_s = data_quality_scores()
                    dqs = clip_val(float(src_s + meth_s), 0.0, 5.0)
                    for dose in dose_array:
                        viab = compute_viability(dose, ec50, p["hill_n"], p["noise_std"])
                        rows.append({
                            "nm_id": nm_id, "material_type": mat, "scenario": label,
                            "core_size_nm": round(core_size, 4),
                            "hydrodynamic_diameter_nm": round(hydro, 4),
                            "zeta_potential_mV": round(zeta, 4),
                            "surface_area_m2g": round(sa, 4),
                            "band_gap_eV": round(bg, 4),
                            "dissolution_rate": round(diss, 4),
                            "aspect_ratio": round(ar, 4),
                            "surface_coating_charge": coating_to_charge(coating),
                            "surface_coating_label": coating,
                            "crystallinity_index": round(cryst, 4),
                            "ROS_production": round(ros, 4),
                            "protein_corona_score": round(corona, 4),
                            "metallic_impurity_level": "low",
                            "dose_mgL": round(float(dose), 6),
                            "exposure_time_h": p.get("exposure_time_h", 24.0),
                            "cell_viability_pct": round(viab, 4),
                            "EC50_mgL": round(ec50, 4),
                            "data_quality_score": round(dqs, 2),
                            "pchem_source_score": src_s,
                            "pchem_method_score": meth_s,
                            "predicted_toxicity_class": classify_toxicity(ec50),
                            "enthalpy_cation_eV": mp["enthalpy_cation_eV"],
                        })

    elif label == "Crystallinity_Phase_Effect":
        materials = ["SiO2", "TiO2"]
        crystallinity_vals = np.linspace(0.0, 1.0, 30)
        core_size = float(p.get("core_size_nm", 20.0))
        fixed_zeta = float(p.get("zeta_potential_mV", -15.0))
        for mat in materials:
            mp = mat_props[mat]
            for cryst_val in crystallinity_vals:
                nm_counter += 1
                nm_id = f"{label}_{mat}_{nm_counter:04d}"
                coating = "uncoated"
                zeta = fixed_zeta + np.random.normal(0, 2.0)
                zeta = clip_val(zeta, -60.0, 60.0)
                density = mp["density_g_cm3"]
                sa = clip_val(6000.0 / (density * core_size), 1.0, 500.0)
                agg_f = sample_agglomeration_factor(p["max_agglomeration_factor"])
                hydro = clip_val(core_size * agg_f, 5.0, 1000.0)
                bg = clip_val(mp["band_gap_eV"] + np.random.normal(0, 0.1), 0.0, 10.0)
                diss = clip_val(mp["dissolution_rate_base"] + np.random.normal(0, 0.05), 0.0, 1.0)
                cryst = clip_val(cryst_val, 0.0, 1.0)
                ar = 1.0
                ros = compute_ROS(bg, cryst, p["ROS_bandgap_threshold"], p["noise_std"])
                corona = compute_corona(zeta, sa, p["corona_surface_weight"], p["corona_size_weight"], p["noise_std"])
                ec50 = compute_EC50(core_size, zeta, ros, cryst, diss, ar, p)
                src_s, meth_s = data_quality_scores()
                dqs = clip_val(float(src_s + meth_s), 0.0, 5.0)
                for dose in dose_array:
                    viab = compute_viability(dose, ec50, p["hill_n"], p["noise_std"])
                    rows.append({
                        "nm_id": nm_id, "material_type": mat, "scenario": label,
                        "core_size_nm": round(core_size, 4),
                        "hydrodynamic_diameter_nm": round(hydro, 4),
                        "zeta_potential_mV": round(zeta, 4),
                        "surface_area_m2g": round(sa, 4),
                        "band_gap_eV": round(bg, 4),
                        "dissolution_rate": round(diss, 4),
                        "aspect_ratio": round(ar, 4),
                        "surface_coating_charge": coating_to_charge(coating),
                        "surface_coating_label": coating,
                        "crystallinity_index": round(cryst, 4),
                        "ROS_production": round(ros, 4),
                        "protein_corona_score": round(corona, 4),
                        "metallic_impurity_level": "low",
                        "dose_mgL": round(float(dose), 6),
                        "exposure_time_h": p.get("exposure_time_h", 24.0),
                        "cell_viability_pct": round(viab, 4),
                        "EC50_mgL": round(ec50, 4),
                        "data_quality_score": round(dqs, 2),
                        "pchem_source_score": src_s,
                        "pchem_method_score": meth_s,
                        "predicted_toxicity_class": classify_toxicity(ec50),
                        "enthalpy_cation_eV": mp["enthalpy_cation_eV"],
                    })

    elif label == "Dose_Response_Multi_NM":
        materials = ["ZnO", "CuO", "Ag", "TiO2", "SiO2", "Au"]
        core_size = 20.0
        dose_fine = np.logspace(-2, 2, 30)  # 0.01 to 100 mg/L
        for mat in materials:
            mp = mat_props[mat]
            # Generate 5 NM variants per material
            for _ in range(5):
                nm_counter += 1
                nm_id = f"{label}_{mat}_{nm_counter:04d}"
                coating = sample_coating()
                zeta = sample_zeta(coating)
                density = mp["density_g_cm3"]
                sa = clip_val(6000.0 / (density * core_size), 1.0, 500.0)
                agg_f = sample_agglomeration_factor(p["max_agglomeration_factor"])
                hydro = clip_val(core_size * agg_f, 5.0, 1000.0)
                bg = clip_val(mp["band_gap_eV"] + np.random.normal(0, 0.1), 0.0, 10.0)
                diss = clip_val(mp["dissolution_rate_base"] + np.random.normal(0, 0.05), 0.0, 1.0)
                cryst = clip_val(np.random.uniform(0.3, 0.9), 0.0, 1.0)
                ar = 1.0
                ros = compute_ROS(bg, cryst, p["ROS_bandgap_threshold"], p["noise_std"])
                corona = compute_corona(zeta, sa, p["corona_surface_weight"], p["corona_size_weight"], p["noise_std"])
                ec50 = compute_EC50(core_size, zeta, ros, cryst, diss, ar, p)
                src_s, meth_s = data_quality_scores()
                dqs = clip_val(float(src_s + meth_s), 0.0, 5.0)
                for dose in dose_fine:
                    viab = compute_viability(dose, ec50, p["hill_n"], p["noise_std"])
                    rows.append({
                        "nm_id": nm_id, "material_type": mat, "scenario": label,
                        "core_size_nm": round(core_size, 4),
                        "hydrodynamic_diameter_nm": round(hydro, 4),
                        "zeta_potential_mV": round(zeta, 4),
                        "surface_area_m2g": round(sa, 4),
                        "band_gap_eV": round(bg, 4),
                        "dissolution_rate": round(diss, 4),
                        "aspect_ratio": round(ar, 4),
                        "surface_coating_charge": coating_to_charge(coating),
                        "surface_coating_label": coating,
                        "crystallinity_index": round(cryst, 4),
                        "ROS_production": round(ros, 4),
                        "protein_corona_score": round(corona, 4),
                        "metallic_impurity_level": "low",
                        "dose_mgL": round(float(dose), 6),
                        "exposure_time_h": float(p.get("exposure_time_h", 24.0)),
                        "cell_viability_pct": round(viab, 4),
                        "EC50_mgL": round(ec50, 4),
                        "data_quality_score": round(dqs, 2),
                        "pchem_source_score": src_s,
                        "pchem_method_score": meth_s,
                        "predicted_toxicity_class": classify_toxicity(ec50),
                        "enthalpy_cation_eV": mp["enthalpy_cation_eV"],
                    })

    elif label == "Protein_Corona_Effect":
        # 105 Au NMs with varying surface modifications (Walkey et al. inspired)
        coatings = ["uncoated", "PEG", "positive", "negative"]
        mat = "Au"
        mp = mat_props[mat]
        sizes = np.random.uniform(5, 100, 105)
        coating_assignments = [coatings[i % 4] for i in range(105)]
        for i in range(105):
            nm_counter += 1
            nm_id = f"{label}_{mat}_{nm_counter:04d}"
            coating = coating_assignments[i]
            size = sizes[i]
            zeta = sample_zeta(coating)
            density = mp["density_g_cm3"]
            sa = clip_val(6000.0 / (density * size), 1.0, 500.0)
            agg_f = sample_agglomeration_factor(p["max_agglomeration_factor"])
            hydro = clip_val(size * agg_f, 5.0, 1000.0)
            bg = clip_val(mp["band_gap_eV"] + np.random.normal(0, 0.05), 0.0, 10.0)
            diss = clip_val(mp["dissolution_rate_base"] + np.random.normal(0, 0.005), 0.0, 1.0)
            cryst = clip_val(np.random.uniform(0.4, 0.9), 0.0, 1.0)
            ar = 1.0
            ros = compute_ROS(bg, cryst, p["ROS_bandgap_threshold"], p["noise_std"])
            corona = compute_corona(zeta, sa, p["corona_surface_weight"], p["corona_size_weight"], p["noise_std"])
            ec50 = compute_EC50(size, zeta, ros, cryst, diss, ar, p)
            src_s, meth_s = data_quality_scores()
            dqs = clip_val(float(src_s + meth_s), 0.0, 5.0)
            for dose in dose_array:
                viab = compute_viability(dose, ec50, p["hill_n"], p["noise_std"])
                rows.append({
                    "nm_id": nm_id, "material_type": mat, "scenario": label,
                    "core_size_nm": round(float(size), 4),
                    "hydrodynamic_diameter_nm": round(hydro, 4),
                    "zeta_potential_mV": round(zeta, 4),
                    "surface_area_m2g": round(sa, 4),
                    "band_gap_eV": round(bg, 4),
                    "dissolution_rate": round(diss, 4),
                    "aspect_ratio": round(ar, 4),
                    "surface_coating_charge": coating_to_charge(coating),
                    "surface_coating_label": coating,
                    "crystallinity_index": round(cryst, 4),
                    "ROS_production": round(ros, 4),
                    "protein_corona_score": round(corona, 4),
                    "metallic_impurity_level": "low",
                    "dose_mgL": round(float(dose), 6),
                    "exposure_time_h": p.get("exposure_time_h", 24.0),
                    "cell_viability_pct": round(viab, 4),
                    "EC50_mgL": round(ec50, 4),
                    "data_quality_score": round(dqs, 2),
                    "pchem_source_score": src_s,
                    "pchem_method_score": meth_s,
                    "predicted_toxicity_class": classify_toxicity(ec50),
                    "enthalpy_cation_eV": mp["enthalpy_cation_eV"],
                })

    elif label == "Data_Quality_Impact":
        materials = ["ZnO", "TiO2", "SiO2", "Ag"]
        core_size = 20.0
        for mat in materials:
            mp = mat_props[mat]
            for _ in range(30):
                nm_counter += 1
                nm_id = f"{label}_{mat}_{nm_counter:04d}"
                coating = sample_coating()
                zeta = sample_zeta(coating)
                density = mp["density_g_cm3"]
                sa = clip_val(6000.0 / (density * core_size), 1.0, 500.0)
                agg_f = sample_agglomeration_factor(p["max_agglomeration_factor"])
                hydro = clip_val(core_size * agg_f, 5.0, 1000.0)
                bg = clip_val(mp["band_gap_eV"] + np.random.normal(0, 0.1), 0.0, 10.0)
                diss = clip_val(mp["dissolution_rate_base"] + np.random.normal(0, 0.05), 0.0, 1.0)
                cryst = clip_val(np.random.uniform(0.3, 0.9), 0.0, 1.0)
                ar = 1.0
                ros = compute_ROS(bg, cryst, p["ROS_bandgap_threshold"], p["noise_std"])
                corona = compute_corona(zeta, sa, p["corona_surface_weight"], p["corona_size_weight"], p["noise_std"])
                ec50 = compute_EC50(core_size, zeta, ros, cryst, diss, ar, p)
                src_s, meth_s = data_quality_scores()
                dqs = clip_val(float(src_s + meth_s), 0.0, 5.0)
                for dose in dose_array:
                    viab = compute_viability(dose, ec50, p["hill_n"], p["noise_std"])
                    rows.append({
                        "nm_id": nm_id, "material_type": mat, "scenario": label,
                        "core_size_nm": round(core_size, 4),
                        "hydrodynamic_diameter_nm": round(hydro, 4),
                        "zeta_potential_mV": round(zeta, 4),
                        "surface_area_m2g": round(sa, 4),
                        "band_gap_eV": round(bg, 4),
                        "dissolution_rate": round(diss, 4),
                        "aspect_ratio": round(ar, 4),
                        "surface_coating_charge": coating_to_charge(coating),
                        "surface_coating_label": coating,
                        "crystallinity_index": round(cryst, 4),
                        "ROS_production": round(ros, 4),
                        "protein_corona_score": round(corona, 4),
                        "metallic_impurity_level": "low",
                        "dose_mgL": round(float(dose), 6),
                        "exposure_time_h": p.get("exposure_time_h", 24.0),
                        "cell_viability_pct": round(viab, 4),
                        "EC50_mgL": round(ec50, 4),
                        "data_quality_score": round(dqs, 2),
                        "pchem_source_score": src_s,
                        "pchem_method_score": meth_s,
                        "predicted_toxicity_class": classify_toxicity(ec50),
                        "enthalpy_cation_eV": mp["enthalpy_cation_eV"],
                    })

    elif label == "CNT_Aspect_Ratio_Pulmonary":
        mat = "CNT"
        mp = mat_props[mat]
        aspect_ratios = np.logspace(0, 2, 30)  # 1 to 100
        impurity_levels = ["low", "medium", "high"]
        impurity_extra_tox = {"low": 0.0, "medium": 0.05, "high": 0.12}
        core_size = 20.0
        for imp_level in impurity_levels:
            extra_tox = impurity_extra_tox[imp_level]
            for ar_val in aspect_ratios:
                nm_counter += 1
                nm_id = f"{label}_{mat}_{imp_level}_{nm_counter:04d}"
                coating = "uncoated"
                zeta = sample_zeta(coating)
                density = mp["density_g_cm3"]
                sa = clip_val(6000.0 / (density * core_size), 1.0, 500.0)
                agg_f = sample_agglomeration_factor(p["max_agglomeration_factor"])
                hydro = clip_val(core_size * agg_f, 5.0, 1000.0)
                bg = clip_val(mp["band_gap_eV"] + np.random.normal(0, 0.05), 0.0, 10.0)
                diss = clip_val(mp["dissolution_rate_base"] + np.random.normal(0, 0.005), 0.0, 1.0)
                cryst = clip_val(np.random.uniform(0.1, 0.5), 0.0, 1.0)
                ar = clip_val(float(ar_val), 1.0, 100.0)
                ros = compute_ROS(bg, cryst, p["ROS_bandgap_threshold"], p["noise_std"])
                corona = compute_corona(zeta, sa, p["corona_surface_weight"], p["corona_size_weight"], p["noise_std"])
                # Apply impurity extra toxicity via modified EC50
                ec50_base = compute_EC50(core_size, zeta, ros, cryst, diss, ar, p)
                # Scale EC50 down (more toxic) with higher impurity
                ec50 = clip_val(ec50_base * max(0.1, 1.0 - extra_tox * 5), 0.01, 1000.0)
                src_s, meth_s = data_quality_scores()
                dqs = clip_val(float(src_s + meth_s), 0.0, 5.0)
                for dose in dose_array:
                    viab = compute_viability(dose, ec50, p["hill_n"], p["noise_std"])
                    rows.append({
                        "nm_id": nm_id, "material_type": mat, "scenario": label,
                        "core_size_nm": round(core_size, 4),
                        "hydrodynamic_diameter_nm": round(hydro, 4),
                        "zeta_potential_mV": round(zeta, 4),
                        "surface_area_m2g": round(sa, 4),
                        "band_gap_eV": round(bg, 4),
                        "dissolution_rate": round(diss, 4),
                        "aspect_ratio": round(ar, 4),
                        "surface_coating_charge": coating_to_charge(coating),
                        "surface_coating_label": coating,
                        "crystallinity_index": round(cryst, 4),
                        "ROS_production": round(ros, 4),
                        "protein_corona_score": round(corona, 4),
                        "metallic_impurity_level": imp_level,
                        "dose_mgL": round(float(dose), 6),
                        "exposure_time_h": p.get("exposure_time_h", 24.0),
                        "cell_viability_pct": round(viab, 4),
                        "EC50_mgL": round(ec50, 4),
                        "data_quality_score": round(dqs, 2),
                        "pchem_source_score": src_s,
                        "pchem_method_score": meth_s,
                        "predicted_toxicity_class": classify_toxicity(ec50),
                        "enthalpy_cation_eV": mp["enthalpy_cation_eV"],
                    })

    return rows


# ---------------------------------------------------------------------------
# FIGURE GENERATION
# ---------------------------------------------------------------------------

MATERIAL_COLORS = {
    "ZnO": "#e41a1c", "CuO": "#ff7f00", "TiO2": "#377eb8",
    "CeO2": "#4daf4a", "SiO2": "#984ea3", "Ag": "#a65628",
    "Au": "#f781bf", "CNT": "#555555",
}

COATING_COLORS = {
    "uncoated": "#d95f02", "positive": "#e41a1c",
    "negative": "#377eb8", "PEG": "#4daf4a",
}


def generate_fig1(rows: List[dict], out_dir: pathlib.Path):
    """EC50 vs Core Size for Metal Oxide NMs."""
    try:
        scenario_rows = [r for r in rows if r["scenario"] == "Metal_Oxide_Size_Series"]
        if not scenario_rows:
            print("WARNING fig1: no data for Metal_Oxide_Size_Series")
            return
        materials = ["ZnO", "CuO", "TiO2", "CeO2"]
        fig, ax = plt.subplots(figsize=(8, 6))
        for mat in materials:
            mat_rows = [r for r in scenario_rows if r["material_type"] == mat]
            if not mat_rows:
                continue
            # Get unique NM IDs and their representative EC50 / core_size
            nm_data = {}
            for r in mat_rows:
                nid = r["nm_id"]
                if nid not in nm_data:
                    nm_data[nid] = {"core_size_nm": r["core_size_nm"], "EC50_mgL": r["EC50_mgL"]}
            sizes = np.array([v["core_size_nm"] for v in nm_data.values()])
            ec50s = np.array([v["EC50_mgL"] for v in nm_data.values()])
            assert len(sizes) == len(ec50s), "fig1 size/ec50 mismatch"
            if len(sizes) == 0:
                continue
            order = np.argsort(sizes)
            sizes = sizes[order]
            ec50s = ec50s[order]
            color = MATERIAL_COLORS.get(mat, "black")
            ax.semilogy(sizes, ec50s, "o-", color=color, label=mat, alpha=0.8, markersize=4)
        ax.set_xlabel("Core Size (nm)", fontsize=12)
        ax.set_ylabel("EC50 (mg/L)", fontsize=12)
        ax.set_title("EC50 vs. Core Size for Metal Oxide NMs (Size Series)", fontsize=13)
        ax.legend(title="Material", fontsize=10)
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig1_EC50_vs_CoreSize.png", dpi=150)
        plt.close()
        print("Saved fig1")
    except Exception as e:
        print(f"WARNING fig1 failed: {e}")
        plt.close("all")


def generate_fig2(rows: List[dict], out_dir: pathlib.Path):
    """EC50 vs Zeta Potential scatter by coating."""
    try:
        scenario_rows = [r for r in rows if r["scenario"] == "Surface_Coating_Effect"]
        if not scenario_rows:
            print("WARNING fig2: no data for Surface_Coating_Effect")
            return
        coatings = ["uncoated", "positive", "negative", "PEG"]
        fig, ax = plt.subplots(figsize=(8, 6))
        for coating in coatings:
            c_rows = [r for r in scenario_rows if r["surface_coating_label"] == coating]
            if not c_rows:
                continue
            zeta = np.array([r["zeta_potential_mV"] for r in c_rows])
            ec50 = np.array([r["EC50_mgL"] for r in c_rows])
            assert len(zeta) == len(ec50), "fig2 zeta/ec50 mismatch"
            if len(zeta) == 0:
                continue
            color = COATING_COLORS.get(coating, "gray")
            ax.scatter(zeta, ec50, c=color, label=coating, alpha=0.6, s=20)
        ax.set_yscale("log")
        ax.set_xlabel("Zeta Potential (mV)", fontsize=12)
        ax.set_ylabel("EC50 (mg/L)", fontsize=12)
        ax.set_title("EC50 vs. Zeta Potential: Surface Charge Effect on NM Toxicity", fontsize=12)
        ax.legend(title="Coating", fontsize=10)
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig2_EC50_vs_ZetaPotential.png", dpi=150)
        plt.close()
        print("Saved fig2")
    except Exception as e:
        print(f"WARNING fig2 failed: {e}")
        plt.close("all")


def generate_fig3(rows: List[dict], out_dir: pathlib.Path):
    """Dose-response curves for six NM types."""
    try:
        scenario_rows = [r for r in rows if r["scenario"] == "Dose_Response_Multi_NM"]
        if not scenario_rows:
            print("WARNING fig3: no data for Dose_Response_Multi_NM")
            return
        materials = ["ZnO", "CuO", "Ag", "TiO2", "SiO2", "Au"]
        fig, ax = plt.subplots(figsize=(9, 6))
        for mat in materials:
            mat_rows = [r for r in scenario_rows if r["material_type"] == mat]
            if not mat_rows:
                continue
            # Aggregate by dose: mean viability
            dose_dict: Dict[float, List[float]] = {}
            for r in mat_rows:
                d = round(r["dose_mgL"], 8)
                if d not in dose_dict:
                    dose_dict[d] = []
                dose_dict[d].append(r["cell_viability_pct"])
            doses = np.array(sorted(dose_dict.keys()))
            viabs = np.array([np.mean(dose_dict[d]) for d in doses])
            assert len(doses) == len(viabs), "fig3 dose/viab mismatch"
            if len(doses) == 0:
                continue
            color = MATERIAL_COLORS.get(mat, "black")
            ax.semilogx(doses, viabs, "-", color=color, label=mat, linewidth=2)
        ax.set_xlabel("Dose (mg/L)", fontsize=12)
        ax.set_ylabel("Cell Viability (%)", fontsize=12)
        ax.set_title("Dose-Response Curves: Cell Viability vs. Dose for Six NM Types", fontsize=12)
        ax.set_xlim([0.01, 100])
        ax.set_ylim([0, 105])
        ax.axhline(50, color="gray", linestyle="--", alpha=0.5, label="50% viability")
        ax.legend(title="Material", fontsize=10)
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig3_DoseResponse_Curves.png", dpi=150)
        plt.close()
        print("Saved fig3")
    except Exception as e:
        print(f"WARNING fig3 failed: {e}")
        plt.close("all")


def generate_fig4(out_dir: pathlib.Path, p: dict):
    """ROS production heatmap: crystallinity vs band gap."""
    try:
        crystallinity_vals = np.linspace(0.0, 1.0, 50)
        bandgap_vals = np.linspace(0.0, 6.0, 50)
        ROS_grid = np.zeros((len(bandgap_vals), len(crystallinity_vals)))
        threshold = p.get("ROS_bandgap_threshold", 3.2)
        for i, bg in enumerate(bandgap_vals):
            for j, cryst in enumerate(crystallinity_vals):
                ros = math.exp(-((bg - threshold) ** 2) / (2 * 1.0 ** 2)) * cryst
                ROS_grid[i, j] = clip_val(ros, 0.0, 1.0)
        fig, ax = plt.subplots(figsize=(8, 6))
        im = ax.imshow(ROS_grid, aspect="auto", origin="lower",
                       extent=[0, 1, 0, 6], cmap="hot", vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, label="ROS Production (a.u.)")
        ax.set_xlabel("Crystallinity Index", fontsize=12)
        ax.set_ylabel("Band Gap (eV)", fontsize=12)
        ax.set_title("ROS Production Heatmap: Crystallinity vs. Band Gap", fontsize=12)
        ax.axhline(threshold, color="cyan", linestyle="--", linewidth=1.5, label=f"BG threshold={threshold} eV")
        ax.legend(fontsize=10)
        plt.tight_layout()
        plt.savefig(out_dir / "fig4_ROS_Heatmap.png", dpi=150)
        plt.close()
        print("Saved fig4")
    except Exception as e:
        print(f"WARNING fig4 failed: {e}")
        plt.close("all")


def generate_fig5(rows: List[dict], out_dir: pathlib.Path):
    """Protein corona score vs cell viability scatter."""
    try:
        scenario_rows = [r for r in rows if r["scenario"] == "Protein_Corona_Effect"]
        if not scenario_rows:
            print("WARNING fig5: no data for Protein_Corona_Effect")
            return
        coatings = ["uncoated", "PEG", "positive", "negative"]
        fig, ax = plt.subplots(figsize=(8, 6))
        for coating in coatings:
            c_rows = [r for r in scenario_rows if r["surface_coating_label"] == coating]
            if not c_rows:
                continue
            corona = np.array([r["protein_corona_score"] for r in c_rows])
            viab = np.array([r["cell_viability_pct"] for r in c_rows])
            assert len(corona) == len(viab), "fig5 corona/viab mismatch"
            if len(corona) == 0:
                continue
            color = COATING_COLORS.get(coating, "gray")
            ax.scatter(corona, viab, c=color, label=coating, alpha=0.5, s=15)
        ax.set_xlabel("Protein Corona Score (a.u.)", fontsize=12)
        ax.set_ylabel("Cell Viability (%)", fontsize=12)
        ax.set_title("Protein Corona Score vs. Cell Viability", fontsize=12)
        ax.set_xlim([-0.05, 1.05])
        ax.set_ylim([-5, 110])
        ax.legend(title="Coating", fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig5_ProteinCorona_vs_Viability.png", dpi=150)
        plt.close()
        print("Saved fig5")
    except Exception as e:
        print(f"WARNING fig5 failed: {e}")
        plt.close("all")


def generate_fig6(rows: List[dict], out_dir: pathlib.Path):
    """CNT EC50 vs Aspect Ratio."""
    try:
        scenario_rows = [r for r in rows if r["scenario"] == "CNT_Aspect_Ratio_Pulmonary"]
        if not scenario_rows:
            print("WARNING fig6: no data for CNT_Aspect_Ratio_Pulmonary")
            return
        impurity_levels = ["low", "medium", "high"]
        imp_colors = {"low": "#4daf4a", "medium": "#ff7f00", "high": "#e41a1c"}
        fig, ax = plt.subplots(figsize=(8, 6))
        for imp in impurity_levels:
            imp_rows = [r for r in scenario_rows if r["metallic_impurity_level"] == imp]
            if not imp_rows:
                continue
            # unique NMs
            nm_data = {}
            for r in imp_rows:
                nid = r["nm_id"]
                if nid not in nm_data:
                    nm_data[nid] = {"aspect_ratio": r["aspect_ratio"], "EC50_mgL": r["EC50_mgL"]}
            ars = np.array([v["aspect_ratio"] for v in nm_data.values()])
            ec50s = np.array([v["EC50_mgL"] for v in nm_data.values()])
            assert len(ars) == len(ec50s), "fig6 ar/ec50 mismatch"
            if len(ars) == 0:
                continue
            order = np.argsort(ars)
            ars = ars[order]
            ec50s = ec50s[order]
            color = imp_colors.get(imp, "black")
            ax.semilogy(ars, ec50s, "o-", color=color, label=f"Impurity: {imp}", alpha=0.8, markersize=4)
        ax.set_xlabel("Aspect Ratio (length/diameter)", fontsize=12)
        ax.set_ylabel("EC50 (mg/L)", fontsize=12)
        ax.set_title("CNT Pulmonary Toxicity: EC50 vs. Aspect Ratio", fontsize=12)
        ax.legend(fontsize=10)
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig6_CNT_EC50_vs_AspectRatio.png", dpi=150)
        plt.close()
        print("Saved fig6")
    except Exception as e:
        print(f"WARNING fig6 failed: {e}")
        plt.close("all")


def generate_fig7(rows: List[dict], out_dir: pathlib.Path, threshold: float = 3.0):
    """Histogram of data quality scores."""
    try:
        if not rows:
            print("WARNING fig7: no data")
            return
        # Use unique NM IDs to avoid dose-level repetition
        seen = set()
        dqs_vals = []
        for r in rows:
            nid = r["nm_id"]
            if nid not in seen:
                seen.add(nid)
                dqs_vals.append(float(r["data_quality_score"]))
        if len(dqs_vals) == 0:
            print("WARNING fig7: empty data quality scores")
            return
        dqs_arr = np.array(dqs_vals)
        fig, ax = plt.subplots(figsize=(8, 6))
        bins = np.arange(-0.5, 6.0, 1.0)
        ax.hist(dqs_arr, bins=bins, color="#377eb8", edgecolor="white", alpha=0.85, rwidth=0.85)
        ax.axvline(threshold, color="red", linestyle="--", linewidth=2, label=f"Reliability threshold = {threshold}")
        ax.set_xlabel("Data Quality Score (0-5)", fontsize=12)
        ax.set_ylabel("Count", fontsize=12)
        ax.set_title("Distribution of NM Data Quality Scores Across Simulated Dataset", fontsize=12)
        ax.legend(fontsize=10)
        ax.set_xticks([0, 1, 2, 3, 4, 5])
        ax.grid(True, axis="y", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig7_DataQuality_Histogram.png", dpi=150)
        plt.close()
        print("Saved fig7")
    except Exception as e:
        print(f"WARNING fig7 failed: {e}")
        plt.close("all")


def generate_fig8(rows: List[dict], out_dir: pathlib.Path):
    """Dissolution rate vs EC50 scatter by material class."""
    try:
        if not rows:
            print("WARNING fig8: no data")
            return
        class_map = {
            "ZnO": "Oxide NMs", "CuO": "Oxide NMs", "TiO2": "Oxide NMs", "CeO2": "Oxide NMs",
            "SiO2": "Oxide NMs",
            "Ag": "Metallic NMs", "Au": "Metallic NMs",
            "CNT": "Carbonaceous NMs",
        }
        class_colors = {
            "Oxide NMs": "#e41a1c",
            "Metallic NMs": "#377eb8",
            "Carbonaceous NMs": "#4daf4a",
            "Quantum Dots": "#984ea3",
        }
        # Unique NM entries only
        seen = set()
        class_data: Dict[str, Tuple[List, List]] = {c: ([], []) for c in class_colors}
        for r in rows:
            nid = r["nm_id"]
            if nid not in seen:
                seen.add(nid)
                mat = r["material_type"]
                cls = class_map.get(mat, "Carbonaceous NMs")
                class_data[cls][0].append(r["dissolution_rate"])
                class_data[cls][1].append(r["EC50_mgL"])
        fig, ax = plt.subplots(figsize=(8, 6))
        for cls, (dr_list, ec50_list) in class_data.items():
            if len(dr_list) == 0:
                continue
            dr_arr = np.array(dr_list)
            ec50_arr = np.array(ec50_list)
            assert len(dr_arr) == len(ec50_arr), f"fig8 dr/ec50 mismatch for {cls}"
            color = class_colors.get(cls, "gray")
            ax.scatter(dr_arr, ec50_arr, c=color, label=cls, alpha=0.5, s=20)
        ax.set_yscale("log")
        ax.set_xlabel("Dissolution Rate (a.u.)", fontsize=12)
        ax.set_ylabel("EC50 (mg/L)", fontsize=12)
        ax.set_title("Dissolution Rate vs. EC50 Across NM Material Classes", fontsize=12)
        ax.legend(title="Material Class", fontsize=10)
        ax.grid(True, which="both", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig8_Dissolution_vs_EC50.png", dpi=150)
        plt.close()
        print("Saved fig8")
    except Exception as e:
        print(f"WARNING fig8 failed: {e}")
        plt.close("all")


# ---------------------------------------------------------------------------
# CSV WRITERS
# ---------------------------------------------------------------------------

SCHEMA_COLUMNS = [
    "nm_id", "material_type", "scenario", "core_size_nm", "hydrodynamic_diameter_nm",
    "zeta_potential_mV", "surface_area_m2g", "band_gap_eV", "dissolution_rate",
    "aspect_ratio", "surface_coating_charge", "surface_coating_label",
    "crystallinity_index", "ROS_production", "protein_corona_score",
    "metallic_impurity_level", "dose_mgL", "exposure_time_h", "cell_viability_pct",
    "EC50_mgL", "data_quality_score", "pchem_source_score", "pchem_method_score",
    "predicted_toxicity_class", "enthalpy_cation_eV",
]


def write_simulation_outputs(all_rows: List[dict], out_dir: pathlib.Path):
    """Write simulation_outputs.csv — full time-series for all scenarios."""
    try:
        if not all_rows:
            print("WARNING: no rows to write to simulation_outputs.csv")
            return
        filepath = out_dir / "simulation_outputs.csv"
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=SCHEMA_COLUMNS)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({col: row.get(col, "") for col in SCHEMA_COLUMNS})
        print(f"Saved simulation_outputs.csv ({len(all_rows)} rows)")
    except Exception as e:
        print(f"WARNING: failed to write simulation_outputs.csv: {e}")


def write_scenario_summary(all_rows: List[dict], out_dir: pathlib.Path):
    """Write scenario_summary.csv — one row per scenario with aggregate metrics."""
    try:
        if not all_rows:
            print("WARNING: no rows for scenario_summary.csv")
            return
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))
        numeric_vars = [
            "core_size_nm", "hydrodynamic_diameter_nm", "zeta_potential_mV",
            "surface_area_m2g", "band_gap_eV", "dissolution_rate", "aspect_ratio",
            "crystallinity_index", "ROS_production", "protein_corona_score",
            "cell_viability_pct", "EC50_mgL", "data_quality_score",
        ]
        header = ["scenario", "n_rows", "n_unique_nms"]
        for var in numeric_vars:
            for stat in ["mean", "std", "min", "max"]:
                header.append(f"{var}_{stat}")
        header += ["pct_high_toxicity", "pct_medium_toxicity", "pct_low_toxicity",
                   "pct_above_quality_threshold"]
        filepath = out_dir / "scenario_summary.csv"
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=header)
            writer.writeheader()
            for sc in scenarios:
                sc_rows = [r for r in all_rows if r["scenario"] == sc]
                n_rows = len(sc_rows)
                unique_nms = len(set(r["nm_id"] for r in sc_rows))
                row_dict = {"scenario": sc, "n_rows": n_rows, "n_unique_nms": unique_nms}
                for var in numeric_vars:
                    vals = np.array([float(r[var]) for r in sc_rows if r.get(var) not in (None, "")])
                    if len(vals) > 0:
                        row_dict[f"{var}_mean"] = round(float(np.mean(vals)), 4)
                        row_dict[f"{var}_std"] = round(float(np.std(vals)), 4)
                        row_dict[f"{var}_min"] = round(float(np.min(vals)), 4)
                        row_dict[f"{var}_max"] = round(float(np.max(vals)), 4)
                    else:
                        row_dict[f"{var}_mean"] = 0.0
                        row_dict[f"{var}_std"] = 0.0
                        row_dict[f"{var}_min"] = 0.0
                        row_dict[f"{var}_max"] = 0.0
                tox_classes = [r["predicted_toxicity_class"] for r in sc_rows]
                n_total = len(tox_classes)
                row_dict["pct_high_toxicity"] = round(100.0 * tox_classes.count("High") / n_total, 2) if n_total else 0
                row_dict["pct_medium_toxicity"] = round(100.0 * tox_classes.count("Medium") / n_total, 2) if n_total else 0
                row_dict["pct_low_toxicity"] = round(100.0 * tox_classes.count("Low") / n_total, 2) if n_total else 0
                threshold = MODEL_PROFILE["parameters"]["data_reliability_threshold"]
                above = sum(1 for r in sc_rows if float(r.get("data_quality_score", 0)) >= threshold)
                row_dict["pct_above_quality_threshold"] = round(100.0 * above / n_total, 2) if n_total else 0
                writer.writerow(row_dict)
        print("Saved scenario_summary.csv")
    except Exception as e:
        print(f"WARNING: failed to write scenario_summary.csv: {e}")


def write_parameters_used(out_dir: pathlib.Path):
    """Write parameters_used.csv — one row per parameter."""
    params_info = [
        ("w_zeta", 0.35, "a.u.", "extracted", "Weight of zeta potential term in toxicity QSAR model"),
        ("w_size", 0.25, "a.u.", "extracted", "Weight of core size term; smaller NMs more toxic"),
        ("w_bandgap", 0.20, "a.u.", "extracted", "Weight of band gap term; links to oxidative stress"),
        ("w_crystallinity", 0.10, "a.u.", "extracted", "Weight of crystallinity index"),
        ("w_dissolution", 0.10, "a.u.", "extracted", "Weight of dissolution rate contribution"),
        ("hill_n", 2.0, "a.u.", "assumed", "Hill coefficient for dose-response sigmoid"),
        ("EC50_size_ref", 20.0, "nm", "extracted", "Reference core size for EC50 scaling (Puzyn et al.)"),
        ("EC50_base_mgL", 10.0, "mg/L", "extracted", "Baseline EC50 for neutral amorphous mid-size NM"),
        ("corona_surface_weight", 0.6, "a.u.", "assumed", "Contribution of surface charge to corona score"),
        ("corona_size_weight", 0.4, "a.u.", "assumed", "Contribution of surface area to corona score"),
        ("ROS_bandgap_threshold", 3.2, "eV", "extracted", "Band gap threshold for max ROS (TiO2 anatase)"),
        ("max_agglomeration_factor", 10.0, "a.u.", "assumed", "Max hydrodynamic-to-core size ratio"),
        ("data_reliability_threshold", 3.0, "a.u.", "extracted", "Min PChem quality score for QSAR modelling"),
        ("n_NMs_per_type", 30.0, "count", "extracted", "NM variants per material type"),
        ("enthalpy_cation_scale", -0.05, "eV per mg/L", "extracted", "Scaling factor for enthalpy to EC50 (Puzyn)"),
        ("aspect_toxicity_exp", 0.5, "a.u.", "assumed", "Exponent for aspect ratio toxicity contribution"),
        ("noise_std", 0.05, "a.u.", "assumed", "Gaussian noise std for experimental variability"),
    ]
    try:
        filepath = out_dir / "parameters_used.csv"
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "value", "unit", "source", "description"])
            for row in params_info:
                writer.writerow(list(row))
        print("Saved parameters_used.csv")
    except Exception as e:
        print(f"WARNING: failed to write parameters_used.csv: {e}")


# ---------------------------------------------------------------------------
# SUMMARY JSON
# ---------------------------------------------------------------------------

def write_summary_json(all_rows: List[dict], out_dir: pathlib.Path):
    """Write summary.json with key aggregate metrics."""
    try:
        if not all_rows:
            print("WARNING: no rows for summary.json")
            return
        ec50_vals = np.array([float(r["EC50_mgL"]) for r in all_rows])
        viab_vals = np.array([float(r["cell_viability_pct"]) for r in all_rows])
        ros_vals = np.array([float(r["ROS_production"]) for r in all_rows])
        dqs_vals = np.array([float(r["data_quality_score"]) for r in all_rows])
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))
        tox_classes = [r["predicted_toxicity_class"] for r in all_rows]
        threshold = MODEL_PROFILE["parameters"]["data_reliability_threshold"]
        summary = {
            "paper": "NanoSolveIT Project: Driving nanoinformatics research to develop innovative and integrated tools for in silico nanosafety assessment",
            "total_rows": len(all_rows),
            "n_scenarios": len(scenarios),
            "scenarios": scenarios,
            "unique_nm_ids": len(set(r["nm_id"] for r in all_rows)),
            "EC50_mgL": {
                "mean": round(float(np.mean(ec50_vals)), 4),
                "std": round(float(np.std(ec50_vals)), 4),
                "min": round(float(np.min(ec50_vals)), 4),
                "max": round(float(np.max(ec50_vals)), 4),
            },
            "cell_viability_pct": {
                "mean": round(float(np.mean(viab_vals)), 4),
                "std": round(float(np.std(viab_vals)), 4),
            },
            "ROS_production": {
                "mean": round(float(np.mean(ros_vals)), 4),
                "std": round(float(np.std(ros_vals)), 4),
            },
            "data_quality_score": {
                "mean": round(float(np.mean(dqs_vals)), 4),
                "pct_above_threshold": round(100.0 * np.sum(dqs_vals >= threshold) / len(dqs_vals), 2),
            },
            "toxicity_class_distribution": {
                "High": round(100.0 * tox_classes.count("High") / len(tox_classes), 2),
                "Medium": round(100.0 * tox_classes.count("Medium") / len(tox_classes), 2),
                "Low": round(100.0 * tox_classes.count("Low") / len(tox_classes), 2),
            },
        }
        filepath = out_dir / "summary.json"
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print("Saved summary.json")
    except Exception as e:
        print(f"WARNING: failed to write summary.json: {e}")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="NanoSolveIT Nanoinformatics Simulator"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # -------------------------------------------------------------------
    # Run all scenarios
    # -------------------------------------------------------------------
    all_rows: List[dict] = []
    for idx, scenario_cfg in enumerate(MODEL_PROFILE["scenarios"]):
        label = scenario_cfg["label"]
        print(f"\n--- Running scenario {idx}: {label} ---")
        try:
            rows = simulate_scenario(idx)
            print(f"  Generated {len(rows)} rows")
            all_rows.extend(rows)
        except Exception as e:
            print(f"WARNING: scenario {label} failed: {e}")

    print(f"\nTotal rows generated: {len(all_rows)}")

    # -------------------------------------------------------------------
    # Write CSVs
    # -------------------------------------------------------------------
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(all_rows, out_dir)
    write_parameters_used(out_dir)

    # -------------------------------------------------------------------
    # Generate all figures
    # -------------------------------------------------------------------
    print("\n--- Generating figures ---")
    default_p = dict(MODEL_PROFILE["parameters"])

    generate_fig1(all_rows, out_dir)
    generate_fig2(all_rows, out_dir)
    generate_fig3(all_rows, out_dir)
    generate_fig4(out_dir, default_p)
    generate_fig5(all_rows, out_dir)
    generate_fig6(all_rows, out_dir)
    generate_fig7(all_rows, out_dir, threshold=default_p["data_reliability_threshold"])
    generate_fig8(all_rows, out_dir)

    # -------------------------------------------------------------------
    # Write summary JSON
    # -------------------------------------------------------------------
    write_summary_json(all_rows, out_dir)

    print(f"\nSimulation complete. All outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()