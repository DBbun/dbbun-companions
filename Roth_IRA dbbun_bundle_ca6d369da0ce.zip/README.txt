================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : b9e7e500-4637-4fff-95f5-06f4289d8cf9
    Generated   : 2026-04-28  12:13:37 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Roth IRA

    CATEGORIES
    ----------
    Financial

    KEYWORDS
    --------
    Roth IRA, retirement savings, tax-advantaged account, compound growth, IRS contribution limits

    ABSTRACT
    --------
    This simulator models the long-term wealth accumulation dynamics of Roth Individual Retirement Accounts (IRAs) as defined under U.S. tax law, faithfully implementing all IRS contribution limits from 1998 through 2026 and beyond, income phase-out rules, catch-up contributions, and the critical tax-treatment distinction between Roth and Traditional IRAs. The simulator computes year-by-year account balances, cumulative contributions versus earnings, after-tax withdrawal values, and the net dollar advantage of Roth versus Traditional strategies across a range of working and retirement tax rate combinations. Eight distinct scenarios spanning moderate-income baseline, high-income phase-out, same-rate equivalence, rising-tax advantage, falling-tax disadvantage, catch-up contributions, and aggressive versus conservative portfolio returns are fully enumerated. Researchers, financial educators, and retirement planners can use the generated CSV data and eight publication-quality figures to quantify optimal IRA strategy selection as a function of income trajectory, expected tax rate changes, and investment return assumptions.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Roth_IRA.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    roth_balance, traditional_balance, roth_contributions_cumulative, traditional_contributions_cumulative, roth_after_tax_value, traditional_after_tax_value, year, age, annual_contribution, magi, roth_tax_savings_cumulative, traditional_tax_paid_withdrawal

    SCENARIOS  (8 total)
    ---------------------------------
        1. baseline_moderate_income — Single filer, age 30 start, MAGI $80,000 growing 3%/yr, 22% working tax rate, 15% retirement tax rate, 7% return, full contributions each year following IRS schedule
2. high_income_phaseout — Single filer, MAGI $130,000 growing 3%/yr, enters the Roth phase-out range around year 5, demonstrating partial then zero direct contributions (backdoor not modeled), 24% working tax rate
3. roth_vs_traditional_same_tax_rate — Both Roth and Traditional IRA are funded identically; tax rate during contribution equals tax rate at withdrawal (22%), showing mathematical equivalence of after-tax outcomes
4. roth_advantage_rising_tax — Roth outperforms Traditional when retirement tax rate exceeds working tax rate — contributor is in 22% bracket now, expected 32% in retirement
5. traditional_advantage_falling_tax — Traditional outperforms Roth when retirement tax rate is much lower than working rate — contributor is in 32% bracket now, expected 12% in retirement
6. catchup_contributions_age50plus — Investor starts at age 50, takes full advantage of catch-up contributions ($1,000 extra/yr from 2008+ schedule), 22% working tax rate, 15% retirement
7. aggressive_growth_portfolio — Same baseline but 10% annual return to simulate equity-heavy portfolio, demonstrating compounding amplification of Roth tax-free advantage
8. conservative_growth_portfolio — Same baseline but 4% annual return to simulate bond-heavy portfolio, showing reduced compounding and smaller Roth advantage

    PARAMETERS
    ----------
    28 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This source covers the structure, rules, contribution limits, eligibility requirements, tax treatment, and long-term wealth accumulation dynamics of Roth Individual Retirement Accounts (IRAs) under U.S. tax law, comparing them to Traditional IRAs across multiple income and tax-rate scenarios.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.