# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T12:13:37.941134Z
# Run ID    : b9e7e500-4637-4fff-95f5-06f4289d8cf9
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Roth IRA Dynamical System Simulator

Paper: "Roth IRA" — covering structure, rules, contribution limits, eligibility
requirements, tax treatment, and long-term wealth accumulation dynamics of Roth
Individual Retirement Accounts (IRAs) under U.S. tax law, comparing them to
Traditional IRAs across multiple income and tax-rate scenarios.
"""

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# MODEL PROFILE
# ---------------------------------------------------------------------------
MODEL_PROFILE = {
    "parameters": {
        "annual_return_rate": {"value": 0.07, "unit": "fraction per year", "source": "assumed",
                               "description": "Nominal annual investment return rate (7% reflects long-run equity market average)"},
        "contribution_tax_rate_working": {"value": 0.22, "unit": "fraction", "source": "assumed",
                                          "description": "Marginal income tax rate during working years"},
        "withdrawal_tax_rate_retirement": {"value": 0.15, "unit": "fraction", "source": "assumed",
                                           "description": "Marginal income tax rate in retirement for Traditional IRA withdrawals"},
        "start_age": {"value": 30.0, "unit": "years", "source": "assumed",
                      "description": "Age at which account holder begins contributing"},
        "retirement_age": {"value": 65.0, "unit": "years", "source": "assumed",
                           "description": "Age at which contributions cease"},
        "end_age": {"value": 85.0, "unit": "years", "source": "assumed",
                    "description": "Age at which simulation ends"},
        "start_year": {"value": 2000.0, "unit": "year", "source": "extracted",
                       "description": "First year of contribution simulation"},
        "magi_init": {"value": 80000.0, "unit": "USD", "source": "assumed",
                      "description": "Initial MAGI at start_year"},
        "magi_growth_rate": {"value": 0.03, "unit": "fraction per year", "source": "assumed",
                             "description": "Annual MAGI growth rate"},
        "inflation_rate": {"value": 0.025, "unit": "fraction per year", "source": "assumed",
                           "description": "Annual inflation rate"},
        "rmd_start_age": {"value": 72.0, "unit": "years", "source": "extracted",
                          "description": "Age at which RMDs begin for Traditional IRA"},
        "qualified_withdrawal_age": {"value": 59.5, "unit": "years", "source": "extracted",
                                     "description": "Minimum age for penalty-free qualified Roth IRA earnings withdrawal"},
        "seasoning_period": {"value": 5.0, "unit": "years", "source": "extracted",
                             "description": "Minimum years account must be open before earnings can be withdrawn tax-free"},
        "future_contribution_growth_rate": {"value": 0.02, "unit": "fraction per year", "source": "assumed",
                                            "description": "Assumed annual growth rate of IRS contribution limits beyond 2026"},
        "magi_phaseout_single_lower_2021": {"value": 125000.0, "unit": "USD", "source": "extracted",
                                            "description": "2021 MAGI lower bound single filer phase-out"},
        "magi_phaseout_single_upper_2021": {"value": 140000.0, "unit": "USD", "source": "extracted",
                                            "description": "2021 MAGI upper bound single filer phase-out"},
        "magi_phaseout_joint_lower_2021": {"value": 198000.0, "unit": "USD", "source": "extracted",
                                           "description": "2021 MAGI lower bound joint filer phase-out"},
        "magi_phaseout_joint_upper_2021": {"value": 208000.0, "unit": "USD", "source": "extracted",
                                           "description": "2021 MAGI upper bound joint filer phase-out"},
    },
    "scenarios": [
        {
            "label": "baseline_moderate_income",
            "description": "Single filer, age 30 start, MAGI $80k, 22%/15% tax rates, 7% return",
            "param_overrides": {
                "start_age": 30.0, "magi_init": 80000.0,
                "contribution_tax_rate_working": 0.22,
                "withdrawal_tax_rate_retirement": 0.15,
                "annual_return_rate": 0.07,
            }
        },
        {
            "label": "high_income_phaseout",
            "description": "Single filer, MAGI $130k, enters phase-out, 24%/20% tax rates",
            "param_overrides": {
                "start_age": 30.0, "magi_init": 130000.0,
                "contribution_tax_rate_working": 0.24,
                "withdrawal_tax_rate_retirement": 0.20,
                "annual_return_rate": 0.07,
            }
        },
        {
            "label": "roth_vs_traditional_same_tax_rate",
            "description": "22%/22% tax rates — mathematical equivalence demonstration",
            "param_overrides": {
                "start_age": 35.0, "magi_init": 75000.0,
                "contribution_tax_rate_working": 0.22,
                "withdrawal_tax_rate_retirement": 0.22,
                "annual_return_rate": 0.07,
            }
        },
        {
            "label": "roth_advantage_rising_tax",
            "description": "22% working / 32% retirement — Roth outperforms",
            "param_overrides": {
                "start_age": 25.0, "magi_init": 65000.0,
                "contribution_tax_rate_working": 0.22,
                "withdrawal_tax_rate_retirement": 0.32,
                "annual_return_rate": 0.07,
            }
        },
        {
            "label": "traditional_advantage_falling_tax",
            "description": "32% working / 12% retirement — Traditional outperforms",
            "param_overrides": {
                "start_age": 40.0, "magi_init": 150000.0,
                "contribution_tax_rate_working": 0.32,
                "withdrawal_tax_rate_retirement": 0.12,
                "annual_return_rate": 0.07,
            }
        },
        {
            "label": "catchup_contributions_age50plus",
            "description": "Starts at 50, full catch-up contributions, 22%/15% tax rates",
            "param_overrides": {
                "start_age": 50.0, "magi_init": 90000.0,
                "contribution_tax_rate_working": 0.22,
                "withdrawal_tax_rate_retirement": 0.15,
                "annual_return_rate": 0.07,
            }
        },
        {
            "label": "aggressive_growth_portfolio",
            "description": "10% annual return, baseline otherwise",
            "param_overrides": {
                "start_age": 30.0, "magi_init": 80000.0,
                "contribution_tax_rate_working": 0.22,
                "withdrawal_tax_rate_retirement": 0.15,
                "annual_return_rate": 0.10,
            }
        },
        {
            "label": "conservative_growth_portfolio",
            "description": "4% annual return, baseline otherwise",
            "param_overrides": {
                "start_age": 30.0, "magi_init": 80000.0,
                "contribution_tax_rate_working": 0.22,
                "withdrawal_tax_rate_retirement": 0.15,
                "annual_return_rate": 0.04,
            }
        },
    ]
}

# ---------------------------------------------------------------------------
# IRS CONTRIBUTION LIMIT SCHEDULE
# ---------------------------------------------------------------------------
# (under_50_limit, over_50_limit)
_IRS_LIMITS = [
    (range(1998, 2002), 2000.0, 2000.0),
    (range(2002, 2005), 3000.0, 3500.0),
    (range(2005, 2006), 4000.0, 4500.0),
    (range(2006, 2008), 4000.0, 5000.0),
    (range(2008, 2013), 5000.0, 6000.0),
    (range(2013, 2019), 5500.0, 6500.0),
    (range(2019, 2023), 6000.0, 7000.0),
    (range(2023, 2024), 6500.0, 7500.0),
    (range(2024, 2026), 7000.0, 8000.0),
    (range(2026, 2027), 7500.0, 8600.0),
]


def get_irs_limit(year: int, future_growth_rate: float = 0.02):
    """Return (under_50_limit, over_50_limit) for a given year."""
    for yr_range, u50, o50 in _IRS_LIMITS:
        if year in yr_range:
            return u50, o50
    # Post-2026: grow from 2026 base at future_growth_rate, round to nearest $500
    years_past = year - 2026
    u50_base = 7500.0
    o50_base = 8600.0
    factor = (1.0 + future_growth_rate) ** years_past
    u50 = round((u50_base * factor) / 500.0) * 500.0
    o50 = round((o50_base * factor) / 500.0) * 500.0
    # Clamp to spec-defined max annual_contribution range [0, 8600] for base year;
    # allow growth beyond for future years but keep reasonable
    u50 = max(7500.0, u50)
    o50 = max(8600.0, o50)
    return u50, o50


# ---------------------------------------------------------------------------
# PHASE-OUT CALCULATION
# ---------------------------------------------------------------------------

def compute_phaseout_fraction(magi: float, year: int, irs_limit_for_age: float,
                               filing_status: str = 'single') -> float:
    """Return fraction [0,1] of IRS limit that is allowable given MAGI."""
    inflation_factor = (1.0 + 0.025) ** (year - 2021)
    if filing_status == 'single':
        lower = 125000.0 * inflation_factor
        upper = 140000.0 * inflation_factor
    else:  # joint
        lower = 198000.0 * inflation_factor
        upper = 208000.0 * inflation_factor

    if magi <= lower:
        return 1.0
    elif magi >= upper:
        return 0.0
    else:
        fraction = 1.0 - (magi - lower) / (upper - lower)
        # Minimum $200 floor
        if irs_limit_for_age > 0:
            min_fraction = 200.0 / irs_limit_for_age
        else:
            min_fraction = 0.0
        return max(fraction, min_fraction)


# ---------------------------------------------------------------------------
# CORE SIMULATION
# ---------------------------------------------------------------------------

def get_default_params():
    """Return default parameter dict from MODEL_PROFILE."""
    return {
        "annual_return_rate": 0.07,
        "contribution_tax_rate_working": 0.22,
        "withdrawal_tax_rate_retirement": 0.15,
        "start_age": 30.0,
        "retirement_age": 65.0,
        "end_age": 85.0,
        "start_year": 2000.0,
        "magi_init": 80000.0,
        "magi_growth_rate": 0.03,
        "inflation_rate": 0.025,
        "rmd_start_age": 72.0,
        "future_contribution_growth_rate": 0.02,
        "filing_status": "single",
    }


def run_scenario(scenario: dict, scenario_index: int) -> list:
    """
    Run a single scenario and return list of row-dicts for all years.
    Uses np.random.seed(scenario_index) for reproducibility.
    """
    np.random.seed(scenario_index)

    params = get_default_params()
    params.update(scenario.get("param_overrides", {}))

    annual_return_rate = float(params["annual_return_rate"])
    contribution_tax_rate_working = float(params["contribution_tax_rate_working"])
    withdrawal_tax_rate_retirement = float(params["withdrawal_tax_rate_retirement"])
    start_age = float(params["start_age"])
    retirement_age = float(params["retirement_age"])
    end_age = float(params["end_age"])
    start_year = int(params["start_year"])
    magi_init = float(params["magi_init"])
    magi_growth_rate = float(params["magi_growth_rate"])
    inflation_rate = float(params["inflation_rate"])
    rmd_start_age = float(params["rmd_start_age"])
    future_growth_rate = float(params["future_contribution_growth_rate"])
    filing_status = str(params.get("filing_status", "single"))
    scenario_label = scenario["label"]

    # Compute end_year
    years_to_end = int(end_age - start_age)
    end_year = start_year + years_to_end

    # State variables
    roth_balance = 0.0
    trad_balance = 0.0
    roth_contrib_cum = 0.0
    trad_contrib_cum = 0.0
    cumulative_inflation = 1.0

    rows = []

    for yr_offset in range(years_to_end + 1):
        year = start_year + yr_offset
        age = start_age + yr_offset
        magi = magi_init * ((1.0 + magi_growth_rate) ** yr_offset)
        cumulative_inflation = (1.0 + inflation_rate) ** (yr_offset + 1)

        # 1. IRS limits
        limit_under50, limit_over50 = get_irs_limit(int(year), future_growth_rate)
        catchup_eligible = age >= 50.0
        irs_limit_this_age = limit_over50 if catchup_eligible else limit_under50

        # 2. Phase-out fraction
        if age < retirement_age:
            po_fraction = compute_phaseout_fraction(magi, int(year), irs_limit_this_age, filing_status)
        else:
            po_fraction = 0.0

        # 3. Actual contributions
        if age < retirement_age:
            contrib_roth = min(irs_limit_this_age * po_fraction, magi)
            contrib_roth = max(0.0, contrib_roth)
            contrib_trad = min(limit_under50 if not catchup_eligible else limit_over50, magi)
            contrib_trad = max(0.0, contrib_trad)
        else:
            contrib_roth = 0.0
            contrib_trad = 0.0

        # 4. Grow balances (apply return, then add contribution)
        roth_balance = roth_balance * (1.0 + annual_return_rate) + contrib_roth
        trad_balance = trad_balance * (1.0 + annual_return_rate) + contrib_trad

        # Post-retirement: Traditional RMD (simplified — remove from balance but don't add to roth)
        if age >= retirement_age and age >= rmd_start_age:
            life_expectancy_factor = max(1.0, 90.0 - age)
            rmd = trad_balance / life_expectancy_factor
            trad_balance = max(0.0, trad_balance - rmd)

        # 5. Cumulative contributions and earnings
        roth_contrib_cum += contrib_roth
        trad_contrib_cum += contrib_trad
        roth_earnings = max(0.0, roth_balance - roth_contrib_cum)
        trad_earnings = max(0.0, trad_balance - trad_contrib_cum)

        # 6. After-tax values
        roth_after_tax = roth_balance  # tax-free withdrawals
        trad_after_tax = trad_balance * (1.0 - withdrawal_tax_rate_retirement)

        # 7. Roth advantage
        roth_advantage = roth_after_tax - trad_after_tax

        # 8. Real balances
        roth_real = roth_balance / cumulative_inflation
        trad_real = trad_balance / cumulative_inflation

        # Clamp all state variables to defined ranges
        roth_balance = max(0.0, min(5000000.0, roth_balance))
        trad_balance = max(0.0, min(5000000.0, trad_balance))
        roth_contrib_cum = max(0.0, min(500000.0, roth_contrib_cum))
        trad_contrib_cum = max(0.0, min(500000.0, trad_contrib_cum))
        roth_after_tax = max(0.0, min(5000000.0, roth_after_tax))
        trad_after_tax = max(0.0, min(4000000.0, trad_after_tax))
        roth_real = max(0.0, min(5000000.0, roth_real))
        trad_real = max(0.0, min(5000000.0, trad_real))
        magi = max(0.0, min(500000.0, magi))
        contrib_roth = max(0.0, min(8600.0, contrib_roth))
        contrib_trad = max(0.0, min(8600.0, contrib_trad))

        row = {
            "scenario_label": scenario_label,
            "year": int(year),
            "age": float(age),
            "magi": round(magi, 2),
            "annual_contribution_limit_under50": limit_under50,
            "annual_contribution_limit_over50": limit_over50,
            "catchup_eligible": int(catchup_eligible),
            "phase_out_fraction": round(po_fraction, 6),
            "actual_contribution_roth": round(contrib_roth, 2),
            "actual_contribution_traditional": round(contrib_trad, 2),
            "roth_balance": round(roth_balance, 2),
            "traditional_balance": round(trad_balance, 2),
            "roth_contributions_cumulative": round(roth_contrib_cum, 2),
            "traditional_contributions_cumulative": round(trad_contrib_cum, 2),
            "roth_earnings_cumulative": round(roth_earnings, 2),
            "traditional_earnings_cumulative": round(trad_earnings, 2),
            "roth_after_tax_value": round(roth_after_tax, 2),
            "traditional_after_tax_value": round(trad_after_tax, 2),
            "roth_advantage_usd": round(roth_advantage, 2),
            "roth_real_balance": round(roth_real, 2),
            "traditional_real_balance": round(trad_real, 2),
            "contribution_tax_rate_working": contribution_tax_rate_working,
            "withdrawal_tax_rate_retirement": withdrawal_tax_rate_retirement,
            "annual_return_rate": annual_return_rate,
            "inflation_rate": inflation_rate,
        }
        rows.append(row)

    return rows


def run_all_scenarios() -> dict:
    """Run all scenarios and return dict of label -> rows."""
    all_data = {}
    scenarios = MODEL_PROFILE["scenarios"]
    for idx, scenario in enumerate(scenarios):
        rows = run_scenario(scenario, idx)
        all_data[scenario["label"]] = rows
    return all_data


# ---------------------------------------------------------------------------
# CSV WRITING
# ---------------------------------------------------------------------------

DATASET_SCHEMA = [
    "scenario_label", "year", "age", "magi",
    "annual_contribution_limit_under50", "annual_contribution_limit_over50",
    "catchup_eligible", "phase_out_fraction",
    "actual_contribution_roth", "actual_contribution_traditional",
    "roth_balance", "traditional_balance",
    "roth_contributions_cumulative", "traditional_contributions_cumulative",
    "roth_earnings_cumulative", "traditional_earnings_cumulative",
    "roth_after_tax_value", "traditional_after_tax_value",
    "roth_advantage_usd", "roth_real_balance", "traditional_real_balance",
    "contribution_tax_rate_working", "withdrawal_tax_rate_retirement",
    "annual_return_rate", "inflation_rate",
]


def write_simulation_outputs(all_data: dict, out_dir: Path):
    """Write simulation_outputs.csv with all scenario rows combined."""
    all_rows = []
    for label, rows in all_data.items():
        all_rows.extend(rows)

    if not all_rows:
        print("WARNING: No simulation output rows to write.")
        return

    fpath = out_dir / "simulation_outputs.csv"
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA)
        writer.writeheader()
        writer.writerows(all_rows)
    print(f"Saved: {fpath} ({len(all_rows)} rows)")


def write_scenario_summary(all_data: dict, out_dir: Path):
    """Write scenario_summary.csv with one row per scenario."""
    summary_rows = []
    state_vars = [
        "roth_balance", "traditional_balance",
        "roth_contributions_cumulative", "traditional_contributions_cumulative",
        "roth_after_tax_value", "traditional_after_tax_value",
        "roth_advantage_usd", "roth_real_balance", "traditional_real_balance",
    ]

    for label, rows in all_data.items():
        if not rows:
            continue
        row_summary = {"scenario_label": label}
        # Params from last row
        last = rows[-1]
        row_summary["contribution_tax_rate_working"] = last["contribution_tax_rate_working"]
        row_summary["withdrawal_tax_rate_retirement"] = last["withdrawal_tax_rate_retirement"]
        row_summary["annual_return_rate"] = last["annual_return_rate"]
        # Retirement row (max age where contributions happen)
        retirement_rows = [r for r in rows if r["age"] >= 65.0]
        if retirement_rows:
            ret_row = retirement_rows[0]
            row_summary["roth_balance_at_retirement"] = ret_row["roth_balance"]
            row_summary["trad_balance_at_retirement"] = ret_row["traditional_balance"]
            row_summary["roth_after_tax_at_retirement"] = ret_row["roth_after_tax_value"]
            row_summary["trad_after_tax_at_retirement"] = ret_row["traditional_after_tax_value"]
            row_summary["roth_advantage_at_retirement"] = ret_row["roth_advantage_usd"]
        else:
            row_summary["roth_balance_at_retirement"] = 0.0
            row_summary["trad_balance_at_retirement"] = 0.0
            row_summary["roth_after_tax_at_retirement"] = 0.0
            row_summary["trad_after_tax_at_retirement"] = 0.0
            row_summary["roth_advantage_at_retirement"] = 0.0

        for var in state_vars:
            vals = np.array([r[var] for r in rows], dtype=float)
            row_summary[f"{var}_mean"] = round(float(np.mean(vals)), 2)
            row_summary[f"{var}_std"] = round(float(np.std(vals)), 2)
            row_summary[f"{var}_min"] = round(float(np.min(vals)), 2)
            row_summary[f"{var}_max"] = round(float(np.max(vals)), 2)

        summary_rows.append(row_summary)

    if not summary_rows:
        print("WARNING: No scenario summary rows to write.")
        return

    fieldnames = list(summary_rows[0].keys())
    fpath = out_dir / "scenario_summary.csv"
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"Saved: {fpath} ({len(summary_rows)} rows)")


def write_parameters_used(out_dir: Path):
    """Write parameters_used.csv."""
    param_rows = []
    params = MODEL_PROFILE["parameters"]
    for name, meta in params.items():
        param_rows.append({
            "name": name,
            "value": meta["value"],
            "unit": meta["unit"],
            "source": meta["source"],
            "description": meta["description"],
        })

    if not param_rows:
        print("WARNING: No parameter rows to write.")
        return

    fpath = out_dir / "parameters_used.csv"
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        writer.writerows(param_rows)
    print(f"Saved: {fpath} ({len(param_rows)} rows)")


# ---------------------------------------------------------------------------
# FIGURE GENERATION
# ---------------------------------------------------------------------------

SCENARIO_COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
    "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
]


def fig1_roth_balance_all_scenarios(all_data: dict, out_dir: Path):
    """Fig1: Roth IRA balance growth over career, all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))
        for idx, (label, rows) in enumerate(all_data.items()):
            if not rows:
                continue
            ages = np.array([r["age"] for r in rows], dtype=float)
            balances = np.array([r["roth_balance"] for r in rows], dtype=float)
            assert len(ages) == len(balances), f"Shape mismatch for {label}"
            color = SCENARIO_COLORS[idx % len(SCENARIO_COLORS)]
            ax.plot(ages, balances / 1e6, label=label.replace("_", " "), color=color, linewidth=1.8)

        ax.set_xlabel("Age (years)", fontsize=12)
        ax.set_ylabel("Roth IRA Balance (Millions USD)", fontsize=12)
        ax.set_title("Roth IRA Balance Growth Over Career (Multiple Scenarios)", fontsize=13)
        ax.legend(fontsize=8, loc="upper left")
        ax.grid(True, alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:.1f}M"))
        plt.tight_layout()
        fpath = out_dir / "fig1_roth_balance_all_scenarios.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig1 failed: {e}")
        plt.close()


def fig2_after_tax_comparison(all_data: dict, out_dir: Path):
    """Fig2: After-tax value Roth vs Traditional for tax-rate comparison scenarios."""
    try:
        tax_scenarios = [
            "roth_vs_traditional_same_tax_rate",
            "roth_advantage_rising_tax",
            "traditional_advantage_falling_tax",
        ]
        fig, axes = plt.subplots(1, 3, figsize=(15, 5), sharey=False)

        for col, label in enumerate(tax_scenarios):
            ax = axes[col]
            if label not in all_data or not all_data[label]:
                ax.set_title(f"{label}\n(no data)")
                continue
            rows = all_data[label]
            ages = np.array([r["age"] for r in rows], dtype=float)
            roth_atv = np.array([r["roth_after_tax_value"] for r in rows], dtype=float)
            trad_atv = np.array([r["traditional_after_tax_value"] for r in rows], dtype=float)
            assert len(ages) == len(roth_atv) == len(trad_atv)
            ax.plot(ages, roth_atv / 1e6, label="Roth (tax-free)", color="#2ca02c", linewidth=2)
            ax.plot(ages, trad_atv / 1e6, label="Traditional (after tax)", color="#d62728",
                    linewidth=2, linestyle="--")
            ax.fill_between(ages, roth_atv / 1e6, trad_atv / 1e6, alpha=0.15,
                            color="#2ca02c" if np.mean(roth_atv) >= np.mean(trad_atv) else "#d62728")
            ax.set_xlabel("Age (years)", fontsize=10)
            ax.set_ylabel("After-Tax Value (Millions USD)", fontsize=9)
            title_map = {
                "roth_vs_traditional_same_tax_rate": "Same Tax Rate\n(22% → 22%)",
                "roth_advantage_rising_tax": "Rising Tax Rate\n(22% → 32%)",
                "traditional_advantage_falling_tax": "Falling Tax Rate\n(32% → 12%)",
            }
            ax.set_title(title_map.get(label, label), fontsize=11)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:.1f}M"))

        fig.suptitle("After-Tax Withdrawal Value: Roth vs. Traditional IRA Across Tax-Rate Scenarios",
                     fontsize=13, y=1.02)
        plt.tight_layout()
        fpath = out_dir / "fig2_after_tax_comparison.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig2 failed: {e}")
        plt.close()


def fig3_contribution_limits(out_dir: Path):
    """Fig3: IRS contribution limits over time 1998-2030."""
    try:
        years = np.arange(1998, 2031, dtype=int)
        under50 = np.zeros(len(years))
        over50 = np.zeros(len(years))
        for i, yr in enumerate(years):
            u, o = get_irs_limit(int(yr), future_growth_rate=0.02)
            under50[i] = u
            over50[i] = o

        assert len(years) == len(under50) == len(over50)

        fig, ax = plt.subplots(figsize=(12, 5))
        ax.step(years, under50, where="post", color="#1f77b4", linewidth=2.5,
                label="Under 50 (standard limit)")
        ax.step(years, over50, where="post", color="#ff7f0e", linewidth=2.5,
                linestyle="--", label="Age 50+ (with catch-up)")
        ax.fill_between(years, under50, over50, step="post", alpha=0.15, color="#ff7f0e")
        ax.set_xlabel("Year", fontsize=12)
        ax.set_ylabel("Annual Contribution Limit (USD)", fontsize=12)
        ax.set_title("IRS Roth IRA Annual Contribution Limits Over Time (1998–2030)", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:,.0f}"))
        ax.axvline(2026, color="gray", linestyle=":", alpha=0.5, label="Projected (post-2026)")
        ax.text(2026.1, under50.min() + 200, "Projected →", fontsize=9, color="gray")
        plt.tight_layout()
        fpath = out_dir / "fig3_contribution_limits.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig3 failed: {e}")
        plt.close()


def fig4_phaseout_magi(out_dir: Path):
    """Fig4: Roth contribution phase-out as function of MAGI (2021)."""
    try:
        magi_vals = np.linspace(100000.0, 220000.0, 500)
        year = 2021
        irs_limit_single = 6000.0  # 2021 standard
        irs_limit_joint = 6000.0

        contrib_single = np.zeros(len(magi_vals))
        contrib_joint = np.zeros(len(magi_vals))

        for i, m in enumerate(magi_vals):
            pof_s = compute_phaseout_fraction(m, year, irs_limit_single, "single")
            pof_j = compute_phaseout_fraction(m, year, irs_limit_joint, "joint")
            contrib_single[i] = irs_limit_single * pof_s
            contrib_joint[i] = irs_limit_joint * pof_j

        assert len(magi_vals) == len(contrib_single) == len(contrib_joint)

        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(magi_vals / 1000, contrib_single, color="#1f77b4", linewidth=2,
                label="Single Filer ($125k–$140k phase-out)")
        ax.plot(magi_vals / 1000, contrib_joint, color="#ff7f0e", linewidth=2,
                linestyle="--", label="Joint Filer ($198k–$208k phase-out)")
        ax.axhline(200, color="gray", linestyle=":", alpha=0.7, label="$200 minimum floor")
        ax.set_xlabel("MAGI (Thousands USD)", fontsize=12)
        ax.set_ylabel("Allowable Roth IRA Contribution (USD)", fontsize=12)
        ax.set_title("Roth IRA Contribution Phase-Out as Function of MAGI\n(Single and Joint Filers, 2021)",
                     fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:,.0f}"))
        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:.0f}k"))
        plt.tight_layout()
        fpath = out_dir / "fig4_phaseout_magi.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig4 failed: {e}")
        plt.close()


def fig5_gross_balance_baseline(all_data: dict, out_dir: Path):
    """Fig5: Gross balance Roth vs Traditional for baseline scenario."""
    try:
        label = "baseline_moderate_income"
        if label not in all_data or not all_data[label]:
            print(f"WARNING fig5: No data for {label}")
            return
        rows = all_data[label]
        ages = np.array([r["age"] for r in rows], dtype=float)
        roth_bal = np.array([r["roth_balance"] for r in rows], dtype=float)
        trad_bal = np.array([r["traditional_balance"] for r in rows], dtype=float)
        trad_tax_liability = np.array([r["withdrawal_tax_rate_retirement"] * r["traditional_balance"]
                                        for r in rows], dtype=float)
        assert len(ages) == len(roth_bal) == len(trad_bal) == len(trad_tax_liability)

        fig, ax = plt.subplots(figsize=(11, 6))
        ax.plot(ages, roth_bal / 1e6, color="#2ca02c", linewidth=2.5,
                label="Roth IRA Balance (after-tax dollars)")
        ax.plot(ages, trad_bal / 1e6, color="#1f77b4", linewidth=2.5,
                linestyle="--", label="Traditional IRA Balance (pre-tax dollars)")
        # Shaded tax liability embedded in Traditional
        ax.fill_between(ages, (trad_bal - trad_tax_liability) / 1e6, trad_bal / 1e6,
                        alpha=0.25, color="#d62728",
                        label=f"Tax liability embedded in Traditional\n(at {rows[-1]['withdrawal_tax_rate_retirement']*100:.0f}% retirement rate)")
        ax.set_xlabel("Age (years)", fontsize=12)
        ax.set_ylabel("Account Balance (Millions USD)", fontsize=12)
        ax.set_title("Gross Balance Accumulation: Roth vs. Traditional IRA (Baseline Scenario)", fontsize=13)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:.1f}M"))
        plt.tight_layout()
        fpath = out_dir / "fig5_gross_balance_baseline.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig5 failed: {e}")
        plt.close()


def fig6_roth_advantage_scatter(out_dir: Path):
    """Fig6: Roth net advantage at retirement vs retirement tax rate (sweep)."""
    try:
        ret_rates = np.linspace(0.10, 0.37, 30)
        working_rate = 0.22
        adv_vals = np.zeros(len(ret_rates))

        for i, ret_rate in enumerate(ret_rates):
            # Simulate baseline to retirement with this ret_rate
            scenario_tmp = {
                "label": f"sweep_{i}",
                "param_overrides": {
                    "start_age": 30.0,
                    "magi_init": 80000.0,
                    "contribution_tax_rate_working": working_rate,
                    "withdrawal_tax_rate_retirement": ret_rate,
                    "annual_return_rate": 0.07,
                }
            }
            rows = run_scenario(scenario_tmp, 999 + i)
            # Find retirement year row (age == 65)
            ret_rows = [r for r in rows if r["age"] == 65.0]
            if ret_rows:
                adv_vals[i] = ret_rows[0]["roth_advantage_usd"]
            else:
                # Use last row before retirement
                working_rows = [r for r in rows if r["age"] < 65.0]
                if working_rows:
                    adv_vals[i] = working_rows[-1]["roth_advantage_usd"]

        assert len(ret_rates) == len(adv_vals)

        fig, ax = plt.subplots(figsize=(10, 6))
        sc = ax.scatter(ret_rates * 100, adv_vals / 1e3,
                        c=ret_rates, cmap="RdYlGn_r", s=80, zorder=5)
        ax.axhline(0, color="black", linewidth=1.5, linestyle="--", alpha=0.7, label="Break-even")
        ax.axvline(working_rate * 100, color="blue", linewidth=1.5, linestyle=":",
                   alpha=0.7, label=f"Working rate ({working_rate*100:.0f}%)")
        cb = plt.colorbar(sc, ax=ax)
        cb.set_label("Retirement Tax Rate", fontsize=10)
        ax.set_xlabel("Retirement Marginal Tax Rate (%)", fontsize=12)
        ax.set_ylabel("Roth Advantage over Traditional (Thousands USD)", fontsize=12)
        ax.set_title("Roth IRA Net Advantage at Retirement vs. Retirement Tax Rate\n"
                     f"(Working tax rate fixed at {working_rate*100:.0f}%)", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:.0f}k"))
        plt.tight_layout()
        fpath = out_dir / "fig6_roth_advantage_scatter.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig6 failed: {e}")
        plt.close()


def fig7_return_rate_comparison(all_data: dict, out_dir: Path):
    """Fig7: Roth balance for 4%, 7%, 10% return scenarios."""
    try:
        scenario_labels = {
            "conservative_growth_portfolio": "4% Annual Return",
            "baseline_moderate_income": "7% Annual Return",
            "aggressive_growth_portfolio": "10% Annual Return",
        }
        colors = ["#1f77b4", "#ff7f0e", "#d62728"]
        fig, ax = plt.subplots(figsize=(11, 6))

        for idx, (label, desc) in enumerate(scenario_labels.items()):
            if label not in all_data or not all_data[label]:
                continue
            rows = all_data[label]
            ages = np.array([r["age"] for r in rows], dtype=float)
            balances = np.array([r["roth_balance"] for r in rows], dtype=float)
            assert len(ages) == len(balances)
            ax.plot(ages, balances / 1e6, label=desc, color=colors[idx], linewidth=2.5)

        ax.set_xlabel("Age (years)", fontsize=12)
        ax.set_ylabel("Roth IRA Balance (Millions USD)", fontsize=12)
        ax.set_title("Impact of Annual Return Rate on Roth IRA Balance (4%, 7%, 10%)", fontsize=13)
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:.1f}M"))
        plt.tight_layout()
        fpath = out_dir / "fig7_return_rate_comparison.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig7 failed: {e}")
        plt.close()


def fig8_contributions_vs_balance(all_data: dict, out_dir: Path):
    """Fig8: Cumulative contributions vs total balance (growth attribution)."""
    try:
        label = "baseline_moderate_income"
        if label not in all_data or not all_data[label]:
            print(f"WARNING fig8: No data for {label}")
            return
        rows = all_data[label]
        ages = np.array([r["age"] for r in rows], dtype=float)
        contrib_cum = np.array([r["roth_contributions_cumulative"] for r in rows], dtype=float)
        balances = np.array([r["roth_balance"] for r in rows], dtype=float)
        assert len(ages) == len(contrib_cum) == len(balances)

        # Find crossover: where earnings (balance - contrib) first exceed contrib_cum
        earnings = balances - contrib_cum
        crossover_age = None
        for i in range(len(ages)):
            if earnings[i] >= contrib_cum[i] and contrib_cum[i] > 0:
                crossover_age = ages[i]
                break

        fig, ax = plt.subplots(figsize=(11, 6))
        ax.plot(ages, balances / 1e6, color="#1f77b4", linewidth=2.5, label="Total Roth Balance")
        ax.plot(ages, contrib_cum / 1e6, color="#2ca02c", linewidth=2.5,
                linestyle="--", label="Cumulative Contributions (Principal)")
        ax.fill_between(ages, contrib_cum / 1e6, balances / 1e6,
                        alpha=0.2, color="#ff7f0e", label="Tax-Free Earnings (Balance − Principal)")

        if crossover_age is not None:
            ax.axvline(crossover_age, color="purple", linestyle=":", linewidth=1.5, alpha=0.8)
            ax.annotate(f"Earnings > Principal\nat age {crossover_age:.0f}",
                        xy=(crossover_age, balances[np.where(ages == crossover_age)[0][0]] / 1e6),
                        xytext=(crossover_age + 2, balances[np.where(ages == crossover_age)[0][0]] / 1e6 + 0.05),
                        fontsize=9, color="purple",
                        arrowprops=dict(arrowstyle="->", color="purple"))

        ax.set_xlabel("Age (years)", fontsize=12)
        ax.set_ylabel("Amount (Millions USD)", fontsize=12)
        ax.set_title("Cumulative Contributions vs. Total Balance: Roth IRA Growth Attribution\n(Baseline Scenario)",
                     fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:.2f}M"))
        plt.tight_layout()
        fpath = out_dir / "fig8_contributions_vs_balance.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved: {fpath}")
    except Exception as e:
        print(f"WARNING fig8 failed: {e}")
        plt.close()


# ---------------------------------------------------------------------------
# SUMMARY JSON
# ---------------------------------------------------------------------------

def write_summary_json(all_data: dict, out_dir: Path):
    """Write summary.json with key aggregate metrics."""
    summary = {}
    for label, rows in all_data.items():
        if not rows:
            continue
        last_row = rows[-1]
        ret_rows = [r for r in rows if r["age"] >= 65.0]
        ret_row = ret_rows[0] if ret_rows else last_row
        summary[label] = {
            "roth_balance_at_retirement": ret_row["roth_balance"],
            "traditional_balance_at_retirement": ret_row["traditional_balance"],
            "roth_after_tax_at_retirement": ret_row["roth_after_tax_value"],
            "traditional_after_tax_at_retirement": ret_row["traditional_after_tax_value"],
            "roth_advantage_at_retirement_usd": ret_row["roth_advantage_usd"],
            "roth_balance_final": last_row["roth_balance"],
            "traditional_balance_final": last_row["traditional_balance"],
            "roth_contributions_total": last_row["roth_contributions_cumulative"],
            "roth_earnings_total": last_row["roth_earnings_cumulative"],
            "annual_return_rate": last_row["annual_return_rate"],
            "withdrawal_tax_rate_retirement": last_row["withdrawal_tax_rate_retirement"],
            "contribution_tax_rate_working": last_row["contribution_tax_rate_working"],
        }

    fpath = out_dir / "summary.json"
    with open(fpath, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"Saved: {fpath}")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Roth IRA Dynamical System Simulator")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all generated files")
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 60)
    print("Roth IRA Simulator — Running All Scenarios")
    print("=" * 60)

    # Run all scenarios
    all_data = run_all_scenarios()

    # Write CSVs
    print("\n--- Writing CSV Files ---")
    write_simulation_outputs(all_data, out_dir)
    write_scenario_summary(all_data, out_dir)
    write_parameters_used(out_dir)

    # Write summary JSON
    print("\n--- Writing Summary JSON ---")
    write_summary_json(all_data, out_dir)

    # Generate all figures
    print("\n--- Generating Figures ---")
    fig1_roth_balance_all_scenarios(all_data, out_dir)
    fig2_after_tax_comparison(all_data, out_dir)
    fig3_contribution_limits(out_dir)
    fig4_phaseout_magi(out_dir)
    fig5_gross_balance_baseline(all_data, out_dir)
    fig6_roth_advantage_scatter(out_dir)
    fig7_return_rate_comparison(all_data, out_dir)
    fig8_contributions_vs_balance(all_data, out_dir)

    print("\n" + "=" * 60)
    print(f"Simulation complete. All outputs saved to: {out_dir.resolve()}")
    print("=" * 60)


if __name__ == "__main__":
    main()