# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-20T13:18:23.245539Z
# Run ID    : da76fa48-c3d1-4306-9c0b-546441a4e520
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Davis Square Intersection Navigation Sign — Davis Square, Somerville MA

Simulator for the complex five-arm uncontrolled intersection at Davis Square,
Somerville, Massachusetts. Models vehicle arrivals, intersection service,
pedestrian impedance, conflict event generation, and exit routing across five
operational scenarios using a stochastic queueing framework.

Reference: Davis Square directional navigation sign showing Elm St, Day St,
Dover St, Holland St, and Highland Ave with two one-way exit restrictions.
"""

import argparse
import csv
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Any

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ---------------------------------------------------------------------------
# MODEL PROFILE
# ---------------------------------------------------------------------------
MODEL_PROFILE = {
    "title": "Davis Square Intersection Navigation Sign — Davis Square, Somerville MA",
    "parameters": {
        "num_arms": {"value": 5.0, "unit": "dimensionless", "source": "extracted",
                     "description": "Number of street arms meeting at the Davis Square intersection"},
        "num_oneway_exits": {"value": 2.0, "unit": "dimensionless", "source": "extracted",
                             "description": "Number of arms that are one-way outbound only (Day St and Highland Ave)"},
        "num_bidirectional_arms": {"value": 3.0, "unit": "dimensionless", "source": "extracted",
                                   "description": "Number of arms that allow two-way traffic: Elm St, Dover St, Holland St"},
        "arrival_rate_elm": {"value": 8.0, "unit": "vehicles/min", "source": "assumed",
                             "description": "Mean vehicle arrival rate from Elm St under baseline conditions"},
        "arrival_rate_dover": {"value": 6.0, "unit": "vehicles/min", "source": "assumed",
                               "description": "Mean vehicle arrival rate from Dover St under baseline conditions"},
        "arrival_rate_holland": {"value": 7.0, "unit": "vehicles/min", "source": "assumed",
                                 "description": "Mean vehicle arrival rate from Holland St under baseline conditions"},
        "arrival_rate_day_pedestrian": {"value": 0.0, "unit": "vehicles/min", "source": "extracted",
                                        "description": "No vehicle arrivals on Day St (one-way exit only)"},
        "arrival_rate_highland_pedestrian": {"value": 0.0, "unit": "vehicles/min", "source": "extracted",
                                             "description": "No vehicle arrivals on Highland Ave (one-way exit only)"},
        "service_rate_intersection": {"value": 12.0, "unit": "vehicles/min", "source": "assumed",
                                      "description": "Maximum throughput rate of the uncontrolled multi-way intersection"},
        "pedestrian_arrival_rate": {"value": 15.0, "unit": "pedestrians/min", "source": "assumed",
                                    "description": "Mean pedestrian arrival rate across all crosswalks"},
        "pedestrian_crossing_time": {"value": 12.0, "unit": "seconds", "source": "assumed",
                                     "description": "Average time for a pedestrian to complete a crossing"},
        "vehicle_conflict_probability": {"value": 0.08, "unit": "probability/event", "source": "assumed",
                                         "description": "Probability that any vehicle entry results in a conflict event"},
        "time_step": {"value": 1.0, "unit": "seconds", "source": "assumed",
                      "description": "Simulation time resolution"},
        "sim_duration": {"value": 3600.0, "unit": "seconds", "source": "assumed",
                         "description": "Total simulation duration (1 hour)"},
        "peak_hour_multiplier": {"value": 1.8, "unit": "dimensionless", "source": "assumed",
                                 "description": "Scaling factor applied to arrival rates during peak hour"},
        "routing_weight_day": {"value": 0.20, "unit": "dimensionless", "source": "assumed",
                               "description": "Fraction of exiting vehicles routed to Day St"},
        "routing_weight_highland": {"value": 0.15, "unit": "dimensionless", "source": "assumed",
                                    "description": "Fraction of exiting vehicles routed to Highland Ave"},
        "routing_weight_elm_out": {"value": 0.25, "unit": "dimensionless", "source": "assumed",
                                   "description": "Fraction of exiting vehicles routed outbound on Elm St"},
        "routing_weight_dover_out": {"value": 0.20, "unit": "dimensionless", "source": "assumed",
                                     "description": "Fraction of exiting vehicles routed outbound on Dover St"},
        "routing_weight_holland_out": {"value": 0.20, "unit": "dimensionless", "source": "assumed",
                                       "description": "Fraction of exiting vehicles routed outbound on Holland St"},
        "mean_vehicle_speed": {"value": 15.0, "unit": "km/h", "source": "assumed",
                               "description": "Average vehicle speed within the intersection zone"},
        "intersection_capacity": {"value": 6.0, "unit": "vehicles", "source": "assumed",
                                  "description": "Maximum simultaneous vehicles inside intersection core"},
        "random_seed": {"value": 42.0, "unit": "dimensionless", "source": "assumed",
                        "description": "Random seed for reproducibility"},
    },
    "scenarios": [
        {
            "label": "baseline_offpeak",
            "description": "Normal off-peak traffic with standard arrival rates",
            "param_overrides": {
                "peak_hour_multiplier": 1.0,
                "arrival_rate_elm": 8.0,
                "arrival_rate_dover": 6.0,
                "arrival_rate_holland": 7.0,
                "pedestrian_arrival_rate": 15.0,
            }
        },
        {
            "label": "morning_peak_hour",
            "description": "Morning rush hour with elevated arrival rates",
            "param_overrides": {
                "peak_hour_multiplier": 1.8,
                "arrival_rate_elm": 14.4,
                "arrival_rate_dover": 10.8,
                "arrival_rate_holland": 12.6,
                "pedestrian_arrival_rate": 27.0,
            }
        },
        {
            "label": "oneway_restriction_removed",
            "description": "Day St and Highland Ave converted to two-way streets",
            "param_overrides": {
                "num_oneway_exits": 0.0,
                "arrival_rate_day_pedestrian": 5.0,
                "arrival_rate_highland_pedestrian": 4.0,
                "peak_hour_multiplier": 1.0,
            }
        },
        {
            "label": "high_pedestrian_pressure",
            "description": "Event-day with very high pedestrian volumes",
            "param_overrides": {
                "pedestrian_arrival_rate": 60.0,
                "pedestrian_crossing_time": 18.0,
                "peak_hour_multiplier": 1.4,
            }
        },
        {
            "label": "reduced_conflict_signage",
            "description": "Stop signs/yield markings reducing conflict probability",
            "param_overrides": {
                "vehicle_conflict_probability": 0.02,
                "service_rate_intersection": 15.0,
                "peak_hour_multiplier": 1.0,
            }
        },
    ]
}

# ---------------------------------------------------------------------------
# SIMULATION
# ---------------------------------------------------------------------------

def get_default_params() -> Dict[str, float]:
    """Extract default parameter values from MODEL_PROFILE."""
    return {name: info["value"] for name, info in MODEL_PROFILE["parameters"].items()}


def run_scenario(scenario_label: str, param_overrides: Dict[str, float],
                 scenario_index: int) -> List[Dict[str, Any]]:
    """Run one scenario and return list of per-timestep record dicts."""

    np.random.seed(scenario_index)

    # Build parameter set
    params = get_default_params()
    for k, v in param_overrides.items():
        params[k] = v

    # Unpack parameters
    arrival_rate_elm = float(params["arrival_rate_elm"])
    arrival_rate_dover = float(params["arrival_rate_dover"])
    arrival_rate_holland = float(params["arrival_rate_holland"])
    arrival_rate_day = float(params.get("arrival_rate_day_pedestrian", 0.0))
    arrival_rate_highland = float(params.get("arrival_rate_highland_pedestrian", 0.0))
    pedestrian_arrival_rate = float(params["pedestrian_arrival_rate"])
    pedestrian_crossing_time = max(1.0, float(params["pedestrian_crossing_time"]))
    service_rate_intersection = float(params["service_rate_intersection"])
    vehicle_conflict_probability = float(params["vehicle_conflict_probability"])
    peak_hour_multiplier = float(params["peak_hour_multiplier"])
    intersection_capacity = float(params["intersection_capacity"])
    sim_duration = float(params["sim_duration"])
    delta_t = float(params["time_step"])
    routing_weight_day = float(params["routing_weight_day"])
    routing_weight_highland = float(params["routing_weight_highland"])
    routing_weight_elm_out = float(params["routing_weight_elm_out"])
    routing_weight_dover_out = float(params["routing_weight_dover_out"])
    routing_weight_holland_out = float(params["routing_weight_holland_out"])

    # State initialization
    queue_elm = 2.0
    queue_dover = 2.0
    queue_holland = 3.0
    queue_day = 0.0
    queue_highland = 0.0
    intersection_occupancy = 1.0
    pedestrian_count = 4.0
    vehicle_count_elm = 5.0
    vehicle_count_day = 3.0
    vehicle_count_dover = 4.0
    vehicle_count_holland = 6.0
    vehicle_count_highland = 4.0
    conflict_events_cumulative = 0
    conflict_events_this_interval = 0
    vehicles_exited_elm = 0
    vehicles_exited_day = 0
    vehicles_exited_dover = 0
    vehicles_exited_holland = 0
    vehicles_exited_highland = 0
    avg_delay = 0.0
    throughput = 0.0

    records = []
    n_steps = int(sim_duration / delta_t)

    for step in range(n_steps):
        t = step * delta_t

        # Reset interval counter at start of each 300-second window
        if step % 300 == 0:
            conflict_events_this_interval = 0

        # --- ARRIVALS ---
        for arm in ['elm', 'dover', 'holland']:
            if arm == 'elm':
                rate = arrival_rate_elm * peak_hour_multiplier
            elif arm == 'dover':
                rate = arrival_rate_dover * peak_hour_multiplier
            else:
                rate = arrival_rate_holland * peak_hour_multiplier
            lam = rate / 60.0 * delta_t
            new_arr = np.random.poisson(max(0.0, lam))
            if arm == 'elm':
                queue_elm += new_arr
                vehicle_count_elm += new_arr
            elif arm == 'dover':
                queue_dover += new_arr
                vehicle_count_dover += new_arr
            else:
                queue_holland += new_arr
                vehicle_count_holland += new_arr

        # Additional arrivals from converted one-way streets
        if arrival_rate_day > 0:
            lam_day = arrival_rate_day / 60.0 * delta_t
            new_day = np.random.poisson(max(0.0, lam_day))
            queue_day += new_day
            vehicle_count_day += new_day

        if arrival_rate_highland > 0:
            lam_hl = arrival_rate_highland / 60.0 * delta_t
            new_hl = np.random.poisson(max(0.0, lam_hl))
            queue_highland += new_hl
            vehicle_count_highland += new_hl

        # --- PEDESTRIAN DYNAMICS ---
        ped_lam = pedestrian_arrival_rate / 60.0 * delta_t
        new_peds = np.random.poisson(max(0.0, ped_lam))
        pedestrian_count += new_peds
        peds_done = pedestrian_count * (delta_t / pedestrian_crossing_time)
        pedestrian_count = max(0.0, pedestrian_count - peds_done)
        pedestrian_count = min(40.0, pedestrian_count)
        ped_impedance = min(1.0, pedestrian_count / 20.0)

        # --- INTERSECTION SERVICE ---
        effective_service_rate = service_rate_intersection * (1.0 - ped_impedance) / 60.0

        total_queue = queue_elm + queue_dover + queue_holland + queue_day + queue_highland
        total_queue = max(0.0, total_queue)

        if intersection_occupancy < intersection_capacity and total_queue > 0:
            arms_service = [
                ('elm', queue_elm),
                ('dover', queue_dover),
                ('holland', queue_holland),
                ('day', queue_day),
                ('highland', queue_highland),
            ]
            for arm_name, q in arms_service:
                if q > 0:
                    share = q / max(total_queue, 1.0)
                    lam_serve = effective_service_rate * share * delta_t
                    served = int(min(q, np.random.poisson(max(0.0, lam_serve))))
                    served = max(0, served)
                    if arm_name == 'elm':
                        queue_elm = max(0.0, queue_elm - served)
                        vehicle_count_elm = max(0.0, vehicle_count_elm - served)
                    elif arm_name == 'dover':
                        queue_dover = max(0.0, queue_dover - served)
                        vehicle_count_dover = max(0.0, vehicle_count_dover - served)
                    elif arm_name == 'holland':
                        queue_holland = max(0.0, queue_holland - served)
                        vehicle_count_holland = max(0.0, vehicle_count_holland - served)
                    elif arm_name == 'day':
                        queue_day = max(0.0, queue_day - served)
                        vehicle_count_day = max(0.0, vehicle_count_day - served)
                    elif arm_name == 'highland':
                        queue_highland = max(0.0, queue_highland - served)
                        vehicle_count_highland = max(0.0, vehicle_count_highland - served)
                    intersection_occupancy += served
                    intersection_occupancy = min(intersection_capacity, intersection_occupancy)

        # --- CONFLICT EVENTS ---
        vehicles_entering = max(0, int(intersection_occupancy) - 1)
        for _ in range(vehicles_entering):
            if np.random.random() < vehicle_conflict_probability:
                conflict_events_cumulative += 1
                conflict_events_this_interval += 1

        # --- EXIT ROUTING ---
        lam_exit = effective_service_rate * delta_t
        vehicles_to_exit = int(min(intersection_occupancy,
                                   np.random.poisson(max(0.0, lam_exit))))
        vehicles_to_exit = max(0, vehicles_to_exit)

        exit_map = {
            'day': routing_weight_day,
            'highland': routing_weight_highland,
            'elm': routing_weight_elm_out,
            'dover': routing_weight_dover_out,
            'holland': routing_weight_holland_out,
        }
        for arm_name, weight in exit_map.items():
            exiting = int(vehicles_to_exit * weight)
            exiting = max(0, exiting)
            if arm_name == 'day':
                vehicles_exited_day += exiting
                vehicle_count_day = min(30.0, vehicle_count_day + exiting)
            elif arm_name == 'highland':
                vehicles_exited_highland += exiting
                vehicle_count_highland = min(30.0, vehicle_count_highland + exiting)
            elif arm_name == 'elm':
                vehicles_exited_elm += exiting
                vehicle_count_elm = min(50.0, vehicle_count_elm + exiting)
            elif arm_name == 'dover':
                vehicles_exited_dover += exiting
                vehicle_count_dover = min(50.0, vehicle_count_dover + exiting)
            elif arm_name == 'holland':
                vehicles_exited_holland += exiting
                vehicle_count_holland = min(50.0, vehicle_count_holland + exiting)

        intersection_occupancy = max(0.0, intersection_occupancy - vehicles_to_exit)

        # --- THROUGHPUT and DELAY ---
        throughput = vehicles_to_exit * 60.0 / delta_t
        throughput = float(np.clip(throughput, 0.0, 30.0))

        free_flow_time = 10.0
        congestion_factor = 1.0 + (total_queue / max(float(intersection_capacity), 1.0))
        actual_transit_time = free_flow_time * congestion_factor
        avg_delay = actual_transit_time - free_flow_time
        avg_delay = float(np.clip(avg_delay, 0.0, 120.0))

        # Clamp state variables to defined ranges
        queue_elm = float(np.clip(queue_elm, 0, 20))
        queue_dover = float(np.clip(queue_dover, 0, 20))
        queue_holland = float(np.clip(queue_holland, 0, 20))
        queue_day = float(np.clip(queue_day, 0, 20))
        queue_highland = float(np.clip(queue_highland, 0, 20))
        intersection_occupancy = float(np.clip(intersection_occupancy, 0, 8))
        pedestrian_count = float(np.clip(pedestrian_count, 0, 40))
        vehicle_count_elm = float(np.clip(vehicle_count_elm, 0, 50))
        vehicle_count_day = float(np.clip(vehicle_count_day, 0, 30))
        vehicle_count_dover = float(np.clip(vehicle_count_dover, 0, 50))
        vehicle_count_holland = float(np.clip(vehicle_count_holland, 0, 50))
        vehicle_count_highland = float(np.clip(vehicle_count_highland, 0, 30))

        total_arrival_rate = (arrival_rate_elm + arrival_rate_dover + arrival_rate_holland +
                              arrival_rate_day + arrival_rate_highland) * peak_hour_multiplier

        records.append({
            "time_seconds": float(t),
            "scenario": scenario_label,
            "queue_length_elm": queue_elm,
            "queue_length_dover": queue_dover,
            "queue_length_holland": queue_holland,
            "queue_length_day": queue_day,
            "queue_length_highland": queue_highland,
            "intersection_occupancy": intersection_occupancy,
            "pedestrian_count": pedestrian_count,
            "vehicle_count_elm": vehicle_count_elm,
            "vehicle_count_day": vehicle_count_day,
            "vehicle_count_dover": vehicle_count_dover,
            "vehicle_count_holland": vehicle_count_holland,
            "vehicle_count_highland": vehicle_count_highland,
            "throughput_vehicles_per_min": throughput,
            "avg_delay_seconds": avg_delay,
            "conflict_events_cumulative": float(conflict_events_cumulative),
            "conflict_events_this_interval": float(conflict_events_this_interval),
            "total_arrival_rate": total_arrival_rate,
            "arrival_rate_elm": arrival_rate_elm,
            "arrival_rate_dover": arrival_rate_dover,
            "arrival_rate_holland": arrival_rate_holland,
            "routing_weight_day": routing_weight_day,
            "routing_weight_highland": routing_weight_highland,
            "routing_weight_elm_out": routing_weight_elm_out,
            "routing_weight_dover_out": routing_weight_dover_out,
            "routing_weight_holland_out": routing_weight_holland_out,
            "vehicles_exited_elm": float(vehicles_exited_elm),
            "vehicles_exited_day": float(vehicles_exited_day),
            "vehicles_exited_dover": float(vehicles_exited_dover),
            "vehicles_exited_holland": float(vehicles_exited_holland),
            "vehicles_exited_highland": float(vehicles_exited_highland),
        })

    return records


# ---------------------------------------------------------------------------
# CSV WRITING
# ---------------------------------------------------------------------------

DATASET_SCHEMA = [
    "time_seconds", "scenario", "queue_length_elm", "queue_length_dover",
    "queue_length_holland", "queue_length_day", "queue_length_highland",
    "intersection_occupancy", "pedestrian_count", "vehicle_count_elm",
    "vehicle_count_day", "vehicle_count_dover", "vehicle_count_holland",
    "vehicle_count_highland", "throughput_vehicles_per_min", "avg_delay_seconds",
    "conflict_events_cumulative", "conflict_events_this_interval",
    "total_arrival_rate", "arrival_rate_elm", "arrival_rate_dover",
    "arrival_rate_holland", "routing_weight_day", "routing_weight_highland",
    "routing_weight_elm_out", "routing_weight_dover_out", "routing_weight_holland_out",
    "vehicles_exited_elm", "vehicles_exited_day", "vehicles_exited_dover",
    "vehicles_exited_holland", "vehicles_exited_highland"
]


def write_simulation_outputs(all_records: List[Dict[str, Any]], out_dir: Path) -> None:
    """Write simulation_outputs.csv with all scenario records."""
    if not all_records:
        print("WARNING: No records to write for simulation_outputs.csv")
        return
    filepath = out_dir / "simulation_outputs.csv"
    try:
        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA)
            writer.writeheader()
            writer.writerows(all_records)
        print(f"Wrote {len(all_records)} rows to {filepath}")
    except Exception as e:
        print(f"WARNING: Could not write simulation_outputs.csv: {e}")


def write_scenario_summary(all_records: List[Dict[str, Any]], out_dir: Path) -> None:
    """Write scenario_summary.csv — one row per scenario."""
    if not all_records:
        print("WARNING: No records for scenario_summary.csv")
        return

    scenarios = {}
    for rec in all_records:
        sc = rec["scenario"]
        if sc not in scenarios:
            scenarios[sc] = []
        scenarios[sc].append(rec)

    state_vars = [
        "queue_length_elm", "queue_length_dover", "queue_length_holland",
        "intersection_occupancy", "pedestrian_count", "throughput_vehicles_per_min",
        "avg_delay_seconds", "conflict_events_cumulative", "total_arrival_rate"
    ]

    headers = ["scenario"]
    for sv in state_vars:
        for stat in ["mean", "std", "min", "max"]:
            headers.append(f"{sv}_{stat}")
    headers.append("total_conflict_events")
    headers.append("total_vehicles_exited")

    filepath = out_dir / "scenario_summary.csv"
    try:
        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            for sc_label, recs in scenarios.items():
                row = {"scenario": sc_label}
                for sv in state_vars:
                    vals = np.array([r[sv] for r in recs], dtype=float)
                    row[f"{sv}_mean"] = float(np.mean(vals))
                    row[f"{sv}_std"] = float(np.std(vals))
                    row[f"{sv}_min"] = float(np.min(vals))
                    row[f"{sv}_max"] = float(np.max(vals))
                row["total_conflict_events"] = float(recs[-1]["conflict_events_cumulative"])
                row["total_vehicles_exited"] = (
                    float(recs[-1]["vehicles_exited_elm"]) +
                    float(recs[-1]["vehicles_exited_day"]) +
                    float(recs[-1]["vehicles_exited_dover"]) +
                    float(recs[-1]["vehicles_exited_holland"]) +
                    float(recs[-1]["vehicles_exited_highland"])
                )
                writer.writerow(row)
        print(f"Wrote scenario_summary.csv to {filepath}")
    except Exception as e:
        print(f"WARNING: Could not write scenario_summary.csv: {e}")


def write_parameters_used(out_dir: Path) -> None:
    """Write parameters_used.csv."""
    filepath = out_dir / "parameters_used.csv"
    headers = ["name", "value", "unit", "source", "description"]
    try:
        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            for name, info in MODEL_PROFILE["parameters"].items():
                writer.writerow({
                    "name": name,
                    "value": info["value"],
                    "unit": info["unit"],
                    "source": info["source"],
                    "description": info["description"],
                })
        print(f"Wrote parameters_used.csv to {filepath}")
    except Exception as e:
        print(f"WARNING: Could not write parameters_used.csv: {e}")


# ---------------------------------------------------------------------------
# FIGURE GENERATION
# ---------------------------------------------------------------------------

SCENARIO_COLORS = {
    "baseline_offpeak": "#1f77b4",
    "morning_peak_hour": "#d62728",
    "oneway_restriction_removed": "#2ca02c",
    "high_pedestrian_pressure": "#ff7f0e",
    "reduced_conflict_signage": "#9467bd",
}

SCENARIO_LABELS = {
    "baseline_offpeak": "Baseline Off-Peak",
    "morning_peak_hour": "Morning Peak Hour",
    "oneway_restriction_removed": "One-Way Restriction Removed",
    "high_pedestrian_pressure": "High Pedestrian Pressure",
    "reduced_conflict_signage": "Reduced Conflict Signage",
}


def records_to_scenario_dict(all_records: List[Dict[str, Any]]) -> Dict[str, List[Dict]]:
    result = {}
    for rec in all_records:
        sc = rec["scenario"]
        if sc not in result:
            result[sc] = []
        result[sc].append(rec)
    return result


def fig1_queue_length_over_time(scenario_data: Dict[str, List[Dict]], out_dir: Path) -> None:
    """Fig1: Queue length per arm over time for all scenarios."""
    try:
        fig, axes = plt.subplots(3, 1, figsize=(12, 10), sharex=True)
        arms = ["queue_length_elm", "queue_length_dover", "queue_length_holland"]
        arm_labels = ["Elm St", "Dover St", "Holland St"]

        for ax, arm_col, arm_label in zip(axes, arms, arm_labels):
            for sc_label, recs in scenario_data.items():
                t_arr = np.array([r["time_seconds"] for r in recs])
                q_arr = np.array([r[arm_col] for r in recs])
                assert len(t_arr) == len(q_arr), f"Length mismatch for {sc_label}/{arm_col}"
                if len(t_arr) == 0 or len(q_arr) == 0:
                    print(f"WARNING: Empty arrays for {sc_label}/{arm_col}, skipping.")
                    continue
                ax.plot(t_arr, q_arr, label=SCENARIO_LABELS.get(sc_label, sc_label),
                        color=SCENARIO_COLORS.get(sc_label, 'gray'), alpha=0.8)
            ax.set_ylabel(f"Queue Length\n({arm_label}) [vehicles]")
            ax.set_ylim(0, 20)
            ax.grid(True, alpha=0.3)
            ax.legend(fontsize=7, loc='upper right')

        axes[-1].set_xlabel("Time [seconds]")
        axes[0].set_title("Queue Length per Incoming Arm Over Time by Scenario")
        plt.tight_layout()
        fp = out_dir / "fig1_queue_length_over_time.png"
        plt.savefig(fp, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {fp}")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")
        plt.close('all')


def fig2_throughput_over_time(scenario_data: Dict[str, List[Dict]], out_dir: Path) -> None:
    """Fig2: Intersection throughput over time for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(12, 5))
        for sc_label, recs in scenario_data.items():
            t_arr = np.array([r["time_seconds"] for r in recs])
            tp_arr = np.array([r["throughput_vehicles_per_min"] for r in recs])
            assert len(t_arr) == len(tp_arr)
            if len(t_arr) == 0:
                continue
            # Smooth with rolling mean over 60 steps
            window = 60
            if len(tp_arr) >= window:
                smoothed = np.convolve(tp_arr, np.ones(window)/window, mode='valid')
                t_smooth = t_arr[window-1:]
                assert len(t_smooth) == len(smoothed)
                ax.plot(t_smooth, smoothed,
                        label=SCENARIO_LABELS.get(sc_label, sc_label),
                        color=SCENARIO_COLORS.get(sc_label, 'gray'), alpha=0.9, linewidth=1.5)
            else:
                ax.plot(t_arr, tp_arr,
                        label=SCENARIO_LABELS.get(sc_label, sc_label),
                        color=SCENARIO_COLORS.get(sc_label, 'gray'), alpha=0.9, linewidth=1.5)

        ax.set_xlabel("Time [seconds]")
        ax.set_ylabel("Throughput [vehicles/min]")
        ax.set_title("Intersection Throughput Over Time — All Scenarios")
        ax.set_ylim(0, 30)
        ax.grid(True, alpha=0.3)
        ax.legend()
        plt.tight_layout()
        fp = out_dir / "fig2_throughput_over_time.png"
        plt.savefig(fp, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {fp}")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")
        plt.close('all')


def fig3_avg_delay_over_time(scenario_data: Dict[str, List[Dict]], out_dir: Path) -> None:
    """Fig3: Average vehicle delay over time for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(12, 5))
        for sc_label, recs in scenario_data.items():
            t_arr = np.array([r["time_seconds"] for r in recs])
            d_arr = np.array([r["avg_delay_seconds"] for r in recs])
            assert len(t_arr) == len(d_arr)
            if len(t_arr) == 0:
                continue
            window = 60
            if len(d_arr) >= window:
                smoothed = np.convolve(d_arr, np.ones(window)/window, mode='valid')
                t_smooth = t_arr[window-1:]
                assert len(t_smooth) == len(smoothed)
                ax.plot(t_smooth, smoothed,
                        label=SCENARIO_LABELS.get(sc_label, sc_label),
                        color=SCENARIO_COLORS.get(sc_label, 'gray'), alpha=0.9, linewidth=1.5)
            else:
                ax.plot(t_arr, d_arr,
                        label=SCENARIO_LABELS.get(sc_label, sc_label),
                        color=SCENARIO_COLORS.get(sc_label, 'gray'), alpha=0.9, linewidth=1.5)

        ax.set_xlabel("Time [seconds]")
        ax.set_ylabel("Average Delay [seconds]")
        ax.set_title("Average Vehicle Delay at Intersection Over Time")
        ax.set_ylim(0, 120)
        ax.grid(True, alpha=0.3)
        ax.legend()
        plt.tight_layout()
        fp = out_dir / "fig3_avg_delay_over_time.png"
        plt.savefig(fp, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {fp}")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")
        plt.close('all')


def fig4_conflict_histogram(scenario_data: Dict[str, List[Dict]], out_dir: Path) -> None:
    """Fig4: Distribution of conflict events per 5-minute interval."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))

        interval_sec = 300  # 5 minutes

        all_empty = True
        for sc_label, recs in scenario_data.items():
            # Compute per-interval conflict counts by differencing cumulative
            n = len(recs)
            if n == 0:
                continue

            # Get cumulative conflict events at each step
            cum_conflicts = np.array([r["conflict_events_cumulative"] for r in recs])

            # Resample to 300-second intervals
            steps_per_interval = interval_sec  # since delta_t=1
            n_intervals = n // steps_per_interval
            if n_intervals < 2:
                continue

            interval_counts = []
            for i in range(n_intervals):
                start_idx = i * steps_per_interval
                end_idx = (i + 1) * steps_per_interval - 1
                end_idx = min(end_idx, n - 1)
                delta = cum_conflicts[end_idx] - (cum_conflicts[start_idx - 1] if start_idx > 0 else 0.0)
                interval_counts.append(max(0.0, float(delta)))

            interval_counts = np.array(interval_counts)
            if len(interval_counts) == 0:
                continue

            all_empty = False
            ax.hist(interval_counts, bins=15, alpha=0.5,
                    label=SCENARIO_LABELS.get(sc_label, sc_label),
                    color=SCENARIO_COLORS.get(sc_label, 'gray'),
                    edgecolor='black', linewidth=0.5)

        if all_empty:
            print("WARNING: No interval conflict data for fig4, skipping.")
            plt.close()
            return

        ax.set_xlabel("Conflict Events per 5-Minute Interval")
        ax.set_ylabel("Frequency")
        ax.set_title("Distribution of Conflict Events per 5-Minute Interval — All Scenarios")
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fp = out_dir / "fig4_conflict_histogram.png"
        plt.savefig(fp, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {fp}")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")
        plt.close('all')


def fig5_od_heatmap(scenario_data: Dict[str, List[Dict]], out_dir: Path) -> None:
    """Fig5: OD matrix heatmap for baseline scenario."""
    try:
        baseline_recs = scenario_data.get("baseline_offpeak", [])
        if not baseline_recs:
            print("WARNING: No baseline_offpeak data for fig5.")
            return

        # Build OD matrix from routing weights and arrival rates
        inbound_arms = ["elm", "dover", "holland"]
        outbound_arms = ["elm", "day", "dover", "holland", "highland"]

        # Arrival fractions
        recs = baseline_recs
        arr_elm = np.mean([r["arrival_rate_elm"] for r in recs])
        arr_dover = np.mean([r["arrival_rate_dover"] for r in recs])
        arr_holland = np.mean([r["arrival_rate_holland"] for r in recs])
        total_arr = arr_elm + arr_dover + arr_holland

        inbound_rates = {
            "elm": arr_elm,
            "dover": arr_dover,
            "holland": arr_holland,
        }

        rw_day = np.mean([r["routing_weight_day"] for r in recs])
        rw_highland = np.mean([r["routing_weight_highland"] for r in recs])
        rw_elm_out = np.mean([r["routing_weight_elm_out"] for r in recs])
        rw_dover_out = np.mean([r["routing_weight_dover_out"] for r in recs])
        rw_holland_out = np.mean([r["routing_weight_holland_out"] for r in recs])

        routing_weights = {
            "elm": rw_elm_out,
            "day": rw_day,
            "dover": rw_dover_out,
            "holland": rw_holland_out,
            "highland": rw_highland,
        }

        # Build 3x5 OD matrix
        od_matrix = np.zeros((3, 5))
        for i, in_arm in enumerate(inbound_arms):
            for j, out_arm in enumerate(outbound_arms):
                # Suppress diagonal (same bidirectional arm = U-turn)
                if in_arm == out_arm:
                    od_matrix[i, j] = 0.0
                else:
                    # vehicles/hour
                    od_matrix[i, j] = inbound_rates[in_arm] * routing_weights[out_arm] * 60.0

        fig, ax = plt.subplots(figsize=(9, 5))
        im = ax.imshow(od_matrix, cmap='YlOrRd', aspect='auto')
        plt.colorbar(im, ax=ax, label='Vehicles per Hour')

        ax.set_xticks(range(5))
        ax.set_xticklabels(["Elm St", "Day St", "Dover St", "Holland St", "Highland Ave"])
        ax.set_yticks(range(3))
        ax.set_yticklabels(["Elm St (in)", "Dover St (in)", "Holland St (in)"])
        ax.set_xlabel("Destination Arm")
        ax.set_ylabel("Origin Arm")
        ax.set_title("Vehicle Flow Origin-Destination Matrix at Davis Square Intersection\n(Baseline Off-Peak)")

        # Annotate cells
        for i in range(3):
            for j in range(5):
                val = od_matrix[i, j]
                ax.text(j, i, f"{val:.0f}", ha='center', va='center',
                        fontsize=9, color='black' if val < od_matrix.max() * 0.7 else 'white')

        plt.tight_layout()
        fp = out_dir / "fig5_od_heatmap.png"
        plt.savefig(fp, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {fp}")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")
        plt.close('all')


def fig6_delay_vs_arrival_rate(scenario_data: Dict[str, List[Dict]], out_dir: Path) -> None:
    """Fig6: Scatter of delay vs total arrival rate, colored by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        window = 60  # aggregate over 60-second windows

        any_plotted = False
        for sc_label, recs in scenario_data.items():
            n = len(recs)
            if n < window:
                continue

            n_windows = n // window
            x_arr = np.zeros(n_windows)
            y_arr = np.zeros(n_windows)

            for i in range(n_windows):
                chunk = recs[i * window: (i + 1) * window]
                x_arr[i] = float(np.mean([r["total_arrival_rate"] for r in chunk]))
                y_arr[i] = float(np.mean([r["avg_delay_seconds"] for r in chunk]))

            assert len(x_arr) == len(y_arr), f"Length mismatch in fig6 for {sc_label}"
            if len(x_arr) == 0 or len(y_arr) == 0:
                continue

            ax.scatter(x_arr, y_arr, alpha=0.5, s=20,
                       label=SCENARIO_LABELS.get(sc_label, sc_label),
                       color=SCENARIO_COLORS.get(sc_label, 'gray'))
            any_plotted = True

        if not any_plotted:
            print("WARNING: No data for fig6, skipping.")
            plt.close()
            return

        ax.set_xlabel("Total Arrival Rate [vehicles/min]")
        ax.set_ylabel("Average Delay [seconds]")
        ax.set_title("Delay vs. Total Arrival Rate — Scenario Comparison")
        ax.set_ylim(0, 120)
        ax.grid(True, alpha=0.3)
        ax.legend()
        plt.tight_layout()
        fp = out_dir / "fig6_delay_vs_arrival_rate.png"
        plt.savefig(fp, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Saved {fp}")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")
        plt.close('all')


# ---------------------------------------------------------------------------
# SUMMARY JSON
# ---------------------------------------------------------------------------

def write_summary_json(all_records: List[Dict[str, Any]], out_dir: Path) -> None:
    """Write summary.json with aggregate metrics."""
    scenario_data = records_to_scenario_dict(all_records)
    summary = {"scenarios": {}}

    for sc_label, recs in scenario_data.items():
        if not recs:
            continue
        delays = np.array([r["avg_delay_seconds"] for r in recs])
        throughputs = np.array([r["throughput_vehicles_per_min"] for r in recs])
        q_total = np.array([r["queue_length_elm"] + r["queue_length_dover"] + r["queue_length_holland"]
                            for r in recs])
        summary["scenarios"][sc_label] = {
            "mean_avg_delay_s": float(np.mean(delays)),
            "mean_throughput_veh_per_min": float(np.mean(throughputs)),
            "mean_total_queue": float(np.mean(q_total)),
            "total_conflict_events": float(recs[-1]["conflict_events_cumulative"]),
            "n_timesteps": len(recs),
        }

    summary["total_records"] = len(all_records)
    summary["n_scenarios"] = len(scenario_data)

    fp = out_dir / "summary.json"
    try:
        with open(fp, 'w') as f:
            json.dump(summary, f, indent=2)
        print(f"Wrote summary.json to {fp}")
    except Exception as e:
        print(f"WARNING: Could not write summary.json: {e}")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Davis Square Intersection Traffic Flow Simulator"
    )
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all generated files")
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # Run all scenarios
    all_records: List[Dict[str, Any]] = []
    for idx, scenario in enumerate(MODEL_PROFILE["scenarios"]):
        label = scenario["label"]
        overrides = scenario["param_overrides"]
        print(f"\nRunning scenario {idx}: {label} ...")
        records = run_scenario(label, overrides, scenario_index=idx)
        all_records.extend(records)
        print(f"  Completed {len(records)} steps.")

    print(f"\nTotal records: {len(all_records)}")

    # Write CSV files
    write_simulation_outputs(all_records, out_dir)
    write_scenario_summary(all_records, out_dir)
    write_parameters_used(out_dir)

    # Build scenario dict for figures
    scenario_data = records_to_scenario_dict(all_records)

    # Generate figures
    print("\nGenerating figures...")
    fig1_queue_length_over_time(scenario_data, out_dir)
    fig2_throughput_over_time(scenario_data, out_dir)
    fig3_avg_delay_over_time(scenario_data, out_dir)
    fig4_conflict_histogram(scenario_data, out_dir)
    fig5_od_heatmap(scenario_data, out_dir)
    fig6_delay_vs_arrival_rate(scenario_data, out_dir)

    # Write summary JSON
    write_summary_json(all_records, out_dir)

    print("\nSimulation complete. All outputs saved to:", out_dir.resolve())


if __name__ == "__main__":
    main()