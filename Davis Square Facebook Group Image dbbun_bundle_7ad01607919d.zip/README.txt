================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : da76fa48-c3d1-4306-9c0b-546441a4e520
    Generated   : 2026-04-20  13:18:23 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Davis Square Intersection Navigation Sign — Davis Square, Somerville MA

    CATEGORIES
    ----------
    Transportation

    KEYWORDS
    --------
    multi-way intersection, urban traffic flow, vehicle routing, one-way street constraint, intersection capacity

    ABSTRACT
    --------
    This simulator models the complex five-arm uncontrolled intersection at Davis Square in Somerville, Massachusetts, as depicted in the directional navigation sign showing Elm St, Day St, Dover St, Holland St, and Highland Ave converging at a single node with two one-way exit restrictions (Day St and Highland Ave). The simulator uses a stochastic queueing framework to reproduce vehicle arrivals, intersection service, pedestrian impedance, conflict event generation, and exit routing across five operational scenarios ranging from off-peak baseline to morning rush hour and special event conditions. Synthetic datasets capture queue lengths, throughput, average delay, and origin-destination flow patterns at one-second resolution over one-hour simulation periods. Researchers, urban planners, and transportation engineers can use the simulator to evaluate the safety and efficiency impact of the existing one-way restrictions, test hypothetical interventions such as traffic signalization or routing changes, and generate training data for machine learning models applied to complex urban intersection control.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Davis Square Facebook Group Image.jpg

    SIMULATION BACKEND
    ------------------
    navigation_control

    STATE VARIABLES
    ---------------
    vehicle_count_elm, vehicle_count_day, vehicle_count_dover, vehicle_count_holland, vehicle_count_highland, queue_length_elm, queue_length_dover, queue_length_holland, intersection_occupancy, pedestrian_count, conflict_events, avg_delay, throughput, time

    SCENARIOS  (5 total)
    ---------------------------------
        1. baseline_offpeak — Normal off-peak traffic with standard arrival rates and no multipliers; represents typical midday conditions at Davis Square
2. morning_peak_hour — Morning rush hour scenario with elevated vehicle and pedestrian arrival rates scaled by peak multiplier
3. oneway_restriction_removed — Hypothetical scenario where Day St and Highland Ave are converted to two-way streets, adding two new inbound arrival streams
4. high_pedestrian_pressure — Event-day scenario with very high pedestrian volumes (farmers market, festival) creating frequent vehicle interruptions
5. reduced_conflict_signage — Simulated addition of stop signs or yield markings that reduce vehicle conflict probability significantly

    PARAMETERS
    ----------
    23 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6

    DOMAIN SUMMARY
    --------------
    The source image depicts a directional navigation sign for the Davis Square multi-way intersection in Somerville, Massachusetts, showing five radiating streets (Elm St, Day St, Dover St, Holland St, Highland Ave) with two one-way restrictions (Day St and Highland Ave marked with do-not-enter symbols). The content supports simulation of complex urban intersection traffic flow, routing, and pedestrian/vehicle movement dynamics.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.