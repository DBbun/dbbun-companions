================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : b99f28de-a1e0-45a3-a2a2-c93b895cebc6
    Generated   : 2026-04-21  14:52:51 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Battle of the Philippine Sea - Wikipedia

    CATEGORIES
    ----------
    Other, Signal Processing, Agent-based Modeling

    KEYWORDS
    --------
    naval air combat, attrition modeling, World War II Pacific, carrier warfare, anti-aircraft defense

    ABSTRACT
    --------
    This simulator models the Battle of the Philippine Sea (June 19-20, 1944), the largest carrier-to-carrier naval engagement in history, with emphasis on the aerial attrition dynamics that produced the 'Great Marianas Turkey Shoot.' It reproduces four Japanese air raid waves, US CAP interception layers, VT proximity fuze anti-aircraft fire, submarine torpedo attacks on Japanese fleet carriers, and the extended-range US counterattack on June 20. The simulator generates time-series aircraft inventory data, wave-by-wave loss ratios, carrier operational status, and fuel margin trajectories across six historically grounded scenarios including counterfactual what-ifs. Researchers can use the synthetic data to study how compounding advantages—pilot experience, radar-directed interception, superior AA technology, and intelligence from captured Japanese plans—combine to produce near-total destruction of an opposing air force, while students and educators can explore the strategic consequences of individual factors through controlled scenario comparison.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Battle of the Philippine Sea - Wikipedia.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    us_aircraft_available, jp_carrier_aircraft_available, jp_landbased_aircraft_available, us_aircraft_losses_cumulative, jp_aircraft_losses_cumulative, jp_carriers_operational, us_carriers_operational, jp_fleet_combat_power, us_fleet_combat_power, jp_oilers_sunk, raid_wave_index, time_hours, jp_pilot_experience_factor, us_pilot_experience_factor, us_cap_layers, jp_submarines_active, us_submarines_active, taiko_status, shokaku_status, us_fuel_margin

    SCENARIOS  (6 total)
    ---------------------------------
        1. historical_baseline — Reproduce historical battle conditions: experienced US pilots, novice Japanese replacements, full VT fuze AA effectiveness, 4 Japanese raid waves plus US counterattack
2. experienced_japanese_pilots — Counterfactual: Japanese pilots have equal experience to US pilots (pre-Midway quality), all other parameters held constant. Examines sensitivity of loss ratio to pilot skill.
3. no_vt_fuze — Counterfactual: US ships lack proximity VT fuze technology, relying only on contact-fused AA fire. Reduces AA kill probability by removing the VT multiplier.
4. no_submarine_attacks — Counterfactual: USS Albacore and Cavalla fail to intercept Japanese carriers; Taiho and Shokaku survive day 1. Japanese fleet retains full carrier capacity for June 20.
5. mitscher_night_advance — Counterfactual: Spruance approves Mitscher's request to advance west during the night of June 18-19, reducing strike range on June 20 from 275 to 150 nautical miles and allowing a second launch wave.
6. larger_jp_landbased_force — Counterfactual: Japanese garrison the Marianas with 300 land-based aircraft instead of 50, as planned before the surprise US timing. Tests the effect of land-based air augmentation.

    PARAMETERS
    ----------
    35 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7

    DOMAIN SUMMARY
    --------------
    The Battle of the Philippine Sea (June 19-20, 1944) was the largest carrier-to-carrier naval engagement in history, featuring air combat attrition, submarine torpedo attacks, and fleet strike operations during World War II's Pacific Theater.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.