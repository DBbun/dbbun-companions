# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-21T14:52:51.821759Z
# Run ID    : b99f28de-a1e0-45a3-a2a2-c93b895cebc6
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Battle of the Philippine Sea Simulator
Based on: 'Battle of the Philippine Sea - Wikipedia'
Models the Great Marianas Turkey Shoot (June 19-20, 1944), the largest carrier-to-carrier
naval engagement in history. Simulates air combat attrition across four Japanese raid waves,
CAP interception layers, VT proximity fuze AA effectiveness, submarine torpedo attacks,
and the extended-range US counterattack on June 20.
"""

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv
import json
import argparse
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple

# ==============================================================================
# MODEL PROFILE
# ==============================================================================
MODEL_PROFILE = {
    "title": "Battle of the Philippine Sea Simulator",
    "domain": "Naval air combat attrition, WWII Pacific Theater",
    "parameters": {
        "raid1_size": {"value": 68.0, "unit": "aircraft", "source": "extracted",
                       "description": "Size of Japanese first carrier raid wave on June 19"},
        "raid2_size": {"value": 107.0, "unit": "aircraft", "source": "extracted",
                       "description": "Size of Japanese second carrier raid wave on June 19"},
        "raid3_size": {"value": 47.0, "unit": "aircraft", "source": "extracted",
                       "description": "Size of Japanese third carrier raid wave on June 19"},
        "raid4_size": {"value": 49.0, "unit": "aircraft", "source": "extracted",
                       "description": "Size of Japanese fourth raid wave on June 19"},
        "us_counterattack_size": {"value": 226.0, "unit": "aircraft", "source": "extracted",
                                   "description": "Total US aircraft in the June 20 afternoon strike"},
        "raid1_us_loss_rate": {"value": 0.015, "unit": "fraction", "source": "extracted",
                                "description": "Fraction of US aircraft lost intercepting raid 1"},
        "raid1_jp_loss_rate": {"value": 0.603, "unit": "fraction", "source": "extracted",
                                "description": "Fraction of raid 1 aircraft destroyed (41 of 68)"},
        "raid2_jp_loss_rate": {"value": 0.907, "unit": "fraction", "source": "extracted",
                                "description": "Fraction of raid 2 aircraft destroyed (97 of 107)"},
        "raid3_jp_loss_rate": {"value": 0.149, "unit": "fraction", "source": "extracted",
                                "description": "Fraction of raid 3 aircraft destroyed (7 of 47)"},
        "raid4_jp_loss_rate": {"value": 0.816, "unit": "fraction", "source": "extracted",
                                "description": "Fraction of raid 4 aircraft destroyed (40 of 49)"},
        "total_jp_day1_losses": {"value": 350.0, "unit": "aircraft", "source": "extracted",
                                  "description": "Total Japanese aircraft losses on June 19"},
        "total_us_day1_losses": {"value": 30.0, "unit": "aircraft", "source": "extracted",
                                  "description": "Approximate US aircraft losses on June 19"},
        "total_us_day2_losses": {"value": 80.0, "unit": "aircraft", "source": "extracted",
                                  "description": "Total US aircraft lost in June 20 counterattack"},
        "us_combat_losses_day2": {"value": 20.0, "unit": "aircraft", "source": "extracted",
                                   "description": "US aircraft lost in combat on June 20"},
        "jp_counterattack_defenders": {"value": 35.0, "unit": "aircraft", "source": "extracted",
                                        "description": "Japanese fighters available for June 20 defense"},
        "albacore_torpedoes_fired": {"value": 6.0, "unit": "torpedoes", "source": "extracted",
                                      "description": "Torpedoes fired by USS Albacore at Taiho"},
        "albacore_torpedoes_hit": {"value": 1.0, "unit": "torpedoes", "source": "extracted",
                                    "description": "Torpedoes that struck Taiho"},
        "cavalla_torpedoes_fired": {"value": 6.0, "unit": "torpedoes", "source": "extracted",
                                     "description": "Torpedoes fired by USS Cavalla at Shokaku"},
        "cavalla_torpedoes_hit": {"value": 3.0, "unit": "torpedoes", "source": "extracted",
                                   "description": "Torpedoes that struck Shokaku"},
        "jp_remaining_aircraft_after_day1": {"value": 150.0, "unit": "aircraft", "source": "extracted",
                                              "description": "Japanese aircraft remaining after day 1"},
        "us_strike_range_limit": {"value": 275.0, "unit": "nautical miles", "source": "extracted",
                                   "description": "Range of Japanese fleet from TF 58 on June 20"},
        "guam_landbased_intercept_losses": {"value": 35.0, "unit": "aircraft", "source": "extracted",
                                             "description": "Japanese aircraft shot down over Orote Field"},
        "jp_pilot_training_hours_ratio": {"value": 0.25, "unit": "fraction", "source": "assumed",
                                           "description": "Ratio of JP replacement pilot hours to US pilot hours"},
        "vt_fuze_effectiveness_multiplier": {"value": 2.5, "unit": "a.u.", "source": "assumed",
                                              "description": "Multiplier on AA gun kill probability from VT fuze"},
        "cap_interception_range_miles": {"value": 70.0, "unit": "nautical miles", "source": "extracted",
                                          "description": "Distance CAP first intercepted Japanese raid 1"},
        "raid2_intercept_range_miles": {"value": 60.0, "unit": "nautical miles", "source": "extracted",
                                         "description": "Distance CAP first intercepted Japanese raid 2"},
        "raid3_intercept_range_miles": {"value": 50.0, "unit": "nautical miles", "source": "extracted",
                                         "description": "Distance CAP first intercepted Japanese raid 3"},
        "taiho_crew_lost": {"value": 1650.0, "unit": "persons", "source": "extracted",
                             "description": "Crew lost when Taiho sank"},
        "shokaku_crew_lost": {"value": 1263.0, "unit": "persons", "source": "extracted",
                               "description": "Total personnel lost when Shokaku sank"},
        "jp_fleet_speed_knots": {"value": 20.0, "unit": "knots", "source": "extracted",
                                  "description": "Speed of Japanese fleet when sighted on June 20"},
        "jp_total_aircraft_losses": {"value": 597.0, "unit": "aircraft", "source": "extracted",
                                      "description": "Midpoint of estimated total Japanese aircraft losses"},
        "us_total_aircraft_losses": {"value": 123.0, "unit": "aircraft", "source": "extracted",
                                      "description": "Total US aircraft losses across the entire battle"},
        "loss_ratio": {"value": 4.85, "unit": "a.u.", "source": "extracted",
                       "description": "Japanese-to-US aircraft loss ratio capturing Turkey Shoot disparity"},
        "radar_detection_range_miles": {"value": 150.0, "unit": "nautical miles", "source": "extracted",
                                         "description": "Radar range at which TF 58 first detected raid 1"},
        "dt": {"value": 0.25, "unit": "hours", "source": "assumed",
               "description": "Simulation time step (15 minutes)"},
    },
    "scenarios": [
        {
            "label": "historical_baseline",
            "description": "Reproduce historical battle conditions",
            "param_overrides": {
                "jp_pilot_training_hours_ratio": 0.25,
                "vt_fuze_effectiveness_multiplier": 2.5,
                "us_pilot_experience_factor": 0.85,
                "jp_pilot_experience_factor": 0.25,
                "raid1_size": 68,
                "raid2_size": 107,
                "raid3_size": 47,
                "raid4_size": 49,
            }
        },
        {
            "label": "experienced_japanese_pilots",
            "description": "Counterfactual: Japanese pilots have equal experience to US pilots",
            "param_overrides": {
                "jp_pilot_experience_factor": 0.85,
                "jp_pilot_training_hours_ratio": 1.0,
                "vt_fuze_effectiveness_multiplier": 2.5,
            }
        },
        {
            "label": "no_vt_fuze",
            "description": "Counterfactual: US ships lack proximity VT fuze technology",
            "param_overrides": {
                "vt_fuze_effectiveness_multiplier": 1.0,
                "jp_pilot_experience_factor": 0.25,
            }
        },
        {
            "label": "no_submarine_attacks",
            "description": "Counterfactual: USS Albacore and Cavalla fail to intercept",
            "param_overrides": {
                "albacore_torpedoes_hit": 0,
                "cavalla_torpedoes_hit": 0,
                "jp_remaining_aircraft_after_day1": 250,
            }
        },
        {
            "label": "mitscher_night_advance",
            "description": "Counterfactual: Spruance approves Mitscher night advance",
            "param_overrides": {
                "us_strike_range_limit": 150.0,
                "us_counterattack_size": 400.0,
                "us_fuel_margin": 0.75,
            }
        },
        {
            "label": "larger_jp_landbased_force",
            "description": "Counterfactual: Japanese garrison Marianas with 300 land-based aircraft",
            "param_overrides": {
                "jp_landbased_aircraft_available": 300.0,
                "raid4_size": 200.0,
            }
        },
    ]
}

# ==============================================================================
# DEFAULT STATE VARIABLE INIT VALUES
# ==============================================================================
DEFAULT_STATE = {
    "us_aircraft_available": 900.0,
    "jp_carrier_aircraft_available": 450.0,
    "jp_landbased_aircraft_available": 300.0,
    "us_aircraft_losses_cumulative": 0.0,
    "jp_aircraft_losses_cumulative": 0.0,
    "jp_carriers_operational": 9.0,
    "us_carriers_operational": 15.0,
    "jp_fleet_combat_power": 1.0,
    "us_fleet_combat_power": 1.0,
    "jp_oilers_sunk": 0.0,
    "raid_wave_index": 0.0,
    "time_hours": 0.0,
    "jp_pilot_experience_factor": 0.25,
    "us_pilot_experience_factor": 0.85,
    "us_cap_layers": 3.0,
    "jp_submarines_active": 24.0,
    "us_submarines_active": 28.0,
    "taiko_status": 1.0,
    "shokaku_status": 1.0,
    "us_fuel_margin": 1.0,
}

DEFAULT_PARAMS = {
    "raid1_size": 68.0,
    "raid2_size": 107.0,
    "raid3_size": 47.0,
    "raid4_size": 49.0,
    "us_counterattack_size": 226.0,
    "raid1_us_loss_rate": 0.015,
    "raid1_jp_loss_rate": 0.603,
    "raid2_jp_loss_rate": 0.907,
    "raid3_jp_loss_rate": 0.149,
    "raid4_jp_loss_rate": 0.816,
    "total_jp_day1_losses": 350.0,
    "total_us_day1_losses": 30.0,
    "total_us_day2_losses": 80.0,
    "us_combat_losses_day2": 20.0,
    "jp_counterattack_defenders": 35.0,
    "albacore_torpedoes_fired": 6.0,
    "albacore_torpedoes_hit": 1.0,
    "cavalla_torpedoes_fired": 6.0,
    "cavalla_torpedoes_hit": 3.0,
    "jp_remaining_aircraft_after_day1": 150.0,
    "us_strike_range_limit": 275.0,
    "guam_landbased_intercept_losses": 35.0,
    "jp_pilot_training_hours_ratio": 0.25,
    "vt_fuze_effectiveness_multiplier": 2.5,
    "cap_interception_range_miles": 70.0,
    "raid2_intercept_range_miles": 60.0,
    "raid3_intercept_range_miles": 50.0,
    "taiho_crew_lost": 1650.0,
    "shokaku_crew_lost": 1263.0,
    "jp_fleet_speed_knots": 20.0,
    "jp_total_aircraft_losses": 597.0,
    "us_total_aircraft_losses": 123.0,
    "loss_ratio": 4.85,
    "radar_detection_range_miles": 150.0,
    "dt": 0.25,
    # Calibration constants
    "base_kill_rate": 0.35,
    "base_aa_rate": 0.20,
    "attrition_rate_on_us": 0.05,
    "max_range": 350.0,
    "combat_fuel_burn": 0.08,
    "taiho_airgroup_size": 75.0,
    "shokaku_airgroup_size": 75.0,
}


# ==============================================================================
# SIMULATION CORE
# ==============================================================================

def clamp(val, lo, hi):
    """Clamp a value to [lo, hi]."""
    return max(lo, min(hi, val))


def run_scenario(scenario_cfg, scenario_index):
    """
    Run a single scenario simulation.
    Returns a list of dicts, one per simulation event/row.
    """
    np.random.seed(scenario_index)

    label = scenario_cfg["label"]
    overrides = scenario_cfg.get("param_overrides", {})

    # Build parameter set
    params = dict(DEFAULT_PARAMS)
    params.update(overrides)

    # Build state
    state = dict(DEFAULT_STATE)
    # Apply state-level overrides from param_overrides
    state_keys = set(DEFAULT_STATE.keys())
    for k, v in overrides.items():
        if k in state_keys:
            state[k] = v

    # Extract key parameters
    jp_pilot_exp = float(params.get("jp_pilot_experience_factor", state["jp_pilot_experience_factor"]))
    us_pilot_exp = float(params.get("us_pilot_experience_factor", state["us_pilot_experience_factor"]))
    vt_mult = float(params["vt_fuze_effectiveness_multiplier"])
    base_kill_rate = float(params["base_kill_rate"])
    base_aa_rate = float(params["base_aa_rate"])
    attrition_rate_on_us = float(params["attrition_rate_on_us"])
    max_range = float(params["max_range"])
    combat_fuel_burn = float(params["combat_fuel_burn"])
    taiho_airgroup_size = float(params["taiho_airgroup_size"])
    shokaku_airgroup_size = float(params["shokaku_airgroup_size"])

    # Update state pilot experience from params if overridden
    if "jp_pilot_experience_factor" in overrides:
        state["jp_pilot_experience_factor"] = jp_pilot_exp
    if "us_pilot_experience_factor" in overrides:
        state["us_pilot_experience_factor"] = us_pilot_exp

    # Initialize aircraft totals
    init_jp_aircraft = state["jp_carrier_aircraft_available"] + state["jp_landbased_aircraft_available"]
    init_us_aircraft = state["us_aircraft_available"]

    jp_aircraft = float(init_jp_aircraft)
    us_aircraft = float(init_us_aircraft)
    jp_losses_cum = 0.0
    us_losses_cum = 0.0
    jp_carriers = float(state["jp_carriers_operational"])
    us_carriers = float(state["us_carriers_operational"])
    taiko_status = float(state["taiko_status"])
    shokaku_status = float(state["shokaku_status"])
    jp_oilers_sunk = float(state["jp_oilers_sunk"])
    jp_submarines = float(state["jp_submarines_active"])
    us_submarines = float(state["us_submarines_active"])
    us_cap_layers = float(state["us_cap_layers"])
    us_fuel_margin = float(state["us_fuel_margin"])

    albacore_hit = int(params["albacore_torpedoes_hit"])
    cavalla_hit = int(params["cavalla_torpedoes_hit"])
    jp_remaining_day1 = float(params["jp_remaining_aircraft_after_day1"])
    strike_range = float(params["us_strike_range_limit"])
    jp_counterattack_defenders = float(params["jp_counterattack_defenders"])

    rows = []

    def make_row(time_h, wave_idx, wave_label, jp_launched, jp_lost_wave, us_lost_wave,
                 intercept_range, jp_avail, us_avail, jp_carr, us_carr,
                 jp_fcp, us_fcp, taik, shok, fuel_margin, jp_sub, us_sub,
                 jp_oil, jp_lc, us_lc):
        lr = jp_lc / max(us_lc, 1.0)
        return {
            "scenario": label,
            "time_hours": round(clamp(time_h, 0, 36), 4),
            "raid_wave_index": int(clamp(wave_idx, 0, 6)),
            "raid_wave_label": wave_label,
            "jp_aircraft_launched_this_wave": max(0, int(jp_launched)),
            "jp_aircraft_lost_this_wave": max(0, int(jp_lost_wave)),
            "us_aircraft_lost_this_wave": max(0, int(us_lost_wave)),
            "jp_aircraft_available": max(0, int(jp_avail)),
            "us_aircraft_available": max(0, int(us_avail)),
            "jp_carriers_operational": int(clamp(jp_carr, 0, 9)),
            "us_carriers_operational": int(clamp(us_carr, 0, 15)),
            "jp_fleet_combat_power": round(clamp(jp_fcp, 0.0, 1.0), 4),
            "us_fleet_combat_power": round(clamp(us_fcp, 0.0, 1.0), 4),
            "taiko_status": int(clamp(taik, 0, 1)),
            "shokaku_status": int(clamp(shok, 0, 1)),
            "jp_pilot_experience_factor": round(clamp(jp_pilot_exp, 0.1, 1.0), 4),
            "us_pilot_experience_factor": round(clamp(us_pilot_exp, 0.5, 1.0), 4),
            "vt_fuze_effectiveness_multiplier": round(vt_mult, 4),
            "loss_ratio_cumulative": round(clamp(lr, 0, 50), 4),
            "jp_aircraft_losses_cumulative": max(0, int(jp_lc)),
            "us_aircraft_losses_cumulative": max(0, int(us_lc)),
            "us_fuel_margin": round(clamp(fuel_margin, 0.0, 1.0), 4),
            "intercept_range_miles": max(0, int(intercept_range)),
            "us_cap_layers_active": int(clamp(us_cap_layers, 0, 5)),
            "jp_oilers_sunk": int(clamp(jp_oil, 0, 6)),
            "jp_submarines_active": int(clamp(jp_sub, 0, 24)),
            "us_submarines_active": int(clamp(us_sub, 0, 28)),
        }

    # Initial row
    jp_fcp = clamp(jp_aircraft / max(init_jp_aircraft, 1), 0.0, 1.0)
    us_fcp = clamp(us_aircraft / max(init_us_aircraft, 1), 0.0, 1.0)
    rows.append(make_row(0.0, 0, "pre_battle", 0, 0, 0, 0,
                         jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                         jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                         jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    # ------------------------------------------------------------------
    # SUBMARINE PHASE
    # ------------------------------------------------------------------
    # USS Albacore attacks Taiho at t=2.26h (08:16)
    taiho_torpedoed_time = 2.26
    taiho_sinking_time = 8.5
    shokaku_torpedoed_time = 6.0
    shokaku_sinking_time = 7.0

    if albacore_hit > 0 and taiko_status > 0:
        # Taiho torpedoed — loses some operational capacity immediately
        taiko_status = 0.5  # damaged, still afloat temporarily
        jp_carriers = clamp(jp_carriers - 0, 0, 9)  # still counted until sunk
        # Aircraft on Taiho cannot launch (partial loss)
        lost_taiho_aircraft = taiho_airgroup_size * 0.3
        jp_aircraft = max(0, jp_aircraft - lost_taiho_aircraft)
        jp_losses_cum += lost_taiho_aircraft
        jp_fcp = clamp(jp_aircraft / max(init_jp_aircraft, 1), 0.0, 1.0)
        us_fcp = clamp(us_aircraft / max(init_us_aircraft, 1), 0.0, 1.0)
        rows.append(make_row(taiho_torpedoed_time, 0, "taiho_torpedoed", 0, lost_taiho_aircraft, 0,
                             0, jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                             jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                             jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    if cavalla_hit > 0 and shokaku_status > 0:
        # Shokaku torpedoed
        shokaku_status = 0.0  # sinks relatively quickly
        jp_carriers = clamp(jp_carriers - 1, 0, 9)
        lost_shokaku_aircraft = shokaku_airgroup_size * 0.8
        jp_aircraft = max(0, jp_aircraft - lost_shokaku_aircraft)
        jp_losses_cum += lost_shokaku_aircraft
        jp_fcp = clamp(jp_aircraft / max(init_jp_aircraft, 1), 0.0, 1.0)
        rows.append(make_row(shokaku_torpedoed_time, 0, "shokaku_sunk", 0, lost_shokaku_aircraft, 0,
                             0, jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                             jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                             jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    # ------------------------------------------------------------------
    # RAID WAVE PHASE — June 19
    # ------------------------------------------------------------------
    wave_params = [
        # (wave_idx, label, launch_time, intercept_range, size_key, intercept_key)
        (1, "raid_1", 4.0,  70.0, "raid1_size", "cap_interception_range_miles"),
        (2, "raid_2", 5.17, 60.0, "raid2_size", "raid2_intercept_range_miles"),
        (3, "raid_3", 7.0,  50.0, "raid3_size", "raid3_intercept_range_miles"),
        (4, "raid_4_guam", 5.5, 40.0, "raid4_size", None),
    ]

    for wave_idx, wave_label, launch_time, intercept_range_val, size_key, intercept_key in wave_params:
        raid_size = float(params[size_key])
        if intercept_key is not None:
            intercept_range_use = float(params[intercept_key])
        else:
            intercept_range_use = intercept_range_val

        # CAP layer attrition
        exp_ratio = us_pilot_exp / max(jp_pilot_exp, 0.01)
        p_kill_per_layer = base_kill_rate * exp_ratio * vt_mult
        p_kill_per_layer = clamp(p_kill_per_layer, 0.0, 0.95)

        jp_surviving_cap = raid_size * ((1.0 - p_kill_per_layer) ** us_cap_layers)
        jp_losses_cap = raid_size - jp_surviving_cap

        # AA gunline attrition
        p_kill_aa = clamp(base_aa_rate * vt_mult, 0.0, 0.95)
        jp_surviving_gunline = jp_surviving_cap * (1.0 - p_kill_aa)
        jp_losses_aa = jp_surviving_cap - jp_surviving_gunline

        # Wave 4 Guam special case
        if wave_idx == 4:
            guam_group_size = int(raid_size * 0.65)
            exp_factor_adj = clamp(1.0 / max(jp_pilot_exp * 4, 0.1), 0.5, 2.0)
            guam_losses = int(guam_group_size * (30.0 / 40.0) * min(exp_factor_adj, 1.0))
            guam_losses = min(guam_losses, guam_group_size)
            jp_losses_aa += guam_losses
            jp_surviving_gunline = max(0, jp_surviving_gunline - guam_losses)

        jp_losses_this_wave = jp_losses_cap + jp_losses_aa

        # US losses from JP aircraft reaching fleet
        jp_reach_fleet = max(0, jp_surviving_gunline)
        us_mean_loss = jp_reach_fleet * attrition_rate_on_us * (1.0 - us_pilot_exp * 0.3)
        us_mean_loss = max(0, us_mean_loss)
        if us_mean_loss > 0:
            us_losses_this_wave = float(np.random.poisson(us_mean_loss))
        else:
            us_losses_this_wave = 0.0

        jp_losses_this_wave = max(0, jp_losses_this_wave)
        jp_losses_cum += jp_losses_this_wave
        us_losses_cum += us_losses_this_wave
        jp_aircraft = max(0, jp_aircraft - jp_losses_this_wave)
        us_aircraft = max(0, us_aircraft - us_losses_this_wave)

        jp_fcp = clamp(jp_aircraft / max(init_jp_aircraft, 1), 0.0, 1.0)
        us_fcp = clamp(us_aircraft / max(init_us_aircraft, 1), 0.0, 1.0)

        rows.append(make_row(launch_time, wave_idx, wave_label, raid_size, jp_losses_this_wave, us_losses_this_wave,
                             intercept_range_use, jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                             jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                             jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    # ------------------------------------------------------------------
    # TAIHO SINKING EVENT (t=8.5h)
    # ------------------------------------------------------------------
    if albacore_hit > 0 and taiko_status > 0:
        taiko_status = 0.0
        jp_carriers = clamp(jp_carriers - 1, 0, 9)
        lost_taiho_final = taiho_airgroup_size * 0.7
        jp_aircraft = max(0, jp_aircraft - lost_taiho_final)
        jp_losses_cum += lost_taiho_final
        jp_fcp = clamp(jp_aircraft / max(init_jp_aircraft, 1), 0.0, 1.0)
        rows.append(make_row(taiho_sinking_time, 0, "taiho_sunk", 0, lost_taiho_final, 0,
                             0, jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                             jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                             jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    # ------------------------------------------------------------------
    # NIGHT TRANSITION (t=15.0h — 21:00 June 19)
    # ------------------------------------------------------------------
    # Ozawa consolidates — use jp_remaining_aircraft_after_day1 as floor
    # but don't increase losses (only can confirm minimum remaining)
    jp_aircraft_night = min(jp_aircraft, jp_remaining_day1)
    # Actually spec says max(jp_aircraft, jp_remaining) but that would increase aircraft
    # We use the remaining as the actual count after consolidation
    jp_aircraft = max(0, min(jp_aircraft, jp_remaining_day1 * 1.1))
    jp_fcp = clamp(jp_aircraft / max(init_jp_aircraft, 1), 0.0, 1.0)
    us_fcp = clamp(us_aircraft / max(init_us_aircraft, 1), 0.0, 1.0)
    rows.append(make_row(15.0, 0, "night_consolidation", 0, 0, 0,
                         0, jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                         jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                         jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    # ------------------------------------------------------------------
    # US COUNTERATTACK — June 20 (t=33.67h ~ 15:40)
    # ------------------------------------------------------------------
    counterattack_time = 33.67
    strike_aircraft = float(params["us_counterattack_size"])

    # Fuel model
    fuel_outbound = 1.0 - (strike_range / max_range) * 0.45
    fuel_at_target = fuel_outbound - combat_fuel_burn
    fuel_return = fuel_at_target - (strike_range / max_range) * 0.45
    # Apply scenario fuel margin override if provided
    if "us_fuel_margin" in overrides:
        us_fuel_margin = float(overrides["us_fuel_margin"])
        fuel_return = us_fuel_margin
    else:
        us_fuel_margin = max(0.0, fuel_return)
        fuel_return = us_fuel_margin

    us_fuel_margin = clamp(us_fuel_margin, 0.0, 1.0)

    # Fuel loss probability
    critical_threshold = 0.15
    fuel_loss_prob = 1.0 / (1.0 + np.exp(10.0 * (us_fuel_margin - critical_threshold)))
    us_fuel_losses = int(strike_aircraft * fuel_loss_prob * 0.35)
    us_fuel_losses = clamp(us_fuel_losses, 0, int(strike_aircraft))

    # Combat losses
    defend_ratio = jp_counterattack_defenders / max(strike_aircraft, 1)
    us_combat_losses_d2 = int(strike_aircraft * defend_ratio * 0.09)
    us_combat_losses_d2 = clamp(us_combat_losses_d2, 0, int(strike_aircraft))

    jp_defense_losses = int(jp_counterattack_defenders * 0.85)
    jp_defense_losses = clamp(jp_defense_losses, 0, int(jp_counterattack_defenders))

    # Strike results — Hiyo sunk
    if strike_range <= 200.0:
        carriers_sunk_day2 = 2
    else:
        carriers_sunk_day2 = 1

    jp_carriers = clamp(jp_carriers - carriers_sunk_day2, 0, 9)
    jp_oilers_sunk = clamp(jp_oilers_sunk + 2, 0, 6)

    total_us_losses_day2 = us_fuel_losses + us_combat_losses_d2
    us_losses_cum += total_us_losses_day2
    jp_losses_cum += jp_defense_losses
    jp_aircraft = max(0, jp_aircraft - jp_defense_losses)
    us_aircraft = max(0, us_aircraft - total_us_losses_day2)

    jp_fcp = clamp(jp_aircraft / max(init_jp_aircraft, 1), 0.0, 1.0)
    us_fcp = clamp(us_aircraft / max(init_us_aircraft, 1), 0.0, 1.0)

    rows.append(make_row(counterattack_time, 5, "us_counterattack", strike_aircraft,
                         jp_defense_losses, total_us_losses_day2,
                         0, jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                         jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                         jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    # Final state row
    rows.append(make_row(36.0, 6, "battle_end", 0, 0, 0,
                         0, jp_aircraft, us_aircraft, jp_carriers, us_carriers,
                         jp_fcp, us_fcp, taiko_status, shokaku_status, us_fuel_margin,
                         jp_submarines, us_submarines, jp_oilers_sunk, jp_losses_cum, us_losses_cum))

    return rows


# ==============================================================================
# CSV WRITING
# ==============================================================================

SCHEMA_COLS = [
    "scenario", "time_hours", "raid_wave_index", "raid_wave_label",
    "jp_aircraft_launched_this_wave", "jp_aircraft_lost_this_wave", "us_aircraft_lost_this_wave",
    "jp_aircraft_available", "us_aircraft_available",
    "jp_carriers_operational", "us_carriers_operational",
    "jp_fleet_combat_power", "us_fleet_combat_power",
    "taiko_status", "shokaku_status",
    "jp_pilot_experience_factor", "us_pilot_experience_factor",
    "vt_fuze_effectiveness_multiplier",
    "loss_ratio_cumulative", "jp_aircraft_losses_cumulative", "us_aircraft_losses_cumulative",
    "us_fuel_margin", "intercept_range_miles", "us_cap_layers_active",
    "jp_oilers_sunk", "jp_submarines_active", "us_submarines_active"
]


def write_simulation_outputs(all_rows, out_dir):
    """Write simulation_outputs.csv."""
    fpath = out_dir / "simulation_outputs.csv"
    if not all_rows:
        print("WARNING: No simulation rows to write.")
        return
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SCHEMA_COLS)
        writer.writeheader()
        for row in all_rows:
            writer.writerow({k: row.get(k, "") for k in SCHEMA_COLS})
    print(f"Wrote {len(all_rows)} rows to {fpath}")


def write_scenario_summary(scenario_results, out_dir):
    """Write scenario_summary.csv — one row per scenario."""
    fpath = out_dir / "scenario_summary.csv"
    summary_rows = []

    for label, rows in scenario_results.items():
        if not rows:
            continue
        jp_avail = np.array([r["jp_aircraft_available"] for r in rows], dtype=float)
        us_avail = np.array([r["us_aircraft_available"] for r in rows], dtype=float)
        jp_losses = np.array([r["jp_aircraft_losses_cumulative"] for r in rows], dtype=float)
        us_losses = np.array([r["us_aircraft_losses_cumulative"] for r in rows], dtype=float)
        jp_carr = np.array([r["jp_carriers_operational"] for r in rows], dtype=float)
        lr = np.array([r["loss_ratio_cumulative"] for r in rows], dtype=float)
        fuel = np.array([r["us_fuel_margin"] for r in rows], dtype=float)
        jp_fcp = np.array([r["jp_fleet_combat_power"] for r in rows], dtype=float)
        us_fcp = np.array([r["us_fleet_combat_power"] for r in rows], dtype=float)

        last = rows[-1]

        summary_rows.append({
            "scenario": label,
            "jp_aircraft_losses_final": last["jp_aircraft_losses_cumulative"],
            "us_aircraft_losses_final": last["us_aircraft_losses_cumulative"],
            "jp_carriers_final": last["jp_carriers_operational"],
            "us_carriers_final": last["us_carriers_operational"],
            "loss_ratio_final": last["loss_ratio_cumulative"],
            "jp_fleet_combat_power_final": last["jp_fleet_combat_power"],
            "us_fleet_combat_power_final": last["us_fleet_combat_power"],
            "us_fuel_margin_final": last["us_fuel_margin"],
            "jp_oilers_sunk_final": last["jp_oilers_sunk"],
            "jp_aircraft_avail_mean": round(float(np.mean(jp_avail)), 2),
            "jp_aircraft_avail_std": round(float(np.std(jp_avail)), 2),
            "jp_aircraft_avail_min": round(float(np.min(jp_avail)), 2),
            "jp_aircraft_avail_max": round(float(np.max(jp_avail)), 2),
            "us_aircraft_avail_mean": round(float(np.mean(us_avail)), 2),
            "us_aircraft_avail_std": round(float(np.std(us_avail)), 2),
            "us_aircraft_avail_min": round(float(np.min(us_avail)), 2),
            "us_aircraft_avail_max": round(float(np.max(us_avail)), 2),
            "jp_carriers_mean": round(float(np.mean(jp_carr)), 2),
            "loss_ratio_mean": round(float(np.mean(lr)), 2),
            "loss_ratio_max": round(float(np.max(lr)), 2),
            "jp_pilot_experience_factor": rows[0]["jp_pilot_experience_factor"],
            "us_pilot_experience_factor": rows[0]["us_pilot_experience_factor"],
            "vt_fuze_effectiveness_multiplier": rows[0]["vt_fuze_effectiveness_multiplier"],
        })

    if not summary_rows:
        print("WARNING: No summary rows to write.")
        return

    cols = list(summary_rows[0].keys())
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        for row in summary_rows:
            writer.writerow(row)
    print(f"Wrote scenario_summary.csv with {len(summary_rows)} rows.")


def write_parameters_used(out_dir):
    """Write parameters_used.csv."""
    fpath = out_dir / "parameters_used.csv"
    param_rows = []
    for name, meta in MODEL_PROFILE["parameters"].items():
        param_rows.append({
            "name": name,
            "value": meta["value"],
            "unit": meta["unit"],
            "source": meta["source"],
            "description": meta["description"],
        })
    if not param_rows:
        print("WARNING: No parameter rows to write.")
        return
    cols = ["name", "value", "unit", "source", "description"]
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        for row in param_rows:
            writer.writerow(row)
    print(f"Wrote parameters_used.csv with {len(param_rows)} rows.")


# ==============================================================================
# FIGURE GENERATION
# ==============================================================================

SCENARIO_COLORS = {
    "historical_baseline": "#1f77b4",
    "experienced_japanese_pilots": "#ff7f0e",
    "no_vt_fuze": "#2ca02c",
    "no_submarine_attacks": "#d62728",
    "mitscher_night_advance": "#9467bd",
    "larger_jp_landbased_force": "#8c564b",
}


def get_color(label):
    return SCENARIO_COLORS.get(label, "#333333")


def fig1_raid_wave_losses(scenario_results, out_dir):
    """Bar chart: JP vs US losses per raid wave (historical_baseline)."""
    try:
        rows = scenario_results.get("historical_baseline", [])
        if not rows:
            print("WARNING fig1: no historical_baseline data")
            return

        wave_labels_map = {
            "raid_1": "Raid 1\n(68 AC)",
            "raid_2": "Raid 2\n(107 AC)",
            "raid_3": "Raid 3\n(47 AC)",
            "raid_4_guam": "Raid 4/Guam\n(49 AC)",
        }
        wave_order = ["raid_1", "raid_2", "raid_3", "raid_4_guam"]

        jp_losses_per_wave = {}
        us_losses_per_wave = {}
        for r in rows:
            wl = r["raid_wave_label"]
            if wl in wave_order:
                jp_losses_per_wave[wl] = r["jp_aircraft_lost_this_wave"]
                us_losses_per_wave[wl] = r["us_aircraft_lost_this_wave"]

        x_labels = []
        jp_vals = []
        us_vals = []
        for wl in wave_order:
            if wl in jp_losses_per_wave:
                x_labels.append(wave_labels_map[wl])
                jp_vals.append(jp_losses_per_wave[wl])
                us_vals.append(us_losses_per_wave.get(wl, 0))

        if not x_labels:
            print("WARNING fig1: no wave data found")
            return

        x_labels = np.array(x_labels)
        jp_vals = np.array(jp_vals, dtype=float)
        us_vals = np.array(us_vals, dtype=float)

        assert len(x_labels) == len(jp_vals) == len(us_vals), "fig1 array length mismatch"

        x = np.arange(len(x_labels))
        width = 0.35

        fig, ax = plt.subplots(figsize=(10, 6))
        bars1 = ax.bar(x - width/2, jp_vals, width, label="Japanese Losses", color="#d62728", alpha=0.85)
        bars2 = ax.bar(x + width/2, us_vals, width, label="US Losses", color="#1f77b4", alpha=0.85)

        ax.set_xticks(x)
        ax.set_xticklabels(x_labels, fontsize=10)
        ax.set_ylabel("Aircraft Lost")
        ax.set_xlabel("Raid Wave")
        ax.set_title("Aircraft Losses per Raid Wave:\nGreat Marianas Turkey Shoot (June 19, 1944)")
        ax.legend()
        ax.grid(axis="y", alpha=0.3)

        for bar in bars1:
            h = bar.get_height()
            if h > 0:
                ax.text(bar.get_x() + bar.get_width()/2, h + 0.5, str(int(h)), ha='center', va='bottom', fontsize=8)
        for bar in bars2:
            h = bar.get_height()
            if h > 0:
                ax.text(bar.get_x() + bar.get_width()/2, h + 0.5, str(int(h)), ha='center', va='bottom', fontsize=8)

        plt.tight_layout()
        fpath = out_dir / "fig1_raid_wave_losses.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def fig2_aircraft_inventory(scenario_results, out_dir):
    """Line chart: US and JP aircraft available over time for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))
        plotted = False

        for label, rows in scenario_results.items():
            if not rows:
                continue
            times = np.array([r["time_hours"] for r in rows], dtype=float)
            jp_avail = np.array([r["jp_aircraft_available"] for r in rows], dtype=float)
            us_avail = np.array([r["us_aircraft_available"] for r in rows], dtype=float)

            assert len(times) == len(jp_avail) == len(us_avail), f"fig2 array mismatch for {label}"

            color = get_color(label)
            ax.plot(times, jp_avail, color=color, linestyle="--", alpha=0.7, linewidth=1.5, label=f"JP: {label}")
            ax.plot(times, us_avail, color=color, linestyle="-", alpha=0.7, linewidth=1.5, label=f"US: {label}")
            plotted = True

        if not plotted:
            print("WARNING fig2: no data to plot")
            plt.close()
            return

        ax.axvline(x=24, color="gray", linestyle=":", alpha=0.5, label="06:00 June 20")
        ax.set_xlabel("Time (hours from 06:00 June 19)")
        ax.set_ylabel("Aircraft Available")
        ax.set_title("Aircraft Inventory Over Time: US vs Japan (June 19-20, 1944)")
        ax.legend(fontsize=7, ncol=2)
        ax.grid(alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig2_aircraft_inventory.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def fig3_loss_ratio_vs_experience(scenario_results, out_dir):
    """Scatter: JP pilot experience vs cumulative loss ratio per scenario."""
    try:
        fig, ax = plt.subplots(figsize=(9, 6))

        exp_vals = []
        lr_vals = []
        labels = []
        colors = []

        for label, rows in scenario_results.items():
            if not rows:
                continue
            last = rows[-1]
            exp_val = last["jp_pilot_experience_factor"]
            lr_val = last["loss_ratio_cumulative"]
            exp_vals.append(exp_val)
            lr_vals.append(lr_val)
            labels.append(label)
            colors.append(get_color(label))

        if not exp_vals:
            print("WARNING fig3: no data")
            plt.close()
            return

        exp_arr = np.array(exp_vals, dtype=float)
        lr_arr = np.array(lr_vals, dtype=float)
        assert len(exp_arr) == len(lr_arr), "fig3 array mismatch"

        ax.scatter(exp_arr, lr_arr, c=colors, s=120, zorder=5, edgecolors="black", linewidths=0.8)

        for i, lbl in enumerate(labels):
            ax.annotate(lbl, (exp_arr[i], lr_arr[i]),
                        textcoords="offset points", xytext=(5, 5), fontsize=7)

        # Sweep line
        sweep_exp = np.linspace(0.1, 1.0, 50)
        sweep_lr = 4.85 * np.exp(-3.0 * (sweep_exp - 0.25))
        sweep_lr = np.clip(sweep_lr, 0.5, 15.0)
        assert len(sweep_exp) == len(sweep_lr), "fig3 sweep mismatch"
        ax.plot(sweep_exp, sweep_lr, "k--", alpha=0.4, linewidth=1, label="Model trend")

        ax.axhline(y=1.0, color="gray", linestyle=":", alpha=0.5, label="1:1 parity")
        ax.set_xlabel("Japanese Pilot Experience Factor")
        ax.set_ylabel("JP-to-US Aircraft Loss Ratio (cumulative)")
        ax.set_title("Aircraft Loss Ratio vs Japanese Pilot Experience Factor")
        ax.legend(fontsize=8)
        ax.grid(alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig3_loss_ratio_vs_experience.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def fig4_carrier_status(scenario_results, out_dir):
    """Line chart: JP carriers operational over time for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(11, 6))
        plotted = False

        for label, rows in scenario_results.items():
            if not rows:
                continue
            times = np.array([r["time_hours"] for r in rows], dtype=float)
            carriers = np.array([r["jp_carriers_operational"] for r in rows], dtype=float)
            assert len(times) == len(carriers), f"fig4 mismatch for {label}"
            color = get_color(label)
            ax.step(times, carriers, color=color, linewidth=2, label=label, where="post")
            plotted = True

        if not plotted:
            print("WARNING fig4: no data")
            plt.close()
            return

        ax.axhline(y=6, color="orange", linestyle="--", alpha=0.5, label="Degraded threshold (6)")
        ax.axhline(y=3, color="red", linestyle="--", alpha=0.5, label="Operationally defeated (3)")
        ax.set_xlabel("Time (hours from 06:00 June 19)")
        ax.set_ylabel("Japanese Carriers Operational")
        ax.set_title("Japanese Carrier Operational Status Over Battle Duration")
        ax.legend(fontsize=8)
        ax.grid(alpha=0.3)
        ax.set_ylim(-0.5, 10)
        plt.tight_layout()
        fpath = out_dir / "fig4_carrier_status.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def fig5_survival_heatmap(out_dir):
    """Heatmap: JP aircraft survival rate vs pilot experience and VT fuze multiplier."""
    try:
        n_exp = 10
        n_vt = 10
        exp_vals = np.linspace(0.1, 1.0, n_exp)
        vt_vals = np.linspace(1.0, 3.0, n_vt)

        survival_grid = np.zeros((n_vt, n_exp))

        base_kill_rate = DEFAULT_PARAMS["base_kill_rate"]
        base_aa_rate = DEFAULT_PARAMS["base_aa_rate"]
        us_pilot_exp = 0.85
        us_cap_layers = 3.0

        for i, vt in enumerate(vt_vals):
            for j, jp_exp in enumerate(exp_vals):
                exp_ratio = us_pilot_exp / max(jp_exp, 0.01)
                p_kill_per_layer = clamp(base_kill_rate * exp_ratio * vt, 0.0, 0.95)
                p_survive_cap = (1.0 - p_kill_per_layer) ** us_cap_layers
                p_kill_aa = clamp(base_aa_rate * vt, 0.0, 0.95)
                p_survive_gunline = p_survive_cap * (1.0 - p_kill_aa)
                survival_grid[i, j] = clamp(p_survive_gunline, 0.0, 1.0)

        assert survival_grid.shape == (n_vt, n_exp), "fig5 grid shape mismatch"

        fig, ax = plt.subplots(figsize=(9, 7))
        im = ax.imshow(survival_grid, origin="lower", aspect="auto",
                       extent=[exp_vals[0], exp_vals[-1], vt_vals[0], vt_vals[-1]],
                       cmap="RdBu", vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, label="Fraction of JP aircraft surviving to fleet")
        ax.set_xlabel("Japanese Pilot Experience Factor")
        ax.set_ylabel("VT Fuze Effectiveness Multiplier")
        ax.set_title("Japanese Aircraft Survival Rate Heatmap:\nPilot Skill vs. AA Technology")
        # Mark historical point
        ax.plot(0.25, 2.5, "w*", markersize=14, label="Historical (0.25, 2.5)")
        ax.legend(fontsize=8)
        plt.tight_layout()
        fpath = out_dir / "fig5_survival_heatmap.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def fig6_fuel_margin(scenario_results, out_dir):
    """Line chart: US fuel margin over time during June 20 counterattack."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False

        # Focus on scenarios relevant to fuel
        focus = ["historical_baseline", "mitscher_night_advance"]

        # Build fuel margin trajectory for June 20 phase (t=30 to t=36)
        max_range = DEFAULT_PARAMS["max_range"]
        combat_fuel_burn = DEFAULT_PARAMS["combat_fuel_burn"]

        for label in focus:
            rows = scenario_results.get(label, [])
            if not rows:
                continue

            # Get strike range for this scenario
            overrides = {}
            for sc in MODEL_PROFILE["scenarios"]:
                if sc["label"] == label:
                    overrides = sc.get("param_overrides", {})
                    break

            params_local = dict(DEFAULT_PARAMS)
            params_local.update(overrides)
            strike_range = float(params_local["us_strike_range_limit"])

            # Build fuel trajectory from t=33.67 (launch) through t=36
            t_launch = 33.67
            t_target = 34.5
            t_recovery = 36.0

            n_pts = 20
            t_arr = np.linspace(t_launch, t_recovery, n_pts)
            fuel_arr = np.zeros(n_pts)

            for k in range(n_pts):
                t = t_arr[k]
                frac = (t - t_launch) / max(t_recovery - t_launch, 0.01)
                # Outbound phase
                if t <= t_target:
                    frac_out = (t - t_launch) / max(t_target - t_launch, 0.01)
                    fuel = 1.0 - frac_out * (strike_range / max_range) * 0.45
                else:
                    # Return phase
                    fuel_at_tgt = 1.0 - (strike_range / max_range) * 0.45 - combat_fuel_burn
                    frac_ret = (t - t_target) / max(t_recovery - t_target, 0.01)
                    fuel = fuel_at_tgt - frac_ret * (strike_range / max_range) * 0.45

                # Override if mitscher scenario has fuel_margin override
                if "us_fuel_margin" in overrides:
                    fuel = float(overrides["us_fuel_margin"]) * (1.0 - frac * 0.2)

                fuel_arr[k] = clamp(fuel, 0.0, 1.0)

            assert len(t_arr) == len(fuel_arr), f"fig6 mismatch for {label}"
            color = get_color(label)
            ax.plot(t_arr, fuel_arr, color=color, linewidth=2.0, label=label)
            plotted = True

        if not plotted:
            print("WARNING fig6: no data")
            plt.close()
            return

        ax.axhline(y=0.15, color="red", linestyle="--", linewidth=1.5, label="Critical fuel threshold (0.15)")
        ax.axvspan(0, 36, ymin=0, ymax=0.15/1.0, alpha=0.1, color="red", label="Critical zone")
        ax.fill_between([30, 36], [0, 0], [0.15, 0.15], alpha=0.15, color="red")
        ax.set_xlabel("Time (hours from 06:00 June 19)")
        ax.set_ylabel("Average Fuel Margin (fraction)")
        ax.set_title("US Strike Aircraft Fuel Margin:\nJune 20 Counterattack at Extended Range")
        ax.legend(fontsize=9)
        ax.grid(alpha=0.3)
        ax.set_xlim(33.0, 36.5)
        ax.set_ylim(0, 1.05)
        plt.tight_layout()
        fpath = out_dir / "fig6_fuel_margin.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def fig7_total_losses_by_scenario(scenario_results, out_dir):
    """Grouped bar chart: Total JP and US losses per scenario with carrier overlay."""
    try:
        scenario_labels = []
        jp_loss_vals = []
        us_loss_vals = []
        jp_carr_loss_vals = []

        for label, rows in scenario_results.items():
            if not rows:
                continue
            last = rows[-1]
            first = rows[0]
            jp_loss = last["jp_aircraft_losses_cumulative"]
            us_loss = last["us_aircraft_losses_cumulative"]
            jp_carr_start = first["jp_carriers_operational"]
            jp_carr_end = last["jp_carriers_operational"]
            jp_carr_lost = max(0, jp_carr_start - jp_carr_end)

            scenario_labels.append(label)
            jp_loss_vals.append(jp_loss)
            us_loss_vals.append(us_loss)
            jp_carr_loss_vals.append(jp_carr_lost)

        if not scenario_labels:
            print("WARNING fig7: no data")
            return

        n = len(scenario_labels)
        scenario_labels = np.array(scenario_labels)
        jp_loss_arr = np.array(jp_loss_vals, dtype=float)
        us_loss_arr = np.array(us_loss_vals, dtype=float)
        jp_carr_arr = np.array(jp_carr_loss_vals, dtype=float)

        assert len(scenario_labels) == len(jp_loss_arr) == len(us_loss_arr) == len(jp_carr_arr), \
            "fig7 array mismatch"

        x = np.arange(n)
        width = 0.28

        fig, ax1 = plt.subplots(figsize=(13, 7))
        ax2 = ax1.twinx()

        bars1 = ax1.bar(x - width, jp_loss_arr, width, label="JP Aircraft Lost", color="#d62728", alpha=0.85)
        bars2 = ax1.bar(x, us_loss_arr, width, label="US Aircraft Lost", color="#1f77b4", alpha=0.85)
        bars3 = ax2.bar(x + width, jp_carr_arr, width, label="JP Carriers Lost (right)", color="#ff7f0e", alpha=0.85)

        ax1.set_xticks(x)
        ax1.set_xticklabels(scenario_labels, rotation=20, ha="right", fontsize=9)
        ax1.set_ylabel("Aircraft Lost")
        ax2.set_ylabel("Japanese Carriers Lost")
        ax1.set_title("Total Battle Losses by Scenario: Aircraft and Ships")

        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right", fontsize=8)
        ax1.grid(axis="y", alpha=0.3)

        plt.tight_layout()
        fpath = out_dir / "fig7_total_losses_by_scenario.png"
        plt.savefig(fpath, dpi=150)
        plt.close()
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


# ==============================================================================
# SUMMARY JSON
# ==============================================================================

def write_summary_json(scenario_results, out_dir):
    """Write summary.json with key aggregate metrics."""
    summary = {}
    for label, rows in scenario_results.items():
        if not rows:
            continue
        last = rows[-1]
        first = rows[0]
        summary[label] = {
            "jp_aircraft_losses_final": last["jp_aircraft_losses_cumulative"],
            "us_aircraft_losses_final": last["us_aircraft_losses_cumulative"],
            "jp_carriers_lost": max(0, first["jp_carriers_operational"] - last["jp_carriers_operational"]),
            "loss_ratio_final": last["loss_ratio_cumulative"],
            "jp_fleet_combat_power_final": last["jp_fleet_combat_power"],
            "us_fleet_combat_power_final": last["us_fleet_combat_power"],
            "us_fuel_margin_final": last["us_fuel_margin"],
            "jp_oilers_sunk": last["jp_oilers_sunk"],
            "taiko_sunk": int(last["taiko_status"] == 0),
            "shokaku_sunk": int(last["shokaku_status"] == 0),
        }

    fpath = out_dir / "summary.json"
    with open(fpath, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"Wrote {fpath}")


# ==============================================================================
# MAIN
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Battle of the Philippine Sea Simulator (June 19-20, 1944)"
    )
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files")
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir}")

    # Run all scenarios
    all_rows = []
    scenario_results = {}

    scenarios = MODEL_PROFILE["scenarios"]
    for idx, sc in enumerate(scenarios):
        label = sc["label"]
        print(f"\nRunning scenario {idx}: {label}")
        rows = run_scenario(sc, scenario_index=idx)
        scenario_results[label] = rows
        all_rows.extend(rows)
        print(f"  Generated {len(rows)} rows. "
              f"JP losses: {rows[-1]['jp_aircraft_losses_cumulative']}, "
              f"US losses: {rows[-1]['us_aircraft_losses_cumulative']}, "
              f"Loss ratio: {rows[-1]['loss_ratio_cumulative']:.2f}")

    # Write CSVs
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(scenario_results, out_dir)
    write_parameters_used(out_dir)

    # Generate figures
    print("\nGenerating figures...")
    fig1_raid_wave_losses(scenario_results, out_dir)
    fig2_aircraft_inventory(scenario_results, out_dir)
    fig3_loss_ratio_vs_experience(scenario_results, out_dir)
    fig4_carrier_status(scenario_results, out_dir)
    fig5_survival_heatmap(out_dir)
    fig6_fuel_margin(scenario_results, out_dir)
    fig7_total_losses_by_scenario(scenario_results, out_dir)

    # Write summary JSON
    write_summary_json(scenario_results, out_dir)

    print("\n=== Simulation complete ===")
    print(f"Scenario summary:")
    header = f"{'Scenario':<35} {'JP Losses':>10} {'US Losses':>10} {'Loss Ratio':>12} {'JP Carriers':>12}"
    print(header)
    print("-" * len(header))
    for label, rows in scenario_results.items():
        if rows:
            last = rows[-1]
            first = rows[0]
            jp_carr_lost = first["jp_carriers_operational"] - last["jp_carriers_operational"]
            line = (
                f"{label:<35} "
                f"{last['jp_aircraft_losses_cumulative']:>10} "
                f"{last['us_aircraft_losses_cumulative']:>10} "
                f"{last['loss_ratio_cumulative']:>12.2f} "
                f"{jp_carr_lost:>12}"
            )
            print(line)


if __name__ == "__main__":
    main()