# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-06-29T01:38:57.341459Z
# Run ID    : 5311db5f-35d7-48b3-a9c5-b96a52339434
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Pneumothorax Mobility & Intuition-Augmented Prediction Simulator

Papers:
  1. "Enhancing Clinical Prediction Performance by Incorporating Intuition" (Kartoun, JMS 2021)
  2. "Improving the management of spontaneous pneumothorax" (Kartoun, ERJ 2018)

This simulator models:
  - How IV/chest-tube placement (same vs. opposite body side) affects patient mobility,
    pain, autonomy, and comfort during spontaneous pneumothorax hospitalization.
  - How clinician intuition scores can augment ML-based risk prediction for readmission
    and adverse outcomes (AF, ASCVD).
"""

import argparse
import csv
import json
import pathlib
import dataclasses
from typing import List, Dict, Any, Optional

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "n_patients": {"value": 500, "unit": "count", "source": "assumed",
                       "description": "Number of synthetic patients in the simulated cohort"},
        "first_los_days": {"value": 4.0, "unit": "days", "source": "extracted",
                           "description": "Length of first hospital admission for pneumothorax"},
        "second_los_days": {"value": 6.0, "unit": "days", "source": "extracted",
                            "description": "Length of second hospital admission (VATS surgery)"},
        "readmission_weeks": {"value": 5.0, "unit": "weeks", "source": "extracted",
                              "description": "Time between first discharge and readmission for lung surgery"},
        "pain_reduction_same_side": {"value": 2.0, "unit": "score units", "source": "assumed",
                                     "description": "Expected pain reduction when devices on same side"},
        "mobility_gain_same_side": {"value": 2.5, "unit": "score units", "source": "assumed",
                                    "description": "Expected mobility gain when devices on same side"},
        "autonomy_gain_same_side": {"value": 2.0, "unit": "score units", "source": "assumed",
                                    "description": "Expected autonomy increase when devices on same side"},
        "walking_freq_opposite": {"value": 1.2, "unit": "walks/day", "source": "assumed",
                                  "description": "Mean daily walking frequency with devices on opposite sides"},
        "walking_freq_same": {"value": 2.8, "unit": "walks/day", "source": "assumed",
                              "description": "Mean daily walking frequency with devices on same side"},
        "staff_assist_opposite": {"value": 0.70, "unit": "fraction", "source": "assumed",
                                  "description": "Staff assistance probability with opposite-side devices"},
        "staff_assist_same": {"value": 0.35, "unit": "fraction", "source": "assumed",
                              "description": "Staff assistance probability with same-side devices"},
        "base_readmission_prob": {"value": 0.40, "unit": "probability", "source": "assumed",
                                  "description": "Baseline readmission probability within 5 weeks"},
        "intuition_auc_boost": {"value": 0.06, "unit": "AUC units", "source": "assumed",
                                "description": "AUC improvement from adding clinician intuition covariate"},
        "intuition_score_noise_sd": {"value": 1.5, "unit": "score units", "source": "assumed",
                                     "description": "SD of clinician intuition score around true risk"},
        "pain_noise_sd": {"value": 1.2, "unit": "score units", "source": "assumed",
                          "description": "SD of patient-reported pain score"},
        "mobility_noise_sd": {"value": 1.0, "unit": "score units", "source": "assumed",
                              "description": "SD of mobility score"},
        "age_pain_slope": {"value": 0.03, "unit": "score/year", "source": "assumed",
                           "description": "Pain increase per year of patient age"},
        "age_mobility_slope": {"value": -0.04, "unit": "score/year", "source": "assumed",
                               "description": "Mobility decrease per year of patient age"},
        "vats_pain_increase": {"value": 1.5, "unit": "score units", "source": "assumed",
                               "description": "Additional pain for VATS surgical admission"},
        "comfort_weight_pain": {"value": 0.4, "unit": "dimensionless", "source": "assumed",
                                "description": "Weight of inverted pain in composite comfort"},
        "comfort_weight_mobility": {"value": 0.35, "unit": "dimensionless", "source": "assumed",
                                    "description": "Weight of mobility in composite comfort"},
        "comfort_weight_autonomy": {"value": 0.25, "unit": "dimensionless", "source": "assumed",
                                    "description": "Weight of perceived autonomy in composite comfort"},
        "n_encounters_per_patient": {"value": 5.0, "unit": "count", "source": "assumed",
                                     "description": "Mean clinician encounters per admission"},
        "base_model_auc": {"value": 0.72, "unit": "AUC", "source": "assumed",
                           "description": "Baseline AUC without intuition covariate"},
        "intuition_only_auc": {"value": 0.68, "unit": "AUC", "source": "assumed",
                               "description": "AUC using intuition score as sole covariate"},
        "full_model_auc": {"value": 0.78, "unit": "AUC", "source": "assumed",
                           "description": "AUC with all covariates including intuition"},
        # Internal simulation constants
        "pain_base_opposite": {"value": 6.5, "unit": "score", "source": "assumed",
                               "description": "Mean pain score for opposite-side placement"},
        "pain_base_same": {"value": 4.5, "unit": "score", "source": "assumed",
                           "description": "Mean pain score for same-side placement"},
        "mobility_base_opposite": {"value": 4.0, "unit": "score", "source": "assumed",
                                   "description": "Mean mobility score for opposite-side placement"},
        "mobility_base_same": {"value": 6.5, "unit": "score", "source": "assumed",
                               "description": "Mean mobility score for same-side placement"},
        "autonomy_base_opposite": {"value": 3.5, "unit": "score", "source": "assumed",
                                   "description": "Mean autonomy score for opposite-side placement"},
        "autonomy_base_same": {"value": 5.5, "unit": "score", "source": "assumed",
                               "description": "Mean autonomy score for same-side placement"},
    },
    "scenarios": [
        {
            "label": "opposite_side_conservative",
            "device_conflict": 1,
            "admission_type": 0,
            "los": 4,
            "walk_base": 1.2,
            "staff_assist_base": 0.70,
            "vats_pain": 0.0,
        },
        {
            "label": "same_side_conservative",
            "device_conflict": 0,
            "admission_type": 0,
            "los": 4,
            "walk_base": 2.8,
            "staff_assist_base": 0.35,
            "vats_pain": 0.0,
        },
        {
            "label": "opposite_side_surgical",
            "device_conflict": 1,
            "admission_type": 1,
            "los": 6,
            "walk_base": 0.8,
            "staff_assist_base": 0.70,
            "vats_pain": 1.5,
        },
        {
            "label": "same_side_surgical",
            "device_conflict": 0,
            "admission_type": 1,
            "los": 6,
            "walk_base": 2.0,
            "staff_assist_base": 0.35,
            "vats_pain": 1.5,
        },
        {
            "label": "intuition_augmented_prediction",
            "device_conflict": 1,
            "admission_type": 0,
            "los": 4,
            "walk_base": 1.5,
            "staff_assist_base": 0.55,
            "vats_pain": 0.0,
            "special": True,
            "base_model_auc": 0.72,
            "intuition_only_auc": 0.68,
            "full_model_auc": 0.78,
        },
        {
            "label": "intuition_score_calibration",
            "device_conflict": 0,
            "admission_type": 0,
            "los": 4,
            "walk_base": 2.0,
            "staff_assist_base": 0.50,
            "vats_pain": 0.0,
            "special": True,
            "intuition_score_noise_sd": 1.5,
            "n_encounters_per_patient": 5,
            "base_readmission_prob": 0.40,
        },
    ],
}

# ============================================================
# SIMULATION CONSTANTS
# ============================================================
P = MODEL_PROFILE["parameters"]
PAIN_BASE_OPPOSITE   = P["pain_base_opposite"]["value"]
PAIN_BASE_SAME       = P["pain_base_same"]["value"]
PAIN_NOISE_SD        = P["pain_noise_sd"]["value"]
MOBILITY_BASE_OPP    = P["mobility_base_opposite"]["value"]
MOBILITY_BASE_SAME   = P["mobility_base_same"]["value"]
MOBILITY_NOISE_SD    = P["mobility_noise_sd"]["value"]
AUTONOMY_BASE_OPP    = P["autonomy_base_opposite"]["value"]
AUTONOMY_BASE_SAME   = P["autonomy_base_same"]["value"]
AUTONOMY_NOISE_SD    = 1.0
AGE_PAIN_SLOPE       = P["age_pain_slope"]["value"]
AGE_MOBILITY_SLOPE   = P["age_mobility_slope"]["value"]
INTUITION_NOISE_SD   = P["intuition_score_noise_sd"]["value"]
BASE_MODEL_AUC       = P["base_model_auc"]["value"]
INTUITION_ONLY_AUC   = P["intuition_only_auc"]["value"]
FULL_MODEL_AUC       = P["full_model_auc"]["value"]
N_PATIENTS           = int(P["n_patients"]["value"])
AUC_NOISE_SD         = 0.02


# ============================================================
# SIMULATION LOGIC
# ============================================================

def simulate_scenario(scenario: Dict[str, Any], n_patients: int, scenario_index: int) -> List[Dict[str, Any]]:
    """Run agent-based simulation for one scenario and return list of row records."""
    np.random.seed(scenario_index)

    label          = scenario["label"]
    device_conflict = int(scenario["device_conflict"])
    admission_type  = int(scenario["admission_type"])
    los             = int(scenario["los"])
    walk_base_val   = float(scenario["walk_base"])
    staff_assist_base = float(scenario["staff_assist_base"])
    vats_pain       = float(scenario.get("vats_pain", 0.0))

    # AUC overrides for special scenarios
    base_auc        = float(scenario.get("base_model_auc", BASE_MODEL_AUC))
    full_auc        = float(scenario.get("full_model_auc", FULL_MODEL_AUC))
    intuit_noise_sd = float(scenario.get("intuition_score_noise_sd", INTUITION_NOISE_SD))

    # Pain and mobility baselines driven by device_conflict
    pain_base_pt   = PAIN_BASE_OPPOSITE if device_conflict == 1 else PAIN_BASE_SAME
    mob_base_pt    = MOBILITY_BASE_OPP  if device_conflict == 1 else MOBILITY_BASE_SAME
    auto_base_pt   = AUTONOMY_BASE_OPP  if device_conflict == 1 else AUTONOMY_BASE_SAME

    # iv_line_side: opposite side from chest_tube when conflict=1
    chest_tube_side = 0  # left by convention
    iv_line_side    = 1 if device_conflict == 1 else 0

    records = []

    for pid in range(n_patients):
        age = np.random.uniform(18, 70)
        # Clip age to defined range
        age = float(np.clip(age, 18.0, 80.0))

        # Per-patient pain / mobility / autonomy base with age adjustments
        pain_base   = pain_base_pt + admission_type * vats_pain + (age - 30.0) * AGE_PAIN_SLOPE
        mob_base    = mob_base_pt  + (age - 30.0) * AGE_MOBILITY_SLOPE - admission_type * 1.0
        auto_base   = auto_base_pt - admission_type * 0.5

        # Staff assistance (per-patient variability)
        staff_assist = float(np.clip(staff_assist_base + np.random.normal(0.0, 0.05), 0.0, 1.0))

        # True readmission probability (differs by device_conflict)
        if device_conflict == 1:
            true_readmit_prob = float(np.random.beta(2, 3))
        else:
            true_readmit_prob = float(np.random.beta(1.5, 4))
        true_readmit_prob = float(np.clip(true_readmit_prob, 0.0, 1.0))

        # Intuition scores
        intuition_readmit = float(np.clip(
            true_readmit_prob * 10.0 + np.random.normal(0.0, intuit_noise_sd), 1.0, 10.0))
        intuition_af      = float(np.clip(
            np.random.uniform(1.0, 10.0) + np.random.normal(0.0, intuit_noise_sd), 1.0, 10.0))
        intuition_ascvd   = float(np.clip(
            np.random.uniform(1.0, 10.0) + np.random.normal(0.0, intuit_noise_sd), 1.0, 10.0))

        true_outcome = int(np.random.uniform() < true_readmit_prob)

        # AUC surrogates per patient
        auc_without = float(np.clip(np.random.normal(base_auc, AUC_NOISE_SD), 0.5, 1.0))
        auc_with    = float(np.clip(np.random.normal(full_auc,  AUC_NOISE_SD), 0.5, 1.0))

        for day in range(1, los + 1):
            decay = (day - 1) / float(los)  # 0 at day 1, approaches 1 at last day

            # Daily state variables with improvement over stay
            pain_day  = float(np.clip(
                pain_base * (1.0 - 0.15 * decay) + np.random.normal(0.0, PAIN_NOISE_SD),
                1.0, 10.0))
            mob_day   = float(np.clip(
                mob_base * (1.0 + 0.10 * decay) + np.random.normal(0.0, MOBILITY_NOISE_SD),
                0.0, 10.0))
            walk_day  = float(np.clip(
                walk_base_val * (1.0 + 0.12 * decay) + np.random.normal(0.0, 0.3),
                0.0, 8.0))
            auto_day  = float(np.clip(
                auto_base * (1.0 + 0.08 * decay) + np.random.normal(0.0, AUTONOMY_NOISE_SD),
                0.0, 10.0))

            # Composite comfort: 0.40*(10-pain) + 0.35*mobility + 0.25*autonomy
            comfort_day = float(np.clip(
                0.40 * (10.0 - pain_day) + 0.35 * mob_day + 0.25 * auto_day,
                0.0, 10.0))

            # Mobility burden (higher = worse)
            mob_burden = float(np.clip(0.5 * pain_day + 0.5 * (10.0 - mob_day), 0.0, 10.0))

            records.append({
                "patient_id":                 f"{label}_{pid}",
                "scenario":                   label,
                "admission_type":             admission_type,
                "device_conflict":            device_conflict,
                "chest_tube_side":            chest_tube_side,
                "iv_line_side":               iv_line_side,
                "patient_age":                round(age, 1),
                "encounter_day":              day,
                "los_days":                   float(los),
                "pain_intensity":             round(pain_day, 2),
                "mobility_score":             round(mob_day, 2),
                "walking_frequency":          round(walk_day, 2),
                "staff_assistance_needed":    round(staff_assist, 2),
                "perceived_autonomy":         round(auto_day, 2),
                "patient_comfort":            round(comfort_day, 2),
                "mobility_burden":            round(mob_burden, 2),
                "intuition_score_readmission": round(intuition_readmit, 1),
                "intuition_score_af":          round(intuition_af, 1),
                "intuition_score_ascvd":       round(intuition_ascvd, 1),
                "readmission_risk":            round(true_readmit_prob, 3),
                "model_auc_without_intuition": round(auc_without, 3),
                "model_auc_with_intuition":    round(auc_with, 3),
                "true_readmission_outcome":    true_outcome,
            })

    return records


def run_all_scenarios() -> List[Dict[str, Any]]:
    """Run all scenarios and return combined records."""
    all_records = []
    scenarios = MODEL_PROFILE["scenarios"]
    for idx, scenario in enumerate(scenarios):
        print(f"  Running scenario [{idx}]: {scenario['label']} ...")
        records = simulate_scenario(scenario, N_PATIENTS, scenario_index=idx)
        all_records.extend(records)
        print(f"    -> {len(records)} rows generated.")
    return all_records


# ============================================================
# CSV WRITERS
# ============================================================
SCHEMA_COLUMNS = [
    "patient_id", "scenario", "admission_type", "device_conflict",
    "chest_tube_side", "iv_line_side", "patient_age", "encounter_day",
    "los_days", "pain_intensity", "mobility_score", "walking_frequency",
    "staff_assistance_needed", "perceived_autonomy", "patient_comfort",
    "mobility_burden", "intuition_score_readmission", "intuition_score_af",
    "intuition_score_ascvd", "readmission_risk", "model_auc_without_intuition",
    "model_auc_with_intuition", "true_readmission_outcome",
]

NUMERIC_STATE_VARS = [
    "pain_intensity", "mobility_score", "walking_frequency",
    "staff_assistance_needed", "perceived_autonomy", "patient_comfort",
    "mobility_burden", "intuition_score_readmission", "intuition_score_af",
    "intuition_score_ascvd", "readmission_risk", "model_auc_without_intuition",
    "model_auc_with_intuition", "patient_age", "los_days",
]


def write_simulation_outputs_csv(records: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv with all scenario rows."""
    if not records:
        print("WARNING: No records to write to simulation_outputs.csv")
        return
    fpath = out_dir / "simulation_outputs.csv"
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=SCHEMA_COLUMNS)
        writer.writeheader()
        writer.writerows(records)
    print(f"  Written: {fpath} ({len(records)} rows)")


def compute_scenario_summary(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Compute per-scenario aggregate metrics."""
    from collections import defaultdict
    scenario_data: Dict[str, List[Dict]] = defaultdict(list)
    for r in records:
        scenario_data[r["scenario"]].append(r)

    summary_rows = []
    for scenario_label, rows in scenario_data.items():
        row = {"scenario": scenario_label, "n_rows": len(rows)}
        for col in NUMERIC_STATE_VARS:
            vals = np.array([r[col] for r in rows], dtype=float)
            row[f"{col}_mean"] = round(float(np.mean(vals)), 4)
            row[f"{col}_std"]  = round(float(np.std(vals)),  4)
            row[f"{col}_min"]  = round(float(np.min(vals)),  4)
            row[f"{col}_max"]  = round(float(np.max(vals)),  4)
        # AUROC / KPI
        auc_without_vals = np.array([r["model_auc_without_intuition"] for r in rows], dtype=float)
        auc_with_vals    = np.array([r["model_auc_with_intuition"]    for r in rows], dtype=float)
        row["mean_auc_without_intuition"] = round(float(np.mean(auc_without_vals)), 4)
        row["mean_auc_with_intuition"]    = round(float(np.mean(auc_with_vals)), 4)
        row["readmission_rate"]           = round(float(np.mean([r["true_readmission_outcome"] for r in rows])), 4)
        summary_rows.append(row)
    return summary_rows


def write_scenario_summary_csv(records: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv."""
    if not records:
        print("WARNING: No records to summarize.")
        return
    summary_rows = compute_scenario_summary(records)
    if not summary_rows:
        print("WARNING: scenario summary is empty.")
        return
    fpath = out_dir / "scenario_summary.csv"
    fieldnames = list(summary_rows[0].keys())
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"  Written: {fpath} ({len(summary_rows)} rows)")


def write_parameters_csv(out_dir: pathlib.Path) -> None:
    """Write parameters_used.csv."""
    params = MODEL_PROFILE["parameters"]
    rows = []
    for name, info in params.items():
        rows.append({
            "name":        name,
            "value":       info["value"],
            "unit":        info["unit"],
            "source":      info["source"],
            "description": info["description"],
        })
    fpath = out_dir / "parameters_used.csv"
    with open(fpath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"  Written: {fpath} ({len(rows)} rows)")


def write_summary_json(records: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write summary.json with aggregate metrics."""
    if not records:
        print("WARNING: No records for summary.json")
        return
    summary_rows = compute_scenario_summary(records)
    # Build compact metrics
    metrics = {}
    for row in summary_rows:
        sc = row["scenario"]
        metrics[sc] = {
            "n_rows":                   row["n_rows"],
            "mean_pain_intensity":      row.get("pain_intensity_mean"),
            "mean_mobility_score":      row.get("mobility_score_mean"),
            "mean_patient_comfort":     row.get("patient_comfort_mean"),
            "mean_walking_frequency":   row.get("walking_frequency_mean"),
            "mean_auc_without":         row.get("mean_auc_without_intuition"),
            "mean_auc_with":            row.get("mean_auc_with_intuition"),
            "readmission_rate":         row.get("readmission_rate"),
        }
    out = {
        "title": "Pneumothorax Mobility & Intuition-Augmented Prediction Simulator",
        "n_total_rows": len(records),
        "n_scenarios": len(metrics),
        "scenario_metrics": metrics,
    }
    fpath = out_dir / "summary.json"
    with open(fpath, "w") as f:
        json.dump(out, f, indent=2)
    print(f"  Written: {fpath}")


# ============================================================
# FIGURE HELPERS
# ============================================================

def get_scenario_data(records: List[Dict], scenario_labels: List[str]) -> Dict[str, List[Dict]]:
    """Group records by scenario label."""
    grouped: Dict[str, List[Dict]] = {lbl: [] for lbl in scenario_labels}
    for r in records:
        if r["scenario"] in grouped:
            grouped[r["scenario"]].append(r)
    return grouped


def _get_vals(rows: List[Dict], col: str) -> np.ndarray:
    return np.array([r[col] for r in rows], dtype=float)


# ============================================================
# FIGURE GENERATORS
# ============================================================

SCENARIO_COLORS = {
    "opposite_side_conservative": "#d62728",
    "same_side_conservative":     "#1f77b4",
    "opposite_side_surgical":     "#ff7f0e",
    "same_side_surgical":         "#2ca02c",
    "intuition_augmented_prediction": "#9467bd",
    "intuition_score_calibration":    "#8c564b",
}


def fig1_pain_by_placement(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig1: Scatter pain_intensity by device_conflict with jitter + box overlay."""
    try:
        conflict_vals = np.array([r["device_conflict"] for r in records], dtype=float)
        pain_vals     = np.array([r["pain_intensity"]  for r in records], dtype=float)
        assert len(conflict_vals) == len(pain_vals), "Length mismatch fig1"
        if len(conflict_vals) == 0:
            print("WARNING fig1: empty data, skipping.")
            return

        fig, ax = plt.subplots(figsize=(8, 6))
        jitter = np.random.default_rng(0).uniform(-0.15, 0.15, size=len(conflict_vals))
        colors = np.where(conflict_vals == 1, "#d62728", "#1f77b4")

        mask_opp  = conflict_vals == 1
        mask_same = conflict_vals == 0

        ax.scatter(conflict_vals[mask_opp]  + jitter[mask_opp],  pain_vals[mask_opp],
                   alpha=0.3, s=8, c="#d62728", label="Opposite Side")
        ax.scatter(conflict_vals[mask_same] + jitter[mask_same], pain_vals[mask_same],
                   alpha=0.3, s=8, c="#1f77b4", label="Same Side")

        # Box plots
        bp = ax.boxplot([pain_vals[mask_opp], pain_vals[mask_same]],
                        positions=[1.0, 0.0], widths=0.25,
                        patch_artist=True,
                        boxprops=dict(alpha=0.7),
                        medianprops=dict(color="black", linewidth=2))
        bp["boxes"][0].set_facecolor("#d62728")
        bp["boxes"][1].set_facecolor("#1f77b4")

        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Same Side\n(conflict=0)", "Opposite Side\n(conflict=1)"], fontsize=12)
        ax.set_ylabel("Pain Intensity (1-10)", fontsize=12)
        ax.set_title("Pain Intensity by Device Placement Configuration", fontsize=13, fontweight="bold")
        ax.legend(fontsize=10)
        ax.set_ylim(0.5, 10.5)
        ax.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig1_pain_by_placement.png", dpi=150)
        plt.close()
        print("  Saved: fig1_pain_by_placement.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")
        plt.close("all")


def fig2_mobility_histograms(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig2: Overlapping histograms of mobility_score by device placement group."""
    try:
        conflict_vals  = np.array([r["device_conflict"]  for r in records], dtype=float)
        mobility_vals  = np.array([r["mobility_score"]   for r in records], dtype=float)
        assert len(conflict_vals) == len(mobility_vals), "Length mismatch fig2"
        if len(conflict_vals) == 0:
            print("WARNING fig2: empty data, skipping.")
            return

        opp_mob  = mobility_vals[conflict_vals == 1]
        same_mob = mobility_vals[conflict_vals == 0]

        if len(opp_mob) == 0 or len(same_mob) == 0:
            print("WARNING fig2: one group empty, skipping.")
            return

        fig, ax = plt.subplots(figsize=(8, 6))
        bins = np.linspace(0, 10, 30)
        ax.hist(opp_mob,  bins=bins, alpha=0.6, color="#d62728", label="Opposite Side", density=False)
        ax.hist(same_mob, bins=bins, alpha=0.6, color="#1f77b4", label="Same Side",     density=False)
        ax.set_xlabel("Mobility Score (0-10)", fontsize=12)
        ax.set_ylabel("Count", fontsize=12)
        ax.set_title("Distribution of Mobility Scores:\nSame-Side vs. Opposite-Side Device Placement",
                     fontsize=13, fontweight="bold")
        ax.legend(fontsize=11)
        ax.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig2_mobility_histograms.png", dpi=150)
        plt.close()
        print("  Saved: fig2_mobility_histograms.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")
        plt.close("all")


def fig3_walking_frequency_over_days(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig3: Line plot mean walking_frequency per encounter_day by scenario (4 device-admission combos)."""
    try:
        target_labels = [
            "opposite_side_conservative",
            "same_side_conservative",
            "opposite_side_surgical",
            "same_side_surgical",
        ]
        colors_map = {
            "opposite_side_conservative": "#d62728",
            "same_side_conservative":     "#1f77b4",
            "opposite_side_surgical":     "#ff7f0e",
            "same_side_surgical":         "#2ca02c",
        }
        style_map = {
            "opposite_side_conservative": "-",
            "same_side_conservative":     "-",
            "opposite_side_surgical":     "--",
            "same_side_surgical":         "--",
        }
        los_map = {
            "opposite_side_conservative": 4,
            "same_side_conservative":     4,
            "opposite_side_surgical":     6,
            "same_side_surgical":         6,
        }

        grouped = {lbl: [] for lbl in target_labels}
        for r in records:
            if r["scenario"] in grouped:
                grouped[r["scenario"]].append(r)

        fig, ax = plt.subplots(figsize=(9, 6))
        for lbl in target_labels:
            rows = grouped[lbl]
            if not rows:
                continue
            los_days = los_map[lbl]
            days_arr = np.arange(1, los_days + 1)
            means = np.zeros(len(days_arr))
            stds  = np.zeros(len(days_arr))
            for i, day in enumerate(days_arr):
                wf = np.array([r["walking_frequency"] for r in rows if r["encounter_day"] == day], dtype=float)
                if len(wf) == 0:
                    continue
                means[i] = np.mean(wf)
                stds[i]  = np.std(wf)
            assert len(days_arr) == len(means), "Length mismatch fig3"
            assert len(days_arr) == len(stds),  "Length mismatch fig3 stds"
            color = colors_map[lbl]
            ls    = style_map[lbl]
            ax.plot(days_arr, means, color=color, linestyle=ls, linewidth=2, marker="o", markersize=5, label=lbl.replace("_", " "))
            ax.fill_between(days_arr, means - stds, means + stds, color=color, alpha=0.15)

        ax.set_xlabel("Encounter Day", fontsize=12)
        ax.set_ylabel("Walking Frequency (walks/day)", fontsize=12)
        ax.set_title("Daily Walking Frequency Over Hospitalization:\nSame-Side vs. Opposite-Side Placement",
                     fontsize=13, fontweight="bold")
        ax.legend(fontsize=9, loc="lower right")
        ax.set_xlim(0.5, 6.5)
        ax.set_ylim(0, 5)
        ax.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig3_walking_frequency_over_days.png", dpi=150)
        plt.close()
        print("  Saved: fig3_walking_frequency_over_days.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")
        plt.close("all")


def fig4_heatmap_comfort(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig4: 2x2 heatmap mean patient_comfort by [admission_type x device_conflict]."""
    try:
        target_labels = [
            "opposite_side_conservative", "same_side_conservative",
            "opposite_side_surgical",     "same_side_surgical",
        ]
        filtered = [r for r in records if r["scenario"] in target_labels]
        if not filtered:
            print("WARNING fig4: no matching records, skipping.")
            return

        # Build 2x2 matrix: rows=admission_type (0,1), cols=device_conflict (0,1)
        heat = np.zeros((2, 2))
        count_mat = np.zeros((2, 2), dtype=int)
        for r in filtered:
            at = int(r["admission_type"])
            dc = int(r["device_conflict"])
            heat[at, dc]      += r["patient_comfort"]
            count_mat[at, dc] += 1

        for i in range(2):
            for j in range(2):
                if count_mat[i, j] > 0:
                    heat[i, j] /= count_mat[i, j]

        fig, ax = plt.subplots(figsize=(6, 5))
        im = ax.imshow(heat, cmap="YlOrRd", vmin=0, vmax=10, aspect="auto")
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label("Mean Patient Comfort (0-10)", fontsize=10)

        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Same Side\n(conflict=0)", "Opposite Side\n(conflict=1)"], fontsize=11)
        ax.set_yticks([0, 1])
        ax.set_yticklabels(["Conservative\n(type=0)", "Surgical VATS\n(type=1)"], fontsize=11)
        ax.set_xlabel("Device Placement", fontsize=12)
        ax.set_ylabel("Admission Type", fontsize=12)
        ax.set_title("Mean Patient Comfort by Device Configuration\nand Admission Type", fontsize=13, fontweight="bold")

        for i in range(2):
            for j in range(2):
                ax.text(j, i, f"{heat[i, j]:.2f}", ha="center", va="center",
                        fontsize=14, fontweight="bold",
                        color="black" if heat[i, j] > 5 else "white")

        plt.tight_layout()
        plt.savefig(out_dir / "fig4_heatmap_comfort.png", dpi=150)
        plt.close()
        print("  Saved: fig4_heatmap_comfort.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")
        plt.close("all")


def fig5_intuition_vs_readmission(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig5: Scatter intuition_score_readmission vs readmission_risk with regression line."""
    try:
        # Use one row per patient (first encounter) to avoid duplication
        seen = set()
        patient_rows = []
        for r in records:
            pid = r["patient_id"]
            if pid not in seen:
                seen.add(pid)
                patient_rows.append(r)

        if not patient_rows:
            print("WARNING fig5: no patient rows, skipping.")
            return

        x_arr = np.array([r["intuition_score_readmission"] for r in patient_rows], dtype=float)
        y_arr = np.array([r["readmission_risk"]             for r in patient_rows], dtype=float)
        assert len(x_arr) == len(y_arr), "Length mismatch fig5"

        # Linear regression
        coeffs  = np.polyfit(x_arr, y_arr, 1)
        poly_fn = np.poly1d(coeffs)
        x_line  = np.linspace(float(x_arr.min()), float(x_arr.max()), 100)
        y_line  = poly_fn(x_line)

        # R-squared
        y_pred   = poly_fn(x_arr)
        ss_res   = np.sum((y_arr - y_pred) ** 2)
        ss_tot   = np.sum((y_arr - np.mean(y_arr)) ** 2)
        r_sq     = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
        corr     = float(np.corrcoef(x_arr, y_arr)[0, 1])

        fig, ax = plt.subplots(figsize=(8, 6))
        ax.scatter(x_arr, y_arr, alpha=0.25, s=10, c="#5b8db8", label="Patient")
        ax.plot(x_line, y_line, color="#d62728", linewidth=2, label=f"Regression (R²={r_sq:.3f})")

        # Reference annotation
        ax.axvline(x=8.0, color="orange", linestyle="--", alpha=0.7)
        ax.axhline(y=0.7, color="orange", linestyle="--", alpha=0.7)
        ax.annotate("Chief physician\nhigh-confidence\nprediction",
                    xy=(8, 0.7), xytext=(8.5, 0.55),
                    arrowprops=dict(arrowstyle="->", color="orange"),
                    fontsize=9, color="orange")

        ax.set_xlabel("Clinician Intuition Score (1-10)", fontsize=12)
        ax.set_ylabel("Actual Readmission Risk (0-1)", fontsize=12)
        ax.set_title("Clinician Intuition Score vs. Actual Readmission Probability",
                     fontsize=13, fontweight="bold")
        ax.text(0.05, 0.92, f"r = {corr:.3f},  R² = {r_sq:.3f}",
                transform=ax.transAxes, fontsize=10,
                bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5))
        ax.set_xlim(0.5, 10.5)
        ax.set_ylim(-0.05, 1.05)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig5_intuition_vs_readmission.png", dpi=150)
        plt.close()
        print("  Saved: fig5_intuition_vs_readmission.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")
        plt.close("all")


def fig6_auc_comparison(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig6: Grouped bar chart AUC for 3 model variants x 3 outcome horizons."""
    try:
        # Use intuition_augmented_prediction scenario data if available, else all data
        aug_rows = [r for r in records if r["scenario"] == "intuition_augmented_prediction"]
        if len(aug_rows) < 10:
            aug_rows = records  # fall back to all

        # Extract per-patient AUC values (deduplicate by patient)
        seen = set()
        patient_rows = []
        for r in aug_rows:
            pid = r["patient_id"]
            if pid not in seen:
                seen.add(pid)
                patient_rows.append(r)

        if not patient_rows:
            print("WARNING fig6: no data, skipping.")
            return

        # Three model variants, three outcome horizons
        # Simulate AUC distributions for each outcome x model variant
        np.random.seed(42)
        n_boot = len(patient_rows)

        outcomes = ["30-day Readmission", "5-year AF", "10-year ASCVD"]
        model_variants = ["Standard\n(no intuition)", "Intuition\nOnly", "Full Model\n(+intuition)"]

        # AUC means per outcome x model variant (clinically motivated)
        auc_means = np.array([
            [0.72, 0.68, 0.78],   # 30-day readmission
            [0.70, 0.65, 0.74],   # 5-year AF (weaker signal for intuition)
            [0.69, 0.63, 0.73],   # 10-year ASCVD
        ])
        auc_sds = np.array([
            [0.02, 0.025, 0.02],
            [0.022, 0.027, 0.022],
            [0.023, 0.030, 0.023],
        ])

        n_outcomes  = len(outcomes)
        n_variants  = len(model_variants)
        x           = np.arange(n_outcomes)
        width       = 0.25
        offset      = np.array([-width, 0, width])
        bar_colors  = ["#1f77b4", "#ff7f0e", "#2ca02c"]

        fig, ax = plt.subplots(figsize=(10, 6))
        for vi in range(n_variants):
            bar_positions = x + offset[vi]
            bar_heights   = auc_means[:, vi]
            bar_errors    = auc_sds[:, vi]
            assert len(bar_positions) == len(bar_heights), "Length mismatch fig6"
            assert len(bar_positions) == len(bar_errors),  "Length mismatch fig6 errors"
            ax.bar(bar_positions, bar_heights, width=width * 0.9,
                   color=bar_colors[vi], alpha=0.85,
                   label=model_variants[vi], zorder=3)
            ax.errorbar(bar_positions, bar_heights, yerr=bar_errors,
                        fmt="none", ecolor="black", capsize=4, linewidth=1.5, zorder=4)

        ax.set_xticks(x)
        ax.set_xticklabels(outcomes, fontsize=12)
        ax.set_ylabel("AUC (Area Under ROC Curve)", fontsize=12)
        ax.set_title("Prediction Model AUC:\nStandard Covariates vs. Intuition-Only vs. Full Model",
                     fontsize=13, fontweight="bold")
        ax.set_ylim(0.5, 0.9)
        ax.legend(fontsize=10)
        ax.axhline(y=0.5, color="gray", linestyle="--", alpha=0.5, linewidth=1)
        ax.grid(axis="y", alpha=0.3, zorder=0)
        plt.tight_layout()
        plt.savefig(out_dir / "fig6_auc_comparison.png", dpi=150)
        plt.close()
        print("  Saved: fig6_auc_comparison.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")
        plt.close("all")


def fig7_autonomy_vs_assistance(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig7: Scatter perceived_autonomy vs staff_assistance_needed colored by scenario."""
    try:
        target_labels = [
            "opposite_side_conservative", "same_side_conservative",
            "opposite_side_surgical",     "same_side_surgical",
        ]
        colors_map = {
            "opposite_side_conservative": "#d62728",
            "same_side_conservative":     "#1f77b4",
            "opposite_side_surgical":     "#ff7f0e",
            "same_side_surgical":         "#2ca02c",
        }

        # One row per patient
        seen = set()
        patient_rows = []
        for r in records:
            if r["scenario"] in target_labels:
                pid = r["patient_id"]
                if pid not in seen:
                    seen.add(pid)
                    patient_rows.append(r)

        if not patient_rows:
            print("WARNING fig7: no matching patient rows, skipping.")
            return

        fig, ax = plt.subplots(figsize=(8, 6))
        for lbl in target_labels:
            rows = [r for r in patient_rows if r["scenario"] == lbl]
            if not rows:
                continue
            x_arr = np.array([r["perceived_autonomy"]      for r in rows], dtype=float)
            y_arr = np.array([r["staff_assistance_needed"]  for r in rows], dtype=float)
            assert len(x_arr) == len(y_arr), f"Length mismatch fig7 {lbl}"
            if len(x_arr) == 0:
                continue
            ax.scatter(x_arr, y_arr, alpha=0.35, s=12,
                       color=colors_map[lbl], label=lbl.replace("_", " "))

        ax.set_xlabel("Perceived Autonomy (0-10)", fontsize=12)
        ax.set_ylabel("Staff Assistance Needed (fraction 0-1)", fontsize=12)
        ax.set_title("Perceived Autonomy vs. Staff Assistance Required:\nDevice Placement Scenarios",
                     fontsize=13, fontweight="bold")
        ax.set_xlim(-0.5, 10.5)
        ax.set_ylim(-0.05, 1.05)
        ax.legend(fontsize=8, loc="upper right")
        ax.grid(alpha=0.3)

        # Quadrant annotations
        ax.text(8.5, 0.1, "High autonomy\nLow assistance", fontsize=8, color="gray", ha="center")
        ax.text(1.5, 0.9, "Low autonomy\nHigh assistance", fontsize=8, color="gray", ha="center")

        plt.tight_layout()
        plt.savefig(out_dir / "fig7_autonomy_vs_assistance.png", dpi=150)
        plt.close()
        print("  Saved: fig7_autonomy_vs_assistance.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")
        plt.close("all")


def fig8_mobility_burden_trajectories(records: List[Dict], out_dir: pathlib.Path) -> None:
    """Fig8: Spaghetti trajectory plot of mobility_burden per day for 50 random patients."""
    try:
        target_labels = [
            "opposite_side_conservative", "same_side_conservative",
            "opposite_side_surgical",     "same_side_surgical",
        ]
        color_base = {
            "opposite_side_conservative": "#d62728",
            "same_side_conservative":     "#1f77b4",
            "opposite_side_surgical":     "#ff7f0e",
            "same_side_surgical":         "#2ca02c",
        }
        linestyle_map = {
            "opposite_side_conservative": "-",
            "same_side_conservative":     "-",
            "opposite_side_surgical":     "--",
            "same_side_surgical":         "--",
        }

        # Collect unique patient IDs per scenario
        patient_days: Dict[str, Dict[str, list]] = {lbl: {} for lbl in target_labels}
        for r in records:
            sc = r["scenario"]
            if sc not in target_labels:
                continue
            pid = r["patient_id"]
            if pid not in patient_days[sc]:
                patient_days[sc][pid] = []
            patient_days[sc][pid].append((int(r["encounter_day"]), float(r["mobility_burden"])))

        fig, ax = plt.subplots(figsize=(10, 6))
        np.random.seed(99)
        n_per_scenario = 13  # ~52 total

        legend_handles = []
        for lbl in target_labels:
            pids = list(patient_days[lbl].keys())
            if not pids:
                continue
            sample_size = min(n_per_scenario, len(pids))
            chosen_pids = np.random.choice(pids, size=sample_size, replace=False)
            color = color_base[lbl]
            ls    = linestyle_map[lbl]

            for pid in chosen_pids:
                day_burden = sorted(patient_days[lbl][pid], key=lambda x: x[0])
                days = np.array([d for d, _ in day_burden], dtype=float)
                burdens = np.array([b for _, b in day_burden], dtype=float)
                if len(days) != len(burdens):
                    continue
                if len(days) == 0:
                    continue
                ax.plot(days, burdens, color=color, linestyle=ls, alpha=0.35, linewidth=0.9)

            # Add one solid line for legend
            patch = mpatches.Patch(color=color, linestyle=ls, label=lbl.replace("_", " "))
            legend_handles.append(patch)

        ax.set_xlabel("Encounter Day", fontsize=12)
        ax.set_ylabel("Mobility Burden (0-10, higher=worse)", fontsize=12)
        ax.set_title("Individual Patient Mobility Burden Trajectories\nAcross Hospitalization",
                     fontsize=13, fontweight="bold")
        ax.legend(handles=legend_handles, fontsize=9, loc="upper right")
        ax.set_xlim(0.5, 6.5)
        ax.set_ylim(-0.5, 10.5)
        ax.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig8_mobility_burden_trajectories.png", dpi=150)
        plt.close()
        print("  Saved: fig8_mobility_burden_trajectories.png")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")
        plt.close("all")


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Pneumothorax Mobility & Intuition-Augmented Prediction Simulator"
    )
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all generated files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # ---- Run Simulation ----
    print("\n[1] Running agent-based simulation across all scenarios ...")
    all_records = run_all_scenarios()
    print(f"  Total records: {len(all_records)}")

    # ---- Write CSVs ----
    print("\n[2] Writing CSV files ...")
    write_simulation_outputs_csv(all_records, out_dir)
    write_scenario_summary_csv(all_records, out_dir)
    write_parameters_csv(out_dir)

    # ---- Write JSON Summary ----
    print("\n[3] Writing summary.json ...")
    write_summary_json(all_records, out_dir)

    # ---- Generate Figures ----
    print("\n[4] Generating figures ...")
    fig1_pain_by_placement(all_records, out_dir)
    fig2_mobility_histograms(all_records, out_dir)
    fig3_walking_frequency_over_days(all_records, out_dir)
    fig4_heatmap_comfort(all_records, out_dir)
    fig5_intuition_vs_readmission(all_records, out_dir)
    fig6_auc_comparison(all_records, out_dir)
    fig7_autonomy_vs_assistance(all_records, out_dir)
    fig8_mobility_burden_trajectories(all_records, out_dir)

    print(f"\n[Done] All outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()