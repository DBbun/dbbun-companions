================================================================
      DBbun LLC — Executable Publication Layer
      Simulator Bundle  |  paper_to_simulator_builder v3.4.0
      ================================================================
      Vendor      : DBbun LLC  |  dbbun.com
      CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
      Run ID      : 5311db5f-35d7-48b3-a9c5-b96a52339434
      Generated   : 2026-06-29  01:38:57 UTC
      © 2024-2025 DBbun LLC. All rights reserved.
      ================================================================

      TITLE
      -----
      Enhancing Clinical Prediction Performance by Incorporating Intuition
Improving the management of spontaneous pneumothorax

      CATEGORIES
      ----------
      Biomedical and Health Sciences, Health, Machine Learning, Signal Processing, Social Sciences

      KEYWORDS
      --------
      spontaneous pneumothorax, patient mobility, clinical prediction, clinician intuition, patient-centered design, device placement, machine learning risk score, electronic health records, video-assisted thoracoscopic surgery, disability access

      ABSTRACT
      --------
      This simulator models the patient-centered consequences of medical device placement decisions during spontaneous pneumothorax hospitalization, specifically comparing scenarios where an IV infusion set and chest tube are mounted on the same versus opposite sides of the patient's body. Drawing directly from first-person clinical accounts and peer-reviewed guideline literature, the simulator generates synthetic patient cohorts with realistic distributions of pain intensity, mobility scores, walking frequency, staff assistance requirements, perceived autonomy, and composite comfort over multi-day hospital stays. A second simulation strand operationalizes the hypothesis from Kartoun (2021) that incorporating clinician intuition scores as novel covariates in machine learning prediction models can improve AUC for outcomes including 30-day readmission, 5-year atrial fibrillation incidence, and 10-year ASCVD risk. Researchers, clinicians, guideline developers, and disability scholars can use this simulator to quantify the mobility and dignity costs of standard opposite-side placement, assess the marginal predictive value of capturing clinician intuition in EMR systems, and generate publication-quality figures for educational or advocacy purposes.

      DATA FORMAT
      -----------
      CSV, PNG, JSON

      SOURCE FILES
      ------------
      EnhancingClinicalPredictionPerformancebyIncorporatingIntuition.pdf
Eur Respir J-2018-Kartoun-1801857.pdf
Prompt June 28 2026.txt

      SIMULATION BACKEND
      ------------------
      agent_based

      STATE VARIABLES
      ---------------
      chest_tube_side, iv_line_side, device_conflict, pain_intensity, mobility_score, walking_frequency, staff_assistance_needed, perceived_autonomy, patient_comfort, mobility_burden, los_days, admission_type, readmission_risk, intuition_score_readmission, intuition_score_af, intuition_score_ascvd, model_auc_without_intuition, model_auc_with_intuition, encounter_day, patient_age

      SCENARIOS  (6 total)
      ---------------------------------
          1. opposite_side_conservative — IV line and chest tube on opposite sides of the body, first admission managed conservatively (no surgery). Represents the status-quo clinical practice and its impact on mobility and pain.
  2. same_side_conservative — IV line and chest tube on the same side of the body, first admission managed conservatively. Represents the proposed guideline improvement and its mobility and autonomy benefits.
  3. opposite_side_surgical — IV line and chest tube on opposite sides, second admission resulting in VATS surgery. Represents the more intensive clinical scenario with higher baseline pain and longer stay.
  4. same_side_surgical — IV line and chest tube on the same side, second admission with VATS surgery. Shows mobility and autonomy benefits of same-side placement even in more painful post-surgical context.
  5. intuition_augmented_prediction — Prediction model comparison: standard covariates only vs. intuition-only vs. full model with intuition covariate. Explores AUC improvement from incorporating clinician intuition scores for readmission and AF risk.
  6. intuition_score_calibration — Simulates how well clinician intuition scores correlate with actual patient outcomes across encounter history, varying noise level and follow-up length. Inspired by the paper's discussion of long follow-up requirements.

      PARAMETERS
      ----------
      26 parameters (see simulation_spec.json for full list with units and sources)

      FIGURES PLANNED
      ---------------
      fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

      DOMAIN SUMMARY
      --------------
      This simulator models how clinical device placement decisions (IV line and chest tube on same vs. opposite body sides) affect spontaneous pneumothorax patient mobility, pain, autonomy, and comfort during hospitalization, and how clinician intuition scores can augment machine learning-based risk prediction for readmission and adverse outcomes.

      FILES IN THIS BUNDLE
      --------------------
      Simulator.py          — runnable document-specific simulator (Python)
      Spec.json    — full analysis spec with DBbun provenance (JSON)
      Documentation.pdf       — auto-generated simulator documentation (PDF)
      README.txt                  — this file
      NOTICE.txt              — legal ownership notice
      sim_outputs/            — CSV datasets, PNG figures, summary.json
        simulation_outputs.csv      — full per-step simulation rows
        scenario_summary.csv        — one row per scenario with aggregate KPIs
        parameters_used.csv         — reproducibility / parameter provenance table
        summary.json                — key aggregate metrics
        *.png                       — publication-quality figures

      INSTRUCTIONS
      ------------
      Requirements:
          pip install numpy matplotlib

      Run with defaults:
          python Simulator.py

      Specify output directory:
          python Simulator.py --output ./my_results

      The simulator is self-contained — no API key or network access needed.
      All parameters are embedded in MODEL_PROFILE at the top of the script
      and can be edited directly to explore sensitivity or extend scenarios.

      See NOTICE.txt for full legal and licensing terms.