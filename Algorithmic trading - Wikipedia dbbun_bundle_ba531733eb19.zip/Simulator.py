# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-27T18:43:21.785759Z
# Run ID    : f229adb8-6191-4286-ad58-1ff45e9997b3
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Algorithmic Trading Simulator
Based on: 'Algorithmic Trading - Wikipedia'

This simulator models key phenomena of algorithmic and high-frequency trading,
including price dynamics under GBM and Ornstein-Uhlenbeck mean reversion,
bid-ask spread compression from market decimalization, and the performance of
canonical strategies such as mean reversion, moving average crossover, VWAP
execution, pairs trading, directional change algorithms, flash crash dynamics,
HFT latency advantage effects, and the Binomial Evolution Function.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "title": "Algorithmic Trading Simulator",
    "source": "Algorithmic Trading - Wikipedia",
    "parameters": {
        "mu": 0.0001,
        "sigma": 0.002,
        "tick_size_pre_2001": 0.0625,
        "tick_size_post_2001": 0.01,
        "half_spread_base": 0.0625,
        "half_spread_decimal": 0.01,
        "mean_reversion_speed": 0.05,
        "mean_reversion_level": 100.0,
        "vwap_window": 20,
        "twap_window": 20,
        "ma_short_window": 50,
        "ma_long_window": 100,
        "hft_market_share_2009": 0.73,
        "hft_market_share_2012": 0.50,
        "algo_market_share_2003": 0.15,
        "algo_market_share_2004": 0.20,
        "algo_market_share_2005": 0.25,
        "algo_market_share_2006": 0.30,
        "algo_market_share_2007": 0.45,
        "algo_market_share_2008": 0.60,
        "algo_market_share_2009": 0.75,
        "algo_market_share_2010": 0.80,
        "algo_market_share_2011": 0.83,
        "algo_market_share_2012": 0.85,
        "forex_algo_share_2016": 0.80,
        "forex_algo_share_2006": 0.25,
        "sp500_passive_loss_bps": 24.5,
        "russell2000_passive_loss_bps": 57.5,
        "large_order_size": 10000.0,
        "order_slice_size": 100.0,
        "pairs_mean_spread": 0.0,
        "pairs_sigma": 1.0,
        "pairs_entry_z": 2.0,
        "pairs_exit_z": 0.5,
        "hft_latency_normal": 5.0,
        "hft_latency_ultra": 0.5,
        "dc_threshold": 0.005,
        "flash_crash_shock": -0.10,
        "flash_crash_recovery_speed": 0.5,
        "num_steps": 1000,
        "n_trades_binomial": 100,
        "strategy_win_rate": 0.55,
        "algo_market_share": 0.15,
        "initial_capital": 100000.0,
    },
    "scenarios": [
        {
            "label": "pre_decimalization_market_making",
            "param_overrides": {
                "half_spread_base": 0.0625,
                "tick_size_pre_2001": 0.0625,
                "sigma": 0.002,
                "mu": 0.0001,
                "algo_market_share": 0.15
            }
        },
        {
            "label": "post_decimalization_market_making",
            "param_overrides": {
                "half_spread_base": 0.01,
                "tick_size_post_2001": 0.01,
                "sigma": 0.002,
                "mu": 0.0001,
                "algo_market_share": 0.60
            }
        },
        {
            "label": "mean_reversion_strategy",
            "param_overrides": {
                "mean_reversion_speed": 0.05,
                "mean_reversion_level": 100.0,
                "sigma": 0.003,
                "mu": 0.0,
                "algo_market_share": 0.50
            }
        },
        {
            "label": "pairs_trading_strategy",
            "param_overrides": {
                "pairs_entry_z": 2.0,
                "pairs_exit_z": 0.5,
                "pairs_sigma": 1.0,
                "mean_reversion_speed": 0.08,
                "sigma": 0.002
            }
        },
        {
            "label": "vwap_execution_algorithm",
            "param_overrides": {
                "large_order_size": 10000.0,
                "order_slice_size": 100.0,
                "vwap_window": 20,
                "sigma": 0.002,
                "mu": 0.0001
            }
        },
        {
            "label": "flash_crash_event",
            "param_overrides": {
                "flash_crash_shock": -0.10,
                "flash_crash_recovery_speed": 0.5,
                "sigma": 0.005,
                "mu": 0.0,
                "algo_market_share": 0.73
            }
        },
        {
            "label": "hft_latency_advantage",
            "param_overrides": {
                "hft_latency_ultra": 0.5,
                "hft_latency_normal": 5.0,
                "sigma": 0.003,
                "mu": 0.0002,
                "algo_market_share": 0.73
            }
        },
        {
            "label": "directional_change_algorithm",
            "param_overrides": {
                "dc_threshold": 0.005,
                "sigma": 0.004,
                "mu": 0.0001,
                "algo_market_share": 0.60
            }
        },
        {
            "label": "algo_market_share_growth_2003_2012",
            "param_overrides": {
                "algo_market_share_2003": 0.15,
                "algo_market_share_2012": 0.85,
                "mu": 0.0001,
                "sigma": 0.002
            }
        },
        {
            "label": "binomial_evolution_function_test",
            "param_overrides": {
                "n_trades_binomial": 100,
                "strategy_win_rate": 0.55,
                "sigma": 0.002,
                "mu": 0.0001
            }
        }
    ]
}

# ============================================================
# PARAMETER UTILITIES
# ============================================================

PARAMETERS_META = [
    ("mu", 0.0001, "per step", "assumed", "Drift of the GBM price process per time step"),
    ("sigma", 0.002, "per step", "assumed", "Volatility of the GBM price process per time step"),
    ("tick_size_pre_2001", 0.0625, "USD", "extracted", "Minimum tick size before decimalization (1/16 of a dollar)"),
    ("tick_size_post_2001", 0.01, "USD", "extracted", "Minimum tick size after SEC decimalization in 2001"),
    ("half_spread_base", 0.0625, "USD", "extracted", "Half bid-ask spread under pre-decimalization regime"),
    ("half_spread_decimal", 0.01, "USD", "assumed", "Half bid-ask spread under post-decimalization regime"),
    ("mean_reversion_speed", 0.05, "per step", "assumed", "Ornstein-Uhlenbeck mean reversion speed kappa"),
    ("mean_reversion_level", 100.0, "USD", "assumed", "Long-run mean price for mean reversion strategy"),
    ("vwap_window", 20.0, "steps", "assumed", "Rolling window length for VWAP calculation"),
    ("twap_window", 20.0, "steps", "assumed", "Rolling window length for TWAP calculation"),
    ("ma_short_window", 50.0, "steps", "extracted", "Short moving average window (50-period)"),
    ("ma_long_window", 100.0, "steps", "extracted", "Long moving average window (100-period)"),
    ("hft_market_share_2009", 0.73, "fraction", "extracted", "HFT share of US equity volume in 2009"),
    ("hft_market_share_2012", 0.50, "fraction", "extracted", "HFT share of US equity volume in 2012"),
    ("algo_market_share_2003", 0.15, "fraction", "extracted", "Algorithmic trading share in 2003"),
    ("algo_market_share_2012", 0.85, "fraction", "extracted", "Algorithmic trading share in 2012"),
    ("large_order_size", 10000.0, "shares", "assumed", "Total large order for VWAP/TWAP execution"),
    ("order_slice_size", 100.0, "shares", "assumed", "Size of each child order slice"),
    ("pairs_entry_z", 2.0, "z-score", "assumed", "Z-score threshold to enter a pairs trade"),
    ("pairs_exit_z", 0.5, "z-score", "assumed", "Z-score threshold to exit a pairs trade"),
    ("hft_latency_normal", 5.0, "milliseconds", "assumed", "Typical latency for normal market participant"),
    ("hft_latency_ultra", 0.5, "milliseconds", "extracted", "Ultra-low latency threshold"),
    ("dc_threshold", 0.005, "fraction", "assumed", "Directional change threshold"),
    ("flash_crash_shock", -0.10, "fraction", "assumed", "Magnitude of sudden price drop"),
    ("flash_crash_recovery_speed", 0.5, "per step", "assumed", "Speed at which price recovers from flash crash"),
    ("num_steps", 1000.0, "steps", "assumed", "Number of simulation time steps"),
    ("n_trades_binomial", 100.0, "trades", "assumed", "Number of trades for binomial test"),
    ("strategy_win_rate", 0.55, "fraction", "assumed", "True win rate for a strategy with genuine predictive capacity"),
]


def get_params(overrides: Dict = None) -> Dict:
    """Get a copy of the default parameters with optional overrides applied."""
    p = dict(MODEL_PROFILE["parameters"])
    if overrides:
        for k, v in overrides.items():
            p[k] = v
    return p


def clip(value, lo, hi):
    """Clamp value to [lo, hi]."""
    return max(lo, min(hi, value))


# ============================================================
# PRICE GENERATION FUNCTIONS
# ============================================================

def generate_gbm_prices(num_steps: int, mu: float, sigma: float,
                         init_price: float = 100.0) -> np.ndarray:
    """Generate GBM price path."""
    prices = np.zeros(num_steps)
    prices[0] = init_price
    dt = 1.0
    Z = np.random.randn(num_steps - 1)
    for t in range(1, num_steps):
        prices[t] = prices[t-1] * np.exp((mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * Z[t-1])
        prices[t] = clip(prices[t], 50.0, 200.0)
    return prices


def generate_ou_prices(num_steps: int, kappa: float, theta: float, sigma: float,
                        init_price: float = 100.0) -> np.ndarray:
    """Generate Ornstein-Uhlenbeck price path."""
    prices = np.zeros(num_steps)
    prices[0] = init_price
    dt = 1.0
    Z = np.random.randn(num_steps - 1)
    for t in range(1, num_steps):
        prices[t] = prices[t-1] + kappa * (theta - prices[t-1]) * dt + sigma * np.sqrt(dt) * Z[t-1]
        prices[t] = clip(prices[t], 50.0, 200.0)
    return prices


def generate_flash_crash_prices(num_steps: int, mu: float, sigma: float,
                                  crash_step: int, crash_shock: float,
                                  recovery_speed: float,
                                  init_price: float = 100.0) -> np.ndarray:
    """Generate GBM price path with flash crash at crash_step."""
    prices = np.zeros(num_steps)
    prices[0] = init_price
    dt = 1.0
    Z = np.random.randn(num_steps - 1)
    sigma_elevated = sigma * 2.0
    price_pre_crash = None
    for t in range(1, num_steps):
        if t == crash_step:
            price_pre_crash = prices[t-1]
            prices[t] = prices[t-1] * (1.0 + crash_shock)
            prices[t] = clip(prices[t], 50.0, 200.0)
        elif t > crash_step and price_pre_crash is not None:
            recovery = price_pre_crash + (prices[crash_step] - price_pre_crash) * np.exp(
                -recovery_speed * (t - crash_step))
            noise = sigma_elevated * np.sqrt(dt) * Z[t-1]
            prices[t] = recovery + noise
            prices[t] = clip(prices[t], 50.0, 200.0)
        else:
            prices[t] = prices[t-1] * np.exp(
                (mu - 0.5 * sigma**2) * dt + sigma * np.sqrt(dt) * Z[t-1])
            prices[t] = clip(prices[t], 50.0, 200.0)
    return prices


# ============================================================
# MARKET MICROSTRUCTURE HELPERS
# ============================================================

def compute_bid_ask(prices: np.ndarray, half_spread: float,
                     tick_noise_scale: float = 0.005) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute bid, ask, and spread arrays."""
    n = len(prices)
    noise_bid = np.random.randn(n) * tick_noise_scale
    noise_ask = np.random.randn(n) * tick_noise_scale
    bids = prices - half_spread + noise_bid
    asks = prices + half_spread + noise_ask
    # Ensure ask > bid
    for i in range(n):
        bids[i] = clip(bids[i], 49.0, 199.0)
        asks[i] = clip(asks[i], 51.0, 201.0)
        if asks[i] <= bids[i]:
            asks[i] = bids[i] + 2 * half_spread
            asks[i] = clip(asks[i], 51.0, 201.0)
    spreads = asks - bids
    spreads = np.clip(spreads, 0.01, 1.0)
    return bids, asks, spreads


def compute_volume(num_steps: int) -> np.ndarray:
    """Generate random volume per step."""
    vol = np.abs(np.random.normal(loc=1000.0, scale=300.0, size=num_steps))
    vol = np.clip(vol, 1.0, 1e8)
    return vol


def compute_rolling_mean(arr: np.ndarray, window: int, t: int) -> float:
    """Rolling mean up to index t."""
    start = max(0, t - window + 1)
    return float(np.mean(arr[start:t+1]))


def compute_rolling_std(arr: np.ndarray, window: int, t: int) -> float:
    """Rolling std up to index t (min 1 element)."""
    start = max(0, t - window + 1)
    sub = arr[start:t+1]
    if len(sub) < 2:
        return 0.0
    return float(np.std(sub))


def compute_vwap(prices: np.ndarray, volumes: np.ndarray, window: int, t: int) -> float:
    """Rolling VWAP."""
    start = max(0, t - window + 1)
    p_sub = prices[start:t+1]
    v_sub = volumes[start:t+1]
    total_vol = np.sum(v_sub)
    if total_vol == 0:
        return float(prices[t])
    vwap = float(np.sum(p_sub * v_sub) / total_vol)
    return clip(vwap, 50.0, 200.0)


def compute_twap(prices: np.ndarray, window: int, t: int) -> float:
    """Rolling TWAP."""
    start = max(0, t - window + 1)
    twap = float(np.mean(prices[start:t+1]))
    return clip(twap, 50.0, 200.0)


def compute_ma(prices: np.ndarray, window: int, t: int) -> float:
    """Simple moving average."""
    start = max(0, t - window + 1)
    ma = float(np.mean(prices[start:t+1]))
    return clip(ma, 50.0, 200.0)


# ============================================================
# SCENARIO SIMULATORS
# ============================================================

def simulate_scenario(scenario_idx: int, scenario: Dict) -> List[Dict]:
    """Run simulation for a given scenario and return list of row dicts."""
    np.random.seed(scenario_idx)
    label = scenario["label"]
    p = get_params(scenario.get("param_overrides", {}))

    num_steps = int(p["num_steps"])
    mu = float(p["mu"])
    sigma = float(p["sigma"])
    half_spread = float(p["half_spread_base"])
    kappa = float(p["mean_reversion_speed"])
    theta = float(p["mean_reversion_level"])
    algo_share = float(p.get("algo_market_share", 0.15))
    initial_capital = float(p["initial_capital"])
    dc_threshold = float(p["dc_threshold"])
    flash_crash_shock = float(p["flash_crash_shock"])
    flash_crash_recovery_speed = float(p["flash_crash_recovery_speed"])
    large_order_size = float(p["large_order_size"])
    order_slice_size = float(p["order_slice_size"])
    pairs_entry_z = float(p["pairs_entry_z"])
    pairs_exit_z = float(p["pairs_exit_z"])
    pairs_sigma = float(p["pairs_sigma"])
    hft_latency_ultra = float(p["hft_latency_ultra"])
    hft_latency_normal = float(p["hft_latency_normal"])
    n_trades_binomial = int(p["n_trades_binomial"])
    strategy_win_rate = float(p["strategy_win_rate"])
    vwap_window = int(p["vwap_window"])
    twap_window = int(p["twap_window"])

    # Generate price path based on scenario type
    if label == "mean_reversion_strategy":
        prices = generate_ou_prices(num_steps, kappa, theta, sigma)
    elif label == "flash_crash_event":
        prices = generate_flash_crash_prices(num_steps, mu, sigma,
                                              crash_step=600,
                                              crash_shock=flash_crash_shock,
                                              recovery_speed=flash_crash_recovery_speed)
    else:
        prices = generate_gbm_prices(num_steps, mu, sigma)

    bids, asks, spreads = compute_bid_ask(prices, half_spread)
    volumes = compute_volume(num_steps)
    cumulative_volume = np.cumsum(volumes)
    cumulative_volume = np.clip(cumulative_volume, 0.0, 1e8)

    # Pairs trading: second asset
    if label == "pairs_trading_strategy":
        rho = 0.9
        Z1 = np.random.randn(num_steps - 1)
        Z2 = rho * Z1 + np.sqrt(1 - rho**2) * np.random.randn(num_steps - 1)
        price_A = np.zeros(num_steps)
        price_B = np.zeros(num_steps)
        price_A[0] = 100.0
        price_B[0] = 100.0
        for t in range(1, num_steps):
            price_A[t] = price_A[t-1] * np.exp(
                (mu - 0.5*sigma**2) + sigma * Z1[t-1])
            price_A[t] = clip(price_A[t], 50.0, 200.0)
            price_B[t] = price_B[t-1] * np.exp(
                (mu - 0.5*sigma**2) + sigma * Z2[t-1])
            price_B[t] = clip(price_B[t], 50.0, 200.0)
        # Override prices with price_A
        prices = price_A

    # HFT latency: compute per-participant prices
    if label == "hft_latency_advantage":
        latency_fast_steps = max(1, int(round(hft_latency_ultra / 0.5)))
        latency_slow_steps = max(1, int(round(hft_latency_normal / 0.5)))

    # Binomial test: precompute p-values for all steps
    if label == "binomial_evolution_function_test":
        binom_p_values = np.zeros(num_steps)
        win_sequences = np.zeros(num_steps)
        for t in range(num_steps):
            wins = np.sum(np.random.rand(n_trades_binomial) < strategy_win_rate)
            # One-tailed binomial test: p(X >= wins | p=0.5)
            from math import comb
            p_val = 0.0
            for k in range(int(wins), n_trades_binomial + 1):
                p_val += comb(n_trades_binomial, k) * (0.5**n_trades_binomial)
            p_val = clip(p_val, 0.0, 1.0)
            binom_p_values[t] = p_val
            win_sequences[t] = wins / n_trades_binomial

    # Directional change tracking
    dc_events = np.zeros(num_steps, dtype=int)
    dc_directions = ['none'] * num_steps
    last_extreme = prices[0]
    last_dc_dir = 'down'  # start looking for upward DC

    # VWAP execution tracking
    exec_remaining = large_order_size
    exec_prices = np.full(num_steps, np.nan)
    arrival_price = prices[0]
    cumulative_exec_cost = 0.0
    cumulative_exec_shares = 0.0

    # Strategy state
    position = 0.0
    pnl = 0.0
    peak_value = initial_capital
    pairs_position = 0  # -1, 0, +1

    # MA crossover state
    prev_ma50_above = None

    # HFT state
    pnl_fast = 0.0
    pnl_slow = 0.0
    pos_fast = 0.0
    pos_slow = 0.0

    rows = []

    # Algo market share growth scenario: interpolate
    if label == "algo_market_share_growth_2003_2012":
        hist_years = np.array([2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012])
        hist_shares = np.array([0.15, 0.20, 0.25, 0.30, 0.45, 0.60, 0.75, 0.80, 0.83, 0.85])
        # Map time steps to year range
        step_years = np.linspace(2003, 2012, num_steps)

    for t in range(num_steps):
        price = prices[t]
        bid = bids[t]
        ask = asks[t]
        spread = spreads[t]
        vol_t = volumes[t]
        cum_vol = cumulative_volume[t]

        # Moving averages
        ma50 = compute_ma(prices, 50, t)
        ma100 = compute_ma(prices, 100, t)

        # VWAP and TWAP
        vwap_t = compute_vwap(prices, volumes, vwap_window, t)
        twap_t = compute_twap(prices, twap_window, t)

        # Rolling volatility (std of prices)
        roll_std = compute_rolling_std(prices, 20, t)
        volatility_t = clip(roll_std, 0.0, 20.0)

        # Mean reversion signal
        roll_mean = compute_rolling_mean(prices, 20, t)
        mr_signal = clip(price - roll_mean, -50.0, 50.0)

        # Return
        if t > 0:
            ret_t = (prices[t] - prices[t-1]) / max(prices[t-1], 1e-8)
        else:
            ret_t = 0.0

        # Flash crash flag
        flash_flag = 0
        if label == "flash_crash_event" and t >= 600:
            flash_flag = 1

        # --- Strategy logic ---
        trade_size = 0.0
        strategy_type = "none"

        if label in ("pre_decimalization_market_making", "post_decimalization_market_making"):
            strategy_type = "market_making"
            # Market maker: earn half spread each step
            trade_profit = half_spread * abs(np.random.randn()) * 10
            pnl += trade_profit
            position = 0.0

        elif label == "mean_reversion_strategy":
            strategy_type = "mean_reversion"
            if volatility_t > 0:
                if mr_signal < -1.0 * volatility_t and position <= 0:
                    trade_size = 1.0
                    position += trade_size
                    pnl -= spread / 2.0 * abs(trade_size)
                elif mr_signal > 1.0 * volatility_t and position >= 0:
                    trade_size = -1.0
                    position += trade_size
                    pnl -= spread / 2.0 * abs(trade_size)
            if t > 0:
                pnl += position * (prices[t] - prices[t-1])

        elif label == "pairs_trading_strategy":
            strategy_type = "pairs_trading"
            ps = price_A[t] - price_B[t]
            ps = clip(ps, -20.0, 20.0)
            ps_mean = compute_rolling_mean(
                price_A[:t+1] - price_B[:t+1], 50, t)
            ps_std = compute_rolling_std(
                price_A[:t+1] - price_B[:t+1], 50, t)
            if ps_std > 0:
                z = (ps - ps_mean) / ps_std
            else:
                z = 0.0
            z = clip(z, -20.0, 20.0)

            prev_pairs_pos = pairs_position
            if pairs_position == 0:
                if z < -pairs_entry_z:
                    pairs_position = 1
                elif z > pairs_entry_z:
                    pairs_position = -1
            elif pairs_position != 0:
                if abs(z) < pairs_exit_z:
                    pairs_position = 0

            pairs_trade = pairs_position - prev_pairs_pos
            trade_size = abs(pairs_trade)
            pnl -= spread * trade_size
            if t > 0:
                dp_a = price_A[t] - price_A[t-1]
                dp_b = price_B[t] - price_B[t-1]
                pnl += pairs_position * dp_a - pairs_position * dp_b

        elif label == "vwap_execution_algorithm":
            strategy_type = "vwap_execution"
            if exec_remaining > 0:
                slice_sz = min(order_slice_size, exec_remaining)
                exec_p = ask  # buying at ask
                exec_prices[t] = exec_p
                cumulative_exec_cost += exec_p * slice_sz
                cumulative_exec_shares += slice_sz
                exec_remaining -= slice_sz
                trade_size = slice_sz
            else:
                exec_prices[t] = ask

            if cumulative_exec_shares > 0:
                avg_exec = cumulative_exec_cost / cumulative_exec_shares
            else:
                avg_exec = arrival_price

            impl_shortfall = avg_exec - arrival_price
            if t > 0:
                pnl += position * (prices[t] - prices[t-1])

        elif label == "flash_crash_event":
            strategy_type = "flash_crash"
            if t > 0:
                if prices[t] < prices[t-1] * 0.98 and position <= 0:
                    trade_size = 1.0
                    position += trade_size
                    pnl -= spread / 2.0
                elif prices[t] > prices[t-1] * 1.01 and position > 0:
                    trade_size = -position
                    position = 0.0
                    pnl -= spread / 2.0 * abs(trade_size)
                pnl += position * (prices[t] - prices[t-1])

        elif label == "hft_latency_advantage":
            strategy_type = "hft_latency"
            # Fast trader
            t_fast = max(0, t - latency_fast_steps)
            t_slow = max(0, t - latency_slow_steps)
            p_fast = prices[t_fast]
            p_slow = prices[t_slow]
            # Market-making PnL
            if t > 0:
                dp = prices[t] - prices[t-1]
                # Fast: trade with 1-step price advantage
                pnl_fast += half_spread * 0.5 + 0.5 * abs(dp)
                # Slow: less advantage
                pnl_slow += half_spread * 0.3 + 0.3 * abs(dp)
            pnl = pnl_fast  # primary pnl is fast

        elif label == "directional_change_algorithm":
            strategy_type = "directional_change"
            if last_dc_dir == 'down' and price >= last_extreme * (1 + dc_threshold):
                dc_events[t] = 1
                dc_directions[t] = 'up'
                last_extreme = price
                last_dc_dir = 'up'
                if position <= 0:
                    trade_size = 1.0 - position
                    position = 1.0
                    pnl -= spread / 2.0 * abs(trade_size)
            elif last_dc_dir == 'up' and price <= last_extreme * (1 - dc_threshold):
                dc_events[t] = 1
                dc_directions[t] = 'down'
                last_extreme = price
                last_dc_dir = 'down'
                if position >= 0:
                    trade_size = -(1.0 + position)
                    position = -1.0
                    pnl -= spread / 2.0 * abs(trade_size)
            if t > 0:
                pnl += position * (prices[t] - prices[t-1])

        elif label == "algo_market_share_growth_2003_2012":
            strategy_type = "market_share_growth"
            yr = step_years[t]
            # Interpolate market share
            algo_share = float(np.interp(yr, hist_years, hist_shares))
            algo_share = clip(algo_share, 0.0, 1.0)
            if t > 0:
                pnl += position * (prices[t] - prices[t-1])

        elif label == "binomial_evolution_function_test":
            strategy_type = "binomial_test"
            # Simple trend following
            if t > 0:
                if prices[t] > prices[t-1]:
                    position = 1.0
                else:
                    position = -1.0
                pnl += position * (prices[t] - prices[t-1])

        # Moving average crossover PnL (for scenarios not otherwise defined)
        if strategy_type == "none":
            strategy_type = "ma_crossover"
            if t > 0:
                ma50_above_now = ma50 > ma100
                if prev_ma50_above is not None:
                    if ma50_above_now and not prev_ma50_above:
                        position = 1.0
                    elif not ma50_above_now and prev_ma50_above:
                        position = -1.0
                prev_ma50_above = ma50_above_now
                pnl += position * (prices[t] - prices[t-1])

        # Portfolio and drawdown
        portfolio_value = clip(initial_capital + pnl, 0.0, 1e7)
        peak_value = max(peak_value, portfolio_value)
        drawdown = clip(portfolio_value - peak_value, -1e6, 0.0)
        pnl_clipped = clip(pnl, -1e6, 1e6)

        # Position clip
        position = clip(position, -10000.0, 10000.0)

        # Order cancellation rate (HFT proxy)
        if label == "hft_latency_advantage":
            ocr = clip(0.7 + 0.1 * np.random.randn(), 0.0, 1.0)
        else:
            ocr = clip(0.3 + 0.05 * np.random.randn(), 0.0, 1.0)

        # Latency
        if label == "hft_latency_advantage":
            lat_ms = hft_latency_ultra
        else:
            lat_ms = hft_latency_normal

        # Binomial p-value
        if label == "binomial_evolution_function_test":
            bpv = binom_p_values[t]
            win_seq = win_sequences[t]
        else:
            bpv = clip(0.5 + 0.0 * t, 0.0, 1.0)
            win_seq = 0.5

        # Pairs spread
        if label == "pairs_trading_strategy":
            ps_val = clip(price_A[t] - price_B[t], -20.0, 20.0)
            ps_mean_v = compute_rolling_mean(
                price_A[:t+1] - price_B[:t+1], 50, t)
            ps_std_v = compute_rolling_std(
                price_A[:t+1] - price_B[:t+1], 50, t)
            if ps_std_v > 0:
                ps_z = clip((ps_val - ps_mean_v) / ps_std_v, -20.0, 20.0)
            else:
                ps_z = 0.0
        else:
            ps_val = 0.0
            ps_z = 0.0

        # Execution price and shortfall
        if label == "vwap_execution_algorithm":
            exec_p_t = exec_prices[t] if not np.isnan(exec_prices[t]) else price
            impl_s = clip(exec_p_t - arrival_price, -50.0, 50.0)
        else:
            exec_p_t = price
            impl_s = 0.0

        # Year label
        year_label = 2003 + int(t / num_steps * 9)

        # Algo market share for non-growth scenario
        if label != "algo_market_share_growth_2003_2012":
            algo_share_row = clip(algo_share, 0.0, 1.0)
        else:
            algo_share_row = clip(algo_share, 0.0, 1.0)

        row = {
            "scenario": label,
            "time_step": t,
            "year_label": year_label,
            "price": clip(price, 50.0, 200.0),
            "bid": clip(bid, 49.0, 199.0),
            "ask": clip(ask, 51.0, 201.0),
            "spread": clip(spread, 0.01, 1.0),
            "volume": clip(vol_t, 0.0, 1e8),
            "vwap": vwap_t,
            "twap": twap_t,
            "moving_avg_50": ma50,
            "moving_avg_100": ma100,
            "portfolio_value": portfolio_value,
            "position": position,
            "pnl": pnl_clipped,
            "drawdown": drawdown,
            "algo_market_share": algo_share_row,
            "volatility": volatility_t,
            "mean_reversion_signal": mr_signal,
            "pairs_spread": ps_val,
            "pairs_spread_zscore": ps_z,
            "pairs_position": pairs_position if label == "pairs_trading_strategy" else 0,
            "dc_event": int(dc_events[t]),
            "dc_direction": dc_directions[t],
            "execution_price": clip(exec_p_t, 50.0, 200.0),
            "implementation_shortfall": impl_s,
            "latency_ms": lat_ms,
            "order_cancellation_rate": ocr,
            "binomial_p_value": bpv,
            "win_sequence": win_seq,
            "strategy_type": strategy_type,
            "return_t": ret_t,
            "flash_crash_flag": flash_flag,
        }
        rows.append(row)

    return rows


# ============================================================
# FIGURE GENERATION
# ============================================================

def generate_figures(all_scenario_data: Dict[str, List[Dict]], output_dir: pathlib.Path):
    """Generate all figures."""

    # ---- Figure 1: Algo market share growth 2003-2012 ----
    try:
        years = np.array([2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012])
        shares = np.array([15.0, 20.0, 25.0, 30.0, 45.0, 60.0, 75.0, 80.0, 83.0, 85.0])
        assert len(years) == len(shares), "years and shares length mismatch"

        # Logistic fit
        def logistic(t, L, k, t0):
            return L / (1 + np.exp(-k * (t - t0)))

        L = 88.0
        t0 = 2007.5
        k_fit = 0.8
        years_fine = np.linspace(2003, 2015, 200)
        smooth = logistic(years_fine, L, k_fit, t0)
        assert len(years_fine) == len(smooth)

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.bar(years, shares, color='steelblue', alpha=0.7, label='Historical data')
        ax.plot(years_fine, smooth, 'r-', linewidth=2, label='Logistic trend')
        ax.set_xlabel('Year')
        ax.set_ylabel('Algorithmic Trading (% of Market Volume)')
        ax.set_title('Algorithmic Trading: Percentage of Market Volume (2003-2012)')
        ax.legend()
        ax.set_ylim(0, 100)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig_01_market_share_growth.png', dpi=120)
        plt.close(fig)
        print("Saved fig_01")
    except Exception as e:
        print(f"Warning: fig_01 failed: {e}")

    # ---- Figure 2: Multiple price paths ----
    try:
        np.random.seed(42)
        n = 1000
        gbm = generate_gbm_prices(n, 0.0001, 0.002)
        ou = generate_ou_prices(n, 0.05, 100.0, 0.003)
        flash = generate_flash_crash_prices(n, 0.0001, 0.002, 600, -0.1, 0.5)
        steps = np.arange(n)

        ma50_gbm = np.array([compute_ma(gbm, 50, t) for t in range(n)])
        ma100_gbm = np.array([compute_ma(gbm, 100, t) for t in range(n)])

        assert len(steps) == len(gbm) == len(ou) == len(flash)
        assert len(steps) == len(ma50_gbm) == len(ma100_gbm)

        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(steps, gbm, 'b-', alpha=0.7, linewidth=0.8, label='GBM')
        ax.plot(steps, ou, 'g-', alpha=0.7, linewidth=0.8, label='OU Mean-Reverting')
        ax.plot(steps, flash, 'r-', alpha=0.7, linewidth=0.8, label='Flash Crash')
        ax.plot(steps, ma50_gbm, 'b--', linewidth=1.5, label='MA50 (GBM)')
        ax.plot(steps, ma100_gbm, 'b:', linewidth=1.5, label='MA100 (GBM)')
        ax.axvline(x=600, color='red', linestyle='--', alpha=0.5, label='Flash Crash onset')
        ax.set_xlabel('Time Step')
        ax.set_ylabel('Price (USD)')
        ax.set_title('Simulated Asset Price Paths: GBM with and without Mean Reversion')
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig_02_price_paths.png', dpi=120)
        plt.close(fig)
        print("Saved fig_02")
    except Exception as e:
        print(f"Warning: fig_02 failed: {e}")

    # ---- Figure 3: Bid-ask spread pre vs post decimalization ----
    try:
        rows_pre = all_scenario_data.get("pre_decimalization_market_making", [])
        rows_post = all_scenario_data.get("post_decimalization_market_making", [])
        if rows_pre and rows_post:
            steps_pre = np.array([r["time_step"] for r in rows_pre])
            spr_pre = np.array([r["spread"] for r in rows_pre])
            steps_post = np.array([r["time_step"] for r in rows_post])
            spr_post = np.array([r["spread"] for r in rows_post])
            assert len(steps_pre) == len(spr_pre)
            assert len(steps_post) == len(spr_post)

            fig, ax = plt.subplots(figsize=(12, 6))
            ax.plot(steps_pre, spr_pre, 'b-', alpha=0.6, linewidth=0.8,
                    label='Pre-decimalization (half-spread=$0.0625)')
            ax.plot(steps_post, spr_post, 'g-', alpha=0.6, linewidth=0.8,
                    label='Post-decimalization (half-spread=$0.01)')
            ax.axhline(y=0.0625, color='orange', linestyle='--', linewidth=1.5,
                       label='Old tick size boundary ($0.0625)')
            ax.set_xlabel('Time Step')
            ax.set_ylabel('Bid-Ask Spread (USD)')
            ax.set_title('Bid-Ask Spread: Pre- vs Post-Decimalization Regimes')
            ax.legend()
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / 'fig_03_spread_comparison.png', dpi=120)
            plt.close(fig)
            print("Saved fig_03")
        else:
            print("Warning: fig_03 skipped - missing scenario data")
    except Exception as e:
        print(f"Warning: fig_03 failed: {e}")

    # ---- Figure 4: Cumulative PnL comparison ----
    try:
        np.random.seed(100)
        n = 1000
        prices_ou = generate_ou_prices(n, 0.05, 100.0, 0.003)

        # Strategy 1: Mean Reversion
        pnl_mr = np.zeros(n)
        pos_mr = 0.0
        for t in range(1, n):
            roll_mean = compute_rolling_mean(prices_ou, 20, t)
            roll_std_ = compute_rolling_std(prices_ou, 20, t)
            sig = prices_ou[t] - roll_mean
            half_s = 0.0625
            if roll_std_ > 0:
                if sig < -roll_std_ and pos_mr <= 0:
                    pos_mr += 1.0
                    pnl_mr[t] = pnl_mr[t-1] - half_s
                elif sig > roll_std_ and pos_mr >= 0:
                    pos_mr -= 1.0
                    pnl_mr[t] = pnl_mr[t-1] - half_s
                else:
                    pnl_mr[t] = pnl_mr[t-1] + pos_mr * (prices_ou[t] - prices_ou[t-1])
            else:
                pnl_mr[t] = pnl_mr[t-1]
            pnl_mr[t] = clip(pnl_mr[t], -1e6, 1e6)

        # Strategy 2: MA Crossover
        pnl_ma = np.zeros(n)
        pos_ma = 0.0
        prev_above = None
        for t in range(1, n):
            ma50t = compute_ma(prices_ou, 50, t)
            ma100t = compute_ma(prices_ou, 100, t)
            above = ma50t > ma100t
            if prev_above is not None:
                if above and not prev_above:
                    pos_ma = 1.0
                elif not above and prev_above:
                    pos_ma = -1.0
            prev_above = above
            pnl_ma[t] = pnl_ma[t-1] + pos_ma * (prices_ou[t] - prices_ou[t-1])
            pnl_ma[t] = clip(pnl_ma[t], -1e6, 1e6)

        # Strategy 3: Random
        pnl_rand = np.zeros(n)
        pos_rand = 0.0
        for t in range(1, n):
            pos_rand = 1.0 if np.random.rand() > 0.5 else -1.0
            pnl_rand[t] = pnl_rand[t-1] + pos_rand * (prices_ou[t] - prices_ou[t-1])
            pnl_rand[t] = clip(pnl_rand[t], -1e6, 1e6)

        steps = np.arange(n)
        assert len(steps) == len(pnl_mr) == len(pnl_ma) == len(pnl_rand)

        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(steps, pnl_mr, 'g-', linewidth=1.0, label='Mean Reversion Strategy')
        ax.plot(steps, pnl_ma, 'b-', linewidth=1.0, label='MA Crossover Strategy')
        ax.plot(steps, pnl_rand, 'r-', alpha=0.6, linewidth=0.8, label='Random Strategy')
        ax.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        ax.set_xlabel('Time Step')
        ax.set_ylabel('Cumulative PnL (USD)')
        ax.set_title('Cumulative PnL: Mean Reversion vs Moving Average Crossover vs Random Strategy')
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig_04_pnl_comparison.png', dpi=120)
        plt.close(fig)
        print("Saved fig_04")
    except Exception as e:
        print(f"Warning: fig_04 failed: {e}")

    # ---- Figure 5: Pairs trading z-score ----
    try:
        rows_pairs = all_scenario_data.get("pairs_trading_strategy", [])
        if rows_pairs:
            steps_p = np.array([r["time_step"] for r in rows_pairs])
            z_scores = np.array([r["pairs_spread_zscore"] for r in rows_pairs])
            assert len(steps_p) == len(z_scores)

            # Entry/exit signals
            entry_long_t = [r["time_step"] for r in rows_pairs
                            if r["pairs_position"] == 1 and
                            (rows_pairs[max(0, r["time_step"]-1)]["pairs_position"] != 1)]
            entry_short_t = [r["time_step"] for r in rows_pairs
                             if r["pairs_position"] == -1 and
                             (rows_pairs[max(0, r["time_step"]-1)]["pairs_position"] != -1)]
            exit_t = [r["time_step"] for r in rows_pairs
                      if r["pairs_position"] == 0 and r["time_step"] > 0 and
                      rows_pairs[r["time_step"]-1]["pairs_position"] != 0]

            entry_long_z = [z_scores[t] for t in entry_long_t if t < len(z_scores)]
            entry_short_z = [z_scores[t] for t in entry_short_t if t < len(z_scores)]
            exit_z_vals = [z_scores[t] for t in exit_t if t < len(z_scores)]

            fig, ax = plt.subplots(figsize=(12, 6))
            ax.plot(steps_p, z_scores, 'b-', linewidth=0.8, label='Spread Z-Score')
            ax.axhline(y=2.0, color='red', linestyle='--', alpha=0.7, label='Entry +2σ')
            ax.axhline(y=-2.0, color='red', linestyle='--', alpha=0.7, label='Entry -2σ')
            ax.axhline(y=0.5, color='green', linestyle=':', alpha=0.7, label='Exit +0.5σ')
            ax.axhline(y=-0.5, color='green', linestyle=':', alpha=0.7, label='Exit -0.5σ')
            ax.axhline(y=0, color='black', linestyle='-', alpha=0.3)
            if entry_long_t and entry_long_z:
                ax.scatter(entry_long_t[:len(entry_long_z)], entry_long_z,
                           marker='^', color='green', s=60, zorder=5, label='Entry Long')
            if entry_short_t and entry_short_z:
                ax.scatter(entry_short_t[:len(entry_short_z)], entry_short_z,
                           marker='v', color='red', s=60, zorder=5, label='Entry Short')
            if exit_t and exit_z_vals:
                ax.scatter(exit_t[:len(exit_z_vals)], exit_z_vals,
                           marker='o', color='orange', s=40, zorder=5, label='Exit')
            ax.set_xlabel('Time Step')
            ax.set_ylabel('Spread Z-Score')
            ax.set_title('Pairs Trading: Spread Z-Score and Trade Entry/Exit Signals')
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            fig.savefig(output_dir / 'fig_05_pairs_trading.png', dpi=120)
            plt.close(fig)
            print("Saved fig_05")
        else:
            print("Warning: fig_05 skipped - missing pairs_trading_strategy data")
    except Exception as e:
        print(f"Warning: fig_05 failed: {e}")

    # ---- Figure 6: Flash crash ----
    try:
        np.random.seed(55)
        n = 1000
        crash_step = 600
        baseline = generate_gbm_prices(n, 0.0, 0.003, 100.0)
        flash_p = generate_flash_crash_prices(n, 0.0, 0.005, crash_step, -0.1, 0.5, 100.0)
        vols_f = compute_volume(n)
        vwap_flash = np.array([compute_vwap(flash_p, vols_f, 20, t) for t in range(n)])
        steps = np.arange(n)

        assert len(steps) == len(baseline) == len(flash_p) == len(vwap_flash)

        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(steps, baseline, 'b-', alpha=0.6, linewidth=0.8, label='Baseline GBM')
        ax.plot(steps, flash_p, 'r-', alpha=0.8, linewidth=1.0, label='Flash Crash Path')
        ax.plot(steps, vwap_flash, 'g--', linewidth=1.2, label='VWAP (flash crash)')
        ax.axvline(x=crash_step, color='red', linestyle='--', linewidth=1.5,
                   label='Crash Onset (t=600)')
        ax.set_xlabel('Time Step')
        ax.set_ylabel('Price (USD)')
        ax.set_title('Flash Crash Simulation: Price Collapse and Recovery Dynamics')
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig_06_flash_crash.png', dpi=120)
        plt.close(fig)
        print("Saved fig_06")
    except Exception as e:
        print(f"Warning: fig_06 failed: {e}")

    # ---- Figure 7: VWAP execution ----
    try:
        rows_vwap = all_scenario_data.get("vwap_execution_algorithm", [])
        if rows_vwap:
            n_exec = int(10000 / 100)  # 100 execution steps
            exec_rows = rows_vwap[:n_exec]
            if len(exec_rows) >= 2:
                steps_e = np.array([r["time_step"] for r in exec_rows])
                exec_p = np.array([r["execution_price"] for r in exec_rows])
                vwap_e = np.array([r["vwap"] for r in exec_rows])
                twap_e = np.array([r["twap"] for r in exec_rows])
                arrival = exec_rows[0]["execution_price"]
                assert len(steps_e) == len(exec_p) == len(vwap_e) == len(twap_e)

                fig, ax = plt.subplots(figsize=(12, 6))
                ax.plot(steps_e, exec_p, 'r-o', markersize=3, linewidth=1.2,
                        label='Execution Price per Slice')
                ax.plot(steps_e, vwap_e, 'b--', linewidth=1.5, label='VWAP Benchmark')
                ax.plot(steps_e, twap_e, 'g:', linewidth=1.5, label='TWAP Benchmark')
                ax.axhline(y=arrival, color='orange', linestyle='--', alpha=0.7,
                           label=f'Arrival Price ({arrival:.2f})')
                ax.fill_between(steps_e, arrival, exec_p,
                                where=exec_p > arrival, alpha=0.2, color='red',
                                label='Implementation Shortfall')
                ax.set_xlabel('Time Step')
                ax.set_ylabel('Price (USD)')
                ax.set_title('VWAP Execution Algorithm: Sliced Order vs Benchmark Price')
                ax.legend()
                ax.grid(True, alpha=0.3)
                plt.tight_layout()
                fig.savefig(output_dir / 'fig_07_vwap_execution.png', dpi=120)
                plt.close(fig)
                print("Saved fig_07")
            else:
                print("Warning: fig_07 skipped - insufficient execution data")
        else:
            print("Warning: fig_07 skipped - missing vwap scenario data")
    except Exception as e:
        print(f"Warning: fig_07 failed: {e}")

    # ---- Figure 8: HFT latency advantage ----
    try:
        np.random.seed(77)
        n = 1000
        prices_hft = generate_gbm_prices(n, 0.0002, 0.003)
        half_s = 0.005
        steps = np.arange(n)

        pnl_fast_arr = np.zeros(n)
        pnl_slow_arr = np.zeros(n)

        for t in range(1, n):
            dp = prices_hft[t] - prices_hft[t-1]
            # Fast: reacts with 1-step lag
            pnl_fast_arr[t] = pnl_fast_arr[t-1] + half_s * 0.5 + 0.6 * abs(dp)
            # Slow: reacts with 5-step lag, worse fill
            pnl_slow_arr[t] = pnl_slow_arr[t-1] + half_s * 0.3 + 0.35 * abs(dp)

        pnl_fast_arr = np.clip(pnl_fast_arr, -1e6, 1e6)
        pnl_slow_arr = np.clip(pnl_slow_arr, -1e6, 1e6)

        assert len(steps) == len(pnl_fast_arr) == len(pnl_slow_arr)

        fig, ax = plt.subplots(figsize=(12, 6))
        ax.plot(steps, pnl_fast_arr, 'b-', linewidth=1.2, label='Fast HFT (0.5ms latency)')
        ax.plot(steps, pnl_slow_arr, 'r-', linewidth=1.2, label='Slow Participant (5ms latency)')
        ax.fill_between(steps, pnl_slow_arr, pnl_fast_arr,
                        where=pnl_fast_arr >= pnl_slow_arr,
                        alpha=0.2, color='blue', label='Latency Premium')
        ax.set_xlabel('Time Step')
        ax.set_ylabel('Cumulative PnL (USD)')
        ax.set_title('HFT Latency Advantage: Fast vs Slow Participant Cumulative PnL')
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig_08_hft_latency.png', dpi=120)
        plt.close(fig)
        print("Saved fig_08")
    except Exception as e:
        print(f"Warning: fig_08 failed: {e}")

    # ---- Figure 9: Directional change algorithm ----
    try:
        rows_dc = all_scenario_data.get("directional_change_algorithm", [])
        if rows_dc:
            steps_dc = np.array([r["time_step"] for r in rows_dc])
            prices_dc = np.array([r["price"] for r in rows_dc])
            dc_ev = np.array([r["dc_event"] for r in rows_dc])
            dc_dir = [r["dc_direction"] for r in rows_dc]

            assert len(steps_dc) == len(prices_dc) == len(dc_ev)

            up_times = [steps_dc[i] for i in range(len(dc_ev))
                        if dc_ev[i] == 1 and dc_dir[i] == 'up']
            up_prices = [prices_dc[i] for i in range(len(dc_ev))
                         if dc_ev[i] == 1 and dc_dir[i] == 'up']
            dn_times = [steps_dc[i] for i in range(len(dc_ev))
                        if dc_ev[i] == 1 and dc_dir[i] == 'down']
            dn_prices = [prices_dc[i] for i in range(len(dc_ev))
                         if dc_ev[i] == 1 and dc_dir[i] == 'down']

            # Compute inter-DC intervals
            all_dc_times = sorted(
                [steps_dc[i] for i in range(len(dc_ev)) if dc_ev[i] == 1])
            if len(all_dc_times) >= 2:
                inter_dc = np.diff(all_dc_times)
                inter_dc_t = np.array(all_dc_times[1:])
            else:
                inter_dc = np.array([0])
                inter_dc_t = np.array([0])

            assert len(inter_dc_t) == len(inter_dc)

            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 9), sharex=False)

            ax1.plot(steps_dc, prices_dc, 'k-', linewidth=0.8, label='Price')
            if up_times and up_prices:
                ax1.scatter(up_times, up_prices, marker='^', color='green',
                            s=60, zorder=5, label='DC Up Event')
            if dn_times and dn_prices:
                ax1.scatter(dn_times, dn_prices, marker='v', color='red',
                            s=60, zorder=5, label='DC Down Event')
            ax1.set_ylabel('Price (USD)')
            ax1.set_title('Directional Change Algorithm: Detected Trend Events on Price Path')
            ax1.legend(fontsize=8)
            ax1.grid(True, alpha=0.3)

            if len(inter_dc) > 0 and len(inter_dc_t) > 0:
                ax2.bar(inter_dc_t[:len(inter_dc)], inter_dc, color='purple', alpha=0.6,
                        width=3, label='Inter-DC Interval')
                ax2.set_xlabel('Time Step')
                ax2.set_ylabel('Steps Between DC Events')
                ax2.set_title('Inter-DC-Event Time Intervals')
                ax2.legend()
                ax2.grid(True, alpha=0.3)

            plt.tight_layout()
            fig.savefig(output_dir / 'fig_09_dc_algorithm.png', dpi=120)
            plt.close(fig)
            print("Saved fig_09")
        else:
            print("Warning: fig_09 skipped - missing directional_change_algorithm data")
    except Exception as e:
        print(f"Warning: fig_09 failed: {e}")

    # ---- Figure 10: Binomial evolution function ----
    try:
        np.random.seed(999)
        n_mc = 5000
        n_trades = 100
        strategy_wr = 0.55

        p_vals_strat = np.zeros(n_mc)
        p_vals_null = np.zeros(n_mc)

        for i in range(n_mc):
            # Strategy
            wins_s = np.sum(np.random.rand(n_trades) < strategy_wr)
            pv_s = 0.0
            for k in range(int(wins_s), n_trades + 1):
                pv_s += math.comb(n_trades, k) * (0.5 ** n_trades)
            p_vals_strat[i] = clip(pv_s, 0.0, 1.0)

            # Null (50%)
            wins_n = np.sum(np.random.rand(n_trades) < 0.5)
            pv_n = 0.0
            for k in range(int(wins_n), n_trades + 1):
                pv_n += math.comb(n_trades, k) * (0.5 ** n_trades)
            p_vals_null[i] = clip(pv_n, 0.0, 1.0)

        assert len(p_vals_strat) == n_mc
        assert len(p_vals_null) == n_mc

        fig, ax = plt.subplots(figsize=(10, 6))
        bins = np.linspace(0, 1, 21)
        ax.hist(p_vals_strat, bins=bins, alpha=0.6, color='blue',
                label=f'Strategy (win rate={strategy_wr})', density=False)
        ax.hist(p_vals_null, bins=bins, alpha=0.6, color='orange',
                label='Null distribution (50% random)', density=False)
        ax.axvline(x=0.05, color='red', linestyle='--', linewidth=2,
                   label='p=0.05 significance threshold')
        ax.set_xlabel('Binomial P-Value')
        ax.set_ylabel('Frequency')
        ax.set_title('Binomial Evolution Function: Strategy Win-Rate vs Random Baseline Distribution')
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig_10_binomial_test.png', dpi=120)
        plt.close(fig)
        print("Saved fig_10")
    except Exception as e:
        print(f"Warning: fig_10 failed: {e}")


# ============================================================
# CSV WRITING
# ============================================================

SCHEMA_COLS = [
    "scenario", "time_step", "year_label", "price", "bid", "ask", "spread",
    "volume", "vwap", "twap", "moving_avg_50", "moving_avg_100",
    "portfolio_value", "position", "pnl", "drawdown", "algo_market_share",
    "volatility", "mean_reversion_signal", "pairs_spread", "pairs_spread_zscore",
    "pairs_position", "dc_event", "dc_direction", "execution_price",
    "implementation_shortfall", "latency_ms", "order_cancellation_rate",
    "binomial_p_value", "win_sequence", "strategy_type", "return_t",
    "flash_crash_flag"
]


def write_simulation_outputs(all_rows: List[Dict], output_dir: pathlib.Path):
    """Write simulation_outputs.csv with all scenario rows."""
    if not all_rows:
        print("Warning: No rows to write for simulation_outputs.csv")
        return
    out_path = output_dir / 'simulation_outputs.csv'
    try:
        with open(out_path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=SCHEMA_COLS, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"Wrote {len(all_rows)} rows to simulation_outputs.csv")
    except Exception as e:
        print(f"Warning: Failed to write simulation_outputs.csv: {e}")


def write_scenario_summary(all_scenario_data: Dict[str, List[Dict]],
                            output_dir: pathlib.Path):
    """Write scenario_summary.csv with one row per scenario."""
    if not all_scenario_data:
        print("Warning: No scenario data for summary")
        return

    numeric_cols = [
        "price", "bid", "ask", "spread", "vwap", "twap", "moving_avg_50",
        "moving_avg_100", "portfolio_value", "position", "pnl", "drawdown",
        "algo_market_share", "volatility", "mean_reversion_signal",
        "pairs_spread", "pairs_spread_zscore", "dc_event",
        "execution_price", "implementation_shortfall", "latency_ms",
        "order_cancellation_rate", "binomial_p_value", "win_sequence",
        "return_t"
    ]

    header = ["scenario"]
    for col in numeric_cols:
        header += [f"{col}_mean", f"{col}_std", f"{col}_min", f"{col}_max"]
    header += ["total_steps", "final_pnl", "max_drawdown", "final_portfolio_value"]

    out_path = output_dir / 'scenario_summary.csv'
    try:
        with open(out_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(header)
            for label, rows in all_scenario_data.items():
                if not rows:
                    continue
                row_out = [label]
                for col in numeric_cols:
                    vals = [r[col] for r in rows
                            if col in r and r[col] is not None]
                    if vals:
                        arr = np.array(vals, dtype=float)
                        row_out += [
                            float(np.mean(arr)),
                            float(np.std(arr)),
                            float(np.min(arr)),
                            float(np.max(arr))
                        ]
                    else:
                        row_out += [0.0, 0.0, 0.0, 0.0]
                row_out.append(len(rows))
                final_row = rows[-1]
                row_out.append(float(final_row.get("pnl", 0.0)))
                row_out.append(float(min(r.get("drawdown", 0.0) for r in rows)))
                row_out.append(float(final_row.get("portfolio_value", 100000.0)))
                writer.writerow(row_out)
        print(f"Wrote scenario_summary.csv with {len(all_scenario_data)} scenarios")
    except Exception as e:
        print(f"Warning: Failed to write scenario_summary.csv: {e}")


def write_parameters_used(output_dir: pathlib.Path):
    """Write parameters_used.csv."""
    out_path = output_dir / 'parameters_used.csv'
    try:
        with open(out_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["name", "value", "unit", "source", "description"])
            for row in PARAMETERS_META:
                writer.writerow(list(row))
        print(f"Wrote parameters_used.csv with {len(PARAMETERS_META)} parameters")
    except Exception as e:
        print(f"Warning: Failed to write parameters_used.csv: {e}")


def write_summary_json(all_scenario_data: Dict[str, List[Dict]],
                        output_dir: pathlib.Path):
    """Write summary.json with key aggregate metrics."""
    summary = {
        "title": MODEL_PROFILE["title"],
        "source": MODEL_PROFILE["source"],
        "scenarios": {}
    }
    for label, rows in all_scenario_data.items():
        if not rows:
            continue
        pnl_vals = [r["pnl"] for r in rows]
        price_vals = [r["price"] for r in rows]
        spread_vals = [r["spread"] for r in rows]
        summary["scenarios"][label] = {
            "num_steps": len(rows),
            "final_pnl": float(rows[-1]["pnl"]),
            "mean_pnl": float(np.mean(pnl_vals)),
            "max_drawdown": float(min(r["drawdown"] for r in rows)),
            "final_portfolio_value": float(rows[-1]["portfolio_value"]),
            "mean_price": float(np.mean(price_vals)),
            "mean_spread": float(np.mean(spread_vals)),
            "final_algo_market_share": float(rows[-1]["algo_market_share"]),
            "total_dc_events": int(sum(r["dc_event"] for r in rows)),
        }
    out_path = output_dir / 'summary.json'
    try:
        with open(out_path, 'w') as f:
            json.dump(summary, f, indent=2)
        print("Wrote summary.json")
    except Exception as e:
        print(f"Warning: Failed to write summary.json: {e}")


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Algorithmic Trading Simulator based on Wikipedia article")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files")
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir}")

    all_rows: List[Dict] = []
    all_scenario_data: Dict[str, List[Dict]] = {}

    scenarios = MODEL_PROFILE["scenarios"]
    for idx, scenario in enumerate(scenarios):
        label = scenario["label"]
        print(f"\nRunning scenario {idx}: {label}")
        try:
            rows = simulate_scenario(idx, scenario)
            all_scenario_data[label] = rows
            all_rows.extend(rows)
            print(f"  -> {len(rows)} steps simulated")
        except Exception as e:
            print(f"  Warning: Scenario {label} failed: {e}")
            import traceback
            traceback.print_exc()

    # Write CSV files
    print("\nWriting CSV files...")
    write_simulation_outputs(all_rows, output_dir)
    write_scenario_summary(all_scenario_data, output_dir)
    write_parameters_used(output_dir)

    # Write JSON summary
    write_summary_json(all_scenario_data, output_dir)

    # Generate figures
    print("\nGenerating figures...")
    generate_figures(all_scenario_data, output_dir)

    print(f"\nSimulation complete. All outputs saved to: {output_dir}")


if __name__ == "__main__":
    main()