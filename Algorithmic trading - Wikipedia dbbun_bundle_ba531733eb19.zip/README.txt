================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : f229adb8-6191-4286-ad58-1ff45e9997b3
    Generated   : 2026-04-27  18:43:21 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Algorithmic Trading - Wikipedia

    CATEGORIES
    ----------
    Financial, Machine Learning, Signal Processing

    KEYWORDS
    --------
    algorithmic trading, high-frequency trading, market microstructure, mean reversion, bid-ask spread, VWAP execution, directional change algorithm, flash crash, pairs trading, binomial evolution function

    ABSTRACT
    --------
    This simulator models the key phenomena of algorithmic and high-frequency trading as described in the Wikipedia article, including price dynamics under Geometric Brownian Motion and Ornstein-Uhlenbeck mean reversion, bid-ask spread compression from market decimalization, and the performance of canonical strategies such as mean reversion, moving average crossover, VWAP execution, pairs trading, and directional change algorithms. It reproduces the historical growth of algorithmic trading market share from 15% in 2003 to 85% in 2012 using a logistic model fitted to Figure 1 data, and simulates flash crash dynamics and HFT latency advantage effects. The simulator also implements the Binomial Evolution Function for assessing whether a strategy's win rate is statistically distinguishable from random chance. Researchers, educators, and quantitative analysts can use the generated synthetic datasets and publication-quality figures to study market microstructure, benchmark execution algorithms, and understand the ecosystem of modern algorithmic finance without requiring access to proprietary market data.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Algorithmic trading - Wikipedia.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    price, bid, ask, spread, volume, vwap, twap, moving_avg_50, moving_avg_100, portfolio_value, position, algo_market_share, volatility, mean_reversion_signal, pairs_spread, pnl, drawdown, order_cancellation_rate, latency, binomial_win_prob

    SCENARIOS  (10 total)
    ---------------------------------
        1. pre_decimalization_market_making — Simulates market making with large tick size (1/16 dollar = $0.0625 half-spread) before 2001 decimalization, showing wide spreads and high market maker profits
2. post_decimalization_market_making — Simulates market making after 2001 decimalization with tight $0.01 spreads, increased algorithmic participation, and reduced market maker edge
3. mean_reversion_strategy — Simulates an Ornstein-Uhlenbeck mean-reverting price process and the corresponding algorithmic mean-reversion trading strategy, showing buy/sell signals relative to rolling mean
4. pairs_trading_strategy — Simulates two cointegrated assets whose spread follows a mean-reverting process; pairs trading algorithm enters when spread exceeds 2 sigma and exits at 0.5 sigma
5. vwap_execution_algorithm — Simulates breaking a large 10,000-share order into 100-share slices executed over time, comparing achieved execution price to VWAP benchmark
6. flash_crash_event — Simulates a sudden algorithmic-driven price collapse (-10%) followed by rapid recovery, reproducing qualitative dynamics of the 2010 Flash Crash
7. hft_latency_advantage — Compares PnL of a fast HFT participant (0.5ms latency) versus a slow participant (5ms latency) in a market where early price information is advantageous
8. directional_change_algorithm — Simulates the DC algorithm that detects uptrend and downtrend events when price moves beyond a threshold, triggering trades on trend confirmation
9. algo_market_share_growth_2003_2012 — Reproduces the historical growth of algorithmic trading market share from 15% in 2003 to 85% in 2012 as shown in Figure 1 of the source
10. binomial_evolution_function_test — Evaluates whether a strategy with a given win rate (55%) is statistically distinguishable from random coin-flipping using the binomial distribution test described in the source

    PARAMETERS
    ----------
    42 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig_01, fig_02, fig_03, fig_04, fig_05, fig_06, fig_07, fig_08, fig_09, fig_10

    DOMAIN SUMMARY
    --------------
    This source covers the history, strategies, mechanics, and ethical implications of algorithmic trading, including high-frequency trading (HFT), market microstructure dynamics, and the growing dominance of automated systems in global financial markets from the 1970s to the present.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.