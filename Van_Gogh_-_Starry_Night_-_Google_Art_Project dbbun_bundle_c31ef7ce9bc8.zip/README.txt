================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 26d6e5f8-772d-48a1-a4d3-c85ddf47283f
    Generated   : 2026-04-15  16:42:36 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Van Gogh - The Starry Night (1889) - Turbulent Flow and Luminance Field Analysis

    CATEGORIES
    ----------
    Image Processing, Fluid dynamics, Signal Processing, Computational Intelligence, Other

    KEYWORDS
    --------
    turbulent flow, vorticity field, Kolmogorov turbulence, luminance structure function, Van Gogh Starry Night

    ABSTRACT
    --------
    This simulator models Vincent van Gogh's 'The Starry Night' (1889) as a scientifically grounded 2D turbulent fluid system, reproducing the swirling vortex field, celestial luminance halos, and Kolmogorov energy spectrum that prior research has confirmed are embedded in the painting's brushstroke structure. Using point-vortex superposition combined with spectrally synthesized Kolmogorov turbulence, the simulator generates velocity fields, vorticity maps, stream functions, and luminance distributions that closely match the visual patterns of the artwork. The simulator outputs the second-order luminance structure function S2(r) ~ r^(2/3), validating the canonical -5/3 power-law energy spectrum across multiple turbulence intensity scenarios. Researchers and educators can use the simulator to explore the intersection of art and fluid dynamics, generate synthetic training data for art analysis algorithms, or teach turbulence concepts through a visually compelling medium.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg

    SIMULATION BACKEND
    ------------------
    fluid_dynamics

    STATE VARIABLES
    ---------------
    u, v, omega, L, psi, E_k, halo_radius, star_intensity, brushstroke_angle, color_hue

    SCENARIOS  (5 total)
    ---------------------------------
        1. canonical_starry_night — Full faithful simulation of The Starry Night: 11 vortices, 11 celestial halos, Kolmogorov turbulence spectrum, canonical blue palette. Reproduces the painting's dominant large central vortex and all major swirl structures.
2. high_turbulence_intensified — Increase vortex strength and viscosity lowered — simulates a more violent turbulent sky as if van Gogh had painted in a stronger storm. Large eddies become more energetic and the energy cascade steepens.
3. calm_night_low_turbulence — Low vortex strength and high viscosity — simulates a calm night sky with minimal swirling, showing what a non-turbulent Starry Night would look like. Energy spectrum becomes shallower and streamlines nearly horizontal.
4. moon_dominant_scene — Enlarges the moon halo significantly and reduces star contributions — emphasizes the large luminous body upper-right. Tests how a single dominant light source reshapes the vortical field around it.
5. kolmogorov_scaling_sweep — Sweeps the turbulence spectral exponent from -1.0 to -2.5, showing how different turbulence regimes change the texture of the simulated sky field and comparing against the canonical -5/3 value.

    PARAMETERS
    ----------
    20 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1_vorticity_field, fig2_streamlines, fig3_turbulent_energy_spectrum, fig4_luminance_halos, fig5_structure_function, fig6_color_palette_distribution, fig7_radial_halo_profile, fig8_scenario_comparison_vorticity

    DOMAIN SUMMARY
    --------------
    This work analyzes Vincent van Gogh's 'The Starry Night' (1889) as a physical system, modeling the turbulent swirling wind patterns, celestial luminance halos, and fluid-dynamics-like brushstroke field that have been shown to exhibit Kolmogorov turbulence scaling in the luminance structure functions.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Scene3D.html      — interactive 3D visualisation (open in browser)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    View 3D scene:
        Open Scene3D.html in any modern browser (Chrome, Firefox, Safari, Edge).
        No build step, no server, no npm — just double-click to open.
        Use mouse drag to rotate the camera, scroll wheel to zoom,
        and click scenario buttons in the sidebar to switch modes.

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.