# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-15T16:42:36.882095Z
# Run ID    : 26d6e5f8-772d-48a1-a4d3-c85ddf47283f
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Van Gogh - The Starry Night (1889) - Turbulent Flow and Luminance Field Analysis

Simulator implementing 2D point-vortex superposition + Kolmogorov spectral turbulence
to model the swirling wind patterns, celestial luminance halos, and fluid-dynamics-like
brushstroke field of The Starry Night, following the scientific analysis of
Aragón et al. (2008) who confirmed Kolmogorov turbulence scaling in the painting's
luminance structure functions.
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from numpy.fft import fft2, ifft2, fftfreq

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "title": "Van Gogh - The Starry Night (1889) - Turbulent Flow and Luminance Field Analysis",
    "parameters": {
        "canvas_width": {"value": 892.0, "unit": "pixels", "source": "extracted",
                         "description": "Width of the original painting canvas in pixels (MoMA digitization)"},
        "canvas_height": {"value": 711.0, "unit": "pixels", "source": "extracted",
                          "description": "Height of the original painting canvas in pixels"},
        "grid_nx": {"value": 128, "unit": "grid cells", "source": "assumed",
                    "description": "Number of grid cells in x-direction for simulation (reduced for speed)"},
        "grid_ny": {"value": 102, "unit": "grid cells", "source": "assumed",
                    "description": "Number of grid cells in y-direction for simulation"},
        "num_vortices": {"value": 11, "unit": "count", "source": "extracted",
                         "description": "Number of major vortex centers visible in the painting sky"},
        "num_stars": {"value": 11, "unit": "count", "source": "extracted",
                      "description": "Number of distinct celestial bodies (10 stars + 1 moon)"},
        "kolmogorov_exponent": {"value": -1.667, "unit": "dimensionless", "source": "extracted",
                                "description": "Power-law exponent E(k)~k^(-5/3) per Kolmogorov scaling"},
        "viscosity": {"value": 0.001, "unit": "a.u.", "source": "assumed",
                      "description": "Effective kinematic viscosity governing vorticity diffusion"},
        "vortex_strength_large": {"value": 8.0, "unit": "a.u.", "source": "assumed",
                                  "description": "Circulation strength of the large dominant central vortex"},
        "vortex_strength_medium": {"value": 4.5, "unit": "a.u.", "source": "assumed",
                                   "description": "Circulation strength of medium eddies around stars"},
        "vortex_strength_small": {"value": 1.5, "unit": "a.u.", "source": "assumed",
                                  "description": "Circulation strength of small peripheral eddies"},
        "moon_halo_radius": {"value": 95.0, "unit": "pixels", "source": "extracted",
                             "description": "Estimated pixel radius of the large moon halo"},
        "star_halo_radius_mean": {"value": 28.0, "unit": "pixels", "source": "extracted",
                                  "description": "Mean pixel radius of star halos across the painting"},
        "sky_base_hue": {"value": 220.0, "unit": "degrees", "source": "extracted",
                         "description": "Dominant HSV hue of the night sky (deep cobalt blue)"},
        "dt": {"value": 0.05, "unit": "s", "source": "assumed",
               "description": "Simulation time step"},
        "n_timesteps": {"value": 60, "unit": "steps", "source": "assumed",
                        "description": "Number of simulation time steps (reduced for speed)"},
        "halo_decay_sigma": {"value": 0.15, "unit": "a.u.", "source": "assumed",
                             "description": "Gaussian sigma for star halo luminance decay"},
        "foreground_fraction": {"value": 0.35, "unit": "dimensionless", "source": "extracted",
                                "description": "Fraction of canvas height occupied by foreground"},
        "cypress_x_fraction": {"value": 0.18, "unit": "dimensionless", "source": "extracted",
                               "description": "Horizontal position of cypress tree as fraction of canvas width"},
        "energy_injection_scale": {"value": 0.25, "unit": "a.u.", "source": "assumed",
                                   "description": "Length scale at which turbulent energy is injected"},
    },
    "scenarios": [
        {
            "label": "canonical_starry_night",
            "description": "Full faithful simulation with 11 vortices, Kolmogorov spectrum, canonical blue palette.",
            "param_overrides": {"num_vortices": 11, "num_stars": 11,
                                "vortex_strength_large": 8.0, "kolmogorov_exponent": -1.667}
        },
        {
            "label": "high_turbulence_intensified",
            "description": "Increased vortex strength, lowered viscosity — violent turbulent sky.",
            "param_overrides": {"vortex_strength_large": 14.0, "vortex_strength_medium": 8.0,
                                "viscosity": 0.0002, "kolmogorov_exponent": -1.9}
        },
        {
            "label": "calm_night_low_turbulence",
            "description": "Low vortex strength, high viscosity — calm night sky.",
            "param_overrides": {"vortex_strength_large": 2.0, "vortex_strength_medium": 1.0,
                                "viscosity": 0.05, "kolmogorov_exponent": -1.0}
        },
        {
            "label": "moon_dominant_scene",
            "description": "Enlarged moon halo, reduced star contributions.",
            "param_overrides": {"moon_halo_radius": 160.0, "star_halo_radius_mean": 15.0,
                                "vortex_strength_large": 6.0}
        },
        {
            "label": "kolmogorov_scaling_sweep",
            "description": "Steepened turbulence spectral exponent -2.5.",
            "param_overrides": {"kolmogorov_exponent": -2.5, "num_vortices": 8,
                                "vortex_strength_large": 6.0}
        },
    ]
}

# ============================================================
# CELESTIAL BODY POSITIONS (fixed layout from painting)
# ============================================================
STAR_POSITIONS = [
    (0.82, 0.82), (0.48, 0.52), (0.14, 0.62), (0.08, 0.52), (0.22, 0.82),
    (0.35, 0.90), (0.56, 0.88), (0.70, 0.88), (0.32, 0.70), (0.42, 0.78), (0.18, 0.75),
]
STAR_INTENSITIES = [0.98, 0.95, 0.75, 0.70, 0.80, 0.72, 0.74, 0.76, 0.78, 0.73, 0.71]

VORTEX_POSITIONS = [
    (0.50, 0.72), (0.68, 0.65), (0.30, 0.80), (0.82, 0.82), (0.48, 0.52),
    (0.14, 0.62), (0.72, 0.78), (0.38, 0.68), (0.60, 0.80), (0.22, 0.75), (0.55, 0.60),
]
VORTEX_SIGNS = [+1, -1, +1, +1, -1, +1, -1, +1, -1, +1, -1]


def get_params(scenario_overrides: Dict = None) -> Dict:
    """Build parameter dict from defaults + overrides."""
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    if scenario_overrides:
        for k, v in scenario_overrides.items():
            if k in params:
                params[k] = v
    return params


def run_simulation(params: Dict, seed: int) -> Dict:
    """
    Run the Starry Night turbulent flow simulation.
    Returns a dict of all computed fields and derived quantities.
    """
    np.random.seed(seed)

    Nx = int(params["grid_nx"])
    Ny = int(params["grid_ny"])
    canvas_width = params["canvas_width"]
    moon_halo_radius = params["moon_halo_radius"]
    star_halo_radius_mean = params["star_halo_radius_mean"]
    num_vortices = int(params["num_vortices"])
    num_stars = int(params["num_stars"])
    kolmogorov_exponent = params["kolmogorov_exponent"]
    viscosity = params["viscosity"]
    dt = params["dt"]
    n_timesteps = int(params["n_timesteps"])
    foreground_fraction = params["foreground_fraction"]
    sky_base_hue = params["sky_base_hue"]
    vortex_strength_large = params["vortex_strength_large"]
    vortex_strength_medium = params["vortex_strength_medium"]
    vortex_strength_small = params["vortex_strength_small"]

    # Clamp num_vortices to available positions
    num_vortices = min(num_vortices, len(VORTEX_POSITIONS))
    num_stars = min(num_stars, len(STAR_POSITIONS))

    # 1. GRID SETUP
    x = np.linspace(0.0, 1.0, Nx)
    y = np.linspace(0.0, 1.0, Ny)
    X, Y = np.meshgrid(x, y)  # shape (Ny, Nx)
    dx = 1.0 / Nx
    dy = 1.0 / Ny

    # 2. STAR SIGMAS
    star_sigmas_base = [
        moon_halo_radius / canvas_width,
        star_halo_radius_mean / canvas_width,
        0.025, 0.022, 0.028, 0.026, 0.027, 0.026, 0.030, 0.029, 0.024
    ]
    # Use up to num_stars
    star_sigmas = star_sigmas_base[:num_stars]
    star_pos = STAR_POSITIONS[:num_stars]
    star_intens = STAR_INTENSITIES[:num_stars]

    # Halo radii in pixels for each star
    star_halo_radii = [moon_halo_radius] + [star_halo_radius_mean] * (num_stars - 1)
    star_halo_radii = star_halo_radii[:num_stars]

    # 3. VORTEX STRENGTHS
    vortex_strengths_list = [
        vortex_strength_large,
        vortex_strength_medium,
        vortex_strength_medium,
        vortex_strength_large * 0.7,
        vortex_strength_medium,
        vortex_strength_small * 2,
        vortex_strength_small * 2,
        vortex_strength_small * 2,
        vortex_strength_small * 2,
        vortex_strength_small,
        vortex_strength_small,
    ]
    vortex_strengths_list = vortex_strengths_list[:num_vortices]
    vortex_pos = VORTEX_POSITIONS[:num_vortices]
    vortex_signs = VORTEX_SIGNS[:num_vortices]

    # 4. STREAM FUNCTION from point vortices
    psi = np.zeros((Ny, Nx))
    for i in range(num_vortices):
        xv, yv = vortex_pos[i]
        Gamma = vortex_signs[i] * vortex_strengths_list[i]
        r2 = (X - xv) ** 2 + (Y - yv) ** 2 + 1e-6
        psi += (Gamma / (2.0 * np.pi)) * 0.5 * np.log(r2)

    # 5. KOLMOGOROV TURBULENCE via spectral synthesis
    kx = fftfreq(Nx, d=dx) * 2.0 * np.pi
    ky = fftfreq(Ny, d=dy) * 2.0 * np.pi
    KX, KY = np.meshgrid(kx, ky)
    K_grid = np.sqrt(KX ** 2 + KY ** 2)
    K_grid[0, 0] = 1.0  # avoid division by zero

    amplitude = K_grid ** (kolmogorov_exponent / 2.0 - 0.5)
    amplitude[0, 0] = 0.0

    random_phase = np.exp(1j * 2.0 * np.pi * np.random.rand(Ny, Nx))
    psi_turbulent = np.real(ifft2(amplitude * random_phase))
    max_val = np.abs(psi_turbulent).max()
    if max_val > 1e-12:
        psi_turbulent = psi_turbulent / max_val * 2.0
    psi = psi + psi_turbulent

    # Clamp psi to defined range
    psi = np.clip(psi, -8.0, 8.0)

    # 6. VELOCITY FIELD FROM STREAM FUNCTION
    # u = dpsi/dy, v = -dpsi/dx
    u = np.gradient(psi, dy, axis=0)   # dpsi/dy
    v = -np.gradient(psi, dx, axis=1)  # -dpsi/dx

    # Clamp velocity
    u = np.clip(u, -5.0, 5.0)
    v = np.clip(v, -5.0, 5.0)

    # 7. VORTICITY
    omega = np.gradient(v, dx, axis=1) - np.gradient(u, dy, axis=0)
    omega = np.clip(omega, -10.0, 10.0)

    # 8. TIME EVOLUTION — record mean |omega| at each step
    mean_vorticity_series = np.zeros(n_timesteps)

    for t_idx in range(n_timesteps):
        domega_dx = np.gradient(omega, dx, axis=1)
        domega_dy = np.gradient(omega, dy, axis=0)

        # Laplacian of omega
        d2omega_dx2 = np.gradient(np.gradient(omega, dx, axis=1), dx, axis=1)
        d2omega_dy2 = np.gradient(np.gradient(omega, dy, axis=0), dy, axis=0)
        lap_omega = d2omega_dx2 + d2omega_dy2

        omega_new = omega + dt * (-u * domega_dx - v * domega_dy + viscosity * lap_omega)

        # Foreground mask: dampen vorticity in lower foreground region
        fg_mask = Y < foreground_fraction
        omega_new[fg_mask] *= 0.1

        # Clamp
        omega_new = np.clip(omega_new, -10.0, 10.0)
        omega = omega_new

        mean_vorticity_series[t_idx] = np.mean(np.abs(omega))

    # 9. LUMINANCE FIELD
    L = np.ones((Ny, Nx)) * 0.2
    for i in range(num_stars):
        xs, ys = star_pos[i]
        sigma = star_sigmas[i]
        I = star_intens[i]
        r2 = (X - xs) ** 2 + (Y - ys) ** 2
        L += I * np.exp(-r2 / (2.0 * sigma ** 2))

    # Modulate with vorticity
    omega_range = omega.max() - omega.min()
    if omega_range > 1e-8:
        L += 0.05 * (omega - omega.min()) / omega_range
    else:
        L += 0.025

    # Foreground darkening
    L[Y < foreground_fraction] *= 0.3
    L = np.clip(L, 0.0, 1.0)

    # 10. COLOR HUE FIELD
    hue = np.ones((Ny, Nx)) * sky_base_hue
    star_proximity = np.zeros((Ny, Nx))
    for i in range(num_stars):
        xs, ys = star_pos[i]
        sigma2 = (star_sigmas[i] * 2.0) ** 2
        r2 = (X - xs) ** 2 + (Y - ys) ** 2
        star_proximity += np.exp(-r2 / (2.0 * sigma2))

    star_proximity = np.clip(star_proximity, 0.0, 1.0)
    hue = sky_base_hue * (1.0 - star_proximity) + 55.0 * star_proximity
    hue[Y < foreground_fraction] = 150.0
    hue = np.clip(hue, 0.0, 360.0)

    # SATURATION field
    saturation = 0.8 * (1.0 - 0.3 * L)
    saturation[Y < foreground_fraction] = 0.6
    saturation = np.clip(saturation, 0.0, 1.0)

    # 11. BRUSHSTROKE ANGLE
    brushstroke_angle = np.degrees(np.arctan2(v, u + 1e-8)) % 360.0
    brushstroke_angle = np.clip(brushstroke_angle, 0.0, 360.0)

    # 12. ENERGY SPECTRUM
    omega_hat = fft2(omega)
    power = np.abs(omega_hat) ** 2
    n_bins = 49
    k_bins = np.linspace(1.0, Nx // 2, n_bins + 1)
    E_k = np.zeros(n_bins)
    k_centers = 0.5 * (k_bins[:-1] + k_bins[1:])
    for j in range(n_bins):
        mask = (K_grid >= k_bins[j]) & (K_grid < k_bins[j + 1])
        if mask.any():
            E_k[j] = power[mask].sum()
        else:
            E_k[j] = 0.0

    E_k = np.clip(E_k, 0.0, 100.0)

    # 13. STRUCTURE FUNCTION
    n_r = 30
    r_vals = np.logspace(0, 2, n_r)
    S2 = np.zeros(n_r)
    for j in range(n_r):
        r = r_vals[j]
        sr = int(np.round(r))
        sc = int(np.round(r))
        sc2 = int(np.round(r / np.sqrt(2)))
        sr2 = int(np.round(r / np.sqrt(2)))

        diffs = []
        # shift in row
        diff1 = L - np.roll(L, sr, axis=0)
        diffs.append(np.mean(diff1 ** 2))
        # shift in col
        diff2 = L - np.roll(L, sc, axis=1)
        diffs.append(np.mean(diff2 ** 2))
        # diagonal shift
        diff3 = L - np.roll(np.roll(L, sr2, axis=0), sc2, axis=1)
        diffs.append(np.mean(diff3 ** 2))

        S2[j] = float(np.mean(diffs))

    # 14. RADIAL HALO PROFILES for 4 representative stars
    radial_star_indices = [0, 1, 2, 4]  # moon, brightest, left-cluster, upper-left
    r_max_px = 150
    r_radial = np.arange(0, r_max_px, 1).astype(float)
    radial_profiles = {}
    for si in radial_star_indices:
        if si < num_stars:
            sigma_norm = star_sigmas[si]
            sigma_px = sigma_norm * canvas_width
            I_peak = star_intens[si]
            L_bg = 0.2
            profile = I_peak * np.exp(-r_radial ** 2 / (2.0 * sigma_px ** 2)) + L_bg
            profile = np.clip(profile, 0.0, 1.0)
            radial_profiles[si] = profile

    return {
        "X": X, "Y": Y, "x": x, "y": y,
        "Nx": Nx, "Ny": Ny, "dx": dx, "dy": dy,
        "psi": psi,
        "u": u, "v": v,
        "omega": omega,
        "L": L,
        "hue": hue,
        "saturation": saturation,
        "brushstroke_angle": brushstroke_angle,
        "E_k": E_k,
        "k_centers": k_centers,
        "S2": S2,
        "r_vals": r_vals,
        "mean_vorticity_series": mean_vorticity_series,
        "n_timesteps": n_timesteps,
        "star_pos": star_pos,
        "star_halo_radii": star_halo_radii,
        "star_sigmas": star_sigmas,
        "star_intens": star_intens,
        "num_stars": num_stars,
        "radial_profiles": radial_profiles,
        "r_radial": r_radial,
        "K_grid": K_grid,
        "params": params,
    }


# ============================================================
# FIGURE GENERATION
# ============================================================

def save_fig1_vorticity(results_list: List[Dict], output_dir: pathlib.Path):
    """Fig1: Vorticity heatmap for canonical scenario."""
    try:
        res = results_list[0]  # canonical
        omega = res["omega"]
        X = res["X"]
        Y = res["Y"]

        assert omega.shape == X.shape, "Shape mismatch omega vs X"

        fig, ax = plt.subplots(figsize=(10, 7))
        vmax = np.percentile(np.abs(omega), 98)
        vmax = max(vmax, 0.01)
        im = ax.imshow(omega, origin='lower', extent=[0, 1, 0, 1],
                       cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
        cs = ax.contour(X, Y, omega, levels=[0], colors='gold', linewidths=0.8, linestyles='--')
        plt.colorbar(im, ax=ax, label='Vorticity ω (a.u./s)')
        ax.set_xlabel('x (canvas position, normalized 0-1)')
        ax.set_ylabel('y (canvas position, normalized 0-1)')
        ax.set_title("Simulated Vorticity Field — The Starry Night Sky\n(Canonical Scenario)")
        ax.axhline(y=res["params"]["foreground_fraction"], color='darkgreen',
                   linewidth=1.5, linestyle=':', label='Foreground boundary')
        ax.legend(loc='lower right', fontsize=8)
        plt.tight_layout()
        fig.savefig(output_dir / "fig1_vorticity_field.png", dpi=120)
        plt.close(fig)
        print("Saved fig1_vorticity_field.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def save_fig2_streamlines(results_list: List[Dict], output_dir: pathlib.Path):
    """Fig2: Streamlines of wind field."""
    try:
        res = results_list[0]
        u = res["u"]
        v = res["v"]
        x = res["x"]
        y = res["y"]
        X = res["X"]
        Y = res["Y"]

        speed = np.sqrt(u ** 2 + v ** 2)
        speed_norm = speed / (speed.max() + 1e-8)

        assert x.shape[0] == u.shape[1], "x/u shape mismatch"
        assert y.shape[0] == u.shape[0], "y/u shape mismatch"

        fig, ax = plt.subplots(figsize=(10, 7))
        strm = ax.streamplot(x, y, u, v, color=speed, cmap='YlOrRd',
                             linewidth=1.0, density=2.5, arrowsize=0.8)
        plt.colorbar(strm.lines, ax=ax, label='Flow speed (a.u./s)')
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('x (canvas position)')
        ax.set_ylabel('y (canvas position)')
        ax.set_title("Streamlines of the Wind Field — Van Gogh Brushstroke Directions")
        ax.axhline(y=res["params"]["foreground_fraction"], color='darkgreen',
                   linewidth=1.5, linestyle='--', alpha=0.7, label='Foreground boundary')
        ax.axvline(x=res["params"]["cypress_x_fraction"], color='saddlebrown',
                   linewidth=1.2, linestyle=':', alpha=0.7, label='Cypress position')
        ax.legend(loc='lower right', fontsize=8)
        plt.tight_layout()
        fig.savefig(output_dir / "fig2_streamlines.png", dpi=120)
        plt.close(fig)
        print("Saved fig2_streamlines.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def save_fig3_energy_spectrum(all_results: Dict[str, Dict], output_dir: pathlib.Path):
    """Fig3: Energy spectrum log-log for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(9, 6))
        colors = plt.cm.tab10(np.linspace(0, 0.9, len(all_results)))

        for idx, (label, res) in enumerate(all_results.items()):
            k_centers = res["k_centers"]
            E_k = res["E_k"]

            assert len(k_centers) == len(E_k), f"Shape mismatch k_centers/E_k for {label}"

            # Filter positive
            mask = (k_centers > 0) & (E_k > 0)
            if mask.sum() < 2:
                continue
            k_plot = k_centers[mask]
            E_plot = E_k[mask]

            ax.loglog(k_plot, E_plot, color=colors[idx], linewidth=1.8, label=label)

        # Reference line k^(-5/3)
        k_ref = np.logspace(np.log10(2), np.log10(60), 40)
        E_ref = 1e8 * k_ref ** (-5.0 / 3.0)
        assert len(k_ref) == len(E_ref)
        ax.loglog(k_ref, E_ref, 'k--', linewidth=2, label='k^(-5/3) Kolmogorov ref')

        ax.set_xlabel('Wavenumber k (log scale)')
        ax.set_ylabel('Energy spectral density E(k) (log scale)')
        ax.set_title("Turbulent Energy Spectrum E(k) — Kolmogorov -5/3 Scaling")
        ax.legend(fontsize=8, loc='upper right')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig3_turbulent_energy_spectrum.png", dpi=120)
        plt.close(fig)
        print("Saved fig3_turbulent_energy_spectrum.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def save_fig4_luminance_halos(results_list: List[Dict], output_dir: pathlib.Path):
    """Fig4: Luminance heatmap for canonical scenario."""
    try:
        res = results_list[0]
        L = res["L"]

        assert L.ndim == 2, "L must be 2D"

        fig, ax = plt.subplots(figsize=(10, 7))
        cmap = mcolors.LinearSegmentedColormap.from_list(
            'starry', ['#05073a', '#1a3a8c', '#4a7fc1', '#c8d8f0', '#fffde7', '#ffec5c'])
        im = ax.imshow(L, origin='lower', extent=[0, 1, 0, 1],
                       cmap=cmap, vmin=0, vmax=1, aspect='auto')
        plt.colorbar(im, ax=ax, label='Luminance L (a.u.)')

        # Mark star positions
        star_pos = res["star_pos"]
        for i, (xs, ys) in enumerate(star_pos):
            marker = '*' if i == 0 else '.'
            ax.plot(xs, ys, marker, color='yellow', markersize=10 if i == 0 else 6,
                    markeredgecolor='white', markeredgewidth=0.5)

        ax.set_xlabel('x (canvas position)')
        ax.set_ylabel('y (canvas position)')
        ax.set_title("Luminance Field with Celestial Halos — Stars and Moon")
        ax.axhline(y=res["params"]["foreground_fraction"], color='darkgreen',
                   linewidth=1.2, linestyle='--', alpha=0.7)
        plt.tight_layout()
        fig.savefig(output_dir / "fig4_luminance_halos.png", dpi=120)
        plt.close(fig)
        print("Saved fig4_luminance_halos.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def save_fig5_structure_function(all_results: Dict[str, Dict], output_dir: pathlib.Path):
    """Fig5: Structure function S2(r) log-log for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(9, 6))
        colors = plt.cm.tab10(np.linspace(0, 0.9, len(all_results)))

        for idx, (label, res) in enumerate(all_results.items()):
            r_vals = res["r_vals"]
            S2 = res["S2"]

            assert len(r_vals) == len(S2), f"Shape mismatch r_vals/S2 for {label}"

            mask = (r_vals > 0) & (S2 > 0)
            if mask.sum() < 2:
                continue
            r_plot = r_vals[mask]
            S2_plot = S2[mask]
            ax.loglog(r_plot, S2_plot, color=colors[idx], linewidth=1.8, label=label)

        # Kolmogorov r^(2/3) reference
        r_ref = np.logspace(0.5, 1.8, 30)
        S2_ref = 0.001 * r_ref ** (2.0 / 3.0)
        assert len(r_ref) == len(S2_ref)
        ax.loglog(r_ref, S2_ref, 'k--', linewidth=2, label='r^(2/3) Kolmogorov ref')

        ax.set_xlabel('Separation distance r (log scale, pixels)')
        ax.set_ylabel('Second-order structure function S2(r) (log scale)')
        ax.set_title("Luminance Structure Function S2(r) — Testing Kolmogorov Scaling")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig5_structure_function.png", dpi=120)
        plt.close(fig)
        print("Saved fig5_structure_function.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def save_fig6_color_distribution(all_results: Dict[str, Dict], output_dir: pathlib.Path):
    """Fig6: Hue distribution histogram."""
    try:
        fig, ax = plt.subplots(figsize=(9, 6))
        colors = plt.cm.tab10(np.linspace(0, 0.9, len(all_results)))

        bins = np.linspace(0, 360, 73)  # 5-degree bins

        first_label = list(all_results.keys())[0]
        res0 = all_results[first_label]
        Y = res0["Y"]
        foreground_fraction = res0["params"]["foreground_fraction"]

        for idx, (label, res) in enumerate(all_results.items()):
            hue = res["hue"]
            Y_local = res["Y"]
            fg_frac = res["params"]["foreground_fraction"]

            sky_mask = Y_local >= fg_frac
            sky_hues = hue[sky_mask].flatten()

            if len(sky_hues) == 0:
                continue

            counts, bin_edges = np.histogram(sky_hues, bins=bins, density=True)
            bin_centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])

            assert len(bin_centers) == len(counts)
            ax.plot(bin_centers, counts, color=colors[idx], linewidth=1.5,
                    alpha=0.8, label=label)

        # Foreground (first scenario)
        res0 = all_results[first_label]
        hue0 = res0["hue"]
        Y0 = res0["Y"]
        fg_hues = hue0[Y0 < res0["params"]["foreground_fraction"]].flatten()
        if len(fg_hues) > 0:
            counts_fg, _ = np.histogram(fg_hues, bins=bins, density=True)
            bin_centers_fg = 0.5 * (bins[:-1] + bins[1:])
            assert len(bin_centers_fg) == len(counts_fg)
            ax.plot(bin_centers_fg, counts_fg, 'g--', linewidth=1.5,
                    alpha=0.7, label='foreground (canonical)')

        ax.set_xlabel('HSV Hue angle (degrees, 0–360)')
        ax.set_ylabel('Pixel density (fraction of sky region)')
        ax.set_title("Color Hue Distribution in Sky Region — Dominance of Blue Palette")
        ax.axvline(x=220, color='blue', linestyle=':', alpha=0.5, label='Sky blue ~220°')
        ax.axvline(x=55, color='gold', linestyle=':', alpha=0.5, label='Star gold ~55°')
        ax.legend(fontsize=7)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig6_color_palette_distribution.png", dpi=120)
        plt.close(fig)
        print("Saved fig6_color_palette_distribution.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def save_fig7_radial_halo(results_list: List[Dict], output_dir: pathlib.Path):
    """Fig7: Radial luminance profiles of star halos."""
    try:
        res = results_list[0]
        radial_profiles = res["radial_profiles"]
        r_radial = res["r_radial"]
        params = res["params"]
        canvas_width = params["canvas_width"]
        star_pos = res["star_pos"]

        star_labels = {0: f"Moon (halo~{params['moon_halo_radius']:.0f}px)",
                       1: f"Brightest star (~{params['star_halo_radius_mean']:.0f}px)",
                       2: "Left cluster star",
                       4: "Upper-left star"}
        colors_map = {0: 'gold', 1: 'white', 2: 'lightyellow', 4: 'lightskyblue'}
        bg_colors = {0: '#2a2a5a', 1: '#1a1a4a', 2: '#111130', 4: '#0d0d28'}

        fig, ax = plt.subplots(figsize=(9, 6), facecolor='#05073a')
        ax.set_facecolor('#05073a')

        for si, profile in radial_profiles.items():
            lbl = star_labels.get(si, f"Star {si}")
            clr = colors_map.get(si, 'white')
            r_plot = r_radial[:len(profile)]
            assert len(r_plot) == len(profile), f"Shape mismatch r/profile for star {si}"
            ax.plot(r_plot, profile, color=clr, linewidth=2.0, label=lbl)

        ax.set_xlabel('Radial distance from star center (pixels)', color='white')
        ax.set_ylabel('Luminance L (normalized 0–1)', color='white')
        ax.set_title("Radial Luminance Profile of Star Halos — Gaussian Decay",
                     color='white')
        ax.tick_params(colors='white')
        ax.spines['bottom'].set_color('white')
        ax.spines['left'].set_color('white')
        ax.spines['top'].set_color('#05073a')
        ax.spines['right'].set_color('#05073a')
        ax.legend(fontsize=8, facecolor='#1a1a4a', labelcolor='white')
        ax.grid(True, alpha=0.2, color='white')
        plt.tight_layout()
        fig.savefig(output_dir / "fig7_radial_halo_profile.png", dpi=120,
                    facecolor='#05073a')
        plt.close(fig)
        print("Saved fig7_radial_halo_profile.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


def save_fig8_scenario_vorticity(all_results: Dict[str, Dict], output_dir: pathlib.Path):
    """Fig8: Temporal evolution of mean vorticity across scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        colors = plt.cm.tab10(np.linspace(0, 0.9, len(all_results)))

        for idx, (label, res) in enumerate(all_results.items()):
            mvs = res["mean_vorticity_series"]
            n_t = len(mvs)
            t_steps = np.arange(n_t)

            assert len(t_steps) == len(mvs), f"Shape mismatch t/mvs for {label}"
            assert len(t_steps) > 0, f"Empty vorticity series for {label}"

            ax.plot(t_steps, mvs, color=colors[idx], linewidth=2.0, label=label)

        ax.set_xlabel('Time step (simulation index)')
        ax.set_ylabel('Mean absolute vorticity ⟨|ω|⟩ (a.u.)')
        ax.set_title("Temporal Evolution of Mean Vorticity Across Scenarios")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig8_scenario_comparison_vorticity.png", dpi=120)
        plt.close(fig)
        print("Saved fig8_scenario_comparison_vorticity.png")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")


# ============================================================
# CSV WRITING
# ============================================================

def write_simulation_outputs_csv(all_results: Dict[str, Dict], output_dir: pathlib.Path):
    """Write simulation_outputs.csv — one row per grid point per scenario (sampled)."""
    try:
        fieldnames = [
            "scenario", "timestep", "grid_x", "grid_y", "x_norm", "y_norm",
            "u_velocity", "v_velocity", "vorticity_omega", "stream_function_psi",
            "luminance_L", "hue_degrees", "saturation", "brushstroke_angle_deg",
            "energy_spectral_density", "wavenumber_k",
            "structure_function_S2", "separation_r",
            "star_index", "halo_radius_px", "radial_distance_from_star", "radial_luminance"
        ]

        rows = []

        for label, res in all_results.items():
            Nx = res["Nx"]
            Ny = res["Ny"]
            X = res["X"]
            Y = res["Y"]
            u_arr = res["u"]
            v_arr = res["v"]
            omega_arr = res["omega"]
            psi_arr = res["psi"]
            L_arr = res["L"]
            hue_arr = res["hue"]
            sat_arr = res["saturation"]
            ba_arr = res["brushstroke_angle"]
            E_k = res["E_k"]
            k_centers = res["k_centers"]
            S2 = res["S2"]
            r_vals = res["r_vals"]
            star_pos = res["star_pos"]
            star_halo_radii = res["star_halo_radii"]
            r_radial = res["r_radial"]
            radial_profiles = res["radial_profiles"]
            n_timesteps = res["n_timesteps"]

            # Sample every 8th grid point to keep CSV manageable
            step = 8
            gy_indices = np.arange(0, Ny, step)
            gx_indices = np.arange(0, Nx, step)

            for gy in gy_indices:
                for gx in gx_indices:
                    # Map to spectral/structure function data by index
                    spec_idx = min(int(gx * len(E_k) / Nx), len(E_k) - 1)
                    sf_idx = min(int(gy * len(S2) / Ny), len(S2) - 1)

                    # Star info: nearest star
                    xn = X[gy, gx]
                    yn = Y[gy, gx]
                    min_dist = 1e9
                    nearest_star = 0
                    for si, (xs, ys) in enumerate(star_pos):
                        d = np.sqrt((xn - xs) ** 2 + (yn - ys) ** 2)
                        if d < min_dist:
                            min_dist = d
                            nearest_star = si
                    rad_dist_px = min_dist * res["params"]["canvas_width"]

                    # Radial luminance at that distance
                    if nearest_star in radial_profiles:
                        prof = radial_profiles[nearest_star]
                        r_idx = min(int(rad_dist_px), len(prof) - 1)
                        rad_lum = float(prof[r_idx])
                    else:
                        rad_lum = 0.2

                    row = {
                        "scenario": label,
                        "timestep": n_timesteps - 1,
                        "grid_x": int(gx),
                        "grid_y": int(gy),
                        "x_norm": round(float(X[gy, gx]), 4),
                        "y_norm": round(float(Y[gy, gx]), 4),
                        "u_velocity": round(float(np.clip(u_arr[gy, gx], -5.0, 5.0)), 4),
                        "v_velocity": round(float(np.clip(v_arr[gy, gx], -5.0, 5.0)), 4),
                        "vorticity_omega": round(float(np.clip(omega_arr[gy, gx], -10.0, 10.0)), 4),
                        "stream_function_psi": round(float(np.clip(psi_arr[gy, gx], -8.0, 8.0)), 4),
                        "luminance_L": round(float(np.clip(L_arr[gy, gx], 0.0, 1.0)), 4),
                        "hue_degrees": round(float(np.clip(hue_arr[gy, gx], 0.0, 360.0)), 2),
                        "saturation": round(float(np.clip(sat_arr[gy, gx], 0.0, 1.0)), 4),
                        "brushstroke_angle_deg": round(float(np.clip(ba_arr[gy, gx], 0.0, 360.0)), 2),
                        "energy_spectral_density": round(float(np.clip(E_k[spec_idx], 0.0, 100.0)), 4),
                        "wavenumber_k": round(float(k_centers[spec_idx]), 4),
                        "structure_function_S2": round(float(max(S2[sf_idx], 0.0)), 6),
                        "separation_r": round(float(r_vals[sf_idx]), 4),
                        "star_index": int(nearest_star),
                        "halo_radius_px": round(float(np.clip(star_halo_radii[nearest_star], 5.0, 120.0)), 2),
                        "radial_distance_from_star": round(float(rad_dist_px), 2),
                        "radial_luminance": round(float(np.clip(rad_lum, 0.0, 1.0)), 4),
                    }
                    rows.append(row)

        if not rows:
            print("WARNING: No rows to write for simulation_outputs.csv")
            return

        with open(output_dir / "simulation_outputs.csv", 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved simulation_outputs.csv ({len(rows)} rows)")

    except Exception as e:
        print(f"WARNING: simulation_outputs.csv failed: {e}")


def write_scenario_summary_csv(all_results: Dict[str, Dict], output_dir: pathlib.Path):
    """Write scenario_summary.csv — one row per scenario."""
    try:
        fieldnames = [
            "scenario",
            "mean_omega", "std_omega", "min_omega", "max_omega",
            "mean_L", "std_L", "min_L", "max_L",
            "mean_u", "std_u", "min_u", "max_u",
            "mean_v", "std_v", "min_v", "max_v",
            "mean_psi", "std_psi", "min_psi", "max_psi",
            "mean_hue", "std_hue",
            "final_mean_vorticity",
            "peak_E_k", "mean_S2",
            "kolmogorov_exponent", "viscosity", "vortex_strength_large",
        ]

        rows = []
        for label, res in all_results.items():
            omega = res["omega"]
            L = res["L"]
            u = res["u"]
            v = res["v"]
            psi = res["psi"]
            hue = res["hue"]
            E_k = res["E_k"]
            S2 = res["S2"]
            mvs = res["mean_vorticity_series"]
            params = res["params"]

            row = {
                "scenario": label,
                "mean_omega": round(float(np.mean(omega)), 5),
                "std_omega": round(float(np.std(omega)), 5),
                "min_omega": round(float(np.min(omega)), 5),
                "max_omega": round(float(np.max(omega)), 5),
                "mean_L": round(float(np.mean(L)), 5),
                "std_L": round(float(np.std(L)), 5),
                "min_L": round(float(np.min(L)), 5),
                "max_L": round(float(np.max(L)), 5),
                "mean_u": round(float(np.mean(u)), 5),
                "std_u": round(float(np.std(u)), 5),
                "min_u": round(float(np.min(u)), 5),
                "max_u": round(float(np.max(u)), 5),
                "mean_v": round(float(np.mean(v)), 5),
                "std_v": round(float(np.std(v)), 5),
                "min_v": round(float(np.min(v)), 5),
                "max_v": round(float(np.max(v)), 5),
                "mean_psi": round(float(np.mean(psi)), 5),
                "std_psi": round(float(np.std(psi)), 5),
                "min_psi": round(float(np.min(psi)), 5),
                "max_psi": round(float(np.max(psi)), 5),
                "mean_hue": round(float(np.mean(hue)), 3),
                "std_hue": round(float(np.std(hue)), 3),
                "final_mean_vorticity": round(float(mvs[-1]) if len(mvs) > 0 else 0.0, 5),
                "peak_E_k": round(float(np.max(E_k)), 4),
                "mean_S2": round(float(np.mean(S2)), 6),
                "kolmogorov_exponent": params["kolmogorov_exponent"],
                "viscosity": params["viscosity"],
                "vortex_strength_large": params["vortex_strength_large"],
            }
            rows.append(row)

        if not rows:
            print("WARNING: No rows for scenario_summary.csv")
            return

        with open(output_dir / "scenario_summary.csv", 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved scenario_summary.csv ({len(rows)} rows)")

    except Exception as e:
        print(f"WARNING: scenario_summary.csv failed: {e}")


def write_parameters_csv(output_dir: pathlib.Path):
    """Write parameters_used.csv — one row per parameter."""
    try:
        fieldnames = ["name", "value", "unit", "source", "description"]
        rows = []
        for name, meta in MODEL_PROFILE["parameters"].items():
            rows.append({
                "name": name,
                "value": meta["value"],
                "unit": meta["unit"],
                "source": meta["source"],
                "description": meta["description"],
            })

        if not rows:
            print("WARNING: No rows for parameters_used.csv")
            return

        with open(output_dir / "parameters_used.csv", 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved parameters_used.csv ({len(rows)} rows)")

    except Exception as e:
        print(f"WARNING: parameters_used.csv failed: {e}")


def write_summary_json(all_results: Dict[str, Dict], output_dir: pathlib.Path):
    """Write summary.json with key aggregate metrics."""
    try:
        summary = {
            "title": MODEL_PROFILE["title"],
            "scenarios": {},
            "global_metrics": {}
        }

        all_mean_omega = []
        all_mean_L = []

        for label, res in all_results.items():
            omega = res["omega"]
            L = res["L"]
            S2 = res["S2"]
            E_k = res["E_k"]
            mvs = res["mean_vorticity_series"]
            params = res["params"]

            mean_omega = float(np.mean(np.abs(omega)))
            mean_L = float(np.mean(L))
            all_mean_omega.append(mean_omega)
            all_mean_L.append(mean_L)

            summary["scenarios"][label] = {
                "mean_abs_vorticity": round(mean_omega, 5),
                "mean_luminance": round(mean_L, 5),
                "max_luminance": round(float(np.max(L)), 5),
                "final_mean_vorticity": round(float(mvs[-1]) if len(mvs) > 0 else 0.0, 5),
                "peak_energy_spectral_density": round(float(np.max(E_k)), 4),
                "mean_structure_function_S2": round(float(np.mean(S2[S2 > 0])) if np.any(S2 > 0) else 0.0, 6),
                "kolmogorov_exponent": params["kolmogorov_exponent"],
                "viscosity": params["viscosity"],
                "vortex_strength_large": params["vortex_strength_large"],
            }

        summary["global_metrics"] = {
            "num_scenarios": len(all_results),
            "mean_omega_across_scenarios": round(float(np.mean(all_mean_omega)), 5),
            "mean_luminance_across_scenarios": round(float(np.mean(all_mean_L)), 5),
        }

        with open(output_dir / "summary.json", 'w') as f:
            json.dump(summary, f, indent=2)
        print("Saved summary.json")

    except Exception as e:
        print(f"WARNING: summary.json failed: {e}")


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Starry Night Turbulent Flow Simulator")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    # Run all scenarios
    all_results: Dict[str, Dict] = {}
    results_list: List[Dict] = []

    scenarios = MODEL_PROFILE["scenarios"]
    for seed_idx, scenario in enumerate(scenarios):
        label = scenario["label"]
        overrides = scenario.get("param_overrides", {})
        print(f"\nRunning scenario [{seed_idx}]: {label}")
        print(f"  Overrides: {overrides}")

        params = get_params(overrides)
        result = run_simulation(params, seed=seed_idx)
        result["label"] = label

        all_results[label] = result
        results_list.append(result)

        print(f"  mean|omega|={np.mean(np.abs(result['omega'])):.4f}, "
              f"mean_L={np.mean(result['L']):.4f}, "
              f"kolmogorov_exp={params['kolmogorov_exponent']}")

    print("\nGenerating figures...")
    save_fig1_vorticity(results_list, output_dir)
    save_fig2_streamlines(results_list, output_dir)
    save_fig3_energy_spectrum(all_results, output_dir)
    save_fig4_luminance_halos(results_list, output_dir)
    save_fig5_structure_function(all_results, output_dir)
    save_fig6_color_distribution(all_results, output_dir)
    save_fig7_radial_halo(results_list, output_dir)
    save_fig8_scenario_vorticity(all_results, output_dir)

    print("\nWriting CSV files...")
    write_simulation_outputs_csv(all_results, output_dir)
    write_scenario_summary_csv(all_results, output_dir)
    write_parameters_csv(output_dir)

    print("\nWriting JSON summary...")
    write_summary_json(all_results, output_dir)

    print(f"\nAll outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()