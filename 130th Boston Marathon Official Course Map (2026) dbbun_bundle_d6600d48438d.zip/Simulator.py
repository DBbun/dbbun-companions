# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-20T00:42:05.555133Z
# Run ID    : ea19c149-68d2-4372-94df-e062173e1217
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Boston Marathon 2026 Course Simulator
Based on: 130th Boston Marathon Official Course Map (2026)

Models physiological dynamics (pace, energy reserve, heart rate) of running the
26.2-mile Boston Marathon course from Hopkinton to Copley Square, using a
piecewise-cubic elevation profile and Euler-integration ODE system.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "parameters": {
        "base_pace_min_per_mi":       8.0,
        "elite_pace_min_per_mi":      4.75,
        "total_distance_mi":          26.2,
        "start_elevation_ft":         462.0,
        "finish_elevation_ft":        18.0,
        "heartbreak_hill_mile":       20.8,
        "heartbreak_hill_elevation_ft": 245.0,
        "newton_hills_start_mile":    17.0,
        "grade_pace_factor":          0.033,
        "fatigue_rate":               0.032,
        "fatigue_pace_factor":        2.5,
        "aid_station_interval_mi":    1.0,
        "aid_station_energy_recovery": 0.03,
        "hr_base":                    140.0,
        "hr_grade_factor":            3.0,
        "hr_fatigue_factor":          15.0,
        "num_runners":                30000.0,
        "pace_std_dev":               1.5,
        "downhill_pace_factor":       0.015,
        "quad_damage_factor":         0.008,
        "sensory_area_mile":          13.5,
    },
    "scenarios": [
        {
            "label": "recreational_runner",
            "description": "Average recreational runner targeting 4-hour finish",
            "param_overrides": {
                "base_pace_min_per_mi": 9.16,
                "fatigue_rate": 0.038,
                "fatigue_pace_factor": 3.5,
            },
        },
        {
            "label": "sub_3hr_runner",
            "description": "Competitive amateur targeting sub-3hr finish",
            "param_overrides": {
                "base_pace_min_per_mi": 6.87,
                "fatigue_rate": 0.025,
                "fatigue_pace_factor": 1.8,
            },
        },
        {
            "label": "elite_runner",
            "description": "Elite runner targeting ~2:05 finish",
            "param_overrides": {
                "base_pace_min_per_mi": 4.75,
                "fatigue_rate": 0.015,
                "fatigue_pace_factor": 0.8,
                "grade_pace_factor": 0.018,
            },
        },
        {
            "label": "positive_split_runner",
            "description": "Runner who starts too fast and bonks after mile 20",
            "param_overrides": {
                "base_pace_min_per_mi": 8.0,
                "fatigue_rate": 0.055,
                "fatigue_pace_factor": 5.0,
            },
        },
        {
            "label": "negative_split_runner",
            "description": "Disciplined runner with conservative start and strong finish",
            "param_overrides": {
                "base_pace_min_per_mi": 8.5,
                "fatigue_rate": 0.020,
                "fatigue_pace_factor": 1.2,
            },
        },
        {
            "label": "population_simulation",
            "description": "Monte Carlo simulation of 500 runners from Gaussian pace distribution",
            "param_overrides": {
                "num_runners": 500.0,
                "pace_std_dev": 1.8,
            },
        },
    ],
}

# ─────────────────────────────────────────────────────────────────────────────
# ELEVATION WAYPOINTS & COURSE GEOMETRY
# ─────────────────────────────────────────────────────────────────────────────
ELEVATION_WAYPOINTS = {
    0.0: 462, 1.0: 400, 2.0: 350, 3.0: 320, 4.0: 305, 5.0: 295,
    6.0: 285, 6.5: 280, 7.0: 270, 8.0: 265, 9.0: 200, 10.0: 175,
    11.0: 170, 12.0: 165, 13.0: 160, 13.5: 158, 14.0: 155, 15.0: 155,
    16.0: 155, 17.0: 160, 17.5: 195, 18.0: 175, 18.5: 205, 19.0: 190,
    19.2: 210, 19.5: 225, 20.0: 230, 20.8: 245, 21.0: 235, 22.0: 180,
    23.0: 130, 24.0: 90, 25.0: 55, 25.2: 50, 26.0: 25, 26.2: 18
}

TOWN_BOUNDARIES = {
    'Hopkinton':  (0.0,  1.5),
    'Ashland':    (1.5,  6.5),
    'Framingham': (6.5,  10.5),
    'Natick':     (10.5, 13.5),
    'Wellesley':  (13.5, 16.5),
    'Newton':     (16.5, 21.5),
    'Brookline':  (21.5, 24.5),
    'Boston':     (24.5, 26.3),
}

LANDMARKS = {
    1.0:  'Kyriakides Statue',
    6.5:  'Framingham Depot',
    13.5: 'Sensory-Friendly Area',
    17.0: 'Newton Hills Start',
    19.2: 'Johnny Kelley Statue',
    20.8: 'Heartbreak Hill Crest',
    25.2: 'CITGO Sign',
}

DS = 0.1  # step size in miles


# ─────────────────────────────────────────────────────────────────────────────
# ELEVATION PROFILE CONSTRUCTION (piecewise linear interpolation)
# ─────────────────────────────────────────────────────────────────────────────
def build_course_profile() -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build distance grid, elevation profile, and grade profile."""
    distance_grid = np.arange(0.0, 26.21, DS)
    n = len(distance_grid)

    # Sort waypoints
    wdist = np.array(sorted(ELEVATION_WAYPOINTS.keys()))
    welev = np.array([ELEVATION_WAYPOINTS[d] for d in wdist])

    # Piecewise linear interpolation (no scipy dependency)
    elevation_profile = np.interp(distance_grid, wdist, welev)

    # Clamp elevation to spec range [10, 462]
    elevation_profile = np.clip(elevation_profile, 10.0, 462.0)

    # Grade: rise/run converted to percent
    # rise in feet, run in feet (1 mile = 5280 ft)
    grade_profile = np.gradient(elevation_profile, distance_grid) / 5280.0 * 100.0

    # Clamp grade to spec range [-8, 8]
    grade_profile = np.clip(grade_profile, -8.0, 8.0)

    return distance_grid, elevation_profile, grade_profile


def get_town(d: float) -> str:
    """Return town name for given distance."""
    for town, (a, b) in TOWN_BOUNDARIES.items():
        if a <= d < b:
            return town
    return 'Boston'


def get_landmark(d: float) -> str:
    """Return landmark name if within 0.05 miles of a landmark."""
    d_rounded = round(d, 1)
    return LANDMARKS.get(d_rounded, '')


# ─────────────────────────────────────────────────────────────────────────────
# CORE SIMULATION
# ─────────────────────────────────────────────────────────────────────────────
def simulate_runner(
    runner_id: int,
    runner_base_pace: float,
    scenario_label: str,
    params: dict,
    distance_grid: np.ndarray,
    elevation_profile: np.ndarray,
    grade_profile: np.ndarray,
) -> List[dict]:
    """Simulate a single runner over the full course. Returns list of row dicts."""

    # Extract parameters
    fatigue_rate         = params['fatigue_rate']
    fatigue_pace_factor  = params['fatigue_pace_factor']
    grade_pace_factor    = params['grade_pace_factor']
    downhill_pace_factor = params['downhill_pace_factor']
    quad_damage_factor   = params['quad_damage_factor']
    aid_recovery         = params['aid_station_energy_recovery']
    hr_base              = params['hr_base']
    hr_grade_factor      = params['hr_grade_factor']
    hr_fatigue_factor    = params['hr_fatigue_factor']

    # Pacing strategy multiplier
    if scenario_label == 'positive_split_runner':
        half_pace_multiplier = 0.90
    elif scenario_label == 'negative_split_runner':
        half_pace_multiplier = 1.05
    else:
        half_pace_multiplier = 1.0

    # State initialization
    energy       = 1.0
    elapsed_time = 0.0
    cum_gain     = 0.0
    cum_loss     = 0.0

    rows = []
    n = len(distance_grid)

    for i in range(n):
        d     = distance_grid[i]
        grade = float(grade_profile[i])
        elev  = float(elevation_profile[i])

        # 5a. Grade pace adjustment
        if grade >= 0.0:
            grade_adjustment = grade_pace_factor * grade
        else:
            grade_adjustment = -downhill_pace_factor * abs(grade)

        # 5b. Fatigue pace adjustment
        fatigue_adjustment = fatigue_pace_factor * (1.0 - energy)

        # 5c. Strategy multiplier
        strategy_mult = half_pace_multiplier if d < 13.1 else (2.0 - half_pace_multiplier)

        # 5d. Instantaneous pace
        instant_pace = (runner_base_pace * strategy_mult) + grade_adjustment + fatigue_adjustment
        # Floor: can't run too fast (85% of base pace)
        floor_pace = runner_base_pace * 0.85
        instant_pace = max(floor_pace, instant_pace)
        # Ceiling: walk limit
        instant_pace = min(instant_pace, 30.0)
        # Spec range clamp
        instant_pace = max(5.0, min(20.0, instant_pace))

        # 5e. Time integration
        dt = instant_pace * DS
        elapsed_time += dt
        # Clamp elapsed_time to spec
        elapsed_time = min(elapsed_time, 480.0)

        # 5f. Energy depletion
        downhill_extra = quad_damage_factor * max(0.0, -grade) * DS
        energy -= (fatigue_rate * DS + downhill_extra)

        # 5g. Aid station recovery (every integer mile, d > 0)
        at_aid = False
        if d > 0.0 and abs(round(d) - d) < 0.05:
            at_aid = True
            energy = min(1.0, energy + aid_recovery)

        # Clamp energy to spec [0, 1]
        energy = max(0.0, min(1.0, energy))

        # 5h. Heart rate
        hr = hr_base + hr_grade_factor * grade + hr_fatigue_factor * (1.0 - energy)
        hr = float(np.clip(hr, 80.0, 200.0))

        # 5i. Cumulative elevation
        if i > 0:
            delta_elev = elevation_profile[i] - elevation_profile[i - 1]
            if delta_elev > 0.0:
                cum_gain += delta_elev
            else:
                cum_loss += abs(delta_elev)

        # Clamp cumulative gains/losses to spec
        cum_gain = min(cum_gain, 1000.0)
        cum_loss = min(cum_loss, 1500.0)

        # 5j. Split time = dt (time for this 0.1-mile segment)
        split_time = max(4.5, min(25.0, dt * 10.0))  # scale to per-mile

        # Build row
        row = {
            'scenario':                    scenario_label,
            'runner_id':                   runner_id,
            'distance_mi':                 round(float(d), 2),
            'elevation_ft':                round(float(elev), 2),
            'grade_pct':                   round(float(grade), 4),
            'pace_min_per_mi':             round(float(instant_pace), 4),
            'elapsed_time_min':            round(float(elapsed_time), 4),
            'energy_reserve':              round(float(energy), 6),
            'heart_rate':                  round(float(hr), 2),
            'cumulative_elevation_gain_ft': round(float(cum_gain), 2),
            'cumulative_elevation_loss_ft': round(float(cum_loss), 2),
            'split_time_min':              round(float(split_time), 4),
            'at_aid_station':              int(at_aid),
            'town_segment':                get_town(d),
            'landmark_nearby':             get_landmark(d),
        }
        rows.append(row)

    return rows


def get_scenario_params(scenario: dict) -> dict:
    """Merge base parameters with scenario overrides."""
    params = dict(MODEL_PROFILE['parameters'])
    params.update(scenario.get('param_overrides', {}))
    return params


def run_all_scenarios(
    distance_grid: np.ndarray,
    elevation_profile: np.ndarray,
    grade_profile: np.ndarray,
) -> Tuple[List[dict], dict]:
    """Run all scenarios and return all rows + summary data."""
    all_rows = []
    scenario_results = {}  # label -> {rows, finish_times, params}

    for scenario_idx, scenario in enumerate(MODEL_PROFILE['scenarios']):
        label = scenario['label']
        np.random.seed(scenario_idx)  # reproducible per scenario

        params = get_scenario_params(scenario)

        base_pace  = params['base_pace_min_per_mi']
        pace_std   = params['pace_std_dev']
        num_run    = int(params['num_runners'])

        # Population simulation uses many runners; others use one
        if label == 'population_simulation':
            pace_samples = np.random.normal(base_pace, pace_std, num_run)
            # Clamp paces to reasonable range
            pace_samples = np.clip(pace_samples, 4.5, 20.0)
        else:
            pace_samples = np.array([base_pace])

        scenario_rows = []
        finish_times  = []

        for runner_id, runner_pace in enumerate(pace_samples):
            rows = simulate_runner(
                runner_id=runner_id,
                runner_base_pace=float(runner_pace),
                scenario_label=label,
                params=params,
                distance_grid=distance_grid,
                elevation_profile=elevation_profile,
                grade_profile=grade_profile,
            )
            scenario_rows.extend(rows)
            if rows:
                finish_times.append(rows[-1]['elapsed_time_min'])

        # For non-population scenarios, add to all_rows
        # For population, also add (but limit output rows to avoid huge CSV)
        if label == 'population_simulation':
            # Only store first 5 runners' full data in simulation_outputs.csv
            pop_rows_limit = []
            for runner_id in range(min(5, len(pace_samples))):
                start = runner_id * len(distance_grid)
                end   = start + len(distance_grid)
                pop_rows_limit.extend(scenario_rows[start:end])
            all_rows.extend(pop_rows_limit)
        else:
            all_rows.extend(scenario_rows)

        scenario_results[label] = {
            'rows':         scenario_rows,
            'finish_times': finish_times,
            'params':       params,
            'pace_samples': pace_samples.tolist(),
        }

        print(f"  Scenario '{label}': {len(pace_samples)} runner(s), "
              f"finish time(s) [{min(finish_times):.1f}–{max(finish_times):.1f}] min")

    return all_rows, scenario_results


# ─────────────────────────────────────────────────────────────────────────────
# CSV WRITERS
# ─────────────────────────────────────────────────────────────────────────────
FIELDNAMES = [
    'scenario', 'runner_id', 'distance_mi', 'elevation_ft', 'grade_pct',
    'pace_min_per_mi', 'elapsed_time_min', 'energy_reserve', 'heart_rate',
    'cumulative_elevation_gain_ft', 'cumulative_elevation_loss_ft',
    'split_time_min', 'at_aid_station', 'town_segment', 'landmark_nearby',
]


def write_simulation_outputs(all_rows: List[dict], output_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv with all scenario rows."""
    if not all_rows:
        print("WARNING: No simulation rows to write.")
        return
    out_path = output_dir / 'simulation_outputs.csv'
    try:
        with open(out_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"  Written: {out_path} ({len(all_rows)} rows)")
    except Exception as e:
        print(f"WARNING: Could not write simulation_outputs.csv: {e}")


def write_scenario_summary(
    scenario_results: dict, output_dir: pathlib.Path
) -> None:
    """Write scenario_summary.csv with aggregate metrics per scenario."""
    summary_rows = []
    state_vars = [
        'pace_min_per_mi', 'energy_reserve', 'heart_rate',
        'elapsed_time_min', 'grade_pct', 'elevation_ft',
        'cumulative_elevation_gain_ft', 'cumulative_elevation_loss_ft',
    ]

    for label, result in scenario_results.items():
        rows = result['rows']
        if not rows:
            continue
        finish_times = result['finish_times']

        summary = {'scenario': label}

        # Aggregate each state variable
        for var in state_vars:
            vals = np.array([r[var] for r in rows], dtype=float)
            summary[f'{var}_mean'] = round(float(np.mean(vals)), 4)
            summary[f'{var}_std']  = round(float(np.std(vals)),  4)
            summary[f'{var}_min']  = round(float(np.min(vals)),  4)
            summary[f'{var}_max']  = round(float(np.max(vals)),  4)

        # Finish time metrics
        ft = np.array(finish_times, dtype=float)
        summary['finish_time_mean_min'] = round(float(np.mean(ft)), 2)
        summary['finish_time_std_min']  = round(float(np.std(ft)),  2)
        summary['finish_time_min_min']  = round(float(np.min(ft)),  2)
        summary['finish_time_max_min']  = round(float(np.max(ft)),  2)
        summary['num_runners']           = len(finish_times)

        summary_rows.append(summary)

    if not summary_rows:
        print("WARNING: No summary rows to write.")
        return

    out_path = output_dir / 'scenario_summary.csv'
    try:
        fieldnames = list(summary_rows[0].keys())
        with open(out_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(summary_rows)
        print(f"  Written: {out_path} ({len(summary_rows)} rows)")
    except Exception as e:
        print(f"WARNING: Could not write scenario_summary.csv: {e}")


def write_parameters_used(output_dir: pathlib.Path) -> None:
    """Write parameters_used.csv with all model parameters."""
    param_meta = {
        'base_pace_min_per_mi':       ('min/mile',        'assumed',   'Flat-ground target pace for average recreational runner'),
        'elite_pace_min_per_mi':      ('min/mile',        'assumed',   'Flat-ground target pace for elite runner (~2:04 finish)'),
        'total_distance_mi':          ('miles',           'extracted', 'Official course distance (26.2 miles / 42.2 km)'),
        'start_elevation_ft':         ('feet',            'extracted', 'Start elevation at Hopkinton'),
        'finish_elevation_ft':        ('feet',            'extracted', 'Finish elevation at Copley Square'),
        'heartbreak_hill_mile':       ('miles',           'extracted', 'Mile marker at Heartbreak Hill crest'),
        'heartbreak_hill_elevation_ft':('feet',           'extracted', 'Elevation at Heartbreak Hill crest'),
        'newton_hills_start_mile':    ('miles',           'extracted', 'Start of Newton Hills'),
        'grade_pace_factor':          ('min/mile/%grade', 'assumed',   'Pace penalty per percent uphill grade'),
        'fatigue_rate':               ('1/mile',          'assumed',   'Energy reserve depletion rate per mile'),
        'fatigue_pace_factor':        ('min/mile',        'assumed',   'Max pace slowdown at full fatigue'),
        'aid_station_interval_mi':    ('miles',           'extracted', 'Gatorade/water every mile mark'),
        'aid_station_energy_recovery':('a.u.',            'assumed',   'Energy recovery per aid station'),
        'hr_base':                    ('bpm',             'assumed',   'Baseline heart rate at target flat pace'),
        'hr_grade_factor':            ('bpm/%grade',      'assumed',   'Heart rate increase per percent uphill'),
        'hr_fatigue_factor':          ('bpm',             'assumed',   'Additional heart rate at full fatigue'),
        'num_runners':                ('runners',         'assumed',   'Approximate field size'),
        'pace_std_dev':               ('min/mile',        'assumed',   'Standard deviation of base pace across population'),
        'downhill_pace_factor':       ('min/mile/%grade', 'assumed',   'Pace benefit per percent downhill grade'),
        'quad_damage_factor':         ('1/mile',          'assumed',   'Extra fatigue rate on downhill from eccentric loading'),
        'sensory_area_mile':          ('miles',           'extracted', 'Location of Sensory-Friendly Viewing Area in Wellesley'),
    }

    params = MODEL_PROFILE['parameters']
    rows = []
    for name, value in params.items():
        meta = param_meta.get(name, ('unknown', 'assumed', name))
        rows.append({
            'name':        name,
            'value':       value,
            'unit':        meta[0],
            'source':      meta[1],
            'description': meta[2],
        })

    if not rows:
        print("WARNING: No parameter rows to write.")
        return

    out_path = output_dir / 'parameters_used.csv'
    try:
        with open(out_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['name', 'value', 'unit', 'source', 'description'])
            writer.writeheader()
            writer.writerows(rows)
        print(f"  Written: {out_path} ({len(rows)} rows)")
    except Exception as e:
        print(f"WARNING: Could not write parameters_used.csv: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE GENERATION
# ─────────────────────────────────────────────────────────────────────────────
ARCHETYPE_COLORS = {
    'elite_runner':         '#1a237e',
    'sub_3hr_runner':       '#0288d1',
    'recreational_runner':  '#388e3c',
    'positive_split_runner':'#d32f2f',
    'negative_split_runner':'#f57c00',
}

ARCHETYPE_LABELS = {
    'elite_runner':         'Elite (~4:45/mi)',
    'sub_3hr_runner':       'Sub-3hr (~6:52/mi)',
    'recreational_runner':  'Recreational (~9:10/mi)',
    'positive_split_runner':'Positive Split (~8:00/mi)',
    'negative_split_runner':'Negative Split (~8:30/mi)',
}

INDIVIDUAL_SCENARIOS = [
    'elite_runner', 'sub_3hr_runner', 'recreational_runner',
    'positive_split_runner', 'negative_split_runner',
]


def extract_arrays(scenario_rows: List[dict], x_key: str, y_key: str) -> Tuple[np.ndarray, np.ndarray]:
    """Extract matched x/y arrays from scenario rows for runner_id=0."""
    x_list, y_list = [], []
    for row in scenario_rows:
        if row.get('runner_id', 0) == 0:
            x_list.append(row[x_key])
            y_list.append(row[y_key])
    return np.array(x_list, dtype=float), np.array(y_list, dtype=float)


def fig1_elevation_profile(
    distance_grid: np.ndarray,
    elevation_profile: np.ndarray,
    output_dir: pathlib.Path,
) -> None:
    """Fig 1: Course elevation profile."""
    try:
        assert len(distance_grid) == len(elevation_profile), "Shape mismatch"
        if len(distance_grid) == 0:
            print("WARNING fig1: empty arrays, skipping.")
            return

        fig, ax = plt.subplots(figsize=(14, 5))
        ax.fill_between(distance_grid, elevation_profile, alpha=0.3, color='saddlebrown')
        ax.plot(distance_grid, elevation_profile, color='saddlebrown', linewidth=2)

        # Landmark vertical lines
        landmark_colors = {
            1.0:  ('gray',   'Kyriakides\nStatue'),
            6.5:  ('blue',   'Framingham\nDepot'),
            17.0: ('orange', 'Newton Hills\nStart'),
            19.2: ('purple', 'Johnny Kelley\nStatue'),
            20.8: ('red',    'Heartbreak\nHill Crest'),
            25.2: ('green',  'CITGO Sign'),
        }
        for mile, (color, lbl) in landmark_colors.items():
            ax.axvline(x=mile, color=color, linestyle='--', alpha=0.6, linewidth=1.2)
            elev_at = float(np.interp(mile, distance_grid, elevation_profile))
            ax.text(mile + 0.1, elev_at + 15, lbl, fontsize=7, color=color,
                    va='bottom', rotation=0)

        # Town shading
        town_colors_bg = {
            'Hopkinton': '#fff9c4', 'Ashland': '#e8f5e9', 'Framingham': '#e3f2fd',
            'Natick': '#fce4ec', 'Wellesley': '#f3e5f5', 'Newton': '#fff3e0',
            'Brookline': '#e0f7fa', 'Boston': '#f1f8e9',
        }
        for town, (a, b) in TOWN_BOUNDARIES.items():
            ax.axvspan(a, min(b, 26.2), alpha=0.15, color=town_colors_bg.get(town, 'white'))

        ax.set_xlabel('Distance (miles)', fontsize=12)
        ax.set_ylabel('Elevation (feet)', fontsize=12)
        ax.set_title('Boston Marathon Course Elevation Profile (0–26.2 miles)', fontsize=14, fontweight='bold')
        ax.set_xlim(0, 26.2)
        ax.set_ylim(0, 500)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig1_elevation_profile.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig1_elevation_profile.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def fig2_pace_by_archetype(
    scenario_results: dict, output_dir: pathlib.Path
) -> None:
    """Fig 2: Mile-by-mile pace by runner archetype."""
    try:
        fig, ax = plt.subplots(figsize=(14, 6))
        plotted = 0
        for label in INDIVIDUAL_SCENARIOS:
            if label not in scenario_results:
                continue
            rows = scenario_results[label]['rows']
            x, y = extract_arrays(rows, 'distance_mi', 'pace_min_per_mi')
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                print(f"WARNING fig2: empty arrays for {label}, skipping.")
                continue
            ax.plot(x, y, label=ARCHETYPE_LABELS.get(label, label),
                    color=ARCHETYPE_COLORS.get(label, 'black'), linewidth=2)
            plotted += 1

        if plotted == 0:
            print("WARNING fig2: no data plotted, skipping save.")
            plt.close()
            return

        ax.axvline(x=17.0, color='orange', linestyle=':', alpha=0.7, linewidth=1.5, label='Newton Hills Start')
        ax.axvline(x=20.8, color='red',    linestyle=':', alpha=0.7, linewidth=1.5, label='Heartbreak Hill')
        ax.set_xlabel('Distance (miles)', fontsize=12)
        ax.set_ylabel('Pace (min/mile)', fontsize=12)
        ax.set_title('Mile-by-Mile Pace by Runner Archetype', fontsize=14, fontweight='bold')
        ax.set_xlim(0, 26.2)
        ax.set_ylim(4, 20)
        ax.legend(loc='upper left', fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig2_pace_by_archetype.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig2_pace_by_archetype.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def fig3_energy_reserve(
    scenario_results: dict, output_dir: pathlib.Path
) -> None:
    """Fig 3: Energy reserve depletion by runner type."""
    try:
        fig, ax = plt.subplots(figsize=(14, 6))
        plotted = 0
        for label in INDIVIDUAL_SCENARIOS:
            if label not in scenario_results:
                continue
            rows = scenario_results[label]['rows']
            x, y = extract_arrays(rows, 'distance_mi', 'energy_reserve')
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=ARCHETYPE_LABELS.get(label, label),
                    color=ARCHETYPE_COLORS.get(label, 'black'), linewidth=2)
            plotted += 1

        if plotted == 0:
            print("WARNING fig3: no data plotted, skipping save.")
            plt.close()
            return

        # Mark aid stations
        for mi in range(1, 27):
            if mi <= 26.2:
                ax.axvline(x=mi, color='lightblue', linestyle='-', alpha=0.4, linewidth=0.8)

        ax.axhline(y=0.4, color='gray', linestyle='--', alpha=0.5, linewidth=1, label='Reserve = 0.4')
        ax.axvline(x=20.8, color='red', linestyle=':', alpha=0.7, linewidth=1.5)
        ax.set_xlabel('Distance (miles)', fontsize=12)
        ax.set_ylabel('Energy Reserve (1.0 = full)', fontsize=12)
        ax.set_title('Energy Reserve Depletion Along Course by Runner Type', fontsize=14, fontweight='bold')
        ax.set_xlim(0, 26.2)
        ax.set_ylim(0, 1.05)
        ax.legend(loc='upper right', fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig3_energy_reserve.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig3_energy_reserve.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def fig4_heart_rate(
    scenario_results: dict, output_dir: pathlib.Path
) -> None:
    """Fig 4: Heart rate profile by runner archetype."""
    try:
        fig, ax = plt.subplots(figsize=(14, 6))
        plotted = 0
        for label in INDIVIDUAL_SCENARIOS:
            if label not in scenario_results:
                continue
            rows = scenario_results[label]['rows']
            x, y = extract_arrays(rows, 'distance_mi', 'heart_rate')
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=ARCHETYPE_LABELS.get(label, label),
                    color=ARCHETYPE_COLORS.get(label, 'black'), linewidth=2)
            plotted += 1

        if plotted == 0:
            print("WARNING fig4: no data plotted, skipping save.")
            plt.close()
            return

        ax.axvline(x=17.0, color='orange', linestyle=':', alpha=0.7, linewidth=1.5, label='Newton Hills Start')
        ax.axvline(x=20.8, color='red',    linestyle=':', alpha=0.7, linewidth=1.5, label='Heartbreak Hill')
        ax.set_xlabel('Distance (miles)', fontsize=12)
        ax.set_ylabel('Heart Rate (bpm)', fontsize=12)
        ax.set_title('Estimated Heart Rate Profile by Runner Archetype', fontsize=14, fontweight='bold')
        ax.set_xlim(0, 26.2)
        ax.set_ylim(80, 210)
        ax.legend(loc='upper left', fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig4_heart_rate.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig4_heart_rate.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def fig5_elapsed_time(
    scenario_results: dict, output_dir: pathlib.Path
) -> None:
    """Fig 5: Cumulative elapsed time vs distance."""
    try:
        fig, ax = plt.subplots(figsize=(14, 6))
        plotted = 0
        for label in INDIVIDUAL_SCENARIOS:
            if label not in scenario_results:
                continue
            rows = scenario_results[label]['rows']
            x, y = extract_arrays(rows, 'distance_mi', 'elapsed_time_min')
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                continue
            ax.plot(x, y, label=ARCHETYPE_LABELS.get(label, label),
                    color=ARCHETYPE_COLORS.get(label, 'black'), linewidth=2)
            plotted += 1

        if plotted == 0:
            print("WARNING fig5: no data plotted, skipping save.")
            plt.close()
            return

        # Reference even-pace line for 8.0 min/mile
        ref_x = np.array([0.0, 26.2])
        ref_y = np.array([0.0, 26.2 * 8.0])
        ax.plot(ref_x, ref_y, 'k--', linewidth=1.2, alpha=0.5, label='Even 8:00/mi pace')

        ax.set_xlabel('Distance (miles)', fontsize=12)
        ax.set_ylabel('Elapsed Time (minutes)', fontsize=12)
        ax.set_title('Cumulative Elapsed Time vs Distance (All Archetypes)', fontsize=14, fontweight='bold')
        ax.set_xlim(0, 26.2)
        ax.set_ylim(0, 480)
        ax.legend(loc='upper left', fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig5_elapsed_time.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig5_elapsed_time.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def fig6_finishing_histogram(
    scenario_results: dict, output_dir: pathlib.Path
) -> None:
    """Fig 6: Finishing time distribution histogram for population simulation."""
    try:
        if 'population_simulation' not in scenario_results:
            print("WARNING fig6: population_simulation not found, skipping.")
            return
        finish_times = scenario_results['population_simulation']['finish_times']
        if not finish_times or len(finish_times) < 2:
            print("WARNING fig6: insufficient finish times, skipping.")
            return

        ft = np.array(finish_times, dtype=float)
        assert len(ft) > 0, "Empty finish times"

        fig, ax1 = plt.subplots(figsize=(12, 6))
        n_bins = min(40, max(10, len(ft) // 10))
        counts, bin_edges, patches = ax1.hist(
            ft, bins=n_bins, color='steelblue', edgecolor='white', alpha=0.8
        )

        ax1.set_xlabel('Finishing Time (minutes)', fontsize=12)
        ax1.set_ylabel('Number of Runners', fontsize=12)
        ax1.set_title(
            f'Simulated Finishing Time Distribution ({len(ft)} Runners)',
            fontsize=14, fontweight='bold'
        )

        # Secondary x-axis in hours
        ax2 = ax1.twiny()
        ax2.set_xlim(ax1.get_xlim()[0] / 60.0, ax1.get_xlim()[1] / 60.0)
        ax2.set_xlabel('Finishing Time (hours)', fontsize=12)

        # Annotate median
        median_ft = float(np.median(ft))
        ax1.axvline(x=median_ft, color='red', linestyle='--', linewidth=2,
                    label=f'Median: {median_ft:.0f} min ({median_ft/60:.2f} hr)')
        ax1.legend(fontsize=10)
        ax1.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig6_finishing_histogram.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig6_finishing_histogram.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def fig7_pace_heatmap(
    distance_grid: np.ndarray,
    grade_profile: np.ndarray,
    output_dir: pathlib.Path,
) -> None:
    """Fig 7: 2D heatmap of instantaneous pace across ability tiers × distance."""
    try:
        ability_tiers = np.arange(4.5, 14.5, 0.5)  # min/mile
        n_tiers = len(ability_tiers)
        n_dist  = len(distance_grid)
        assert n_dist > 0 and n_tiers > 0, "Empty arrays"

        params_base = dict(MODEL_PROFILE['parameters'])
        grade_pace_factor    = params_base['grade_pace_factor']
        downhill_pace_factor = params_base['downhill_pace_factor']
        fatigue_rate         = params_base['fatigue_rate']
        quad_damage_factor   = params_base['quad_damage_factor']
        aid_recovery         = params_base['aid_station_energy_recovery']
        fatigue_pace_factor  = params_base['fatigue_pace_factor']

        heatmap_matrix = np.zeros((n_tiers, n_dist), dtype=float)

        for ti, tier_pace in enumerate(ability_tiers):
            energy = 1.0
            for ji in range(n_dist):
                d     = distance_grid[ji]
                grade = float(grade_profile[ji])

                # Grade adjustment
                if grade >= 0.0:
                    g_adj = grade_pace_factor * grade
                else:
                    g_adj = -downhill_pace_factor * abs(grade)

                # Fatigue adjustment
                f_adj = fatigue_pace_factor * (1.0 - energy)

                instant_pace = tier_pace + g_adj + f_adj
                instant_pace = max(tier_pace * 0.85, instant_pace)
                instant_pace = min(instant_pace, 30.0)

                heatmap_matrix[ti, ji] = instant_pace

                # Update energy
                downhill_extra = quad_damage_factor * max(0.0, -grade) * DS
                energy -= (fatigue_rate * DS + downhill_extra)
                if d > 0.0 and abs(round(d) - d) < 0.05:
                    energy = min(1.0, energy + aid_recovery)
                energy = max(0.0, min(1.0, energy))

        assert heatmap_matrix.shape == (n_tiers, n_dist), "Heatmap shape mismatch"

        fig, ax = plt.subplots(figsize=(16, 7))
        im = ax.imshow(
            heatmap_matrix,
            aspect='auto',
            origin='lower',
            extent=[distance_grid[0], distance_grid[-1], ability_tiers[0], ability_tiers[-1]],
            cmap='RdYlGn_r',
            vmin=4.5, vmax=20.0,
        )
        plt.colorbar(im, ax=ax, label='Instantaneous Pace (min/mile)')

        # Town boundary lines
        town_bounds_miles = [1.5, 6.5, 10.5, 13.5, 16.5, 21.5, 24.5]
        town_names = ['Ashland', 'Framingham', 'Natick', 'Wellesley', 'Newton', 'Brookline', 'Boston']
        for bmi, tname in zip(town_bounds_miles, town_names):
            ax.axvline(x=bmi, color='white', linestyle='--', linewidth=1.0, alpha=0.8)
            ax.text(bmi + 0.1, ability_tiers[-1] - 0.5, tname, color='white',
                    fontsize=7, va='top')

        # Landmark lines
        for mile in [17.0, 20.8, 25.2]:
            ax.axvline(x=mile, color='cyan', linestyle=':', linewidth=1.5, alpha=0.9)

        ax.set_xlabel('Distance (miles)', fontsize=12)
        ax.set_ylabel('Runner Ability (base pace, min/mile)', fontsize=12)
        ax.set_title('Pace Heatmap: Instantaneous Pace Across Runner Ability × Course Distance',
                     fontsize=13, fontweight='bold')
        plt.tight_layout()
        plt.savefig(output_dir / 'fig7_pace_heatmap.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig7_pace_heatmap.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


def fig8_grade_profile(
    distance_grid: np.ndarray,
    grade_profile: np.ndarray,
    output_dir: pathlib.Path,
) -> None:
    """Fig 8: Course grade profile with landmark annotations."""
    try:
        assert len(distance_grid) == len(grade_profile), "Shape mismatch"
        if len(distance_grid) == 0:
            print("WARNING fig8: empty arrays, skipping.")
            return

        fig, ax = plt.subplots(figsize=(14, 5))
        ax.fill_between(distance_grid, grade_profile, 0, where=grade_profile >= 0,
                        alpha=0.4, color='firebrick', label='Uphill')
        ax.fill_between(distance_grid, grade_profile, 0, where=grade_profile < 0,
                        alpha=0.4, color='steelblue', label='Downhill')
        ax.plot(distance_grid, grade_profile, color='black', linewidth=1.2)
        ax.axhline(y=0, color='black', linewidth=0.8)

        # Landmark annotations
        landmark_annots = {
            1.0:  ('Kyriakides\nStatue',      'gray'),
            6.5:  ('Framingham\nDepot',        'blue'),
            17.0: ('Newton Hills\nStart',      'orange'),
            19.2: ('Johnny Kelley\nStatue',    'purple'),
            20.8: ('Heartbreak\nHill Crest',   'red'),
            25.2: ('CITGO Sign',               'green'),
        }
        for mile, (lbl, color) in landmark_annots.items():
            ax.axvline(x=mile, color=color, linestyle='--', alpha=0.7, linewidth=1.5)
            g_at = float(np.interp(mile, distance_grid, grade_profile))
            y_pos = g_at + 0.5 if g_at >= 0 else g_at - 0.5
            ax.text(mile + 0.1, y_pos, lbl, fontsize=7, color=color, va='center')

        ax.set_xlabel('Distance (miles)', fontsize=12)
        ax.set_ylabel('Grade (%)', fontsize=12)
        ax.set_title('Course Grade Profile with Landmark Annotations', fontsize=14, fontweight='bold')
        ax.set_xlim(0, 26.2)
        ax.set_ylim(-9, 9)
        ax.legend(loc='upper right', fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig8_grade_profile.png', dpi=150)
        plt.close(fig)
        print("  Saved: fig8_grade_profile.png")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY JSON
# ─────────────────────────────────────────────────────────────────────────────
def write_summary_json(
    scenario_results: dict, output_dir: pathlib.Path
) -> None:
    """Write summary.json with key aggregate metrics."""
    summary = {}
    for label, result in scenario_results.items():
        ft = result['finish_times']
        if not ft:
            continue
        ft_arr = np.array(ft, dtype=float)
        rows = result['rows']
        energy_vals = np.array([r['energy_reserve'] for r in rows if r.get('runner_id', 0) == 0], dtype=float)
        hr_vals     = np.array([r['heart_rate']     for r in rows if r.get('runner_id', 0) == 0], dtype=float)
        summary[label] = {
            'finish_time_mean_min':  round(float(np.mean(ft_arr)), 2),
            'finish_time_min_min':   round(float(np.min(ft_arr)),  2),
            'finish_time_max_min':   round(float(np.max(ft_arr)),  2),
            'finish_time_std_min':   round(float(np.std(ft_arr)),  2),
            'num_runners':           len(ft),
            'energy_at_finish_mean': round(float(np.mean(energy_vals[-5:])) if len(energy_vals) >= 5 else float(np.mean(energy_vals)), 4),
            'max_heart_rate_mean':   round(float(np.max(hr_vals)) if len(hr_vals) > 0 else 0.0, 2),
            'base_pace':             result['params'].get('base_pace_min_per_mi', 0.0),
        }

    out_path = output_dir / 'summary.json'
    try:
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2)
        print(f"  Written: {out_path}")
    except Exception as e:
        print(f"WARNING: Could not write summary.json: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(
        description='Boston Marathon 2026 Course Simulator'
    )
    parser.add_argument(
        '--output', type=str, default='./sim_outputs',
        help='Output directory for all generated files (default: ./sim_outputs)'
    )
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"\nBoston Marathon 2026 Simulator")
    print(f"Output directory: {output_dir.resolve()}")

    # ── Build course profile ───────────────────────────────────────────────
    print("\n[1/4] Building course profile...")
    distance_grid, elevation_profile, grade_profile = build_course_profile()
    print(f"  Course grid: {len(distance_grid)} points, "
          f"elevation range [{elevation_profile.min():.1f}–{elevation_profile.max():.1f}] ft, "
          f"grade range [{grade_profile.min():.2f}–{grade_profile.max():.2f}]%")

    # ── Run simulations ────────────────────────────────────────────────────
    print("\n[2/4] Running scenarios...")
    all_rows, scenario_results = run_all_scenarios(
        distance_grid, elevation_profile, grade_profile
    )
    print(f"  Total rows in simulation_outputs: {len(all_rows)}")

    # ── Write CSVs ─────────────────────────────────────────────────────────
    print("\n[3/4] Writing CSV files...")
    write_simulation_outputs(all_rows, output_dir)
    write_scenario_summary(scenario_results, output_dir)
    write_parameters_used(output_dir)
    write_summary_json(scenario_results, output_dir)

    # ── Generate figures ───────────────────────────────────────────────────
    print("\n[4/4] Generating figures...")
    fig1_elevation_profile(distance_grid, elevation_profile, output_dir)
    fig2_pace_by_archetype(scenario_results, output_dir)
    fig3_energy_reserve(scenario_results, output_dir)
    fig4_heart_rate(scenario_results, output_dir)
    fig5_elapsed_time(scenario_results, output_dir)
    fig6_finishing_histogram(scenario_results, output_dir)
    fig7_pace_heatmap(distance_grid, grade_profile, output_dir)
    fig8_grade_profile(distance_grid, grade_profile, output_dir)

    print(f"\nSimulation complete. All outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()