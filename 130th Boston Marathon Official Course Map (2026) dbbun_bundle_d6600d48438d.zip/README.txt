================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : ea19c149-68d2-4372-94df-e062173e1217
    Generated   : 2026-04-20  00:42:05 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    130th Boston Marathon Official Course Map (2026)

    CATEGORIES
    ----------
    Health, Biomedical and Health Sciences, Signal Processing, Demographic, Other

    KEYWORDS
    --------
    Boston Marathon, elevation profile, running pacing, physiological modeling, endurance fatigue

    ABSTRACT
    --------
    This simulator models the physiological and biomechanical dynamics of running the 130th Boston Marathon course (2026), replicating the official 26.2-mile route from Hopkinton to Copley Square. It integrates a piecewise-cubic elevation profile derived from the official course map — including the notorious Newton Hills and Heartbreak Hill crest at mile 20.8 — with a coupled ODE system governing pace, energy reserve, and heart rate as functions of road grade, accumulated fatigue, and aid station carbohydrate intake (every mile as specified on the map). Five individual runner archetypes (elite, sub-3hr, recreational, positive-split, and negative-split) and a 500-runner Monte Carlo population simulation are supported across eight publication-quality figures. Researchers, coaches, and athletes can use the generated synthetic datasets and figures to analyze pacing strategy, predict bonk risk, and understand how course topography interacts with physiological fatigue.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    2026-Course-Map.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    distance_mi, elevation_ft, grade_pct, pace_min_per_mi, elapsed_time_min, energy_reserve, heart_rate, cumulative_elevation_gain_ft, cumulative_elevation_loss_ft, split_time_min

    SCENARIOS  (6 total)
    ---------------------------------
        1. recreational_runner — Average recreational runner targeting a 4-hour finish with base pace 9.16 min/mile; experiences significant fatigue after mile 20
2. sub_3hr_runner — Competitive amateur runner targeting sub-3 hour finish at ~6.87 min/mile; better fatigue management but still affected by Newton Hills
3. elite_runner — Elite runner targeting ~2:05 finish at ~4.75 min/mile; minimal fatigue degradation, efficient biomechanics on hills
4. positive_split_runner — Runner who starts too fast (first half 10% faster than goal) and dramatically slows in second half — classic Boston bonk scenario
5. negative_split_runner — Disciplined runner who starts conservatively and accelerates in the second half; represents optimal pacing strategy
6. population_simulation — Monte Carlo simulation of 500 runners drawn from a Gaussian pace distribution representing the full Boston field; produces finishing time histogram

    PARAMETERS
    ----------
    21 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    The source describes the official 2026 Boston Marathon course from Hopkinton to Boston (26.2 miles / 42.2 km), including elevation profiles, landmark mile markers, town segments, and race logistics such as aid station placement.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.