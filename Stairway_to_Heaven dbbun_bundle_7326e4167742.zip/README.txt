================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 9d1e40cd-3a7c-49e6-ac73-11b46f83d1bb
    Generated   : 2026-04-28  18:22:57 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Stairway to Heaven – Led Zeppelin IV (1971) Musical Structure & Cultural Impact Analysis

    CATEGORIES
    ----------
    Signal Processing, Social Sciences, Other

    KEYWORDS
    --------
    musical structure simulation, amplitude envelope modelling, tempo dynamics, cultural impact metrics, rock music analysis

    ABSTRACT
    --------
    This simulator models the structural and cultural dynamics of Led Zeppelin's 'Stairway to Heaven' (1971), one of the most celebrated rock compositions in history. The core model captures the song's defining characteristic of continuous acceleration: tempo, amplitude, instrumental layer count, and spectral density all increase monotonically across five defined sections (acoustic intro, electric middle, guitar solo, hard rock finale, and a-cappella epilogue), with sigmoid-smoothed transitions and Gaussian noise for realistic variability. Four scenarios are provided — Studio Original, Live Extended, Sunset Sound Mix, and Acoustic Demo — enabling comparison of how different performance and production contexts alter the song's intensity profile. Auxiliary models track the historical accumulation of FM radio plays (anchored to 2.874 million by 1991 and 3 million by 2000) and sheet music sales (15,000 copies/year average, over 1 million total), while extracted chart and accolade data across 12 territories and 8 publications are rendered as comparative visualisations. Researchers, music educators, signal processing students, and data scientists can use the synthetic datasets and figures to study musical structure modelling, cultural diffusion metrics, and phase-space representations of compositional evolution.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Stairway_to_Heaven.pdf

    SIMULATION BACKEND
    ------------------
    signal_field

    STATE VARIABLES
    ---------------
    time_s, tempo_bpm, amplitude_envelope, instrument_layer_count, spectral_density, section_id, radio_plays_cumulative_M, sheet_music_sales_cumulative_k

    SCENARIOS  (5 total)
    ---------------------------------
        1. Studio_Original — Faithfully reproduces the studio recording: exact section boundaries from the text (0–135s acoustic, 136–333s electric, 334–404s solo, 405–465s hard rock, 466–482s epilogue), standard tempo and amplitude profiles per section.
2. Live_Extended — Simulates a typical live performance where Page extends the guitar solo and Plant adds lyrical ad-libs, pushing total duration beyond 10 minutes (factor ~1.3x studio). Tempo in hard rock section is slightly elevated, solo section extended by ~80s.
3. Sunset_Sound_Mix — Reproduces the alternate Sunset Sound Mix (8:04 duration, muddier, guitar-heavy). Models higher guitar spectral density contribution, slightly lower overall clarity (reduced spectral sharpness), duration 484s.
4. Acoustic_Demo — Hypothetical stripped-down acoustic arrangement (analogous to the Tokyo acoustic version): all sections use acoustic-level amplitude and no drum entry, approximating an intimate unplugged rendition.
5. Cultural_Impact_Trajectory — Focuses on the historical radio play accumulation and sheet music sales from 1971 to 2005, using linear interpolation anchored to the two extracted data points (2.874M plays by ~1991, 3.0M plays by 2000, 15k sheet music/year, 1M total).

    PARAMETERS
    ----------
    27 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig01, fig02, fig03, fig04, fig05, fig06, fig07, fig08, fig09, fig10

    DOMAIN SUMMARY
    --------------
    This source covers the musical composition, structural dynamics, recording history, live performance legacy, chart performance, critical reception, and copyright litigation surrounding Led Zeppelin's 'Stairway to Heaven' (1971), with emphasis on the song's three-section progressive structure that accelerates in tempo, volume, and instrumental texture from a quiet acoustic introduction to an uptempo hard rock finale.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.