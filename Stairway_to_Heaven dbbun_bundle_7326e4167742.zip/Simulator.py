# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T18:22:57.102947Z
# Run ID    : 9d1e40cd-3a7c-49e6-ac73-11b46f83d1bb
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Stairway to Heaven – Led Zeppelin IV (1971) Musical Structure & Cultural Impact Analysis

Simulator implementing the structural and cultural dynamics of Led Zeppelin's
'Stairway to Heaven' (1971). Models amplitude envelope, tempo, instrumental
layer count, and spectral density across five song sections with sigmoid-smoothed
transitions, plus cultural impact metrics (radio plays, chart positions, accolades).

References:
  - "Stairway to Heaven – Led Zeppelin IV (1971) Musical Structure & Cultural Impact Analysis"
"""

import argparse
import csv
import json
import copy
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple, Optional

# ─── MODEL PROFILE ────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "title": "Stairway to Heaven – Led Zeppelin IV (1971) Musical Structure & Cultural Impact Analysis",
    "parameters": {
        "section_boundaries_s": {"value": 0.0, "unit": "s", "source": "extracted",
            "description": "Section boundary times: Acoustic 0–135s, Electric 136–333s, Solo 334–404s, Hard Rock 405–465s, Epilogue 466–482s"},
        "tempo_acoustic":       {"value": 63.0,  "unit": "BPM",             "source": "assumed",   "description": "Effective tempo of the opening acoustic section"},
        "tempo_electric_mid":   {"value": 75.0,  "unit": "BPM",             "source": "assumed",   "description": "Effective tempo of the electric middle section"},
        "tempo_solo":           {"value": 95.0,  "unit": "BPM",             "source": "assumed",   "description": "Effective tempo during the extended guitar solo"},
        "tempo_hard_rock":      {"value": 112.0, "unit": "BPM",             "source": "assumed",   "description": "Effective uptempo hard rock section tempo"},
        "tempo_epilogue":       {"value": 58.0,  "unit": "BPM",             "source": "assumed",   "description": "A-cappella epilogue effective tempo"},
        "amplitude_acoustic":   {"value": 0.12,  "unit": "a.u.",            "source": "assumed",   "description": "Mean normalised amplitude of the acoustic opening section"},
        "amplitude_electric_mid":{"value": 0.40, "unit": "a.u.",            "source": "assumed",   "description": "Mean normalised amplitude of the electric middle section"},
        "amplitude_solo":       {"value": 0.65,  "unit": "a.u.",            "source": "assumed",   "description": "Mean normalised amplitude during guitar solo"},
        "amplitude_hard_rock":  {"value": 0.92,  "unit": "a.u.",            "source": "assumed",   "description": "Mean normalised amplitude of the hard rock finale"},
        "amplitude_epilogue":   {"value": 0.18,  "unit": "a.u.",            "source": "assumed",   "description": "Mean normalised amplitude of the a-cappella epilogue"},
        "drums_entry_time_s":   {"value": 258.0, "unit": "s",               "source": "extracted", "description": "Timestamp at which drums enter (4:18 into the song)"},
        "total_duration_s":     {"value": 482.0, "unit": "s",               "source": "extracted", "description": "Total song duration (8 minutes 2 seconds)"},
        "radio_plays_1990_M":   {"value": 2.874, "unit": "millions",        "source": "extracted", "description": "Estimated FM radio plays by 20th anniversary (1990/1991)"},
        "radio_plays_2000_M":   {"value": 3.0,   "unit": "millions",        "source": "extracted", "description": "Estimated FM radio plays as of year 2000"},
        "sheet_music_annual_sales_k": {"value": 15.0, "unit": "thousands/year", "source": "extracted", "description": "Average annual sheet music sales"},
        "sheet_music_total_sales_k":  {"value": 1000.0, "unit": "thousands",  "source": "extracted", "description": "Total sheet music copies sold (over one million)"},
        "rolling_stone_rank_2004": {"value": 31.0, "unit": "rank",          "source": "extracted", "description": "Rolling Stone 500 Greatest Songs ranking in 2004"},
        "rolling_stone_rank_2021": {"value": 61.0, "unit": "rank",          "source": "extracted", "description": "Rolling Stone 500 Greatest Songs ranking in 2021"},
        "vh1_rank_2000":        {"value": 3.0,   "unit": "rank",            "source": "extracted", "description": "VH1 100 Greatest Rock Songs rank in 2000"},
        "uk_singles_peak":      {"value": 37.0,  "unit": "rank",            "source": "extracted", "description": "UK Singles Chart peak position (November 2007)"},
        "us_digital_peak":      {"value": 30.0,  "unit": "rank",            "source": "extracted", "description": "US Billboard Hot Digital Songs peak chart position"},
        "norway_peak":          {"value": 5.0,   "unit": "rank",            "source": "extracted", "description": "Norwegian Singles Chart peak position"},
        "nz_peak":              {"value": 13.0,  "unit": "rank",            "source": "extracted", "description": "New Zealand RIANZ Singles Chart peak position"},
        "transition_smoothing_s": {"value": 4.0, "unit": "s",               "source": "assumed",   "description": "Half-width of sigmoid crossfade window at section boundaries"},
        "noise_sigma":          {"value": 0.02,  "unit": "a.u.",            "source": "assumed",   "description": "Gaussian noise standard deviation for amplitude/spectral density"},
        "live_extension_factor":{"value": 1.3,   "unit": "dimensionless",   "source": "extracted", "description": "Factor by which live performances extend song duration"},
    },
    "scenarios": [
        {
            "label": "Studio_Original",
            "description": "Faithfully reproduces the studio recording with exact section boundaries.",
            "param_overrides": {
                "total_duration_s": 482.0,
                "live_extension_factor": 1.0,
                "noise_sigma": 0.015
            }
        },
        {
            "label": "Live_Extended",
            "description": "Simulates a typical live performance with extended guitar solo.",
            "param_overrides": {
                "total_duration_s": 620.0,
                "live_extension_factor": 1.3,
                "tempo_hard_rock": 118.0,
                "noise_sigma": 0.04
            }
        },
        {
            "label": "Sunset_Sound_Mix",
            "description": "Alternate Sunset Sound Mix: guitar-heavy, slightly muddier.",
            "param_overrides": {
                "total_duration_s": 484.0,
                "amplitude_hard_rock": 0.88,
                "amplitude_electric_mid": 0.45,
                "noise_sigma": 0.03
            }
        },
        {
            "label": "Acoustic_Demo",
            "description": "Hypothetical stripped-down acoustic arrangement, no drum entry.",
            "param_overrides": {
                "amplitude_electric_mid": 0.18,
                "amplitude_solo": 0.22,
                "amplitude_hard_rock": 0.28,
                "tempo_hard_rock": 85.0,
                "drums_entry_time_s": 9999.0,
                "noise_sigma": 0.01
            }
        },
        {
            "label": "Cultural_Impact_Trajectory",
            "description": "Historical radio play accumulation and sheet music sales 1971–2005.",
            "param_overrides": {
                "radio_plays_1990_M": 2.874,
                "radio_plays_2000_M": 3.0,
                "sheet_music_annual_sales_k": 15.0,
                "sheet_music_total_sales_k": 1000.0
            }
        }
    ]
}

# ─── STATIC DATA ──────────────────────────────────────────────────────────────
CHART_DATA = [
    {'chart_territory': 'Canada Billboard Digital', 'peak_chart_position': 17},
    {'chart_territory': 'EU Billboard Hot 100',     'peak_chart_position': 79},
    {'chart_territory': 'Germany GfK',              'peak_chart_position': 15},
    {'chart_territory': 'Ireland',                  'peak_chart_position': 24},
    {'chart_territory': 'New Zealand',              'peak_chart_position': 13},
    {'chart_territory': 'Norway',                   'peak_chart_position':  5},
    {'chart_territory': 'Portugal',                 'peak_chart_position':  8},
    {'chart_territory': 'Sweden',                   'peak_chart_position': 57},
    {'chart_territory': 'Switzerland',              'peak_chart_position': 17},
    {'chart_territory': 'UK Singles',               'peak_chart_position': 37},
    {'chart_territory': 'US Billboard Digital',     'peak_chart_position': 30},
    {'chart_territory': 'US Hot Recurrents',        'peak_chart_position': 16},
]

ACCOLADE_DATA = [
    {'accolade_publication': 'VH1',           'accolade_year': 2000, 'accolade_rank':  3},
    {'accolade_publication': 'RIAA',          'accolade_year': 2001, 'accolade_rank': 53},
    {'accolade_publication': 'Q',             'accolade_year': 2003, 'accolade_rank': 47},
    {'accolade_publication': 'Rolling Stone', 'accolade_year': 2004, 'accolade_rank': 31},
    {'accolade_publication': 'Q',             'accolade_year': 2006, 'accolade_rank':  8},
    {'accolade_publication': 'Guitar World',  'accolade_year': 2006, 'accolade_rank':  1},
    {'accolade_publication': 'Rolling Stone', 'accolade_year': 2008, 'accolade_rank':  8},
    {'accolade_publication': 'Rolling Stone', 'accolade_year': 2021, 'accolade_rank': 61},
]

# ─── SECTION DEFINITIONS ──────────────────────────────────────────────────────
# Each tuple: (start_s, end_s, section_id, label, tempo_bpm, amp_mean, layers, spec_density_mean)
BASE_SECTIONS = [
    (0,   135, 0, 'Acoustic_Intro',  63.0,  0.12, 5, 0.15),
    (135, 333, 1, 'Electric_Middle', 75.0,  0.40, 6, 0.42),
    (333, 404, 2, 'Guitar_Solo',     95.0,  0.65, 7, 0.68),
    (404, 465, 3, 'Hard_Rock',      112.0,  0.92, 7, 0.93),
    (465, 482, 4, 'Epilogue',        58.0,  0.18, 1, 0.12),
]

SECTION_LABELS = ['Acoustic_Intro', 'Electric_Middle', 'Guitar_Solo', 'Hard_Rock', 'Epilogue']

# ─── HELPER FUNCTIONS ─────────────────────────────────────────────────────────

def sigmoid_blend(x: float, k: float = 2.5) -> float:
    """Sigmoid function used for smooth section transitions."""
    clipped = np.clip(-k * x, -500, 500)
    return float(1.0 / (1.0 + np.exp(clipped)))


def interpolate_param(t: float, sections: list, param_idx: int,
                       smoothing_s: float = 4.0) -> float:
    """
    Interpolate a section parameter at time t using sigmoid blending at boundaries.
    param_idx: index into the section tuple (4=tempo, 5=amp, 6=layers, 7=spec)
    """
    val = float(sections[0][param_idx])
    for i, sec in enumerate(sections):
        t_start = float(sec[0])
        if t >= t_start:
            if i == 0:
                val = float(sec[param_idx])
            else:
                prev_val = float(sections[i - 1][param_idx])
                cur_val  = float(sec[param_idx])
                # blend factor: 0 at t_start, approaches 1 as t >> t_start
                blend = sigmoid_blend((t - t_start) / smoothing_s - 1.0, k=2.5)
                val = prev_val * (1.0 - blend) + cur_val * blend
    return val


def get_section_at(t: float, sections: list) -> Tuple[int, str]:
    """Return (section_id, section_label) for time t."""
    sid = int(sections[0][2])
    slabel = str(sections[0][3])
    for sec in sections:
        if t >= float(sec[0]):
            sid = int(sec[2])
            slabel = str(sec[3])
    return sid, slabel


def build_sections(overrides: Dict[str, Any]) -> list:
    """
    Build section table from BASE_SECTIONS, applying scenario-specific overrides.
    Handles amplitude/tempo overrides and live extension of section durations.
    """
    secs = copy.deepcopy(BASE_SECTIONS)
    # Convert to list of lists for mutability
    secs = [list(s) for s in secs]

    # Index map: 0=start, 1=end, 2=id, 3=label, 4=tempo, 5=amp, 6=layers, 7=spec

    # Apply amplitude overrides
    amp_map = {
        'amplitude_acoustic':    0,
        'amplitude_electric_mid':1,
        'amplitude_solo':        2,
        'amplitude_hard_rock':   3,
        'amplitude_epilogue':    4,
    }
    for key, idx in amp_map.items():
        if key in overrides:
            secs[idx][5] = float(overrides[key])

    # Apply tempo overrides
    tempo_map = {
        'tempo_acoustic':    0,
        'tempo_electric_mid':1,
        'tempo_solo':        2,
        'tempo_hard_rock':   3,
        'tempo_epilogue':    4,
    }
    for key, idx in tempo_map.items():
        if key in overrides:
            secs[idx][4] = float(overrides[key])

    # Apply live extension factor to solo + hard rock sections
    lef = float(overrides.get('live_extension_factor', 1.0))
    total_dur = float(overrides.get('total_duration_s', 482.0))

    if lef > 1.0:
        # Extend guitar solo and hard rock sections proportionally
        # Base: solo 333-404 (71s), hard rock 404-465 (61s), epilogue 465-482 (17s)
        base_solo_dur   = 71.0
        base_hr_dur     = 61.0
        base_ep_dur     = 17.0
        base_total      = 482.0

        extra_time = total_dur - base_total
        # Distribute 60% to solo, 40% to hard rock
        solo_ext = extra_time * 0.6
        hr_ext   = extra_time * 0.4

        # Recalculate boundaries
        solo_start = 333.0
        solo_end   = 404.0 + solo_ext
        hr_start   = solo_end
        hr_end     = hr_start + base_hr_dur + hr_ext
        ep_start   = hr_end
        ep_end     = ep_start + base_ep_dur

        secs[2][0] = solo_start
        secs[2][1] = solo_end
        secs[3][0] = hr_start
        secs[3][1] = hr_end
        secs[4][0] = ep_start
        secs[4][1] = ep_end
    else:
        # Apply total_duration_s to epilogue end if slightly different
        if total_dur != 482.0:
            diff = total_dur - 482.0
            secs[4][1] = max(secs[4][0] + 5.0, secs[4][1] + diff)

    # Recompute spectral density based on amp (proportional scaling)
    # spec_density roughly tracks amplitude with a slight boost
    spec_base = [0.15, 0.42, 0.68, 0.93, 0.12]
    amp_base  = [0.12, 0.40, 0.65, 0.92, 0.18]
    for i in range(5):
        amp_ratio = secs[i][5] / amp_base[i] if amp_base[i] > 0 else 1.0
        secs[i][7] = float(np.clip(spec_base[i] * amp_ratio, 0.05, 1.0))

    return secs


def simulate_song(scenario_label: str, sections: list, total_duration_s: float,
                  drums_entry_s: float = 258.0, noise_sigma: float = 0.02,
                  dt: float = 0.5) -> List[Dict[str, Any]]:
    """
    Main simulation loop: Euler integration at dt=0.5s with sigmoid blending.
    Returns list of row dicts matching dataset_schema.
    """
    rows = []
    smoothing_s = 4.0

    n_steps = int(np.ceil(total_duration_s / dt)) + 1
    t_array = np.linspace(0.0, total_duration_s, n_steps)

    for t in t_array:
        t = float(t)

        sid, slabel = get_section_at(t, sections)

        tempo  = interpolate_param(t, sections, param_idx=4, smoothing_s=smoothing_s)
        amp    = interpolate_param(t, sections, param_idx=5, smoothing_s=smoothing_s)
        layers = interpolate_param(t, sections, param_idx=6, smoothing_s=smoothing_s)
        spec   = interpolate_param(t, sections, param_idx=7, smoothing_s=smoothing_s)

        # Clamp to defined ranges
        tempo  = float(np.clip(tempo,  55.0, 130.0))
        amp    = float(np.clip(amp,    0.0,  1.0))
        layers = float(np.clip(layers, 1.0,  7.0))
        spec   = float(np.clip(spec,   0.0,  1.0))

        # Instrument flags
        drums_active  = 1 if t >= drums_entry_s else 0
        elec_active   = 1 if t >= 135.0 else 0
        solo_active   = 1 if (t >= 333.0 and t < float(sections[4][0])) else 0

        # Gaussian noise
        noise     = float(np.random.normal(0.0, noise_sigma))
        amp_noisy  = float(np.clip(amp  + noise, 0.0, 1.0))
        spec_noisy = float(np.clip(spec + np.random.normal(0.0, noise_sigma), 0.0, 1.0))

        # Composite intensity = amplitude * normalised_tempo
        tempo_norm = (tempo - 55.0) / (130.0 - 55.0)
        composite  = float(np.clip(amp_noisy * tempo_norm, 0.0, 1.0))

        rows.append({
            'scenario':              scenario_label,
            'time_s':                round(t, 1),
            'section_id':            sid,
            'section_label':         slabel,
            'tempo_bpm':             round(tempo, 2),
            'amplitude_envelope':    round(amp_noisy, 4),
            'instrument_layer_count':round(layers, 2),
            'spectral_density':      round(spec_noisy, 4),
            'drums_active':          drums_active,
            'electric_guitar_active':elec_active,
            'solo_guitar_active':    solo_active,
            'noise_realisation':     round(noise, 5),
            'composite_intensity':   round(composite, 4),
            'year':                  '',
            'radio_plays_cumulative_M':      '',
            'sheet_music_sales_cumulative_k':'',
            'chart_territory':       '',
            'peak_chart_position':   '',
            'accolade_publication':  '',
            'accolade_year':         '',
            'accolade_rank':         '',
        })

    return rows


def simulate_cultural(scenario_label: str, year_start: int = 1971,
                       year_end: int = 2005,
                       radio_1990: float = 2.874,
                       radio_2000: float = 3.0,
                       sheet_annual: float = 15.0) -> List[Dict[str, Any]]:
    """
    Simulate cultural impact trajectory: radio plays and sheet music sales.
    """
    rows = []
    for yr in range(year_start, year_end + 1):
        elapsed = yr - 1971

        # Radio plays: power-law growth to 1991, then linear to 2000, flat after
        if yr <= 1991:
            radio = radio_1990 * (elapsed / 20.0) ** 1.3
        elif yr <= 2000:
            radio = radio_1990 + (yr - 1991) * (radio_2000 - radio_1990) / (2000 - 1991)
        else:
            radio = radio_2000 + (yr - 2000) * 0.01  # slight continued growth
        radio = float(np.clip(radio, 0.0, 3.0))

        sheet = float(np.clip(elapsed * sheet_annual, 0.0, 1000.0))

        rows.append({
            'scenario':              scenario_label,
            'time_s':                '',
            'section_id':            '',
            'section_label':         '',
            'tempo_bpm':             '',
            'amplitude_envelope':    '',
            'instrument_layer_count':'',
            'spectral_density':      '',
            'drums_active':          '',
            'electric_guitar_active':'',
            'solo_guitar_active':    '',
            'noise_realisation':     '',
            'composite_intensity':   '',
            'year':                  yr,
            'radio_plays_cumulative_M':       round(radio, 4),
            'sheet_music_sales_cumulative_k': round(sheet, 1),
            'chart_territory':       '',
            'peak_chart_position':   '',
            'accolade_publication':  '',
            'accolade_year':         '',
            'accolade_rank':         '',
        })
    return rows


# ─── FIGURE GENERATION ────────────────────────────────────────────────────────

SECTION_BOUNDARIES_STUDIO = [135, 333, 404, 465]
SECTION_COLORS = ['#8FBC8F', '#4682B4', '#DAA520', '#B22222', '#9370DB']

def make_fig01(all_rows_by_scenario: Dict[str, list], out_dir: Path) -> None:
    """Fig01: Amplitude envelope vs time for Studio, Live Extended, Acoustic Demo."""
    try:
        fig, ax = plt.subplots(figsize=(12, 5))
        target_scenarios = ['Studio_Original', 'Live_Extended', 'Acoustic_Demo']
        colors_map = {'Studio_Original': '#1f77b4', 'Live_Extended': '#ff7f0e',
                      'Acoustic_Demo': '#2ca02c'}
        for sc in target_scenarios:
            if sc not in all_rows_by_scenario:
                continue
            rows = all_rows_by_scenario[sc]
            t_arr  = np.array([r['time_s'] for r in rows if isinstance(r['time_s'], (int, float))])
            a_arr  = np.array([r['amplitude_envelope'] for r in rows
                               if isinstance(r['amplitude_envelope'], (int, float))])
            assert len(t_arr) == len(a_arr), f"Array length mismatch for {sc}"
            if len(t_arr) == 0:
                print(f"Warning fig01: no data for {sc}")
                continue
            ax.plot(t_arr, a_arr, label=sc, color=colors_map.get(sc, 'gray'), alpha=0.85, lw=1.5)

        for b in SECTION_BOUNDARIES_STUDIO:
            ax.axvline(b, color='gray', linestyle='--', alpha=0.5, lw=1)

        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Amplitude Envelope (a.u.)')
        ax.set_title('Song Amplitude Envelope Across All Sections (Studio vs Live)')
        ax.legend()
        ax.set_ylim(0, 1.05)
        ax.text(20,   0.95, 'Acoustic', fontsize=8, color='gray')
        ax.text(180,  0.95, 'Electric', fontsize=8, color='gray')
        ax.text(345,  0.95, 'Solo',     fontsize=8, color='gray')
        ax.text(415,  0.95, 'Hard\nRock', fontsize=8, color='gray')
        ax.text(467,  0.95, 'Ep.',      fontsize=8, color='gray')
        plt.tight_layout()
        fig.savefig(out_dir / 'fig01_amplitude_envelope.png', dpi=150)
        plt.close(fig)
        print("Saved fig01_amplitude_envelope.png")
    except Exception as e:
        print(f"Warning: fig01 failed: {e}")


def make_fig02(all_rows_by_scenario: Dict[str, list], out_dir: Path) -> None:
    """Fig02: Tempo profile vs time for Studio Original and Live Extended."""
    try:
        fig, ax = plt.subplots(figsize=(12, 5))
        target = ['Studio_Original', 'Live_Extended']
        colors_map = {'Studio_Original': '#1f77b4', 'Live_Extended': '#ff7f0e'}
        for sc in target:
            if sc not in all_rows_by_scenario:
                continue
            rows = all_rows_by_scenario[sc]
            t_arr = np.array([r['time_s'] for r in rows if isinstance(r['time_s'], (int, float))])
            bpm   = np.array([r['tempo_bpm'] for r in rows if isinstance(r['tempo_bpm'], (int, float))])
            assert len(t_arr) == len(bpm)
            if len(t_arr) == 0:
                continue
            ax.plot(t_arr, bpm, label=sc, color=colors_map.get(sc, 'gray'), lw=1.8)

        for b in SECTION_BOUNDARIES_STUDIO:
            ax.axvline(b, color='gray', linestyle='--', alpha=0.5, lw=1)

        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Tempo (BPM)')
        ax.set_title('Effective Tempo Profile Across Song Sections')
        ax.legend()
        ax.set_ylim(50, 135)
        plt.tight_layout()
        fig.savefig(out_dir / 'fig02_tempo_profile.png', dpi=150)
        plt.close(fig)
        print("Saved fig02_tempo_profile.png")
    except Exception as e:
        print(f"Warning: fig02 failed: {e}")


def make_fig03(all_rows_by_scenario: Dict[str, list], out_dir: Path,
               drums_entry_map: Dict[str, float]) -> None:
    """Fig03: Instrument layer count over time."""
    try:
        fig, ax = plt.subplots(figsize=(12, 5))
        target = ['Studio_Original', 'Live_Extended']
        colors_map = {'Studio_Original': '#1f77b4', 'Live_Extended': '#ff7f0e'}
        for sc in target:
            if sc not in all_rows_by_scenario:
                continue
            rows = all_rows_by_scenario[sc]
            t_arr = np.array([r['time_s'] for r in rows if isinstance(r['time_s'], (int, float))])
            lyr   = np.array([r['instrument_layer_count'] for r in rows
                               if isinstance(r['instrument_layer_count'], (int, float))])
            assert len(t_arr) == len(lyr)
            if len(t_arr) == 0:
                continue
            ax.plot(t_arr, lyr, label=sc, color=colors_map.get(sc, 'gray'), lw=1.8)

        for b in SECTION_BOUNDARIES_STUDIO:
            ax.axvline(b, color='gray', linestyle='--', alpha=0.4, lw=1)

        # Mark drums entry for studio
        drums_t = drums_entry_map.get('Studio_Original', 258.0)
        if drums_t < 9000:
            ax.axvline(drums_t, color='red', linestyle=':', lw=1.5)
            ax.annotate('Drums\nentry', xy=(drums_t, 5.5), fontsize=8, color='red',
                        xytext=(drums_t + 10, 5.8),
                        arrowprops=dict(arrowstyle='->', color='red'))

        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Instrument Layer Count')
        ax.set_title('Instrumental Layer Count Over Time (Texture Buildup)')
        ax.legend()
        ax.set_ylim(0, 8)
        plt.tight_layout()
        fig.savefig(out_dir / 'fig03_layer_count.png', dpi=150)
        plt.close(fig)
        print("Saved fig03_layer_count.png")
    except Exception as e:
        print(f"Warning: fig03 failed: {e}")


def make_fig04(all_rows_by_scenario: Dict[str, list], out_dir: Path) -> None:
    """Fig04: Spectral density profile for Studio Original and Sunset Sound Mix."""
    try:
        fig, ax = plt.subplots(figsize=(12, 5))
        target = ['Studio_Original', 'Sunset_Sound_Mix']
        colors_map = {'Studio_Original': '#1f77b4', 'Sunset_Sound_Mix': '#d62728'}
        for sc in target:
            if sc not in all_rows_by_scenario:
                continue
            rows = all_rows_by_scenario[sc]
            t_arr = np.array([r['time_s'] for r in rows if isinstance(r['time_s'], (int, float))])
            spec  = np.array([r['spectral_density'] for r in rows
                               if isinstance(r['spectral_density'], (int, float))])
            assert len(t_arr) == len(spec)
            if len(t_arr) == 0:
                continue
            ax.plot(t_arr, spec, label=sc, color=colors_map.get(sc, 'gray'), lw=1.8, alpha=0.9)

        for b in SECTION_BOUNDARIES_STUDIO:
            ax.axvline(b, color='gray', linestyle='--', alpha=0.4, lw=1)

        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Spectral Density (a.u.)')
        ax.set_title('Spectral Density / Timbral Richness Profile')
        ax.legend()
        ax.set_ylim(0, 1.05)
        plt.tight_layout()
        fig.savefig(out_dir / 'fig04_spectral_density.png', dpi=150)
        plt.close(fig)
        print("Saved fig04_spectral_density.png")
    except Exception as e:
        print(f"Warning: fig04 failed: {e}")


def make_fig05(cultural_rows: list, out_dir: Path) -> None:
    """Fig05: Cumulative FM radio plays 1971–2000."""
    try:
        valid = [r for r in cultural_rows if isinstance(r.get('year'), int)
                 and isinstance(r.get('radio_plays_cumulative_M'), (int, float))]
        if len(valid) == 0:
            print("Warning fig05: no cultural data")
            return

        years = np.array([r['year'] for r in valid])
        radio = np.array([r['radio_plays_cumulative_M'] for r in valid])
        assert len(years) == len(radio)

        fig, ax = plt.subplots(figsize=(10, 5))
        ax.plot(years, radio, color='#1f77b4', lw=2.5, marker='o', markersize=3)
        ax.axhline(2.874, color='orange', linestyle='--', lw=1, label='2.874M @ 1991')
        ax.axhline(3.0,   color='red',    linestyle='--', lw=1, label='3.0M @ 2000')
        ax.axvline(1991,  color='orange', linestyle=':', lw=1)
        ax.axvline(2000,  color='red',    linestyle=':', lw=1)
        ax.set_xlabel('Year')
        ax.set_ylabel('Cumulative FM Radio Plays (millions)')
        ax.set_title('Cumulative FM Radio Plays 1971–2000')
        ax.legend()
        ax.set_ylim(0, 3.2)
        plt.tight_layout()
        fig.savefig(out_dir / 'fig05_radio_plays.png', dpi=150)
        plt.close(fig)
        print("Saved fig05_radio_plays.png")
    except Exception as e:
        print(f"Warning: fig05 failed: {e}")


def make_fig06(cultural_rows: list, out_dir: Path) -> None:
    """Fig06: Cumulative sheet music sales 1971–2005."""
    try:
        valid = [r for r in cultural_rows if isinstance(r.get('year'), int)
                 and isinstance(r.get('sheet_music_sales_cumulative_k'), (int, float))]
        if len(valid) == 0:
            print("Warning fig06: no cultural data")
            return

        years = np.array([r['year'] for r in valid])
        sales = np.array([r['sheet_music_sales_cumulative_k'] for r in valid])
        assert len(years) == len(sales)

        fig, ax1 = plt.subplots(figsize=(10, 5))
        ax1.plot(years, sales, color='#2ca02c', lw=2.5, marker='s', markersize=3)
        ax1.set_xlabel('Year')
        ax1.set_ylabel('Cumulative Sheet Music Sales (thousands)', color='#2ca02c')
        ax1.tick_params(axis='y', labelcolor='#2ca02c')
        ax1.set_title('Cumulative Sheet Music Sales 1971–2005 (15,000 copies/year average)')

        # Secondary axis: annual rate (roughly constant ~15k/year, slight decline after 1995)
        ax2 = ax1.twinx()
        annual_rates = []
        for yr in years:
            if yr <= 1995:
                rate = 15.0
            else:
                rate = max(8.0, 15.0 - (yr - 1995) * 0.5)
            annual_rates.append(rate)
        annual_arr = np.array(annual_rates)
        assert len(years) == len(annual_arr)
        ax2.plot(years, annual_arr, color='#ff7f0e', lw=1.5, linestyle='--', label='Annual rate (k/yr)')
        ax2.set_ylabel('Annual Sales Rate (thousands/year)', color='#ff7f0e')
        ax2.tick_params(axis='y', labelcolor='#ff7f0e')
        ax2.set_ylim(0, 25)

        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, ['Cumulative sales'] + labels2, loc='upper left')
        plt.tight_layout()
        fig.savefig(out_dir / 'fig06_sheet_music_sales.png', dpi=150)
        plt.close(fig)
        print("Saved fig06_sheet_music_sales.png")
    except Exception as e:
        print(f"Warning: fig06 failed: {e}")


def make_fig07(out_dir: Path) -> None:
    """Fig07: Horizontal bar chart of 2007–2010 international chart peak positions."""
    try:
        territories = [d['chart_territory']    for d in CHART_DATA]
        positions   = [d['peak_chart_position'] for d in CHART_DATA]

        # Sort by position (lower = higher chart position = better)
        sorted_pairs = sorted(zip(positions, territories))
        pos_sorted  = np.array([p for p, _ in sorted_pairs])
        ter_sorted  = [t for _, t in sorted_pairs]
        assert len(pos_sorted) == len(ter_sorted)

        fig, ax = plt.subplots(figsize=(10, 7))
        colors = plt.cm.RdYlGn_r(np.linspace(0.1, 0.9, len(pos_sorted)))
        bars = ax.barh(ter_sorted, pos_sorted, color=colors)

        for bar, val in zip(bars, pos_sorted):
            ax.text(val + 0.5, bar.get_y() + bar.get_height() / 2,
                    f'#{int(val)}', va='center', fontsize=9)

        ax.set_xlabel('Peak Chart Position (lower = better)')
        ax.set_title('2007–2010 International Chart Peak Positions by Territory')
        ax.invert_xaxis()  # Best (1) on right, worst on left
        ax.set_xlim(max(pos_sorted) + 10, 0)
        plt.tight_layout()
        fig.savefig(out_dir / 'fig07_chart_positions.png', dpi=150)
        plt.close(fig)
        print("Saved fig07_chart_positions.png")
    except Exception as e:
        print(f"Warning: fig07 failed: {e}")


def make_fig08(out_dir: Path) -> None:
    """Fig08: Scatter plot of critical rankings over time."""
    try:
        years  = np.array([d['accolade_year'] for d in ACCOLADE_DATA])
        ranks  = np.array([d['accolade_rank']  for d in ACCOLADE_DATA])
        pubs   = [d['accolade_publication']    for d in ACCOLADE_DATA]
        assert len(years) == len(ranks) == len(pubs)

        # Size proportional to influence (VH1, Rolling Stone, Guitar World = large)
        size_map = {'VH1': 200, 'Rolling Stone': 180, 'Guitar World': 220,
                    'Q': 120, 'RIAA': 100}
        sizes = np.array([size_map.get(p, 100) for p in pubs])
        color_map = {'VH1': '#1f77b4', 'Rolling Stone': '#ff7f0e', 'Guitar World': '#2ca02c',
                     'Q': '#d62728', 'RIAA': '#9467bd'}
        colors = [color_map.get(p, 'gray') for p in pubs]

        fig, ax = plt.subplots(figsize=(10, 6))
        scatter = ax.scatter(years, ranks, s=sizes, c=colors, alpha=0.8, zorder=5)

        # Annotate each point
        for yr, rk, pub in zip(years, ranks, pubs):
            ax.annotate(f'{pub}\n#{rk}', xy=(yr, rk), xytext=(3, 3),
                        textcoords='offset points', fontsize=7)

        # Trend line
        if len(years) >= 2:
            z = np.polyfit(years, ranks, 1)
            p = np.poly1d(z)
            x_trend = np.linspace(years.min(), years.max(), 100)
            y_trend = p(x_trend)
            ax.plot(x_trend, y_trend, 'k--', lw=1, alpha=0.5, label='Trend')

        ax.set_xlabel('Year')
        ax.set_ylabel('Rank (lower = more prestigious)')
        ax.set_title('Critical Rankings Over Time (2000–2021)')
        ax.invert_yaxis()
        ax.legend()
        plt.tight_layout()
        fig.savefig(out_dir / 'fig08_accolades_scatter.png', dpi=150)
        plt.close(fig)
        print("Saved fig08_accolades_scatter.png")
    except Exception as e:
        print(f"Warning: fig08 failed: {e}")


def make_fig09(all_rows_by_scenario: Dict[str, list], out_dir: Path) -> None:
    """Fig09: Heatmap of composite intensity by scenario x section."""
    try:
        heatmap_scenarios = ['Studio_Original', 'Live_Extended', 'Sunset_Sound_Mix', 'Acoustic_Demo']
        section_order     = ['Acoustic_Intro', 'Electric_Middle', 'Guitar_Solo', 'Hard_Rock', 'Epilogue']

        matrix = np.zeros((len(section_order), len(heatmap_scenarios)))

        for j, sc in enumerate(heatmap_scenarios):
            if sc not in all_rows_by_scenario:
                continue
            rows = all_rows_by_scenario[sc]
            for i, sec_label in enumerate(section_order):
                sec_rows = [r for r in rows
                            if r.get('section_label') == sec_label
                            and isinstance(r.get('composite_intensity'), (int, float))]
                if len(sec_rows) > 0:
                    matrix[i, j] = float(np.mean([r['composite_intensity'] for r in sec_rows]))

        fig, ax = plt.subplots(figsize=(9, 6))
        im = ax.imshow(matrix, cmap='YlOrRd', aspect='auto', vmin=0, vmax=1)
        plt.colorbar(im, ax=ax, label='Composite Intensity (amp × norm_tempo)')

        ax.set_xticks(range(len(heatmap_scenarios)))
        ax.set_xticklabels([s.replace('_', '\n') for s in heatmap_scenarios], fontsize=9)
        ax.set_yticks(range(len(section_order)))
        ax.set_yticklabels([s.replace('_', ' ') for s in section_order], fontsize=9)

        for i in range(len(section_order)):
            for j in range(len(heatmap_scenarios)):
                ax.text(j, i, f'{matrix[i, j]:.2f}', ha='center', va='center',
                        fontsize=10, color='black' if matrix[i, j] < 0.6 else 'white')

        ax.set_title('Amplitude × Tempo Composite Score Heatmap by Scenario and Section')
        plt.tight_layout()
        fig.savefig(out_dir / 'fig09_heatmap.png', dpi=150)
        plt.close(fig)
        print("Saved fig09_heatmap.png")
    except Exception as e:
        print(f"Warning: fig09 failed: {e}")


def make_fig10(all_rows_by_scenario: Dict[str, list], out_dir: Path) -> None:
    """Fig10: Phase-space trajectory: amplitude vs tempo for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(10, 7))
        target = ['Studio_Original', 'Live_Extended', 'Sunset_Sound_Mix', 'Acoustic_Demo']
        colors_map = {
            'Studio_Original':  '#1f77b4',
            'Live_Extended':    '#ff7f0e',
            'Sunset_Sound_Mix': '#d62728',
            'Acoustic_Demo':    '#2ca02c'
        }

        for sc in target:
            if sc not in all_rows_by_scenario:
                continue
            rows = all_rows_by_scenario[sc]
            amp_arr = np.array([r['amplitude_envelope'] for r in rows
                                if isinstance(r['amplitude_envelope'], (int, float))])
            bpm_arr = np.array([r['tempo_bpm'] for r in rows
                                if isinstance(r['tempo_bpm'], (int, float))])
            assert len(amp_arr) == len(bpm_arr), f"Phase space array mismatch for {sc}"
            if len(amp_arr) < 2:
                continue

            color = colors_map.get(sc, 'gray')
            ax.plot(amp_arr, bpm_arr, label=sc, color=color, lw=1.5, alpha=0.75)

            # Add arrows every ~50 steps
            arrow_step = max(1, len(amp_arr) // 10)
            for k in range(0, len(amp_arr) - arrow_step - 1, arrow_step):
                dx = amp_arr[k + 1] - amp_arr[k]
                dy = bpm_arr[k + 1] - bpm_arr[k]
                if abs(dx) > 1e-6 or abs(dy) > 1e-6:
                    ax.annotate('', xy=(amp_arr[k + 1], bpm_arr[k + 1]),
                                xytext=(amp_arr[k], bpm_arr[k]),
                                arrowprops=dict(arrowstyle='->', color=color, lw=0.8))

            # Mark start and end
            ax.scatter(amp_arr[0],  bpm_arr[0],  color=color, marker='o', s=80, zorder=5)
            ax.scatter(amp_arr[-1], bpm_arr[-1], color=color, marker='s', s=80, zorder=5)

        ax.set_xlabel('Amplitude Envelope (a.u.)')
        ax.set_ylabel('Tempo (BPM)')
        ax.set_title('Phase-Space Trajectory: Amplitude vs Tempo (All Scenarios)')
        ax.legend()
        ax.set_xlim(-0.05, 1.05)
        ax.set_ylim(50, 135)
        plt.tight_layout()
        fig.savefig(out_dir / 'fig10_phase_space.png', dpi=150)
        plt.close(fig)
        print("Saved fig10_phase_space.png")
    except Exception as e:
        print(f"Warning: fig10 failed: {e}")


# ─── CSV WRITING ──────────────────────────────────────────────────────────────

SCHEMA_COLUMNS = [
    'scenario', 'time_s', 'section_id', 'section_label', 'tempo_bpm',
    'amplitude_envelope', 'instrument_layer_count', 'spectral_density',
    'drums_active', 'electric_guitar_active', 'solo_guitar_active',
    'noise_realisation', 'composite_intensity', 'year',
    'radio_plays_cumulative_M', 'sheet_music_sales_cumulative_k',
    'chart_territory', 'peak_chart_position', 'accolade_publication',
    'accolade_year', 'accolade_rank'
]


def write_simulation_outputs(all_rows: List[Dict], out_dir: Path) -> None:
    """Write simulation_outputs.csv — all rows across all scenarios."""
    try:
        if len(all_rows) == 0:
            print("Warning: simulation_outputs.csv has no rows, skipping.")
            return
        filepath = out_dir / 'simulation_outputs.csv'
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=SCHEMA_COLUMNS, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"Saved simulation_outputs.csv ({len(all_rows)} rows)")
    except Exception as e:
        print(f"Warning: simulation_outputs.csv write failed: {e}")


def write_scenario_summary(all_rows_by_scenario: Dict[str, list],
                            cultural_rows: List[Dict], out_dir: Path) -> None:
    """Write scenario_summary.csv — one row per scenario with aggregate metrics."""
    try:
        summary_rows = []
        numeric_vars = ['tempo_bpm', 'amplitude_envelope', 'instrument_layer_count',
                        'spectral_density', 'composite_intensity']

        all_scenarios = list(all_rows_by_scenario.keys())

        for sc in all_scenarios:
            rows = all_rows_by_scenario[sc]
            sim_rows = [r for r in rows if isinstance(r.get('time_s'), (int, float))]
            row_out = {'scenario': sc}

            for var in numeric_vars:
                vals = np.array([r[var] for r in sim_rows
                                 if isinstance(r.get(var), (int, float))])
                if len(vals) > 0:
                    row_out[f'{var}_mean'] = round(float(np.mean(vals)), 4)
                    row_out[f'{var}_std']  = round(float(np.std(vals)), 4)
                    row_out[f'{var}_min']  = round(float(np.min(vals)), 4)
                    row_out[f'{var}_max']  = round(float(np.max(vals)), 4)
                else:
                    row_out[f'{var}_mean'] = ''
                    row_out[f'{var}_std']  = ''
                    row_out[f'{var}_min']  = ''
                    row_out[f'{var}_max']  = ''

            row_out['n_steps'] = len(sim_rows)

            # Count section coverage
            for sec_label in SECTION_LABELS:
                count = sum(1 for r in sim_rows if r.get('section_label') == sec_label)
                row_out[f'steps_in_{sec_label}'] = count

            row_out['drums_active_fraction'] = round(
                sum(1 for r in sim_rows if r.get('drums_active') == 1) / max(1, len(sim_rows)), 4)
            row_out['solo_active_fraction'] = round(
                sum(1 for r in sim_rows if r.get('solo_guitar_active') == 1) / max(1, len(sim_rows)), 4)

            summary_rows.append(row_out)

        # Cultural impact scenario summary
        if cultural_rows:
            cul_valid = [r for r in cultural_rows
                         if isinstance(r.get('radio_plays_cumulative_M'), (int, float))]
            if cul_valid:
                radio_vals = np.array([r['radio_plays_cumulative_M'] for r in cul_valid])
                sheet_vals = np.array([r['sheet_music_sales_cumulative_k'] for r in cul_valid])
                row_out = {
                    'scenario': 'Cultural_Impact_Trajectory',
                    'n_steps': len(cul_valid),
                    'radio_plays_mean': round(float(np.mean(radio_vals)), 4),
                    'radio_plays_max':  round(float(np.max(radio_vals)), 4),
                    'sheet_sales_mean': round(float(np.mean(sheet_vals)), 1),
                    'sheet_sales_max':  round(float(np.max(sheet_vals)), 1),
                }
                # Fill missing numeric var columns with empty
                for var in numeric_vars:
                    for stat in ['mean', 'std', 'min', 'max']:
                        if f'{var}_{stat}' not in row_out:
                            row_out[f'{var}_{stat}'] = ''
                summary_rows.append(row_out)

        if len(summary_rows) == 0:
            print("Warning: scenario_summary.csv has no rows, skipping.")
            return

        # Collect all keys
        all_keys = set()
        for r in summary_rows:
            all_keys.update(r.keys())
        all_keys = sorted(all_keys)
        # Put scenario first
        all_keys = ['scenario'] + [k for k in all_keys if k != 'scenario']

        filepath = out_dir / 'scenario_summary.csv'
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=all_keys, extrasaction='ignore')
            writer.writeheader()
            for r in summary_rows:
                filled = {k: r.get(k, '') for k in all_keys}
                writer.writerow(filled)
        print(f"Saved scenario_summary.csv ({len(summary_rows)} rows)")
    except Exception as e:
        print(f"Warning: scenario_summary.csv write failed: {e}")


def write_parameters_used(out_dir: Path) -> None:
    """Write parameters_used.csv — one row per parameter."""
    try:
        params = MODEL_PROFILE['parameters']
        rows = []
        for name, info in params.items():
            rows.append({
                'name':        name,
                'value':       info['value'],
                'unit':        info['unit'],
                'source':      info['source'],
                'description': info['description'],
            })
        if len(rows) == 0:
            print("Warning: parameters_used.csv has no rows.")
            return
        filepath = out_dir / 'parameters_used.csv'
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=['name', 'value', 'unit', 'source', 'description'])
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved parameters_used.csv ({len(rows)} rows)")
    except Exception as e:
        print(f"Warning: parameters_used.csv write failed: {e}")


def write_summary_json(all_rows_by_scenario: Dict[str, list],
                        cultural_rows: List[Dict], out_dir: Path) -> None:
    """Write summary.json with key aggregate metrics."""
    try:
        summary = {
            'title': MODEL_PROFILE['title'],
            'scenarios': {}
        }
        for sc, rows in all_rows_by_scenario.items():
            sim_rows = [r for r in rows if isinstance(r.get('time_s'), (int, float))]
            if sim_rows:
                amp_vals   = [r['amplitude_envelope'] for r in sim_rows
                              if isinstance(r.get('amplitude_envelope'), (int, float))]
                tempo_vals = [r['tempo_bpm'] for r in sim_rows
                              if isinstance(r.get('tempo_bpm'), (int, float))]
                comp_vals  = [r['composite_intensity'] for r in sim_rows
                              if isinstance(r.get('composite_intensity'), (int, float))]
                summary['scenarios'][sc] = {
                    'n_steps': len(sim_rows),
                    'amplitude_mean':   round(float(np.mean(amp_vals)), 4)   if amp_vals   else 0,
                    'amplitude_max':    round(float(np.max(amp_vals)), 4)    if amp_vals   else 0,
                    'tempo_mean_bpm':   round(float(np.mean(tempo_vals)), 2) if tempo_vals else 0,
                    'tempo_max_bpm':    round(float(np.max(tempo_vals)), 2)  if tempo_vals else 0,
                    'composite_mean':   round(float(np.mean(comp_vals)), 4)  if comp_vals  else 0,
                }

        if cultural_rows:
            cul_valid = [r for r in cultural_rows
                         if isinstance(r.get('radio_plays_cumulative_M'), (int, float))]
            if cul_valid:
                summary['cultural_impact'] = {
                    'year_range': [1971, 2005],
                    'radio_plays_max_M': round(float(max(r['radio_plays_cumulative_M']
                                                         for r in cul_valid)), 4),
                    'sheet_sales_max_k': round(float(max(r['sheet_music_sales_cumulative_k']
                                                         for r in cul_valid)), 1),
                }

        summary['chart_data_n_territories'] = len(CHART_DATA)
        summary['accolades_n']              = len(ACCOLADE_DATA)

        filepath = out_dir / 'summary.json'
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2)
        print("Saved summary.json")
    except Exception as e:
        print(f"Warning: summary.json write failed: {e}")


# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='Stairway to Heaven – Musical Structure & Cultural Impact Simulator')
    parser.add_argument('--output', type=str, default='./sim_outputs',
                        help='Output directory for all files (default: ./sim_outputs)')
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # ─── Run scenarios ────────────────────────────────────────────────────────
    all_rows_by_scenario: Dict[str, list] = {}
    all_rows_combined:    List[Dict]      = []
    cultural_rows_all:    List[Dict]      = []
    drums_entry_map:      Dict[str, float] = {}

    scenarios = MODEL_PROFILE['scenarios']

    for sc_idx, scenario_cfg in enumerate(scenarios):
        label     = scenario_cfg['label']
        overrides = scenario_cfg['param_overrides']

        np.random.seed(sc_idx)  # Reproducible, distinct seed per scenario
        print(f"\nRunning scenario [{sc_idx}]: {label}")

        if label == 'Cultural_Impact_Trajectory':
            # This scenario runs the cultural impact model
            radio_1990  = float(overrides.get('radio_plays_1990_M', 2.874))
            radio_2000  = float(overrides.get('radio_plays_2000_M', 3.0))
            sheet_ann   = float(overrides.get('sheet_music_annual_sales_k', 15.0))
            cult_rows = simulate_cultural(
                scenario_label=label,
                year_start=1971, year_end=2005,
                radio_1990=radio_1990, radio_2000=radio_2000,
                sheet_annual=sheet_ann
            )
            cultural_rows_all.extend(cult_rows)
            all_rows_combined.extend(cult_rows)
            all_rows_by_scenario[label] = cult_rows
            print(f"  Cultural rows: {len(cult_rows)}")
        else:
            # Build sections with overrides
            sections       = build_sections(overrides)
            total_dur      = float(overrides.get('total_duration_s', 482.0))
            drums_entry_s  = float(overrides.get('drums_entry_time_s', 258.0))
            noise_sigma    = float(overrides.get('noise_sigma', 0.02))

            drums_entry_map[label] = drums_entry_s

            rows = simulate_song(
                scenario_label=label,
                sections=sections,
                total_duration_s=total_dur,
                drums_entry_s=drums_entry_s,
                noise_sigma=noise_sigma,
                dt=0.5
            )
            all_rows_by_scenario[label] = rows
            all_rows_combined.extend(rows)
            print(f"  Simulation rows: {len(rows)}, duration: {total_dur}s")

            # Basic sanity check
            amp_vals = [r['amplitude_envelope'] for r in rows]
            print(f"  Amplitude range: [{min(amp_vals):.3f}, {max(amp_vals):.3f}]")

    # Also add chart and accolade rows to combined (as separate rows)
    for d in CHART_DATA:
        all_rows_combined.append({
            'scenario': 'Chart_Data',
            'time_s': '', 'section_id': '', 'section_label': '',
            'tempo_bpm': '', 'amplitude_envelope': '', 'instrument_layer_count': '',
            'spectral_density': '', 'drums_active': '', 'electric_guitar_active': '',
            'solo_guitar_active': '', 'noise_realisation': '', 'composite_intensity': '',
            'year': '', 'radio_plays_cumulative_M': '', 'sheet_music_sales_cumulative_k': '',
            'chart_territory': d['chart_territory'],
            'peak_chart_position': d['peak_chart_position'],
            'accolade_publication': '', 'accolade_year': '', 'accolade_rank': '',
        })

    for d in ACCOLADE_DATA:
        all_rows_combined.append({
            'scenario': 'Accolades',
            'time_s': '', 'section_id': '', 'section_label': '',
            'tempo_bpm': '', 'amplitude_envelope': '', 'instrument_layer_count': '',
            'spectral_density': '', 'drums_active': '', 'electric_guitar_active': '',
            'solo_guitar_active': '', 'noise_realisation': '', 'composite_intensity': '',
            'year': '', 'radio_plays_cumulative_M': '', 'sheet_music_sales_cumulative_k': '',
            'chart_territory': '',
            'peak_chart_position': '',
            'accolade_publication': d['accolade_publication'],
            'accolade_year': d['accolade_year'],
            'accolade_rank': d['accolade_rank'],
        })

    # ─── Generate figures ─────────────────────────────────────────────────────
    print("\nGenerating figures...")

    make_fig01(all_rows_by_scenario, out_dir)
    make_fig02(all_rows_by_scenario, out_dir)
    make_fig03(all_rows_by_scenario, out_dir, drums_entry_map)
    make_fig04(all_rows_by_scenario, out_dir)
    make_fig05(cultural_rows_all, out_dir)
    make_fig06(cultural_rows_all, out_dir)
    make_fig07(out_dir)
    make_fig08(out_dir)
    make_fig09(all_rows_by_scenario, out_dir)
    make_fig10(all_rows_by_scenario, out_dir)

    # ─── Write CSV files ──────────────────────────────────────────────────────
    print("\nWriting CSV files...")
    write_simulation_outputs(all_rows_combined, out_dir)
    write_scenario_summary(all_rows_by_scenario, cultural_rows_all, out_dir)
    write_parameters_used(out_dir)

    # ─── Write summary JSON ───────────────────────────────────────────────────
    print("\nWriting summary.json...")
    write_summary_json(all_rows_by_scenario, cultural_rows_all, out_dir)

    print(f"\nAll outputs saved to: {out_dir.resolve()}")
    print("Simulation complete.")


if __name__ == "__main__":
    main()