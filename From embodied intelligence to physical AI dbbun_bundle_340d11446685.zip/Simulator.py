# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-25T23:51:35.220334Z
# Run ID    : 2c09fc1d-6b3e-4cf5-9e57-e5571acaf0cb
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Simulator for: 'From embodied intelligence to physical AI'
Based on the Nature Machine Intelligence editorial surveying world models,
embodied intelligence, ecological psychology, and physical AI frameworks,
with emphasis on Moravec's paradox and the gap between digital AI capability
and real-world sensorimotor performance.
"""

import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Any, Tuple

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "n_agents": 4,
        "n_steps": 500,
        "env_grid_size": 10.0,
        "moravec_alpha": 0.8,
        "world_model_learning_rate": 0.05,
        "affordance_detection_threshold": 0.6,
        "environment_noise_sigma": 0.2,
        "embodiment_gain": 0.3,
        "data_scarcity_penalty": 0.4,
        "cognitive_task_difficulty": 0.3,
        "sensorimotor_task_difficulty": 0.8,
        "dt": 0.1,
        "affordance_update_rate": 0.1,
        "physical_ai_embodiment": 0.9,
        "world_model_embodiment": 0.3,
        "reactive_embodiment": 0.5,
        "affordance_embodiment": 0.7,
        "data_availability": 0.5,
    },
    "agent_types": ["world_model", "affordance_based", "reactive", "physical_ai"],
    "embodiment_map": {
        "world_model": 0.3,
        "affordance_based": 0.7,
        "reactive": 0.5,
        "physical_ai": 0.9,
    },
    "scenario_plan": [
        {
            "label": "cognitive_vs_sensorimotor",
            "description": "Compares all four agent architectures on a spectrum of tasks ranging from purely cognitive to purely sensorimotor",
            "param_overrides": {"environment_noise_sigma": 0.1, "n_steps": 500},
        },
        {
            "label": "high_environment_uncertainty",
            "description": "All agents operate in a highly stochastic environment",
            "param_overrides": {"environment_noise_sigma": 0.5, "n_steps": 500},
        },
        {
            "label": "data_scarce_physical_interaction",
            "description": "Simulates the data scarcity problem for physical interaction tasks",
            "param_overrides": {"data_scarcity_penalty": 0.7, "data_availability": 0.2, "n_steps": 500},
        },
        {
            "label": "embodiment_spectrum",
            "description": "Varies the embodiment coefficient continuously from 0 to 1",
            "param_overrides": {"environment_noise_sigma": 0.2, "sensorimotor_task_difficulty": 0.8, "n_steps": 500},
        },
        {
            "label": "world_model_learning_dynamics",
            "description": "Tracks world model accuracy over time under varying environmental uncertainty",
            "param_overrides": {"world_model_learning_rate": 0.05, "environment_noise_sigma": 0.15, "n_steps": 500},
        },
    ],
}


# ============================================================
# SIMULATION CORE
# ============================================================

def get_params(scenario_overrides: Dict[str, Any]) -> Dict[str, Any]:
    """Merge default parameters with scenario overrides."""
    params = dict(MODEL_PROFILE["parameters"])
    params.update(scenario_overrides)
    return params


def run_agent_simulation(
    agent_type: str,
    params: Dict[str, Any],
    scenario_label: str,
    rng_seed: int,
) -> List[Dict[str, Any]]:
    """Run simulation for a single agent type and return list of row dicts."""
    np.random.seed(rng_seed)

    n_steps = int(params["n_steps"])
    env_grid_size = float(params["env_grid_size"])
    wm_lr = float(params["world_model_learning_rate"])
    affordance_thresh = float(params["affordance_detection_threshold"])
    env_noise_sigma = float(params["environment_noise_sigma"])
    embodiment_gain = float(params["embodiment_gain"])
    data_scarcity_penalty = float(params["data_scarcity_penalty"])
    cognitive_task_diff = float(params["cognitive_task_difficulty"])
    sensorimotor_task_diff = float(params["sensorimotor_task_difficulty"])
    dt = float(params["dt"])
    affordance_update_rate = float(params["affordance_update_rate"])
    data_avail = float(params["data_availability"])

    emb_coeff = MODEL_PROFILE["embodiment_map"][agent_type]

    # Initial state
    pos = np.array([env_grid_size / 2.0, env_grid_size / 2.0])
    vel = np.zeros(2)
    wm_accuracy = 0.5
    aff_percep = 0.0
    tsr = 0.0
    sm_error = 0.5
    cog_load = np.random.uniform(0.2, 0.8)

    records = []

    goal = np.array([env_grid_size * 0.8, env_grid_size * 0.8])

    for t in range(n_steps):
        # 1. ENVIRONMENT NOISE
        env_noise = np.random.normal(0.0, env_noise_sigma, size=2)
        env_noise_norm = float(np.linalg.norm(env_noise))

        # 2. MORAVEC DIFFICULTY INDEX
        sensorimotor_difficulty = (
            sensorimotor_task_diff * (1.0 - cog_load) + cognitive_task_diff * cog_load
        )
        moravec_idx = 1.0 - cog_load  # 1 = pure sensorimotor

        # 3. WORLD MODEL UPDATE
        if agent_type == "world_model":
            prediction_error = sensorimotor_difficulty * (1.0 - wm_accuracy) + env_noise_norm
            wm_accuracy += wm_lr * (1.0 - wm_accuracy - prediction_error)
            wm_accuracy -= data_scarcity_penalty * (1.0 - data_avail) * 0.01
            wm_accuracy = float(np.clip(wm_accuracy, 0.0, 1.0))
        else:
            wm_accuracy += 0.5 * wm_lr * (0.5 - wm_accuracy)
            wm_accuracy = float(np.clip(wm_accuracy, 0.0, 1.0))

        # 4. AFFORDANCE PERCEPTION UPDATE
        if agent_type in ["affordance_based", "physical_ai"]:
            target_affordance = min(
                1.0, emb_coeff * (1.0 - sensorimotor_difficulty * 0.5) + 0.2
            )
            aff_percep += affordance_update_rate * (target_affordance - aff_percep)
            aff_percep += float(np.random.normal(0.0, 0.05))
            aff_percep = float(np.clip(aff_percep, 0.0, 1.0))
        else:
            aff_percep = wm_accuracy * 0.6 + float(np.random.normal(0.0, 0.1))
            aff_percep = float(np.clip(aff_percep, 0.0, 1.0))

        # 5. ACTION DECISION
        if agent_type == "reactive":
            action_taken = aff_percep > 0.3
        elif agent_type == "world_model":
            action_taken = wm_accuracy > 0.55
        elif agent_type == "affordance_based":
            action_taken = aff_percep > affordance_thresh
        else:  # physical_ai
            action_taken = aff_percep > affordance_thresh * 0.8

        # 6. SENSORIMOTOR ERROR UPDATE
        if action_taken:
            base_error = sensorimotor_difficulty * (1.0 - emb_coeff * embodiment_gain)
            sm_error_new = base_error + env_noise_norm * 0.3
            sm_error_new = float(np.clip(sm_error_new, 0.0, 1.0))
        else:
            sm_error_new = sm_error * 0.95

        sm_error = float(np.clip(0.8 * sm_error + 0.2 * sm_error_new, 0.0, 1.0))

        # 7. TASK SUCCESS RATE UPDATE
        if action_taken:
            success_prob = (
                wm_accuracy * 0.3
                + aff_percep * 0.3
                + emb_coeff * embodiment_gain
                + (1.0 - sm_error) * 0.2
            ) * (1.0 - env_noise_sigma * 0.5)
            success_prob = float(np.clip(success_prob, 0.0, 1.0))
            trial_success = float(np.random.random() < success_prob)
        else:
            trial_success = 0.0

        tsr = float(np.clip(0.95 * tsr + 0.05 * trial_success, 0.0, 1.0))

        # 8. POSITION / VELOCITY UPDATE (Euler)
        dist_to_goal = float(np.linalg.norm(goal - pos))
        direction = (goal - pos) / (dist_to_goal + 1e-8)
        force = direction * (1.0 - sm_error) + env_noise * 0.5
        vel = vel * 0.9 + force * dt
        vel = np.clip(vel, -2.0, 2.0)
        pos = pos + vel * dt
        pos = np.clip(pos, 0.0, env_grid_size)

        # 9. COGNITIVE LOAD VARIATION
        cog_load = 0.5 + 0.4 * np.sin(2.0 * np.pi * t / 100.0)
        cog_load = float(np.clip(cog_load, 0.0, 1.0))

        # 10. RECORD ROW
        task_type = "cognitive" if cog_load > 0.6 else "sensorimotor"

        records.append({
            "scenario": scenario_label,
            "agent_type": agent_type,
            "timestep": t,
            "agent_position_x": float(np.clip(pos[0], 0.0, env_grid_size)),
            "agent_position_y": float(np.clip(pos[1], 0.0, env_grid_size)),
            "agent_velocity_x": float(np.clip(vel[0], -2.0, 2.0)),
            "agent_velocity_y": float(np.clip(vel[1], -2.0, 2.0)),
            "world_model_accuracy": float(np.clip(wm_accuracy, 0.0, 1.0)),
            "affordance_perception": float(np.clip(aff_percep, 0.0, 1.0)),
            "task_success_rate": float(np.clip(tsr, 0.0, 1.0)),
            "sensorimotor_error": float(np.clip(sm_error, 0.0, 1.0)),
            "cognitive_load": float(np.clip(cog_load, 0.0, 1.0)),
            "environment_uncertainty": float(np.clip(env_noise_sigma, 0.0, 1.0)),
            "embodiment_coefficient": float(np.clip(emb_coeff, 0.0, 1.0)),
            "data_availability": float(np.clip(data_avail, 0.0, 1.0)),
            "task_type": task_type,
            "moravec_difficulty_index": float(np.clip(moravec_idx, 0.0, 1.0)),
        })

    return records


def run_all_scenarios() -> List[Dict[str, Any]]:
    """Run all scenarios and return combined records."""
    all_records = []
    agent_types = MODEL_PROFILE["agent_types"]
    scenarios = MODEL_PROFILE["scenario_plan"]

    for scenario_idx, scenario in enumerate(scenarios):
        params = get_params(scenario["param_overrides"])
        label = scenario["label"]
        print(f"  Running scenario [{scenario_idx}]: {label}")

        for agent_idx, agent_type in enumerate(agent_types):
            # Unique seed per scenario+agent combination
            seed = scenario_idx * 100 + agent_idx
            np.random.seed(seed)
            records = run_agent_simulation(agent_type, params, label, seed)
            all_records.extend(records)

    return all_records


# ============================================================
# POST-PROCESSING FOR FIGURES
# ============================================================

def run_embodiment_sweep(n_embodiment_pts: int = 50) -> Tuple[np.ndarray, np.ndarray]:
    """Sweep embodiment coefficient and return (emb_vals, mean_sm_error)."""
    emb_values = np.linspace(0.0, 1.0, n_embodiment_pts)
    mean_errors = np.zeros(n_embodiment_pts)

    base_params = get_params({"environment_noise_sigma": 0.2, "sensorimotor_task_difficulty": 0.8})
    n_steps = 200

    for i, emb_val in enumerate(emb_values):
        np.random.seed(200 + i)
        sm_errors_last100 = []
        sm_error = 0.5
        cog_load = 0.1  # low cognitive = high sensorimotor difficulty

        for t in range(n_steps):
            env_noise = np.random.normal(0.0, base_params["environment_noise_sigma"], size=2)
            env_noise_norm = float(np.linalg.norm(env_noise))
            sensorimotor_difficulty = (
                base_params["sensorimotor_task_difficulty"] * (1.0 - cog_load)
                + base_params["cognitive_task_difficulty"] * cog_load
            )
            action_taken = True  # always act for sweep
            base_error = sensorimotor_difficulty * (1.0 - emb_val * base_params["embodiment_gain"])
            sm_error_new = base_error + env_noise_norm * 0.3
            sm_error_new = float(np.clip(sm_error_new, 0.0, 1.0))
            sm_error = float(np.clip(0.8 * sm_error + 0.2 * sm_error_new, 0.0, 1.0))
            cog_load = 0.5 + 0.4 * np.sin(2.0 * np.pi * t / 100.0)
            cog_load = max(0.0, min(1.0, cog_load))

            if t >= n_steps - 100:
                sm_errors_last100.append(sm_error)

        mean_errors[i] = float(np.mean(sm_errors_last100)) if sm_errors_last100 else 0.5

    assert len(emb_values) == len(mean_errors), "Embodiment sweep array length mismatch"
    return emb_values, mean_errors


def run_heatmap_grid(grid_size: int = 10) -> np.ndarray:
    """Run world_model agent on a grid of (env_uncertainty x data_availability)."""
    env_uncerts = np.linspace(0.0, 1.0, grid_size)
    data_avails = np.linspace(0.0, 1.0, grid_size)
    heatmap = np.zeros((grid_size, grid_size))

    for i, da in enumerate(data_avails):
        for j, eu in enumerate(env_uncerts):
            np.random.seed(300 + i * grid_size + j)
            eu_clamped = float(np.clip(eu, 0.01, 1.0))
            da_clamped = float(np.clip(da, 0.0, 1.0))
            params = get_params({
                "environment_noise_sigma": eu_clamped,
                "data_availability": da_clamped,
                "data_scarcity_penalty": 0.4,
            })
            records = run_agent_simulation("world_model", params, "heatmap", 300 + i * grid_size + j)
            if records:
                tsr_vals = [r["task_success_rate"] for r in records]
                heatmap[i, j] = float(np.mean(tsr_vals[-50:]))

    return heatmap


# ============================================================
# FIGURE GENERATION
# ============================================================

AGENT_COLORS = {
    "world_model": "#1f77b4",
    "affordance_based": "#2ca02c",
    "reactive": "#ff7f0e",
    "physical_ai": "#d62728",
}

AGENT_LABELS = {
    "world_model": "World Model",
    "affordance_based": "Affordance-Based",
    "reactive": "Reactive",
    "physical_ai": "Physical AI",
}


def generate_fig1(all_records: List[Dict], output_dir: Path) -> None:
    """Fig1: Moravec's Paradox - task success rate vs cognitive load."""
    try:
        fig, ax = plt.subplots(figsize=(9, 6))
        cog_bins = np.linspace(0.0, 1.0, 20)
        bin_centers = 0.5 * (cog_bins[:-1] + cog_bins[1:])

        agent_types = MODEL_PROFILE["agent_types"]

        # Filter to cognitive_vs_sensorimotor scenario
        scenario_records = [r for r in all_records if r["scenario"] == "cognitive_vs_sensorimotor"]

        for agent_type in agent_types:
            agent_records = [r for r in scenario_records if r["agent_type"] == agent_type]
            if not agent_records:
                continue

            cog_arr = np.array([r["cognitive_load"] for r in agent_records])
            tsr_arr = np.array([r["task_success_rate"] for r in agent_records])

            bin_means = []
            for k in range(len(bin_centers)):
                mask = (cog_arr >= cog_bins[k]) & (cog_arr < cog_bins[k + 1])
                if mask.sum() > 0:
                    bin_means.append(float(np.mean(tsr_arr[mask])))
                else:
                    bin_means.append(np.nan)

            bin_means_arr = np.array(bin_means)
            valid = ~np.isnan(bin_means_arr)
            x_plot = bin_centers[valid]
            y_plot = bin_means_arr[valid]

            if len(x_plot) > 0 and len(y_plot) > 0:
                assert len(x_plot) == len(y_plot)
                ax.plot(x_plot, y_plot, color=AGENT_COLORS[agent_type],
                        label=AGENT_LABELS[agent_type], linewidth=2.0, marker='o', markersize=4)

        # Human baseline: inverse of machine performance
        human_x = np.linspace(0.0, 1.0, 50)
        human_y = np.clip(0.9 - 0.7 * human_x + 0.1 * np.sin(np.pi * human_x), 0.0, 1.0)
        assert len(human_x) == len(human_y)
        ax.plot(human_x, human_y, color="purple", linestyle="--", linewidth=2.0,
                label="Human Baseline", alpha=0.8)

        ax.set_xlabel("Cognitive Load (0=Sensorimotor, 1=Abstract Reasoning)", fontsize=12)
        ax.set_ylabel("Task Success Rate", fontsize=12)
        ax.set_title("Moravec's Paradox: Machine vs Human Task Difficulty Inversion", fontsize=13)
        ax.legend(fontsize=10)
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, 1.0)
        ax.grid(True, alpha=0.3)
        ax.axvline(x=0.5, color="gray", linestyle=":", alpha=0.5)
        plt.tight_layout()
        plt.savefig(output_dir / "fig1_moravec_paradox.png", dpi=150)
        plt.close(fig)
        print("  Saved fig1_moravec_paradox.png")
    except Exception as e:
        print(f"  WARNING: fig1 failed: {e}")


def generate_fig2(all_records: List[Dict], output_dir: Path) -> None:
    """Fig2: Task success rate over time for all four agent architectures."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        scenario_records = [r for r in all_records if r["scenario"] == "cognitive_vs_sensorimotor"]
        agent_types = MODEL_PROFILE["agent_types"]

        for agent_type in agent_types:
            agent_records = sorted(
                [r for r in scenario_records if r["agent_type"] == agent_type],
                key=lambda x: x["timestep"]
            )
            if not agent_records:
                continue

            timesteps = np.array([r["timestep"] for r in agent_records])
            tsr = np.array([r["task_success_rate"] for r in agent_records])

            assert len(timesteps) == len(tsr)
            if len(timesteps) == 0:
                continue

            ax.plot(timesteps, tsr, color=AGENT_COLORS[agent_type],
                    label=AGENT_LABELS[agent_type], linewidth=2.0, alpha=0.85)

        ax.set_xlabel("Timestep", fontsize=12)
        ax.set_ylabel("Task Success Rate (rolling EMA)", fontsize=12)
        ax.set_title("Task Success Rate Over Time: Four Agent Architectures", fontsize=13)
        ax.legend(fontsize=10)
        ax.set_xlim(0, 500)
        ax.set_ylim(0.0, 1.0)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / "fig2_task_success_over_time.png", dpi=150)
        plt.close(fig)
        print("  Saved fig2_task_success_over_time.png")
    except Exception as e:
        print(f"  WARNING: fig2 failed: {e}")


def generate_fig3(all_records: List[Dict], output_dir: Path) -> None:
    """Fig3: World model accuracy dynamics under varying environmental uncertainty."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))

        noise_levels = [
            ("cognitive_vs_sensorimotor", "Low Noise (σ=0.1)", "#1f77b4"),
            ("world_model_learning_dynamics", "Medium Noise (σ=0.15)", "#ff7f0e"),
            ("high_environment_uncertainty", "High Noise (σ=0.5)", "#d62728"),
        ]

        for scenario_label, label_str, color in noise_levels:
            wm_records = sorted(
                [r for r in all_records
                 if r["scenario"] == scenario_label and r["agent_type"] == "world_model"],
                key=lambda x: x["timestep"]
            )
            if not wm_records:
                continue

            timesteps = np.array([r["timestep"] for r in wm_records])
            wma = np.array([r["world_model_accuracy"] for r in wm_records])

            assert len(timesteps) == len(wma)
            if len(timesteps) == 0:
                continue

            ax.plot(timesteps, wma, color=color, label=label_str, linewidth=2.0)

        ax.set_xlabel("Timestep", fontsize=12)
        ax.set_ylabel("World Model Accuracy", fontsize=12)
        ax.set_title("World Model Accuracy Dynamics Under Varying Environmental Uncertainty", fontsize=13)
        ax.legend(fontsize=10)
        ax.set_xlim(0, 500)
        ax.set_ylim(0.0, 1.0)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / "fig3_world_model_accuracy.png", dpi=150)
        plt.close(fig)
        print("  Saved fig3_world_model_accuracy.png")
    except Exception as e:
        print(f"  WARNING: fig3 failed: {e}")


def generate_fig4(output_dir: Path) -> None:
    """Fig4: Sensorimotor error vs embodiment coefficient sweep."""
    try:
        emb_values, mean_errors = run_embodiment_sweep(50)
        assert len(emb_values) == len(mean_errors)

        if len(emb_values) == 0:
            print("  WARNING: fig4 - empty sweep arrays, skipping")
            return

        fig, ax = plt.subplots(figsize=(9, 6))
        ax.plot(emb_values, mean_errors, color="#1f77b4", linewidth=2.5, label="Embodiment Sweep")

        # Annotate named agent types
        embodiment_map = MODEL_PROFILE["embodiment_map"]
        agent_emb_errors = {}
        for agent_name, emb_val in embodiment_map.items():
            idx = int(np.argmin(np.abs(emb_values - emb_val)))
            agent_emb_errors[agent_name] = (emb_val, float(mean_errors[idx]))

        annotation_colors = {
            "world_model": "#1f77b4",
            "affordance_based": "#2ca02c",
            "reactive": "#ff7f0e",
            "physical_ai": "#d62728",
        }
        for agent_name, (ex, ey) in agent_emb_errors.items():
            ax.scatter([ex], [ey], color=annotation_colors[agent_name], s=100, zorder=5)
            ax.annotate(
                AGENT_LABELS[agent_name],
                xy=(ex, ey),
                xytext=(ex + 0.03, ey + 0.02),
                fontsize=9,
                color=annotation_colors[agent_name],
            )

        ax.set_xlabel("Embodiment Coefficient (0=Pure Software, 1=Full Physical AI)", fontsize=12)
        ax.set_ylabel("Mean Sensorimotor Error", fontsize=12)
        ax.set_title("Sensorimotor Error vs Embodiment Coefficient Across Agent Types", fontsize=13)
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, 1.0)
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=10)
        plt.tight_layout()
        plt.savefig(output_dir / "fig4_sensorimotor_error_vs_embodiment.png", dpi=150)
        plt.close(fig)
        print("  Saved fig4_sensorimotor_error_vs_embodiment.png")
    except Exception as e:
        print(f"  WARNING: fig4 failed: {e}")


def generate_fig5(output_dir: Path) -> None:
    """Fig5: Heatmap of task success rate vs environment uncertainty x data availability."""
    try:
        grid_size = 10
        heatmap = run_heatmap_grid(grid_size)

        if heatmap.shape[0] == 0 or heatmap.shape[1] == 0:
            print("  WARNING: fig5 - empty heatmap, skipping")
            return

        fig, ax = plt.subplots(figsize=(8, 6))
        env_uncerts = np.linspace(0.0, 1.0, grid_size)
        data_avails = np.linspace(0.0, 1.0, grid_size)

        im = ax.imshow(
            heatmap,
            origin="lower",
            aspect="auto",
            extent=[env_uncerts[0], env_uncerts[-1], data_avails[0], data_avails[-1]],
            cmap="RdYlGn",
            vmin=0.0,
            vmax=1.0,
        )
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label("Mean Task Success Rate", fontsize=11)
        ax.set_xlabel("Environment Uncertainty", fontsize=12)
        ax.set_ylabel("Data Availability", fontsize=12)
        ax.set_title("Task Success Rate Heatmap:\nEnvironment Uncertainty vs Data Availability", fontsize=13)
        plt.tight_layout()
        plt.savefig(output_dir / "fig5_heatmap_uncertainty_data.png", dpi=150)
        plt.close(fig)
        print("  Saved fig5_heatmap_uncertainty_data.png")
    except Exception as e:
        print(f"  WARNING: fig5 failed: {e}")


def generate_fig6(all_records: List[Dict], output_dir: Path) -> None:
    """Fig6: Scatter plot affordance perception vs task success rate."""
    try:
        fig, ax = plt.subplots(figsize=(9, 6))
        # Use cognitive_vs_sensorimotor scenario for clarity
        scenario_records = [r for r in all_records if r["scenario"] == "cognitive_vs_sensorimotor"]
        agent_types = MODEL_PROFILE["agent_types"]

        # Sample every 5th record to avoid overplotting
        for agent_type in agent_types:
            agent_records = [r for r in scenario_records if r["agent_type"] == agent_type]
            sampled = agent_records[::5]
            if not sampled:
                continue

            aff_arr = np.array([r["affordance_perception"] for r in sampled])
            tsr_arr = np.array([r["task_success_rate"] for r in sampled])

            assert len(aff_arr) == len(tsr_arr)
            if len(aff_arr) == 0:
                continue

            ax.scatter(
                aff_arr, tsr_arr,
                color=AGENT_COLORS[agent_type],
                label=AGENT_LABELS[agent_type],
                alpha=0.5, s=20,
            )

        # Threshold line
        thresh = MODEL_PROFILE["parameters"]["affordance_detection_threshold"]
        ax.axvline(x=thresh, color="black", linestyle="--", linewidth=1.5,
                   label=f"Detection Threshold ({thresh})")

        ax.set_xlabel("Affordance Perception Score", fontsize=12)
        ax.set_ylabel("Task Success Rate", fontsize=12)
        ax.set_title("Affordance Perception vs Task Success: Ecological Psychology Perspective", fontsize=13)
        ax.legend(fontsize=9, loc="upper left")
        ax.set_xlim(0.0, 1.0)
        ax.set_ylim(0.0, 1.0)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / "fig6_affordance_vs_success.png", dpi=150)
        plt.close(fig)
        print("  Saved fig6_affordance_vs_success.png")
    except Exception as e:
        print(f"  WARNING: fig6 failed: {e}")


def generate_fig7(all_records: List[Dict], output_dir: Path) -> None:
    """Fig7: Sensorimotor error under high vs low environmental uncertainty."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(14, 6), sharey=True)
        agent_types = MODEL_PROFILE["agent_types"]

        scenario_pairs = [
            ("cognitive_vs_sensorimotor", "Low Uncertainty (σ=0.1)", axes[0]),
            ("high_environment_uncertainty", "High Uncertainty (σ=0.5)", axes[1]),
        ]

        for scenario_label, title_str, ax in scenario_pairs:
            scenario_records = [r for r in all_records if r["scenario"] == scenario_label]
            for agent_type in agent_types:
                agent_records = sorted(
                    [r for r in scenario_records if r["agent_type"] == agent_type],
                    key=lambda x: x["timestep"]
                )
                if not agent_records:
                    continue

                timesteps = np.array([r["timestep"] for r in agent_records])
                sm_err = np.array([r["sensorimotor_error"] for r in agent_records])

                assert len(timesteps) == len(sm_err)
                if len(timesteps) == 0:
                    continue

                ax.plot(timesteps, sm_err, color=AGENT_COLORS[agent_type],
                        label=AGENT_LABELS[agent_type], linewidth=1.8, alpha=0.85)

            ax.set_title(title_str, fontsize=12)
            ax.set_xlabel("Timestep", fontsize=11)
            ax.set_xlim(0, 500)
            ax.set_ylim(0.0, 1.0)
            ax.grid(True, alpha=0.3)
            ax.legend(fontsize=9)

        axes[0].set_ylabel("Sensorimotor Error", fontsize=12)
        fig.suptitle("Sensorimotor Error Under High vs Low Environmental Uncertainty", fontsize=13)
        plt.tight_layout()
        plt.savefig(output_dir / "fig7_sensorimotor_error_uncertainty.png", dpi=150)
        plt.close(fig)
        print("  Saved fig7_sensorimotor_error_uncertainty.png")
    except Exception as e:
        print(f"  WARNING: fig7 failed: {e}")


# ============================================================
# CSV WRITING
# ============================================================

DATASET_SCHEMA = [
    "scenario", "agent_type", "timestep",
    "agent_position_x", "agent_position_y",
    "agent_velocity_x", "agent_velocity_y",
    "world_model_accuracy", "affordance_perception",
    "task_success_rate", "sensorimotor_error",
    "cognitive_load", "environment_uncertainty",
    "embodiment_coefficient", "data_availability",
    "task_type", "moravec_difficulty_index",
]


def save_simulation_outputs(all_records: List[Dict], output_dir: Path) -> None:
    """Save simulation_outputs.csv."""
    if not all_records:
        print("  WARNING: No records to write to simulation_outputs.csv")
        return

    filepath = output_dir / "simulation_outputs.csv"
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA)
            writer.writeheader()
            for row in all_records:
                writer.writerow({k: row[k] for k in DATASET_SCHEMA})
        print(f"  Saved simulation_outputs.csv ({len(all_records)} rows)")
    except Exception as e:
        print(f"  WARNING: Failed to write simulation_outputs.csv: {e}")


def save_scenario_summary(all_records: List[Dict], output_dir: Path) -> None:
    """Save scenario_summary.csv with one row per scenario+agent_type."""
    if not all_records:
        print("  WARNING: No records for scenario_summary.csv")
        return

    # Aggregate per scenario+agent_type
    from collections import defaultdict
    groups: Dict[Tuple, List] = defaultdict(list)
    for r in all_records:
        key = (r["scenario"], r["agent_type"])
        groups[key].append(r)

    numeric_vars = [
        "world_model_accuracy", "affordance_perception", "task_success_rate",
        "sensorimotor_error", "cognitive_load", "embodiment_coefficient",
        "environment_uncertainty", "data_availability", "moravec_difficulty_index",
    ]

    summary_rows = []
    for (scenario, agent_type), records in sorted(groups.items()):
        row = {"scenario": scenario, "agent_type": agent_type, "n_steps": len(records)}
        for var in numeric_vars:
            vals = np.array([r[var] for r in records])
            row[f"{var}_mean"] = float(np.mean(vals))
            row[f"{var}_std"] = float(np.std(vals))
            row[f"{var}_min"] = float(np.min(vals))
            row[f"{var}_max"] = float(np.max(vals))
        # Final TSR as KPI
        last_tsr = np.array([r["task_success_rate"] for r in records[-50:]])
        row["final_tsr_mean"] = float(np.mean(last_tsr))
        summary_rows.append(row)

    if not summary_rows:
        print("  WARNING: No summary rows computed")
        return

    filepath = output_dir / "scenario_summary.csv"
    try:
        fieldnames = list(summary_rows[0].keys())
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(summary_rows)
        print(f"  Saved scenario_summary.csv ({len(summary_rows)} rows)")
    except Exception as e:
        print(f"  WARNING: Failed to write scenario_summary.csv: {e}")


def save_parameters_used(output_dir: Path) -> None:
    """Save parameters_used.csv."""
    param_info = [
        ("n_agents", 4, "count", "assumed", "Number of agents representing different architectures"),
        ("n_steps", 500, "steps", "assumed", "Total number of simulation timesteps per scenario"),
        ("env_grid_size", 10.0, "m", "assumed", "Side length of square 2D environment grid"),
        ("moravec_alpha", 0.8, "a.u.", "extracted", "Scaling parameter encoding Moravec's paradox"),
        ("world_model_learning_rate", 0.05, "per step", "assumed", "Rate at which the world-model agent updates its internal predictive model accuracy"),
        ("affordance_detection_threshold", 0.6, "a.u.", "assumed", "Minimum affordance perception score for agent to attempt an action"),
        ("environment_noise_sigma", 0.2, "a.u.", "extracted", "Standard deviation of stochastic perturbations"),
        ("embodiment_gain", 0.3, "a.u.", "extracted", "Bonus to task success rate granted by high embodiment coefficient"),
        ("data_scarcity_penalty", 0.4, "a.u.", "extracted", "Reduction in world_model_accuracy when physical interaction data is scarce"),
        ("cognitive_task_difficulty", 0.3, "a.u.", "assumed", "Base difficulty level for abstract/cognitive tasks"),
        ("sensorimotor_task_difficulty", 0.8, "a.u.", "extracted", "Base difficulty level for mundane sensorimotor tasks"),
        ("dt", 0.1, "s", "assumed", "Simulation timestep duration in seconds"),
        ("affordance_update_rate", 0.1, "per step", "assumed", "Rate at which affordance perception adapts to environmental structure"),
        ("physical_ai_embodiment", 0.9, "a.u.", "extracted", "Embodiment coefficient for physical AI agent"),
        ("world_model_embodiment", 0.3, "a.u.", "assumed", "Embodiment coefficient for world-model-only agent"),
        ("reactive_embodiment", 0.5, "a.u.", "assumed", "Embodiment coefficient for reactive agent"),
        ("affordance_embodiment", 0.7, "a.u.", "assumed", "Embodiment coefficient for Gibson affordance-based agent"),
        ("data_availability", 0.5, "a.u.", "assumed", "Relative quantity of task-relevant training data available"),
    ]

    filepath = output_dir / "parameters_used.csv"
    try:
        with open(filepath, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["name", "value", "unit", "source", "description"])
            for row in param_info:
                writer.writerow(row)
        print(f"  Saved parameters_used.csv ({len(param_info)} rows)")
    except Exception as e:
        print(f"  WARNING: Failed to write parameters_used.csv: {e}")


# ============================================================
# SUMMARY JSON
# ============================================================

def save_summary_json(all_records: List[Dict], output_dir: Path) -> None:
    """Save summary.json with aggregate metrics."""
    if not all_records:
        print("  WARNING: No records for summary.json")
        return

    from collections import defaultdict
    scenario_metrics: Dict[str, Dict] = defaultdict(dict)

    scenarios = MODEL_PROFILE["scenario_plan"]
    agent_types = MODEL_PROFILE["agent_types"]

    for scenario in scenarios:
        label = scenario["label"]
        sc_records = [r for r in all_records if r["scenario"] == label]
        if not sc_records:
            continue

        tsr_all = np.array([r["task_success_rate"] for r in sc_records])
        sm_all = np.array([r["sensorimotor_error"] for r in sc_records])
        wma_all = np.array([r["world_model_accuracy"] for r in sc_records])

        scenario_metrics[label]["mean_tsr"] = float(np.mean(tsr_all))
        scenario_metrics[label]["mean_sm_error"] = float(np.mean(sm_all))
        scenario_metrics[label]["mean_wm_accuracy"] = float(np.mean(wma_all))
        scenario_metrics[label]["n_records"] = len(sc_records)

        agent_summary = {}
        for agent_type in agent_types:
            ag_recs = [r for r in sc_records if r["agent_type"] == agent_type]
            if ag_recs:
                final_recs = ag_recs[-50:]
                agent_summary[agent_type] = {
                    "final_tsr": float(np.mean([r["task_success_rate"] for r in final_recs])),
                    "final_sm_error": float(np.mean([r["sensorimotor_error"] for r in final_recs])),
                    "final_wm_accuracy": float(np.mean([r["world_model_accuracy"] for r in final_recs])),
                }
        scenario_metrics[label]["by_agent"] = agent_summary

    summary = {
        "title": "From embodied intelligence to physical AI - Simulation Summary",
        "total_records": len(all_records),
        "n_scenarios": len(scenarios),
        "n_agent_types": len(agent_types),
        "agent_types": agent_types,
        "scenario_metrics": dict(scenario_metrics),
        "parameters": MODEL_PROFILE["parameters"],
    }

    filepath = output_dir / "summary.json"
    try:
        with open(filepath, "w") as f:
            json.dump(summary, f, indent=2)
        print(f"  Saved summary.json")
    except Exception as e:
        print(f"  WARNING: Failed to write summary.json: {e}")


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Simulator: From embodied intelligence to physical AI"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    print("\n=== Running All Scenarios ===")
    all_records = run_all_scenarios()
    print(f"Total simulation records: {len(all_records)}")

    print("\n=== Saving CSV Files ===")
    save_simulation_outputs(all_records, output_dir)
    save_scenario_summary(all_records, output_dir)
    save_parameters_used(output_dir)

    print("\n=== Generating Figures ===")
    generate_fig1(all_records, output_dir)
    generate_fig2(all_records, output_dir)
    generate_fig3(all_records, output_dir)
    generate_fig4(output_dir)
    generate_fig5(output_dir)
    generate_fig6(all_records, output_dir)
    generate_fig7(all_records, output_dir)

    print("\n=== Saving Summary JSON ===")
    save_summary_json(all_records, output_dir)

    print(f"\n=== Simulation Complete ===")
    print(f"All outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()