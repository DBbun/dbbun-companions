================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 2c09fc1d-6b3e-4cf5-9e57-e5571acaf0cb
    Generated   : 2026-04-25  23:51:35 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    From embodied intelligence to physical AI

    CATEGORIES
    ----------
    Artificial Intelligence, Computational Intelligence, Machine Learning

    KEYWORDS
    --------
    embodied intelligence, physical AI, Moravec's paradox, affordances, world models, sensorimotor control, agent-based simulation, ecological psychology, robotics

    ABSTRACT
    --------
    This simulator models the core theoretical tensions described in the Nature Machine Intelligence editorial 'From embodied intelligence to physical AI', including Moravec's paradox, the role of embodiment in task performance, world model learning under data scarcity, and affordance-based perception-action coupling. Four distinct agent architectures—world-model, affordance-based, reactive, and physical AI—are simulated across 500 timesteps in a stochastic 2D physical environment, reproducing the key prediction that machines excel at abstract cognitive tasks but struggle with mundane sensorimotor tasks unless equipped with high embodiment coefficients. The simulator generates a rich CSV dataset capturing world model accuracy, affordance perception, task success rates, and sensorimotor error across five experimental scenarios spanning varying environmental uncertainty and data availability conditions. Researchers can use the synthetic data and publication-quality figures to study the quantitative trade-offs between different AI architectures for physical interaction tasks without requiring expensive real-world robot experiments.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    s42256-026-01239-3.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    agent_position, agent_velocity, world_model_accuracy, affordance_perception, task_success_rate, sensorimotor_error, cognitive_load, environment_uncertainty, embodiment_coefficient, data_availability, timestep

    SCENARIOS  (5 total)
    ---------------------------------
        1. cognitive_vs_sensorimotor — Compares all four agent architectures on a spectrum of tasks ranging from purely cognitive (abstract reasoning) to purely sensorimotor (door opening), illustrating Moravec's paradox where machine performance inverts relative to human intuition
2. high_environment_uncertainty — All agents operate in a highly stochastic environment (large noise sigma) representing real-world variation; shows how world-model and affordance agents degrade differently compared to physical AI when identical situations lead to different responses
3. data_scarce_physical_interaction — Simulates the data scarcity problem for physical interaction tasks by applying a strong data scarcity penalty; world-model agents suffer most while affordance-based and physical AI agents are less dependent on labeled data
4. embodiment_spectrum — Varies the embodiment coefficient continuously from 0 (pure software) to 1 (full physical AI) for a single agent on sensorimotor tasks; maps how task success rate and sensorimotor error change as intelligence is increasingly realized in materials and morphology
5. world_model_learning_dynamics — Tracks world model accuracy over time for the world-model agent as it updates its internal predictive model; shows convergence behavior under low vs high environmental uncertainty, inspired by Craik's 1943 small-scale model concept

    PARAMETERS
    ----------
    17 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7

    DOMAIN SUMMARY
    --------------
    This editorial surveys the convergence of world models, embodied intelligence, ecological psychology, and physical AI frameworks on the problem of enabling machines to act intelligently and robustly in the physical world, highlighting Moravec's paradox and the gap between digital AI capability and real-world sensorimotor performance.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.