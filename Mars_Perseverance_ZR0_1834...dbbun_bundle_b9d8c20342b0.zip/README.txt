================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : c6ae4012-2d89-4ac0-8ca5-ec283ddd1f4a
    Generated   : 2026-04-25  03:43:43 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Mars Perseverance Rover Mastcam-Z Surface Imaging: Jezero Crater Rock and Regolith Scene (Sol 1834)

    CATEGORIES
    ----------
    Astronomy, Geoscience and Remote Sensing, Signal Processing, Sensors, Climate Change/Environmental

    KEYWORDS
    --------
    Mars surface geology, Jezero Crater, Mastcam-Z imaging, aeolian sediment transport, planetary photometry

    ABSTRACT
    --------
    This simulator models the Martian surface scene captured by NASA Perseverance rover's Mastcam-Z camera at Sol 1834 in Jezero Crater, reproducing the spatial distribution of rocks, regolith, albedo contrast, shadow casting, and aeolian sediment transport on a 2D terrain grid. The simulation faithfully replicates the photometric and morphological phenomena visible in the raw image: light-toned sedimentary rocks with high reflectance (~0.48) partially embedded in lower-albedo reddish regolith (~0.24), sharp shadow zones at the observed solar elevation of ~42 degrees, and wind-driven sediment ripples consistent with Martian meteorological conditions. Six scenarios spanning different wind speeds, solar angles, and atmospheric dust opacities allow systematic exploration of how illumination geometry, dust storms, and aeolian erosion alter the observable scene over time. Researchers, planetary scientists, and educators can use the synthetic dataset and figures to calibrate image analysis pipelines, validate photometric models, and understand aeolian geomorphology on Mars without requiring access to the original raw data products.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Mars_Perseverance_ZR0_1834_0829756209_724EBY_N0874184ZCAM04354_1100LMJ.jpg

    SIMULATION BACKEND
    ------------------
    signal_field

    STATE VARIABLES
    ---------------
    elevation, regolith_depth, albedo, grain_size, shadow_mask, wind_flux, surface_roughness, rock_presence

    SCENARIOS  (6 total)
    ---------------------------------
        1. baseline_calm — Baseline scene with observed wind speed and solar angle matching image acquisition conditions. Reproduces the static snapshot geometry with minimal sediment transport.
2. dust_storm_high_opacity — High atmospheric dust loading (tau=3.0) simulating a regional dust storm, reducing surface irradiance and altering apparent albedo contrast between rocks and regolith.
3. low_solar_angle_dawn — Low solar elevation (15 degrees) simulating dawn or dusk illumination, dramatically extending rock shadows and enhancing topographic contrast.
4. high_solar_angle_noon — High solar elevation (75 degrees) simulating near-noon illumination, minimizing shadows and reducing topographic relief appearance.
5. strong_aeolian_transport — Enhanced wind speed well above saltation threshold, simulating active aeolian sediment redistribution over 100 sols, burying lower rock margins and forming larger drifts.
6. erosion_over_time — Multi-sol simulation tracking regolith depth change and rock exposure as a function of progressive aeolian erosion with moderate wind.

    PARAMETERS
    ----------
    23 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This image, captured by NASA's Perseverance rover Mastcam-Z camera on Sol 1834, shows Martian surface geology featuring light-toned sedimentary or igneous rocks partially buried in fine-grained reddish-orange regolith within Jezero Crater, providing data on rock morphology, surface texture, wind-driven sediment distribution, and photometric properties under Martian illumination.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.