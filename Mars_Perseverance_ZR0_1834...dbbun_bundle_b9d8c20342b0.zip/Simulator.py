# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-25T03:43:43.176291Z
# Run ID    : c6ae4012-2d89-4ac0-8ca5-ec283ddd1f4a
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Mars Perseverance Rover Mastcam-Z Surface Imaging: Jezero Crater Rock and Regolith Scene (Sol 1834)

Simulator for Martian surface geology featuring light-toned sedimentary/igneous rocks
partially buried in fine-grained reddish-orange regolith within Jezero Crater.
Models rock geometry, albedo contrast, shadow casting, and aeolian sediment transport
across a 2D terrain grid under six illumination and wind scenarios.
"""

import argparse
import csv
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "title": "Mars Perseverance Rover Mastcam-Z Surface Imaging: Jezero Crater Rock and Regolith Scene (Sol 1834)",
    "parameters": {
        "solar_elevation_angle": {"value": 42.0, "unit": "degrees", "source": "extracted",
                                   "description": "Estimated solar elevation angle inferred from shadow length"},
        "solar_azimuth_angle":   {"value": 195.0, "unit": "degrees", "source": "assumed",
                                   "description": "Estimated solar azimuth from north"},
        "mars_gravity":          {"value": 3.72,  "unit": "m/s2",    "source": "extracted",
                                   "description": "Martian gravitational acceleration"},
        "atmospheric_opacity_tau":{"value": 0.55, "unit": "a.u.",    "source": "assumed",
                                   "description": "Mars atmospheric dust optical depth"},
        "rock_albedo_light":     {"value": 0.48,  "unit": "a.u.",    "source": "extracted",
                                   "description": "Albedo of light-toned rocks"},
        "rock_albedo_dark":      {"value": 0.12,  "unit": "a.u.",    "source": "extracted",
                                   "description": "Albedo of darker rock faces"},
        "regolith_albedo":       {"value": 0.24,  "unit": "a.u.",    "source": "extracted",
                                   "description": "Albedo of surrounding fine-grained regolith"},
        "wind_speed":            {"value": 5.5,   "unit": "m/s",     "source": "assumed",
                                   "description": "Typical near-surface wind speed in Jezero"},
        "wind_direction":        {"value": 270.0, "unit": "degrees", "source": "assumed",
                                   "description": "Dominant wind direction (westerly)"},
        "grid_resolution":       {"value": 0.01,  "unit": "m",       "source": "assumed",
                                   "description": "Spatial resolution of simulation grid cells"},
        "grid_size_x":           {"value": 300,   "unit": "cells",   "source": "assumed",
                                   "description": "Number of grid cells in x direction"},
        "grid_size_y":           {"value": 220,   "unit": "cells",   "source": "assumed",
                                   "description": "Number of grid cells in y direction"},
        "rock1_major_axis":      {"value": 0.65,  "unit": "m",       "source": "extracted",
                                   "description": "Major axis length of largest light-toned rock"},
        "rock1_minor_axis":      {"value": 0.35,  "unit": "m",       "source": "extracted",
                                   "description": "Minor axis length of largest rock"},
        "rock1_height":          {"value": 0.22,  "unit": "m",       "source": "extracted",
                                   "description": "Height of largest rock above surrounding regolith"},
        "rock2_major_axis":      {"value": 0.50,  "unit": "m",       "source": "extracted",
                                   "description": "Major axis of secondary rock cluster"},
        "rock2_height":          {"value": 0.18,  "unit": "m",       "source": "extracted",
                                   "description": "Height of right rock cluster"},
        "sediment_ripple_wavelength": {"value": 0.08, "unit": "m",   "source": "extracted",
                                   "description": "Wavelength of visible sediment ripple patterns"},
        "mars_sol_duration":     {"value": 88775.0,"unit": "s",      "source": "extracted",
                                   "description": "Duration of one Martian sol in seconds"},
        "mastcamz_focal_length": {"value": 26.0,  "unit": "mm",      "source": "extracted",
                                   "description": "Estimated Mastcam-Z focal length"},
        "simulation_duration_sols":{"value": 100.0,"unit": "sols",   "source": "assumed",
                                   "description": "Number of Martian sols simulated"},
        "threshold_wind_speed":  {"value": 4.2,   "unit": "m/s",     "source": "assumed",
                                   "description": "Threshold wind speed for saltation initiation"},
        "air_density_mars":      {"value": 0.02,  "unit": "kg/m3",   "source": "extracted",
                                   "description": "Near-surface atmospheric density on Mars"},
    },
    "scenarios": [
        {"label": "baseline_calm",        "param_overrides": {"wind_speed": 5.5,  "solar_elevation_angle": 42.0, "atmospheric_opacity_tau": 0.55}},
        {"label": "dust_storm_high_opacity","param_overrides": {"wind_speed": 18.0,"solar_elevation_angle": 42.0, "atmospheric_opacity_tau": 3.0}},
        {"label": "low_solar_angle_dawn", "param_overrides": {"wind_speed": 3.0,  "solar_elevation_angle": 15.0, "atmospheric_opacity_tau": 0.55}},
        {"label": "high_solar_angle_noon","param_overrides": {"wind_speed": 6.0,  "solar_elevation_angle": 75.0, "atmospheric_opacity_tau": 0.55}},
        {"label": "strong_aeolian_transport","param_overrides": {"wind_speed": 12.0,"solar_elevation_angle": 42.0,"atmospheric_opacity_tau": 0.8}},
        {"label": "erosion_over_time",    "param_overrides": {"wind_speed": 7.5,  "solar_elevation_angle": 42.0, "atmospheric_opacity_tau": 0.6, "simulation_duration_sols": 500.0}},
    ],
}

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────
NX       = int(MODEL_PROFILE["parameters"]["grid_size_x"]["value"])
NY       = int(MODEL_PROFILE["parameters"]["grid_size_y"]["value"])
DX       = MODEL_PROFILE["parameters"]["grid_resolution"]["value"]
S0_MARS  = 586.0          # W/m² top-of-atmosphere at Mars
RHO_GRAIN= 2500.0         # kg/m³ silicate grain density
BULK_DENSITY = 1500.0     # kg/m³ Martian regolith bulk density

SAMPLE_STRIDE = 10        # record every 10th sol

# ─────────────────────────────────────────────────────────────────────────────
# GRID HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def make_grid():
    """Return meshgrid X, Y in metres."""
    x_arr = np.linspace(0.0, NX * DX, NX, endpoint=False)
    y_arr = np.linspace(0.0, NY * DX, NY, endpoint=False)
    X, Y  = np.meshgrid(x_arr, y_arr)
    return X, Y

X_GLOBAL, Y_GLOBAL = make_grid()

def init_state(rng: np.random.Generator, params: Dict) -> Dict:
    """Initialise all state arrays for a fresh scenario run."""
    regolith_albedo = params["regolith_albedo"]

    elevation        = np.clip(np.random.normal(0.0, 0.003, (NY, NX)), -0.1, 0.6)
    regolith_depth   = np.full((NY, NX), 0.05)
    albedo           = np.full((NY, NX), regolith_albedo)
    grain_size       = np.clip(np.random.lognormal(np.log(0.15), 0.4, (NY, NX)), 0.05, 2.0)
    surface_roughness= np.clip(np.random.uniform(0.003, 0.015, (NY, NX)), 0.001, 0.05)
    rock_presence    = np.zeros((NY, NX))
    shadow_mask      = np.zeros((NY, NX))
    wind_flux        = np.zeros((NY, NX))

    return dict(elevation=elevation, regolith_depth=regolith_depth, albedo=albedo,
                grain_size=grain_size, surface_roughness=surface_roughness,
                rock_presence=rock_presence, shadow_mask=shadow_mask, wind_flux=wind_flux)


# ─────────────────────────────────────────────────────────────────────────────
# ROCK PLACEMENT (vectorised ellipsoidal caps)
# ─────────────────────────────────────────────────────────────────────────────

def place_rock(state: Dict, params: Dict,
               cx: float, cy: float, a: float, b: float, h: float,
               angle_deg: float, rock_alb: float) -> None:
    """Place one ellipsoidal rock bump in-place."""
    regolith_albedo = params["regolith_albedo"]
    angle   = np.radians(angle_deg)
    cos_a   = np.cos(angle); sin_a = np.sin(angle)

    dx_ = X_GLOBAL - cx
    dy_ = Y_GLOBAL - cy
    xr  = dx_ * cos_a + dy_ * sin_a
    yr  = -dx_ * sin_a + dy_ * cos_a

    r2  = (xr / a) ** 2 + (yr / b) ** 2
    inside = r2 < 1.0

    r2_safe = np.where(inside, r2, 1.0)
    rock_h  = h * np.sqrt(np.maximum(0.0, 1.0 - r2_safe))

    face_angle = np.arctan2(rock_h, np.sqrt(xr**2 + yr**2) + 1e-6)
    frac       = np.clip(face_angle / (np.pi / 2.0), 0.0, 1.0) ** 0.3
    cell_alb   = rock_alb * frac + regolith_albedo * (1.0 - frac)

    state["elevation"]     = np.where(inside, state["elevation"] + rock_h, state["elevation"])
    state["albedo"]        = np.where(inside, cell_alb, state["albedo"])
    state["rock_presence"] = np.where(inside, 1.0, state["rock_presence"])


def place_all_rocks(state: Dict, params: Dict) -> None:
    rock_alb_mid = (params["rock_albedo_light"] + params["rock_albedo_dark"]) / 2.0
    # Rock 1
    place_rock(state, params,
               cx=1.2, cy=1.1,
               a=params["rock1_major_axis"] / 2.0,
               b=params["rock1_minor_axis"] / 2.0,
               h=params["rock1_height"],
               angle_deg=15.0,
               rock_alb=params["rock_albedo_light"])
    # Rock 2
    place_rock(state, params,
               cx=1.9, cy=1.0,
               a=params["rock2_major_axis"] / 2.0,
               b=0.25,
               h=params["rock2_height"],
               angle_deg=-10.0,
               rock_alb=rock_alb_mid)

    # Clip elevation after placement
    state["elevation"] = np.clip(state["elevation"], -0.1, 0.6)
    state["albedo"]    = np.clip(state["albedo"],    0.10, 0.55)


# ─────────────────────────────────────────────────────────────────────────────
# SHADOW MODEL (fast vectorised ray-march approximation)
# ─────────────────────────────────────────────────────────────────────────────

def compute_shadow_fast(elevation: np.ndarray, solar_elev_deg: float, solar_az_deg: float) -> np.ndarray:
    """
    Approximate shadow mask using column-by-column ray marching along the
    sun direction projected on the ground plane.  Much faster than per-cell loops.
    Returns shadow array in [0, 1].
    """
    elev_rad = np.radians(np.clip(solar_elev_deg, 1.0, 89.0))
    az_rad   = np.radians(solar_az_deg)

    # Ground-plane step per vertical unit
    horiz_per_vert = 1.0 / np.tan(elev_rad)  # m horizontal per m vertical

    # Sun direction in grid coords (direction FROM surface TOWARD sun)
    sun_gx = -np.cos(elev_rad) * np.sin(az_rad)   # x (col) component
    sun_gy = -np.cos(elev_rad) * np.cos(az_rad)   # y (row) component

    shadow = np.zeros((NY, NX), dtype=np.float32)

    # Number of marching steps: proportional to max rock height / tan(elev)
    max_h    = elevation.max() - elevation.min() + 0.01
    max_dist = max_h * horiz_per_vert  # max horizontal shadow length
    n_steps  = max(1, int(max_dist / DX) + 2)

    for step in range(1, n_steps + 1):
        offset_x = step * DX * (-sun_gx) / (np.sqrt(sun_gx**2 + sun_gy**2) + 1e-9) * np.cos(elev_rad)
        offset_y = step * DX * (-sun_gy) / (np.sqrt(sun_gx**2 + sun_gy**2) + 1e-9) * np.cos(elev_rad)
        dz       = step * DX * np.tan(elev_rad)

        # Source cell (the cell casting shadow)
        col_src = np.arange(NX)[np.newaxis, :] - int(round(offset_x / DX))
        row_src = np.arange(NY)[:, np.newaxis] - int(round(offset_y / DX))

        col_src = np.clip(col_src, 0, NX - 1)
        row_src = np.clip(row_src, 0, NY - 1)

        elev_source = elevation[row_src, col_src]
        in_shadow   = (elev_source - dz) > elevation   # source is higher than ray height at target

        shadow = np.maximum(shadow, in_shadow.astype(np.float32))

    return shadow


def compute_irradiance(elevation: np.ndarray, solar_elev_deg: float,
                       solar_az_deg: float, tau: float) -> Tuple:
    elev_rad = np.radians(np.clip(solar_elev_deg, 1.0, 89.0))
    sin_e    = np.sin(elev_rad)

    direct  = S0_MARS * np.exp(-tau / sin_e) * sin_e
    diffuse = S0_MARS * 0.3 * tau

    shadow  = compute_shadow_fast(elevation, solar_elev_deg, solar_az_deg)
    irrad   = (1.0 - shadow) * direct + diffuse
    return irrad, shadow, direct, diffuse


# ─────────────────────────────────────────────────────────────────────────────
# AEOLIAN TRANSPORT
# ─────────────────────────────────────────────────────────────────────────────

def compute_aeolian_flux(grain_size_mm: np.ndarray, wind_speed: float,
                          wind_dir_deg: float, rho_air: float = 0.02,
                          g: float = 3.72, sol_dur: float = 88775.0
                          ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    d          = grain_size_mm * 1e-3                          # m
    u_star_t   = 0.1 * np.sqrt((RHO_GRAIN - rho_air) * g * d / rho_air)
    u_star     = wind_speed * 0.05                             # scalar

    with np.errstate(divide='ignore', invalid='ignore'):
        ratio2 = np.where(u_star > u_star_t, (u_star_t / u_star) ** 2, 1.0)
    flux_ms    = np.where(u_star > u_star_t,
                          rho_air / g * u_star ** 3 * (1.0 - ratio2),
                          0.0)  # kg/m/s
    flux_sol   = np.clip(flux_ms * sol_dur, 0.0, 0.05)        # kg/m/sol, clamped

    wd_rad     = np.radians(wind_dir_deg)
    flux_x     = flux_sol * np.sin(wd_rad)
    flux_y     = flux_sol * np.cos(wd_rad)
    return flux_x, flux_y, flux_sol


# ─────────────────────────────────────────────────────────────────────────────
# SURFACE EVOLUTION
# ─────────────────────────────────────────────────────────────────────────────

def update_surface(regolith_depth: np.ndarray, elevation: np.ndarray,
                   flux_x: np.ndarray, flux_y: np.ndarray,
                   rock_presence: np.ndarray,
                   dt_sol: float = 1.0) -> Tuple[np.ndarray, np.ndarray]:
    dfx_dx      = np.gradient(flux_x, DX, axis=1)
    dfy_dy      = np.gradient(flux_y, DX, axis=0)
    divergence  = dfx_dx + dfy_dy  # positive = net removal

    depth_change = -divergence * dt_sol / BULK_DENSITY        # m per sol
    new_depth    = np.clip(regolith_depth + depth_change * (1.0 - rock_presence),
                           0.0, 0.3)
    elev_change  = (new_depth - regolith_depth) * (1.0 - rock_presence)
    new_elevation= np.clip(elevation + elev_change, -0.1, 0.6)
    return new_depth, new_elevation


# ─────────────────────────────────────────────────────────────────────────────
# RUN ONE SCENARIO
# ─────────────────────────────────────────────────────────────────────────────

def run_scenario(scenario_idx: int, scenario_cfg: Dict) -> Tuple[List[Dict], Dict]:
    """
    Runs one scenario.  Returns (rows_list, summary_dict).
    rows_list: one row dict per recorded sol×sampled_cells.
    """
    np.random.seed(scenario_idx)  # deterministic per scenario

    label  = scenario_cfg["label"]
    # Build params by merging defaults with overrides
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    params.update(scenario_cfg["param_overrides"])

    n_sols = int(params["simulation_duration_sols"])

    # Init state
    state = init_state(np.random.default_rng(scenario_idx), params)
    place_all_rocks(state, params)

    # Alias for convenience
    rock_presence    = state["rock_presence"]
    grain_size       = state["grain_size"]
    surface_roughness= state["surface_roughness"]

    rows: List[Dict] = []

    # Pre-compute irradiance/shadow (static per scenario; wind changes surface)
    irrad_full, shadow_full, direct_full, diffuse_full = compute_irradiance(
        state["elevation"], params["solar_elevation_angle"],
        params["solar_azimuth_angle"], params["atmospheric_opacity_tau"])

    mean_regolith_ts = []  # for fig3
    sol_ts           = []

    for sol in range(n_sols):
        # Update albedo
        albedo = np.where((state["regolith_depth"] < 0.005) & (rock_presence > 0),
                          params["rock_albedo_light"], state["albedo"])
        albedo = np.where(rock_presence == 0, params["regolith_albedo"], albedo)
        albedo = np.clip(albedo, 0.10, 0.55)
        state["albedo"] = albedo

        # Recompute shadow/irradiance every 20 sols (elevation changes slowly)
        if sol % 20 == 0:
            irrad_full, shadow_full, direct_full, diffuse_full = compute_irradiance(
                state["elevation"], params["solar_elevation_angle"],
                params["solar_azimuth_angle"], params["atmospheric_opacity_tau"])

        state["shadow_mask"] = shadow_full

        # Aeolian flux
        fx, fy, flux_mag = compute_aeolian_flux(
            grain_size, params["wind_speed"], params["wind_direction"],
            rho_air=params["air_density_mars"],
            g=params["mars_gravity"],
            sol_dur=params["mars_sol_duration"])
        state["wind_flux"] = np.clip(flux_mag, 0.0, 0.05)

        # Surface evolution
        state["regolith_depth"], state["elevation"] = update_surface(
            state["regolith_depth"], state["elevation"], fx, fy, rock_presence)

        # Aggregate metrics
        shadow_frac     = float(np.mean(state["shadow_mask"]))
        mean_reg_depth  = float(np.mean(state["regolith_depth"]))
        total_flux      = float(np.sum(state["wind_flux"]) * DX * DX)
        diff_frac       = float(diffuse_full / (direct_full + diffuse_full + 1e-9))

        mean_regolith_ts.append(mean_reg_depth)
        sol_ts.append(sol)

        # Record every SAMPLE_STRIDE sols (subsample spatial grid to keep CSV manageable)
        if sol % SAMPLE_STRIDE == 0:
            step_x = max(1, NX // 30)
            step_y = max(1, NY // 30)
            for iy in range(0, NY, step_y):
                for ix in range(0, NX, step_x):
                    rows.append({
                        "scenario_label":        label,
                        "simulation_sol":        sol,
                        "cell_x_index":          ix,
                        "cell_y_index":          iy,
                        "x_position_m":          round(float(X_GLOBAL[iy, ix]), 4),
                        "y_position_m":          round(float(Y_GLOBAL[iy, ix]), 4),
                        "elevation_m":           round(float(np.clip(state["elevation"][iy, ix], -0.1, 0.6)), 5),
                        "regolith_depth_m":      round(float(np.clip(state["regolith_depth"][iy, ix], 0.0, 0.3)), 5),
                        "albedo":                round(float(np.clip(state["albedo"][iy, ix], 0.10, 0.55)), 4),
                        "shadow_mask":           round(float(np.clip(state["shadow_mask"][iy, ix], 0.0, 1.0)), 3),
                        "grain_size_mm":         round(float(np.clip(grain_size[iy, ix], 0.05, 2.0)), 4),
                        "wind_flux_kg_per_m2_per_sol": round(float(np.clip(state["wind_flux"][iy, ix], 0.0, 0.05)), 6),
                        "surface_roughness_m":   round(float(np.clip(surface_roughness[iy, ix], 0.001, 0.05)), 5),
                        "rock_presence":         round(float(rock_presence[iy, ix]), 2),
                        "solar_elevation_angle_deg": params["solar_elevation_angle"],
                        "solar_azimuth_deg":     params["solar_azimuth_angle"],
                        "atmospheric_opacity_tau": params["atmospheric_opacity_tau"],
                        "wind_speed_m_per_s":    params["wind_speed"],
                        "wind_direction_deg":    params["wind_direction"],
                        "irradiance_W_per_m2":   round(float(irrad_full[iy, ix]), 3),
                        "diffuse_fraction":      round(diff_frac, 4),
                        "shadow_fraction_scene": round(shadow_frac, 4),
                        "mean_regolith_depth_scene_m": round(mean_reg_depth, 5),
                        "total_flux_kg_per_sol": round(total_flux, 6),
                    })

    # Build summary
    elev_flat   = state["elevation"].ravel()
    reg_flat    = state["regolith_depth"].ravel()
    alb_flat    = state["albedo"].ravel()
    flux_flat   = state["wind_flux"].ravel()

    summary = {
        "scenario":               label,
        "wind_speed":             params["wind_speed"],
        "solar_elevation_angle":  params["solar_elevation_angle"],
        "atmospheric_opacity_tau":params["atmospheric_opacity_tau"],
        "simulation_duration_sols": n_sols,
        "elevation_mean":         float(np.mean(elev_flat)),
        "elevation_std":          float(np.std(elev_flat)),
        "elevation_min":          float(np.min(elev_flat)),
        "elevation_max":          float(np.max(elev_flat)),
        "regolith_depth_mean":    float(np.mean(reg_flat)),
        "regolith_depth_std":     float(np.std(reg_flat)),
        "regolith_depth_min":     float(np.min(reg_flat)),
        "regolith_depth_max":     float(np.max(reg_flat)),
        "albedo_mean":            float(np.mean(alb_flat)),
        "albedo_std":             float(np.std(alb_flat)),
        "albedo_min":             float(np.min(alb_flat)),
        "albedo_max":             float(np.max(alb_flat)),
        "wind_flux_mean":         float(np.mean(flux_flat)),
        "wind_flux_std":          float(np.std(flux_flat)),
        "wind_flux_min":          float(np.min(flux_flat)),
        "wind_flux_max":          float(np.max(flux_flat)),
        "shadow_fraction_final":  float(np.mean(state["shadow_mask"])),
        "rock_fraction":          float(np.mean(rock_presence)),
        "total_flux_final_kg_per_sol": float(np.sum(state["wind_flux"]) * DX * DX),
        "mean_regolith_ts":       mean_regolith_ts,
        "sol_ts":                 sol_ts,
        "final_elevation":        state["elevation"].copy(),
        "final_albedo":           state["albedo"].copy(),
        "final_shadow":           state["shadow_mask"].copy(),
        "final_wind_flux":        state["wind_flux"].copy(),
        "final_flux_x":           np.gradient(state["wind_flux"], DX, axis=1),  # recompute from final
        "final_flux_y":           np.gradient(state["wind_flux"], DX, axis=0),
        "rock_presence":          rock_presence.copy(),
        "grain_size":             grain_size.copy(),
    }
    return rows, summary


# ─────────────────────────────────────────────────────────────────────────────
# CSV WRITERS
# ─────────────────────────────────────────────────────────────────────────────

SCHEMA_COLS = [
    "scenario_label", "simulation_sol", "cell_x_index", "cell_y_index",
    "x_position_m", "y_position_m", "elevation_m", "regolith_depth_m",
    "albedo", "shadow_mask", "grain_size_mm", "wind_flux_kg_per_m2_per_sol",
    "surface_roughness_m", "rock_presence", "solar_elevation_angle_deg",
    "solar_azimuth_deg", "atmospheric_opacity_tau", "wind_speed_m_per_s",
    "wind_direction_deg", "irradiance_W_per_m2", "diffuse_fraction",
    "shadow_fraction_scene", "mean_regolith_depth_scene_m", "total_flux_kg_per_sol",
]


def write_simulation_outputs(all_rows: List[Dict], out_dir: Path) -> None:
    if not all_rows:
        print("WARNING: no simulation output rows to write.")
        return
    fpath = out_dir / "simulation_outputs.csv"
    with open(fpath, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=SCHEMA_COLS)
        w.writeheader()
        w.writerows(all_rows)
    print(f"  Saved {fpath} ({len(all_rows)} rows)")


def write_scenario_summary(summaries: List[Dict], out_dir: Path) -> None:
    if not summaries:
        print("WARNING: no scenario summaries to write.")
        return
    cols = [k for k in summaries[0].keys()
            if not isinstance(summaries[0][k], (list, np.ndarray))]
    fpath = out_dir / "scenario_summary.csv"
    with open(fpath, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for s in summaries:
            w.writerow({k: s[k] for k in cols})
    print(f"  Saved {fpath} ({len(summaries)} rows)")


def write_parameters_used(out_dir: Path) -> None:
    fpath = out_dir / "parameters_used.csv"
    with open(fpath, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["name", "value", "unit", "source", "description"])
        for name, meta in MODEL_PROFILE["parameters"].items():
            w.writerow([name, meta["value"], meta["unit"],
                        meta["source"], meta["description"]])
    print(f"  Saved {fpath}")


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE GENERATION
# ─────────────────────────────────────────────────────────────────────────────

SCENARIO_COLORS = [
    "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"
]


def fig1_elevation_map(summaries: List[Dict], out_dir: Path) -> None:
    try:
        s = summaries[0]  # baseline
        elev = s["final_elevation"]
        assert elev.size > 0
        fig, ax = plt.subplots(figsize=(9, 7))
        im = ax.imshow(elev, origin="lower", extent=[0, NX * DX, 0, NY * DX],
                       cmap="terrain", vmin=-0.1, vmax=0.6)
        cb = fig.colorbar(im, ax=ax, label="Elevation (m)")
        ax.set_xlabel("x position (m)")
        ax.set_ylabel("y position (m)")
        ax.set_title("Simulated Mars Surface Elevation Map with Rock Placement\n"
                     "(Jezero Crater Scene – baseline_calm scenario)")
        ax.contour(np.linspace(0, NX * DX, NX), np.linspace(0, NY * DX, NY),
                   elev, levels=8, colors="k", linewidths=0.3, alpha=0.4)
        plt.tight_layout()
        fpath = out_dir / "fig1_elevation_map.png"
        fig.savefig(fpath, dpi=120)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig1 failed: {e}")


def fig2_albedo_map(summaries: List[Dict], out_dir: Path) -> None:
    try:
        n = len(summaries)
        ncols = 3; nrows = (n + ncols - 1) // ncols
        fig, axes = plt.subplots(nrows, ncols, figsize=(15, 5 * nrows))
        axes_flat = axes.ravel() if hasattr(axes, "ravel") else [axes]
        for idx, s in enumerate(summaries):
            ax = axes_flat[idx]
            # Combined apparent albedo: albedo * (1 - 0.7 * shadow)
            apparent = s["final_albedo"] * (1.0 - 0.7 * s["final_shadow"])
            apparent = np.clip(apparent, 0.05, 0.55)
            assert apparent.size > 0
            im = ax.imshow(apparent, origin="lower",
                           extent=[0, NX * DX, 0, NY * DX],
                           cmap="hot", vmin=0.05, vmax=0.55)
            fig.colorbar(im, ax=ax, label="Apparent albedo")
            ax.set_title(s["scenario"], fontsize=9)
            ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
        for idx in range(n, len(axes_flat)):
            axes_flat[idx].set_visible(False)
        fig.suptitle("Simulated Surface Albedo Map Including Shadow Mask (All Scenarios)",
                     fontsize=12)
        plt.tight_layout()
        fpath = out_dir / "fig2_albedo_map.png"
        fig.savefig(fpath, dpi=100)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig2 failed: {e}")


def fig3_regolith_depth_timeseries(summaries: List[Dict], out_dir: Path) -> None:
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        for idx, s in enumerate(summaries):
            sol_ts = np.array(s["sol_ts"])
            dep_ts = np.array(s["mean_regolith_ts"])
            assert len(sol_ts) == len(dep_ts), "length mismatch"
            if len(sol_ts) == 0:
                continue
            ax.plot(sol_ts, dep_ts, color=SCENARIO_COLORS[idx], label=s["scenario"], lw=2)
        ax.set_xlabel("Simulation Sol")
        ax.set_ylabel("Mean Regolith Depth (m)")
        ax.set_title("Regolith Depth Evolution Over Martian Sols Under Different Wind Scenarios")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig3_regolith_depth_timeseries.png"
        fig.savefig(fpath, dpi=120)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig3 failed: {e}")


def _compute_shadow_fraction(elevation: np.ndarray, solar_elev: float,
                              solar_az: float) -> float:
    """Compute scene-wide shadow fraction for a given solar elevation."""
    shadow = compute_shadow_fast(elevation, solar_elev, solar_az)
    return float(np.mean(shadow))


def fig4_shadow_vs_solar_angle(summaries: List[Dict], out_dir: Path) -> None:
    try:
        elev_ref   = summaries[0]["final_elevation"]
        solar_az   = MODEL_PROFILE["parameters"]["solar_azimuth_angle"]["value"]
        tau_vals   = [0.55, 1.5, 3.0]
        sol_angles = np.linspace(5.0, 85.0, 17)

        fig, ax = plt.subplots(figsize=(9, 6))
        for tau in tau_vals:
            fracs = np.zeros(len(sol_angles))
            for k, sa in enumerate(sol_angles):
                raw_frac = _compute_shadow_fraction(elev_ref, sa, solar_az)
                # Diffuse light reduces effective shadow contrast
                sin_e    = np.sin(np.radians(np.clip(sa, 1.0, 89.0)))
                direct   = S0_MARS * np.exp(-tau / sin_e) * sin_e
                diffuse  = S0_MARS * 0.3 * tau
                fill_frac = diffuse / (direct + diffuse + 1e-9)
                fracs[k] = raw_frac * (1.0 - 0.5 * fill_frac)

            assert len(sol_angles) == len(fracs), "shape mismatch"
            ax.plot(sol_angles, fracs, marker="o", ms=4, label=f"tau={tau}")

        ax.set_xlabel("Solar Elevation Angle (deg)")
        ax.set_ylabel("Effective Shadow Fraction")
        ax.set_title("Shadow Coverage Fraction vs Solar Elevation Angle for Rock Scene")
        ax.legend()
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig4_shadow_vs_solar_angle.png"
        fig.savefig(fpath, dpi=120)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig4 failed: {e}")


def fig5_flux_vs_grain_size(summaries: List[Dict], out_dir: Path) -> None:
    try:
        grain_vals = np.linspace(0.05, 2.0, 200)
        wind_configs = [
            (5.5,  "baseline_calm",          SCENARIO_COLORS[0]),
            (18.0, "dust_storm",             SCENARIO_COLORS[1]),
            (3.0,  "low_solar_dawn",         SCENARIO_COLORS[2]),
            (6.0,  "high_solar_noon",        SCENARIO_COLORS[3]),
            (12.0, "strong_aeolian",         SCENARIO_COLORS[4]),
            (7.5,  "erosion_over_time",      SCENARIO_COLORS[5]),
        ]
        rho_air = MODEL_PROFILE["parameters"]["air_density_mars"]["value"]
        g       = MODEL_PROFILE["parameters"]["mars_gravity"]["value"]
        sol_dur = MODEL_PROFILE["parameters"]["mars_sol_duration"]["value"]

        fig, ax = plt.subplots(figsize=(9, 6))
        for ws, label, col in wind_configs:
            d        = grain_vals * 1e-3
            u_star_t = 0.1 * np.sqrt((RHO_GRAIN - rho_air) * g * d / rho_air)
            u_star   = ws * 0.05
            with np.errstate(divide='ignore', invalid='ignore'):
                ratio2 = np.where(u_star > u_star_t, (u_star_t / u_star) ** 2, 1.0)
            flux_ms  = np.where(u_star > u_star_t,
                                rho_air / g * u_star**3 * (1.0 - ratio2), 0.0)
            flux_sol = np.clip(flux_ms * sol_dur, 0.0, 0.05)

            assert len(grain_vals) == len(flux_sol), "shape mismatch"
            ax.scatter(grain_vals[::4], flux_sol[::4], color=col, s=15,
                       alpha=0.7, label=f"{label} ({ws} m/s)")

        ax.set_xlabel("Grain Size (mm)")
        ax.set_ylabel("Aeolian Flux (kg/m²/sol)")
        ax.set_title("Aeolian Transport Flux vs Grain Size for Martian Regolith")
        ax.legend(fontsize=7)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig5_flux_vs_grain_size.png"
        fig.savefig(fpath, dpi=120)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig5 failed: {e}")


def fig6_flux_field(summaries: List[Dict], out_dir: Path) -> None:
    try:
        # Use strong_aeolian_transport scenario
        s = next((x for x in summaries if "strong" in x["scenario"]), summaries[0])
        flux   = s["final_wind_flux"]
        assert flux.size > 0

        # Recompute directional flux for arrows
        params_local = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
        params_local.update(next(sc for sc in MODEL_PROFILE["scenarios"]
                                  if "strong" in sc["label"])["param_overrides"])
        gs  = s["grain_size"]
        fx, fy, _ = compute_aeolian_flux(
            gs, params_local["wind_speed"], params_local["wind_direction"],
            rho_air=params_local["air_density_mars"],
            g=params_local["mars_gravity"],
            sol_dur=params_local["mars_sol_duration"])

        fig, ax = plt.subplots(figsize=(10, 7))
        im = ax.imshow(flux, origin="lower", extent=[0, NX * DX, 0, NY * DX],
                       cmap="YlOrRd", vmin=0.0, vmax=flux.max() + 1e-9)
        fig.colorbar(im, ax=ax, label="Wind flux (kg/m²/sol)")

        # Quiver subsample
        step = 15
        xq   = X_GLOBAL[::step, ::step]
        yq   = Y_GLOBAL[::step, ::step]
        fxq  = fx[::step, ::step]
        fyq  = fy[::step, ::step]
        mag  = np.sqrt(fxq**2 + fyq**2) + 1e-12
        ax.quiver(xq, yq, fxq / mag, fyq / mag, color="white", scale=30,
                  width=0.003, alpha=0.6)

        ax.contour(np.linspace(0, NX * DX, NX), np.linspace(0, NY * DX, NY),
                   s["rock_presence"], levels=[0.5], colors="blue", linewidths=1.5)
        ax.set_xlabel("x (m)"); ax.set_ylabel("y (m)")
        ax.set_title("Sediment Flux Field and Rock Wake Patterns\n(strong_aeolian_transport scenario)")
        plt.tight_layout()
        fpath = out_dir / "fig6_flux_field.png"
        fig.savefig(fpath, dpi=120)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig6 failed: {e}")


def fig7_radial_albedo_profile(summaries: List[Dict], out_dir: Path) -> None:
    try:
        s     = summaries[0]  # baseline
        albedo= s["final_albedo"]
        assert albedo.size > 0

        rock_cx_m, rock_cy_m = 1.2, 1.1
        rock_cx_px = int(round(rock_cx_m / DX))
        rock_cy_px = int(round(rock_cy_m / DX))

        directions = {"N": (0, 1), "S": (0, -1), "E": (1, 0), "W": (-1, 0)}
        max_r_cells = 120

        fig, ax = plt.subplots(figsize=(9, 6))
        for label, (dx_dir, dy_dir) in directions.items():
            dist_arr = np.zeros(max_r_cells)
            alb_arr  = np.zeros(max_r_cells)
            for step in range(max_r_cells):
                px = rock_cx_px + dx_dir * step
                py = rock_cy_px + dy_dir * step
                px = np.clip(px, 0, NX - 1)
                py = np.clip(py, 0, NY - 1)
                dist_arr[step] = step * DX
                alb_arr[step]  = float(np.clip(albedo[py, px], 0.10, 0.55))
            assert len(dist_arr) == len(alb_arr), "shape mismatch"
            ax.plot(dist_arr, alb_arr, label=f"Transect {label}", lw=2)

        ax.axhline(MODEL_PROFILE["parameters"]["regolith_albedo"]["value"],
                   ls="--", color="gray", alpha=0.5, label="Regolith albedo")
        ax.axhline(MODEL_PROFILE["parameters"]["rock_albedo_light"]["value"],
                   ls=":", color="tan", alpha=0.7, label="Rock albedo (light)")
        ax.set_xlabel("Distance from rock center (m)")
        ax.set_ylabel("Albedo")
        ax.set_title("Radial Albedo Profile Transects Across Rock and Regolith")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig7_radial_albedo_profile.png"
        fig.savefig(fpath, dpi=120)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig7 failed: {e}")


def fig8_albedo_histogram(summaries: List[Dict], out_dir: Path) -> None:
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        bins = np.linspace(0.05, 0.58, 54)
        for idx, s in enumerate(summaries):
            vals = s["final_albedo"].ravel()
            assert len(vals) > 0
            ax.hist(vals, bins=bins, alpha=0.45, color=SCENARIO_COLORS[idx],
                    label=s["scenario"], density=False)

        ax.axvline(MODEL_PROFILE["parameters"]["rock_albedo_light"]["value"],
                   color="gold", ls="--", lw=1.5, label="Light rock albedo")
        ax.axvline(MODEL_PROFILE["parameters"]["regolith_albedo"]["value"],
                   color="brown", ls="--", lw=1.5, label="Regolith albedo")
        ax.axvline(MODEL_PROFILE["parameters"]["rock_albedo_dark"]["value"],
                   color="gray", ls="--", lw=1.5, label="Dark rock albedo")
        ax.set_xlabel("Albedo")
        ax.set_ylabel("Frequency Count")
        ax.set_title("Albedo Distribution Histogram of Simulated Scene by Surface Type\n"
                     "(all scenarios overlaid)")
        ax.legend(fontsize=7, ncol=2)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fpath = out_dir / "fig8_albedo_histogram.png"
        fig.savefig(fpath, dpi=120)
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"WARNING fig8 failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY JSON
# ─────────────────────────────────────────────────────────────────────────────

def write_summary_json(summaries: List[Dict], out_dir: Path) -> None:
    out = {}
    for s in summaries:
        out[s["scenario"]] = {
            k: v for k, v in s.items()
            if not isinstance(v, (list, np.ndarray)) and k not in ("sol_ts", "mean_regolith_ts")
        }
    fpath = out_dir / "summary.json"
    with open(fpath, "w") as f:
        json.dump(out, f, indent=2, default=str)
    print(f"  Saved {fpath}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Mars Jezero Crater Surface Simulator (Mastcam-Z Sol 1834)")
    parser.add_argument("--output", default="./sim_outputs",
                        help="Output directory for all figures, CSVs, and JSON")
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    scenarios = MODEL_PROFILE["scenarios"]
    all_rows: List[Dict]  = []
    summaries: List[Dict] = []

    for idx, sc in enumerate(scenarios):
        print(f"\n[Scenario {idx+1}/{len(scenarios)}] {sc['label']}")
        rows, summary = run_scenario(idx, sc)
        all_rows.extend(rows)
        summaries.append(summary)
        print(f"  Recorded {len(rows)} data rows; final mean regolith depth = "
              f"{summary['regolith_depth_mean']:.4f} m")

    print("\n--- Writing CSV files ---")
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(summaries, out_dir)
    write_parameters_used(out_dir)

    print("\n--- Writing summary JSON ---")
    write_summary_json(summaries, out_dir)

    print("\n--- Generating figures ---")
    fig1_elevation_map(summaries, out_dir)
    fig2_albedo_map(summaries, out_dir)
    fig3_regolith_depth_timeseries(summaries, out_dir)
    fig4_shadow_vs_solar_angle(summaries, out_dir)
    fig5_flux_vs_grain_size(summaries, out_dir)
    fig6_flux_field(summaries, out_dir)
    fig7_radial_albedo_profile(summaries, out_dir)
    fig8_albedo_histogram(summaries, out_dir)

    print("\nSimulation complete.")


if __name__ == "__main__":
    main()