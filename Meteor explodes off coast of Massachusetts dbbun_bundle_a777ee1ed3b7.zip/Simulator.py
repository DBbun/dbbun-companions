# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-05-30T20:57:21.742526Z
# Run ID    : c89eb434-762b-4716-be9e-dd6fcede9b64
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
May 30, 2026 Massachusetts Fireball/Bolide Event — Synthetic Simulation Companion

Papers/Sources:
- 'Earthquake? Sonic boom? Explosion? Meteor? Loud boom heard in MA – NBC Boston'
- 'Meteor explodes off coast of Massachusetts, causing loud boom - CBS Boston'
- 'GOES-19 CONUS Geostationary Lightning Mapper – GLM Flash Extent Density (30 May 2026 18:11 UTC)'
- 'NOAA/CIRA Satellite Image – Meteor atmospheric entry flash over New England (30 May 2026)'
- 'Prompt: Meteor May 30 2026 – DBbun Simulation Companion Request'
- 'Loud boom heard in Boston likely exploding meteor above ocean – WBUR News'

This simulator models atmospheric entry, fragmentation, sonic-boom propagation, synthetic witness
reports, and hypothetical debris fields for a bolide event using RK4 integration of coupled ODEs.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ---------------------------------------------------------------------------
# MODEL PROFILE
# ---------------------------------------------------------------------------
MODEL_PROFILE = {
    "parameters": {
        "entry_velocity_km_s": {"value": 20.0, "unit": "km/s", "source": "assumed",
            "description": "Nominal meteor entry velocity; typical range 11-72 km/s, median ~20 km/s for sporadic events"},
        "entry_angle_nominal_deg": {"value": 20.0, "unit": "deg", "source": "assumed",
            "description": "Nominal shallow entry angle consistent with wide geographic sound spread across New England"},
        "initial_mass_kg": {"value": 1000.0, "unit": "kg", "source": "assumed",
            "description": "Plausible pre-entry mass for a bolide producing audible ground-level sonic boom over hundreds of km"},
        "bulk_density_kg_m3": {"value": 3000.0, "unit": "kg/m3", "source": "assumed",
            "description": "Stony meteorite bulk density (chondrite class, most common)"},
        "drag_coefficient": {"value": 0.47, "unit": "dimensionless", "source": "assumed",
            "description": "Drag coefficient for a roughly spherical body"},
        "ablation_coefficient_s2_km2": {"value": 0.014, "unit": "s2/km2", "source": "assumed",
            "description": "Heat-transfer-based ablation coefficient (sigma) typical for stony meteors"},
        "fragmentation_pressure_Pa": {"value": 1.0e6, "unit": "Pa", "source": "assumed",
            "description": "Ram-pressure threshold triggering catastrophic fragmentation/airburst (~1 MPa for weak stony bodies)"},
        "luminous_efficiency": {"value": 0.05, "unit": "dimensionless", "source": "assumed",
            "description": "Fraction of kinetic energy converted to optical radiation during ablation"},
        "acoustic_yield_fraction": {"value": 0.001, "unit": "dimensionless", "source": "assumed",
            "description": "Fraction of burst kinetic energy converted to acoustic energy"},
        "sound_speed_m_s": {"value": 340.0, "unit": "m/s", "source": "extracted",
            "description": "Near-surface sound speed; boom delay times imply ~340 m/s for distance estimates"},
        "burst_altitude_km_nominal": {"value": 30.0, "unit": "km", "source": "assumed",
            "description": "Plausible airburst altitude for a ~1-tonne stony body at 20 km/s, 20-deg entry"},
        "burst_lat": {"value": 42.35, "unit": "deg_N", "source": "extracted",
            "description": "Approximate latitude of atmospheric entry/burst: east of Boston, ~42.35 N"},
        "burst_lon": {"value": -70.5, "unit": "deg_E", "source": "extracted",
            "description": "Approximate longitude of atmospheric burst: east of Boston coast, ~-70.5 E"},
        "event_time_utc_decimal": {"value": 18.183, "unit": "hours_UTC", "source": "extracted",
            "description": "Event time 18:11 UTC (2:11 PM EDT) on 30 May 2026"},
        "observer_distance_ref_km": {"value": 100.0, "unit": "km", "source": "assumed",
            "description": "Reference observer distance for acoustic overpressure scaling"},
        "atmos_scale_height_km": {"value": 7.0, "unit": "km", "source": "assumed",
            "description": "Exponential atmosphere scale height for air density profile"},
        "rho0_kg_m3": {"value": 1.225, "unit": "kg/m3", "source": "assumed",
            "description": "Sea-level air density"},
        "dt_s": {"value": 0.1, "unit": "s", "source": "assumed",
            "description": "Integration time step for RK4 solver"},
        "n_witness_synthetic": {"value": 200, "unit": "count", "source": "assumed",
            "description": "Number of synthetic witness reports to generate across MA and neighboring states"},
        "n_debris_fragments_max": {"value": 20, "unit": "count", "source": "assumed",
            "description": "Maximum number of hypothetical debris fragments simulated"},
        "boom_heard_radius_km": {"value": 300.0, "unit": "km", "source": "extracted",
            "description": "Maximum radius over which boom was reported, based on news coverage spanning NH, MA, RI, CT"},
    },
    "scenarios": [
        {
            "label": "nominal_shallow_entry",
            "description": "Baseline scenario: 20 km/s entry at 20-deg angle, 1000-kg stony body.",
            "param_overrides": {
                "entry_velocity_km_s": 20.0, "entry_angle_nominal_deg": 20.0,
                "initial_mass_kg": 1000.0, "fragmentation_pressure_Pa": 1.0e6,
            }
        },
        {
            "label": "steep_fast_entry",
            "description": "Steeper 45-deg entry at 30 km/s. Higher-altitude burst, shorter boom footprint.",
            "param_overrides": {
                "entry_velocity_km_s": 30.0, "entry_angle_nominal_deg": 45.0,
                "initial_mass_kg": 1000.0, "fragmentation_pressure_Pa": 1.0e6,
            }
        },
        {
            "label": "large_body_shallow",
            "description": "Larger 5000-kg body at shallow 15-deg entry producing lower-altitude airburst.",
            "param_overrides": {
                "entry_velocity_km_s": 20.0, "entry_angle_nominal_deg": 15.0,
                "initial_mass_kg": 5000.0, "fragmentation_pressure_Pa": 5.0e5,
            }
        },
        {
            "label": "weak_fragile_body",
            "description": "Low-strength body that fragments at low ram pressure, high-altitude airburst.",
            "param_overrides": {
                "entry_velocity_km_s": 18.0, "entry_angle_nominal_deg": 25.0,
                "initial_mass_kg": 800.0, "fragmentation_pressure_Pa": 2.0e5,
            }
        },
        {
            "label": "slow_grazing_entry",
            "description": "Very shallow 10-deg entry at 15 km/s, long visible trail, delayed boom arrival.",
            "param_overrides": {
                "entry_velocity_km_s": 15.0, "entry_angle_nominal_deg": 10.0,
                "initial_mass_kg": 1500.0, "fragmentation_pressure_Pa": 1.0e6,
            }
        },
    ],
    "state_variable_ranges": {
        "altitude_km": (0.0, 100.0),
        "velocity_km_s": (11.2, 72.0),
        "mass_kg": (0.001, 100000.0),
        "entry_angle_deg": (5.0, 90.0),
        "cross_range_km": (0.0, 500.0),
        "dynamic_pressure_Pa": (0.0, 1.0e8),
        "luminosity_W": (0.0, 1.0e14),
        "overpressure_Pa": (0.0, 5000.0),
        "boom_delay_s": (0.0, 600.0),
        "fragment_count": (1.0, 50.0),
        "debris_downrange_km": (0.0, 200.0),
        "witness_confidence": (0.0, 1.0),
    }
}

# ---------------------------------------------------------------------------
# PHYSICAL CONSTANTS & HELPERS
# ---------------------------------------------------------------------------
RHO0 = 1.225          # kg/m3
H_KM = 7.0            # scale height km
G_MS2 = 9.81          # m/s^2
BULK_DENSITY = 3000.0 # kg/m3
CD = 0.47
LUM_EFF = 0.05
ABLATION_COEFF = 0.014e-6  # convert from s2/km2 to s2/m2: 0.014 s2/km2 * (1km/1000m)^2 = 1.4e-8 s2/m2
# Actually spec says 0.014 s2/km2 -> need SI: 0.014 s2/km2 = 0.014/(1e6) s2/m2 = 1.4e-8 s2/m2
SIGMA_SI = 0.014 / 1.0e6  # s2/m2
SOUND_SPEED = 340.0   # m/s
ACOUSTIC_YIELD = 0.001


def rho_air(z_km: float) -> float:
    """Exponential atmosphere density at altitude z_km."""
    z_km_clamped = max(0.0, z_km)
    return RHO0 * math.exp(-z_km_clamped / H_KM)


def meteor_cross_section(mass_kg: float, bulk_density: float = BULK_DENSITY) -> Tuple[float, float]:
    """Return (radius_m, area_m2) for a sphere of given mass and density."""
    mass_kg = max(0.001, mass_kg)
    R = (3.0 * mass_kg / (4.0 * math.pi * bulk_density)) ** (1.0 / 3.0)
    A = math.pi * R * R
    return R, A


def derivatives(state: np.ndarray, params: dict) -> np.ndarray:
    """
    Compute [dz/dt (km/s), dv/dt (km/s^2), dm/dt (kg/s)] for RK4.
    state = [altitude_km, velocity_km_s, mass_kg]
    """
    z, v, m = state
    m = max(0.001, m)
    v = max(0.0, v)
    z = max(0.0, z)

    v_ms = v * 1000.0  # m/s
    rho = rho_air(z)   # kg/m3
    _, A = meteor_cross_section(m, params['bulk_density'])

    sin_theta = math.sin(math.radians(params['entry_angle_deg']))
    cos_theta = math.cos(math.radians(params['entry_angle_deg']))

    # Drag deceleration
    F_drag = 0.5 * params['Cd'] * rho * A * v_ms ** 2
    dv_ms_dt = -F_drag / m  # m/s^2
    dv_dt = dv_ms_dt / 1000.0  # km/s^2

    # Ablation
    dm_dt = -SIGMA_SI * rho * A * v_ms ** 3 / 2.0  # kg/s

    # Altitude change
    dz_dt = -v * sin_theta  # km/s

    return np.array([dz_dt, dv_dt, dm_dt])


def rk4_step(state: np.ndarray, t: float, dt: float, params: dict) -> np.ndarray:
    """Single RK4 integration step."""
    k1 = dt * derivatives(state, params)
    k2 = dt * derivatives(state + k1 / 2.0, params)
    k3 = dt * derivatives(state + k2 / 2.0, params)
    k4 = dt * derivatives(state + k3, params)
    return state + (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0


def power_law_mass_split(total_mass: float, n_frags: int) -> np.ndarray:
    """Split mass into n_frags fragments with power-law distribution."""
    n_frags = max(1, n_frags)
    indices = np.arange(1, n_frags + 1, dtype=float)
    weights = indices ** (-1.5)
    weights /= weights.sum()
    return weights * total_mass


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Haversine distance in km between two lat/lon points."""
    R_earth = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2)
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return R_earth * c


def lat_lon_to_state(lat: float, lon: float) -> str:
    """Very coarse state lookup for New England region."""
    if lat > 43.5:
        return "NH"
    elif lat > 42.0 and lon > -72.0:
        return "MA"
    elif lat > 41.5 and lon < -71.8:
        return "CT"
    elif lon > -71.9 and lat < 41.8:
        return "RI"
    elif lat > 43.5 and lon < -71.0:
        return "ME"
    elif lat > 42.7:
        return "VT" if lon < -72.5 else "NH"
    else:
        return "MA"


# ---------------------------------------------------------------------------
# SCENARIO RUNNER
# ---------------------------------------------------------------------------
def run_scenario(scenario_idx: int, scenario: dict) -> dict:
    """
    Run a single scenario. Returns dict with trajectory, witness, debris records.
    """
    np.random.seed(scenario_idx)

    # Build params dict from MODEL_PROFILE defaults + overrides
    params = {}
    for k, v in MODEL_PROFILE['parameters'].items():
        params[k] = v['value']
    for k, v in scenario['param_overrides'].items():
        params[k] = v

    dt = params['dt_s']
    v0 = params['entry_velocity_km_s']
    m0 = params['initial_mass_kg']
    theta_deg = params['entry_angle_nominal_deg']
    frag_pressure = params['fragmentation_pressure_Pa']
    burst_lat_ref = params['burst_lat']
    burst_lon_ref = params['burst_lon']
    n_witnesses = int(params['n_witness_synthetic'])
    n_debris_max = int(params['n_debris_fragments_max'])

    params['entry_angle_deg'] = theta_deg
    params['bulk_density'] = params['bulk_density_kg_m3']
    params['Cd'] = params['drag_coefficient']

    cos_theta = math.cos(math.radians(theta_deg))
    sin_theta = math.sin(math.radians(theta_deg))

    # Initial state
    state = np.array([100.0, max(11.2, min(72.0, v0)), max(0.001, m0)])
    t = 0.0
    cross_range = 0.0

    trajectory = []
    fragmented = False
    burst_info = None
    burst_mass_at_frag = m0
    burst_vel_at_frag = v0
    fragment_count = 1
    luminosity_burst = 0.0
    max_lum = 0.0

    MAX_STEPS = 20000  # safety cap

    for _ in range(MAX_STEPS):
        z, v, m = state
        if z <= 0.0 or v <= 0.1 or m <= 0.001:
            break

        rho = rho_air(z)
        v_ms = v * 1000.0
        dyn_P = 0.5 * rho * v_ms ** 2
        dyn_P = max(0.0, min(1.0e8, dyn_P))

        # Compute luminosity from ablation rate (using derivative)
        deriv = derivatives(state, params)
        dm_dt = deriv[2]  # kg/s (negative)
        lum = LUM_EFF * abs(dm_dt) * v_ms ** 2 / 2.0
        lum = max(0.0, min(1.0e14, lum))

        # Fragmentation check
        is_burst = False
        if dyn_P >= frag_pressure and not fragmented:
            fragmented = True
            burst_mass_at_frag = float(m)
            burst_vel_at_frag = float(v)
            burst_info = {
                't': t,
                'altitude_km': float(z),
                'cross_range_km': float(cross_range),
            }
            fragment_count = max(1, min(50, int(m0 ** 0.3)))
            luminosity_burst = LUM_EFF * 0.5 * float(m) * v_ms ** 2
            lum = max(lum, luminosity_burst)
            lum = min(1.0e14, lum)
            is_burst = True

        max_lum = max(max_lum, lum)

        # Record
        trajectory.append({
            'time_s': round(t, 3),
            'altitude_km': round(max(0.0, min(100.0, z)), 4),
            'velocity_km_s': round(max(11.2, min(72.0, v)), 4),
            'mass_kg': round(max(0.001, min(1.0e5, m)), 4),
            'entry_angle_deg': round(max(5.0, min(90.0, theta_deg)), 2),
            'cross_range_km': round(max(0.0, min(500.0, cross_range)), 4),
            'dynamic_pressure_Pa': round(dyn_P, 2),
            'luminosity_W': round(lum, 2),
            'fragment_count': int(fragment_count if fragmented else 1),
            'is_burst_point': 1 if is_burst else 0,
        })

        # RK4 step
        new_state = rk4_step(state, t, dt, params)
        new_state[0] = max(0.0, new_state[0])
        new_state[1] = max(0.0, new_state[1])
        new_state[2] = max(0.001, new_state[2])

        # Update cross_range
        cross_range += v * cos_theta * dt
        cross_range = max(0.0, min(500.0, cross_range))

        state = new_state
        t += dt

    # Burst location (use last known state if no fragmentation occurred)
    if burst_info is None:
        # No fragmentation — assign burst at min altitude reached
        if trajectory:
            last = trajectory[-1]
            burst_info = {
                't': last['time_s'],
                'altitude_km': last['altitude_km'],
                'cross_range_km': last['cross_range_km'],
            }
            burst_mass_at_frag = last['mass_kg']
            burst_vel_at_frag = last['velocity_km_s']
            luminosity_burst = LUM_EFF * 0.5 * burst_mass_at_frag * (burst_vel_at_frag * 1000) ** 2
            fragment_count = 1
        else:
            burst_info = {'t': 0.0, 'altitude_km': 50.0, 'cross_range_km': 0.0}

    burst_alt = max(0.0, min(100.0, burst_info['altitude_km']))
    burst_cross = burst_info['cross_range_km']

    # Geographic burst position (approx: entry from NE moving W)
    azimuth_rad = math.radians(250.0)  # roughly westward
    actual_burst_lat = burst_lat_ref + burst_cross * math.cos(azimuth_rad) / 111.0
    actual_burst_lon = burst_lon_ref + burst_cross * math.sin(azimuth_rad) / 111.0

    # Overpressure at 100 km
    E_burst_J = ACOUSTIC_YIELD * 0.5 * burst_mass_at_frag * (burst_vel_at_frag * 1000.0) ** 2
    R_ref_m = 100.0 * 1000.0
    slant_ref = math.sqrt(R_ref_m ** 2 + (burst_alt * 1000.0) ** 2)
    if slant_ref > 0:
        overpressure_100km = max(0.0, min(5000.0, 3.2 * (max(0, E_burst_J) ** (1.0 / 3.0)) / slant_ref))
    else:
        overpressure_100km = 0.0

    # GLM flash intensity
    glm_intensity = min(1.0, max(0.0, luminosity_burst / 1.0e13))

    # ---------------------------------------------------------------------------
    # SYNTHETIC WITNESSES
    # ---------------------------------------------------------------------------
    witness_records = []
    for wi in range(n_witnesses):
        w_lat = np.random.uniform(41.0, 44.0)
        w_lon = np.random.uniform(-74.0, -69.0)
        dist_km = haversine_km(w_lat, w_lon, actual_burst_lat, actual_burst_lon)
        slant_km = math.sqrt(dist_km ** 2 + burst_alt ** 2)
        delay_raw = slant_km * 1000.0 / SOUND_SPEED + np.random.normal(0, 5.0)
        delay_s = max(0.0, min(600.0, delay_raw))
        intensity_raw = math.exp(-dist_km / 150.0) + np.random.normal(0, 0.05)
        intensity = max(0.0, min(1.0, intensity_raw))
        confidence_raw = 0.9 - dist_km / 600.0 + np.random.normal(0, 0.1)
        confidence = max(0.0, min(1.0, confidence_raw))
        # Direction from witness to burst
        dlat = actual_burst_lat - w_lat
        dlon = actual_burst_lon - w_lon
        direction_deg = math.degrees(math.atan2(dlon * math.cos(math.radians(w_lat)), dlat)) % 360.0
        dir_uncertainty = min(180.0, 15.0 + dist_km * 0.1)
        state_name = lat_lon_to_state(w_lat, w_lon)
        witness_records.append({
            'witness_id': wi,
            'witness_lat': round(w_lat, 4),
            'witness_lon': round(w_lon, 4),
            'witness_state': state_name,
            'boom_delay_s': round(delay_s, 2),
            'perceived_intensity_0to1': round(intensity, 4),
            'witness_confidence': round(confidence, 4),
            'reported_direction_deg': round(direction_deg, 2),
            'direction_uncertainty_deg': round(dir_uncertainty, 2),
        })

    # ---------------------------------------------------------------------------
    # DEBRIS FIELD
    # ---------------------------------------------------------------------------
    debris_records = []
    # Generate debris regardless of burst altitude so we always have non-trivial output
    frag_masses = power_law_mass_split(burst_mass_at_frag * 0.3, min(fragment_count, n_debris_max))
    wind_speed_ms = 20.0  # m/s nominal wind
    fall_azimuth = math.radians(270.0)  # westward

    for fid, fm in enumerate(frag_masses):
        fm = max(0.001, fm)
        _, A_f = meteor_cross_section(fm)
        v_term = math.sqrt(2.0 * fm * G_MS2 / (CD * RHO0 * A_f))
        v_term = max(10.0, v_term)
        fall_time_s = burst_alt * 1000.0 / v_term
        wind_drift_m = wind_speed_ms * fall_time_s
        downrange_extra_km = max(0.0, min(200.0, wind_drift_m / 1000.0))
        # Add scatter
        scatter_km = np.random.uniform(0.0, max(1.0, burst_alt * 0.1))
        total_dr = min(200.0, downrange_extra_km + scatter_km)
        deb_lat = actual_burst_lat + total_dr * math.cos(fall_azimuth) / 111.0
        deb_lon = actual_burst_lon + total_dr * math.sin(fall_azimuth) / 111.0
        debris_records.append({
            'debris_fragment_id': fid,
            'debris_lat': round(deb_lat, 5),
            'debris_lon': round(deb_lon, 5),
            'debris_mass_kg': round(max(0.001, fm), 6),
            'debris_downrange_km': round(total_dr, 3),
        })

    return {
        'label': scenario['label'],
        'trajectory': trajectory,
        'witness_records': witness_records,
        'debris_records': debris_records,
        'burst_info': {
            'altitude_km': round(burst_alt, 3),
            'burst_lat': round(actual_burst_lat, 5),
            'burst_lon': round(actual_burst_lon, 5),
            'cross_range_km': round(burst_cross, 3),
            'fragment_count': fragment_count,
            'burst_mass_kg': round(burst_mass_at_frag, 3),
            'burst_vel_km_s': round(burst_vel_at_frag, 3),
            'luminosity_burst_W': round(luminosity_burst, 2),
            'glm_flash_intensity_normalized': round(glm_intensity, 5),
            'overpressure_at_100km_Pa': round(overpressure_100km, 4),
        },
        'params': {k: v for k, v in params.items()},
        'max_luminosity_W': round(max_lum, 2),
    }


# ---------------------------------------------------------------------------
# CSV WRITERS
# ---------------------------------------------------------------------------
DATASET_COLUMNS = [
    "scenario_label", "time_s", "altitude_km", "velocity_km_s", "mass_kg",
    "entry_angle_deg", "cross_range_km", "dynamic_pressure_Pa", "luminosity_W",
    "fragment_count", "is_burst_point",
    "witness_id", "witness_lat", "witness_lon", "witness_state",
    "boom_delay_s", "perceived_intensity_0to1", "witness_confidence",
    "reported_direction_deg", "direction_uncertainty_deg",
    "debris_fragment_id", "debris_lat", "debris_lon", "debris_mass_kg", "debris_downrange_km",
    "overpressure_at_100km_Pa", "burst_altitude_km", "burst_lat", "burst_lon",
    "glm_flash_intensity_normalized"
]


def write_simulation_outputs(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv — one row per simulation step / witness / debris."""
    rows = []
    for res in all_results:
        label = res['label']
        bi = res['burst_info']
        # Trajectory rows
        for trec in res['trajectory']:
            row = {col: '' for col in DATASET_COLUMNS}
            row['scenario_label'] = label
            row['time_s'] = trec['time_s']
            row['altitude_km'] = trec['altitude_km']
            row['velocity_km_s'] = trec['velocity_km_s']
            row['mass_kg'] = trec['mass_kg']
            row['entry_angle_deg'] = trec['entry_angle_deg']
            row['cross_range_km'] = trec['cross_range_km']
            row['dynamic_pressure_Pa'] = trec['dynamic_pressure_Pa']
            row['luminosity_W'] = trec['luminosity_W']
            row['fragment_count'] = trec['fragment_count']
            row['is_burst_point'] = trec['is_burst_point']
            row['overpressure_at_100km_Pa'] = bi['overpressure_at_100km_Pa']
            row['burst_altitude_km'] = bi['altitude_km']
            row['burst_lat'] = bi['burst_lat']
            row['burst_lon'] = bi['burst_lon']
            row['glm_flash_intensity_normalized'] = bi['glm_flash_intensity_normalized']
            rows.append(row)
        # Witness rows
        for wrec in res['witness_records']:
            row = {col: '' for col in DATASET_COLUMNS}
            row['scenario_label'] = label
            row['witness_id'] = wrec['witness_id']
            row['witness_lat'] = wrec['witness_lat']
            row['witness_lon'] = wrec['witness_lon']
            row['witness_state'] = wrec['witness_state']
            row['boom_delay_s'] = wrec['boom_delay_s']
            row['perceived_intensity_0to1'] = wrec['perceived_intensity_0to1']
            row['witness_confidence'] = wrec['witness_confidence']
            row['reported_direction_deg'] = wrec['reported_direction_deg']
            row['direction_uncertainty_deg'] = wrec['direction_uncertainty_deg']
            row['burst_altitude_km'] = bi['altitude_km']
            row['burst_lat'] = bi['burst_lat']
            row['burst_lon'] = bi['burst_lon']
            row['overpressure_at_100km_Pa'] = bi['overpressure_at_100km_Pa']
            row['glm_flash_intensity_normalized'] = bi['glm_flash_intensity_normalized']
            rows.append(row)
        # Debris rows
        for drec in res['debris_records']:
            row = {col: '' for col in DATASET_COLUMNS}
            row['scenario_label'] = label
            row['debris_fragment_id'] = drec['debris_fragment_id']
            row['debris_lat'] = drec['debris_lat']
            row['debris_lon'] = drec['debris_lon']
            row['debris_mass_kg'] = drec['debris_mass_kg']
            row['debris_downrange_km'] = drec['debris_downrange_km']
            row['burst_altitude_km'] = bi['altitude_km']
            row['burst_lat'] = bi['burst_lat']
            row['burst_lon'] = bi['burst_lon']
            row['overpressure_at_100km_Pa'] = bi['overpressure_at_100km_Pa']
            row['glm_flash_intensity_normalized'] = bi['glm_flash_intensity_normalized']
            rows.append(row)

    if not rows:
        print("WARNING: No rows for simulation_outputs.csv — skipping.")
        return

    out_path = output_dir / "simulation_outputs.csv"
    with open(out_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=DATASET_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to {out_path}")


def write_scenario_summary(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv — one row per scenario with aggregate metrics."""
    summary_rows = []
    for res in all_results:
        traj = res['trajectory']
        bi = res['burst_info']
        witnesses = res['witness_records']

        alts = np.array([r['altitude_km'] for r in traj]) if traj else np.array([0.0])
        vels = np.array([r['velocity_km_s'] for r in traj]) if traj else np.array([0.0])
        masses = np.array([r['mass_kg'] for r in traj]) if traj else np.array([0.0])
        dyp = np.array([r['dynamic_pressure_Pa'] for r in traj]) if traj else np.array([0.0])
        lums = np.array([r['luminosity_W'] for r in traj]) if traj else np.array([0.0])
        delays = np.array([w['boom_delay_s'] for w in witnesses]) if witnesses else np.array([0.0])
        confs = np.array([w['witness_confidence'] for w in witnesses]) if witnesses else np.array([0.0])

        row = {
            'scenario_label': res['label'],
            'burst_altitude_km': bi['altitude_km'],
            'burst_lat': bi['burst_lat'],
            'burst_lon': bi['burst_lon'],
            'fragment_count': bi['fragment_count'],
            'burst_mass_kg': bi['burst_mass_kg'],
            'burst_vel_km_s': bi['burst_vel_km_s'],
            'luminosity_burst_W': bi['luminosity_burst_W'],
            'glm_flash_intensity_normalized': bi['glm_flash_intensity_normalized'],
            'overpressure_at_100km_Pa': bi['overpressure_at_100km_Pa'],
            'n_trajectory_steps': len(traj),
            'altitude_mean': round(float(np.mean(alts)), 3),
            'altitude_std': round(float(np.std(alts)), 3),
            'altitude_min': round(float(np.min(alts)), 3),
            'altitude_max': round(float(np.max(alts)), 3),
            'velocity_mean': round(float(np.mean(vels)), 3),
            'velocity_std': round(float(np.std(vels)), 3),
            'velocity_min': round(float(np.min(vels)), 3),
            'velocity_max': round(float(np.max(vels)), 3),
            'mass_mean': round(float(np.mean(masses)), 3),
            'mass_std': round(float(np.std(masses)), 3),
            'mass_min': round(float(np.min(masses)), 6),
            'mass_max': round(float(np.max(masses)), 3),
            'dyn_pressure_mean': round(float(np.mean(dyp)), 2),
            'dyn_pressure_max': round(float(np.max(dyp)), 2),
            'luminosity_mean': round(float(np.mean(lums)), 2),
            'luminosity_max': round(float(np.max(lums)), 2),
            'boom_delay_mean_s': round(float(np.mean(delays)), 2),
            'boom_delay_std_s': round(float(np.std(delays)), 2),
            'boom_delay_min_s': round(float(np.min(delays)), 2),
            'boom_delay_max_s': round(float(np.max(delays)), 2),
            'witness_confidence_mean': round(float(np.mean(confs)), 4),
            'n_debris_fragments': len(res['debris_records']),
        }
        summary_rows.append(row)

    if not summary_rows:
        print("WARNING: No rows for scenario_summary.csv — skipping.")
        return

    out_path = output_dir / "scenario_summary.csv"
    with open(out_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"Wrote {len(summary_rows)} rows to {out_path}")


def write_parameters_used(output_dir: pathlib.Path) -> None:
    """Write parameters_used.csv — one row per parameter."""
    rows = []
    for name, pinfo in MODEL_PROFILE['parameters'].items():
        rows.append({
            'name': name,
            'value': pinfo['value'],
            'unit': pinfo['unit'],
            'source': pinfo['source'],
            'description': pinfo['description'],
        })

    if not rows:
        print("WARNING: No rows for parameters_used.csv — skipping.")
        return

    out_path = output_dir / "parameters_used.csv"
    with open(out_path, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['name', 'value', 'unit', 'source', 'description'])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} rows to {out_path}")


# ---------------------------------------------------------------------------
# FIGURE GENERATORS
# ---------------------------------------------------------------------------
SCENARIO_COLORS = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
SCENARIO_MARKERS = ['o', 's', '^', 'D', 'v']


def fig1_trajectory_altitude_vs_time(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 1: Altitude vs. Time for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, res in enumerate(all_results):
            traj = res['trajectory']
            if len(traj) < 2:
                continue
            times = np.array([r['time_s'] for r in traj])
            alts = np.array([r['altitude_km'] for r in traj])
            assert len(times) == len(alts), f"Mismatch: {len(times)} vs {len(alts)}"
            color = SCENARIO_COLORS[idx % len(SCENARIO_COLORS)]
            ax.plot(times, alts, color=color, linewidth=2, label=res['label'])
            # Mark burst point
            bi = res['burst_info']
            burst_t = bi.get('t', None)
            # Find closest time in trajectory
            if len(times) > 0:
                burst_alt = bi['altitude_km']
                burst_idx = np.argmin(np.abs(alts - burst_alt))
                if 0 <= burst_idx < len(times):
                    ax.plot(times[burst_idx], alts[burst_idx], '*',
                            color=color, markersize=14, markeredgecolor='k')
            plotted = True
        if plotted:
            ax.set_xlabel("Time (s)", fontsize=12)
            ax.set_ylabel("Altitude (km)", fontsize=12)
            ax.set_title("Meteor Altitude vs. Time for All Scenarios", fontsize=13)
            ax.legend(fontsize=10)
            ax.grid(True, alpha=0.3)
            ax.set_ylim(0, 105)
            plt.tight_layout()
            fig.savefig(output_dir / "fig1_trajectory_altitude_vs_time.png", dpi=150)
        else:
            print("WARNING: fig1 — no plottable data.")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def fig2_velocity_deceleration(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 2: Velocity vs. Altitude for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, res in enumerate(all_results):
            traj = res['trajectory']
            if len(traj) < 2:
                continue
            alts = np.array([r['altitude_km'] for r in traj])
            vels = np.array([r['velocity_km_s'] for r in traj])
            assert len(alts) == len(vels)
            color = SCENARIO_COLORS[idx % len(SCENARIO_COLORS)]
            ax.plot(alts, vels, color=color, linewidth=2, label=res['label'])
            # Mark burst
            bi = res['burst_info']
            burst_alt = bi['altitude_km']
            burst_idx = np.argmin(np.abs(alts - burst_alt))
            if 0 <= burst_idx < len(alts):
                ax.plot(alts[burst_idx], vels[burst_idx], '*',
                        color=color, markersize=14, markeredgecolor='k')
            plotted = True
        if plotted:
            ax.set_xlabel("Altitude (km)", fontsize=12)
            ax.set_ylabel("Velocity (km/s)", fontsize=12)
            ax.set_title("Velocity vs. Altitude During Atmospheric Entry", fontsize=13)
            ax.legend(fontsize=10)
            ax.grid(True, alpha=0.3)
            ax.invert_xaxis()
            plt.tight_layout()
            fig.savefig(output_dir / "fig2_velocity_deceleration.png", dpi=150)
        else:
            print("WARNING: fig2 — no plottable data.")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def fig3_luminosity_profile(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 3: Luminosity vs. Altitude (log scale) for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, res in enumerate(all_results):
            traj = res['trajectory']
            if len(traj) < 2:
                continue
            alts = np.array([r['altitude_km'] for r in traj])
            lums = np.array([r['luminosity_W'] for r in traj])
            assert len(alts) == len(lums)
            # Clip to positive for log scale
            lums_plot = np.clip(lums, 1.0, 1.0e14)
            color = SCENARIO_COLORS[idx % len(SCENARIO_COLORS)]
            ax.semilogy(alts, lums_plot, color=color, linewidth=2, label=res['label'])
            plotted = True
        if plotted:
            ax.set_xlabel("Altitude (km)", fontsize=12)
            ax.set_ylabel("Luminosity (W)", fontsize=12)
            ax.set_title("Bolide Luminosity Profile vs. Altitude", fontsize=13)
            ax.legend(fontsize=10)
            ax.grid(True, alpha=0.3, which='both')
            ax.invert_xaxis()
            # GOES-19 GLM detection threshold reference
            ax.axhline(1.0e9, color='gray', linestyle='--', alpha=0.6, label='GLM ~threshold')
            plt.tight_layout()
            fig.savefig(output_dir / "fig3_luminosity_profile.png", dpi=150)
        else:
            print("WARNING: fig3 — no plottable data.")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def fig4_sonic_boom_propagation(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 4: Sonic boom arrival time heatmap for nominal scenario."""
    try:
        # Use first scenario (nominal) for the heatmap
        res = all_results[0]
        bi = res['burst_info']
        burst_alt = bi['altitude_km']
        b_lat = bi['burst_lat']
        b_lon = bi['burst_lon']

        lat_arr = np.linspace(41.0, 44.0, 60)
        lon_arr = np.linspace(-74.0, -69.0, 100)
        lon_grid, lat_grid = np.meshgrid(lon_arr, lat_arr)

        # Slant distance from burst to each grid point
        dlat_km = (lat_grid - b_lat) * 111.0
        dlon_km = (lon_grid - b_lon) * 111.0 * np.cos(math.radians(b_lat))
        horiz_km = np.sqrt(dlat_km ** 2 + dlon_km ** 2)
        slant_km = np.sqrt(horiz_km ** 2 + burst_alt ** 2)
        delay_grid = slant_km * 1000.0 / SOUND_SPEED

        fig, ax = plt.subplots(figsize=(10, 7))
        pcm = ax.pcolormesh(lon_grid, lat_grid, delay_grid, cmap='YlOrRd', shading='auto')
        cb = fig.colorbar(pcm, ax=ax)
        cb.set_label("Boom Arrival Delay (s)", fontsize=11)
        # Contours
        cs = ax.contour(lon_grid, lat_grid, delay_grid,
                        levels=np.arange(30, 400, 30), colors='white', alpha=0.5, linewidths=0.8)
        ax.clabel(cs, inline=True, fontsize=8, fmt='%d s')
        # Burst point
        ax.plot(b_lon, b_lat, 'b*', markersize=16, label=f'Burst ({bi["altitude_km"]:.1f} km alt)')
        ax.set_xlabel("Longitude (°E)", fontsize=12)
        ax.set_ylabel("Latitude (°N)", fontsize=12)
        ax.set_title(f"Synthetic Sonic Boom Arrival Time Map – MA & New England\n(Scenario: {res['label']})", fontsize=12)
        ax.legend(fontsize=10)
        plt.tight_layout()
        fig.savefig(output_dir / "fig4_sonic_boom_propagation.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def fig5_boom_delay_distribution(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 5: Histogram of boom delay times for all scenarios."""
    try:
        fig, axes = plt.subplots(2, 3, figsize=(14, 8))
        axes = axes.flatten()
        for idx, res in enumerate(all_results):
            if idx >= len(axes):
                break
            ax = axes[idx]
            delays = np.array([w['boom_delay_s'] for w in res['witness_records']])
            if len(delays) == 0:
                ax.text(0.5, 0.5, 'No data', ha='center', va='center', transform=ax.transAxes)
                continue
            ax.hist(delays, bins=20, color=SCENARIO_COLORS[idx % len(SCENARIO_COLORS)],
                    edgecolor='k', alpha=0.75)
            ax.set_xlabel("Boom Delay (s)", fontsize=10)
            ax.set_ylabel("Witness Count", fontsize=10)
            ax.set_title(res['label'], fontsize=10)
            ax.grid(True, alpha=0.3)
        # Hide unused subplots
        for idx in range(len(all_results), len(axes)):
            axes[idx].set_visible(False)
        fig.suptitle("Distribution of Synthetic Witness Boom-Delay Reports", fontsize=13)
        plt.tight_layout()
        fig.savefig(output_dir / "fig5_boom_delay_distribution.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def fig6_witness_report_map(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 6: Scatter plot of witness locations colored by confidence — nominal scenario."""
    try:
        res = all_results[0]
        witnesses = res['witness_records']
        if not witnesses:
            print("WARNING: fig6 — no witness data.")
            return

        w_lats = np.array([w['witness_lat'] for w in witnesses])
        w_lons = np.array([w['witness_lon'] for w in witnesses])
        confs = np.array([w['witness_confidence'] for w in witnesses])
        intens = np.array([w['perceived_intensity_0to1'] for w in witnesses])
        assert len(w_lats) == len(w_lons) == len(confs) == len(intens)

        fig, ax = plt.subplots(figsize=(10, 8))
        sc = ax.scatter(w_lons, w_lats, c=confs, cmap='plasma',
                        s=intens * 200 + 20, alpha=0.7, edgecolors='k', linewidths=0.5,
                        vmin=0.0, vmax=1.0)
        cb = fig.colorbar(sc, ax=ax)
        cb.set_label("Witness Confidence (0=uncertain, 1=certain)", fontsize=11)
        bi = res['burst_info']
        ax.plot(bi['burst_lon'], bi['burst_lat'], 'r*', markersize=20,
                label=f"Burst point ({bi['altitude_km']:.1f} km)")
        ax.set_xlabel("Longitude (°E)", fontsize=12)
        ax.set_ylabel("Latitude (°N)", fontsize=12)
        ax.set_title(f"Synthetic Witness Report Locations and Confidence Scores\n(Scenario: {res['label']})", fontsize=12)
        ax.legend(fontsize=10)
        ax.set_xlim(-74.5, -68.5)
        ax.set_ylim(40.5, 44.5)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig6_witness_report_map.png", dpi=150)
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def fig7_debris_field_ellipses(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 7: Hypothetical debris field scatter for all scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(11, 8))
        any_plotted = False
        for idx, res in enumerate(all_results):
            debris = res['debris_records']
            if not debris:
                continue
            d_lats = np.array([d['debris_lat'] for d in debris])
            d_lons = np.array([d['debris_lon'] for d in debris])
            d_masses = np.array([d['debris_mass_kg'] for d in debris])
            assert len(d_lats) == len(d_lons) == len(d_masses)
            log_masses = np.log10(np.clip(d_masses, 0.001, 1.0e5))
            sc = ax.scatter(d_lons, d_lats,
                            c=log_masses, cmap='hot_r',
                            s=60, alpha=0.75,
                            marker=SCENARIO_MARKERS[idx % len(SCENARIO_MARKERS)],
                            label=res['label'],
                            edgecolors=SCENARIO_COLORS[idx % len(SCENARIO_COLORS)],
                            linewidths=0.8)
            any_plotted = True

        if any_plotted:
            plt.colorbar(sc, ax=ax, label='log₁₀(Fragment Mass kg)')
            ax.set_xlabel("Longitude (°E)", fontsize=12)
            ax.set_ylabel("Latitude (°N)", fontsize=12)
            ax.set_title("Hypothetical Debris-Field Scenarios (Illustrative Only)", fontsize=13)
            ax.legend(fontsize=9)
            ax.grid(True, alpha=0.3)
            # Bold disclaimer
            ax.text(0.5, 0.02,
                    "⚠ ILLUSTRATIVE ONLY — No confirmed debris locations as of simulation date",
                    transform=ax.transAxes, ha='center', va='bottom',
                    fontsize=9, color='red', fontweight='bold',
                    bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.8))
            plt.tight_layout()
            fig.savefig(output_dir / "fig7_debris_field_ellipses.png", dpi=150)
        else:
            print("WARNING: fig7 — no debris data to plot.")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


def fig8_dynamic_pressure_vs_altitude(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 8: Dynamic (ram) pressure vs. Altitude with fragmentation threshold."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False
        for idx, res in enumerate(all_results):
            traj = res['trajectory']
            if len(traj) < 2:
                continue
            alts = np.array([r['altitude_km'] for r in traj])
            dyp = np.array([r['dynamic_pressure_Pa'] for r in traj])
            assert len(alts) == len(dyp)
            color = SCENARIO_COLORS[idx % len(SCENARIO_COLORS)]
            ax.semilogy(alts, np.clip(dyp, 1.0, 1.0e8),
                        color=color, linewidth=2, label=res['label'])
            plotted = True

        if plotted:
            # Fragmentation thresholds
            thresholds = list(set([
                sc['param_overrides']['fragmentation_pressure_Pa']
                for sc in MODEL_PROFILE['scenarios']
            ]))
            line_styles = ['--', '-.', ':']
            for ti, thresh in enumerate(sorted(thresholds)):
                ax.axhline(thresh, color='gray', linestyle=line_styles[ti % 3],
                           alpha=0.7, linewidth=1.5,
                           label=f"Frag threshold: {thresh:.0e} Pa")
            ax.set_xlabel("Altitude (km)", fontsize=12)
            ax.set_ylabel("Dynamic Pressure (Pa)", fontsize=12)
            ax.set_title("Dynamic (Ram) Pressure vs. Altitude – Fragmentation Threshold", fontsize=13)
            ax.legend(fontsize=9)
            ax.grid(True, alpha=0.3, which='both')
            ax.invert_xaxis()
            plt.tight_layout()
            fig.savefig(output_dir / "fig8_dynamic_pressure_vs_altitude.png", dpi=150)
        else:
            print("WARNING: fig8 — no plottable data.")
        plt.close(fig)
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")


# ---------------------------------------------------------------------------
# SUMMARY JSON
# ---------------------------------------------------------------------------
def write_summary_json(all_results: List[dict], output_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    summary = {}
    for res in all_results:
        bi = res['burst_info']
        traj = res['trajectory']
        witnesses = res['witness_records']
        delays = [w['boom_delay_s'] for w in witnesses]
        alts = [r['altitude_km'] for r in traj]
        lums = [r['luminosity_W'] for r in traj]
        summary[res['label']] = {
            'burst_altitude_km': bi['altitude_km'],
            'burst_lat': bi['burst_lat'],
            'burst_lon': bi['burst_lon'],
            'fragment_count': bi['fragment_count'],
            'glm_flash_intensity_normalized': bi['glm_flash_intensity_normalized'],
            'overpressure_at_100km_Pa': bi['overpressure_at_100km_Pa'],
            'peak_luminosity_W': res['max_luminosity_W'],
            'n_trajectory_steps': len(traj),
            'n_witnesses': len(witnesses),
            'n_debris_fragments': len(res['debris_records']),
            'mean_boom_delay_s': round(float(np.mean(delays)), 2) if delays else 0.0,
            'min_altitude_km': round(float(np.min(alts)), 3) if alts else 0.0,
            'max_luminosity_in_traj_W': round(float(np.max(lums)), 2) if lums else 0.0,
        }
    out_path = output_dir / "summary.json"
    with open(out_path, 'w') as f:
        json.dump(summary, f, indent=2)
    print(f"Wrote summary to {out_path}")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser(
        description="May 30 2026 Massachusetts Fireball/Bolide Atmospheric Entry Simulator"
    )
    parser.add_argument("--output", default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("May 30, 2026 Massachusetts Fireball/Bolide Simulation")
    print(f"Output directory: {output_dir}")
    print("=" * 70)

    # Run all scenarios
    all_results = []
    for scenario_idx, scenario in enumerate(MODEL_PROFILE['scenarios']):
        print(f"\nRunning scenario {scenario_idx}: {scenario['label']} ...")
        result = run_scenario(scenario_idx, scenario)
        n_traj = len(result['trajectory'])
        bi = result['burst_info']
        print(f"  Trajectory steps: {n_traj}")
        print(f"  Burst altitude: {bi['altitude_km']:.2f} km")
        print(f"  Fragment count: {bi['fragment_count']}")
        print(f"  GLM intensity: {bi['glm_flash_intensity_normalized']:.4f}")
        print(f"  Overpressure @100km: {bi['overpressure_at_100km_Pa']:.2f} Pa")
        all_results.append(result)

    # Write CSV files
    print("\n--- Writing CSV files ---")
    write_simulation_outputs(all_results, output_dir)
    write_scenario_summary(all_results, output_dir)
    write_parameters_used(output_dir)

    # Write summary JSON
    print("\n--- Writing summary.json ---")
    write_summary_json(all_results, output_dir)

    # Generate all figures
    print("\n--- Generating figures ---")
    fig1_trajectory_altitude_vs_time(all_results, output_dir)
    fig2_velocity_deceleration(all_results, output_dir)
    fig3_luminosity_profile(all_results, output_dir)
    fig4_sonic_boom_propagation(all_results, output_dir)
    fig5_boom_delay_distribution(all_results, output_dir)
    fig6_witness_report_map(all_results, output_dir)
    fig7_debris_field_ellipses(all_results, output_dir)
    fig8_dynamic_pressure_vs_altitude(all_results, output_dir)

    print("\n" + "=" * 70)
    print("Simulation complete.")
    print(f"All outputs saved to: {output_dir}")
    print("=" * 70)


if __name__ == "__main__":
    main()