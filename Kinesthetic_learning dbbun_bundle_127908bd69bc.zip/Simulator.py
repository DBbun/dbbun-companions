# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T14:39:25.904457Z
# Run ID    : 5c27a8e9-5eab-479a-9118-8b0a24e52737
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Kinesthetic Learning Simulator
================================
Paper: 'Kinesthetic Learning' — modeling the Law of Learning, short-term vs.
long-term memory consolidation, synaptic plasticity growth, and classroom
strategy effects via a discrete-session dynamical system.

Based on the VARK model, Dunn-Dunn learning styles framework, and
neuroscience-based learning research (Favre 2009, Sprenger 2008).
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Any, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "learning_rate": {"value": 0.15, "unit": "per session", "source": "assumed",
                          "description": "Base rate at which skill level increases per practice session"},
        "plasticity_growth_rate": {"value": 0.08, "unit": "per session", "source": "assumed",
                                   "description": "Rate at which synaptic plasticity accumulates with practice"},
        "stm_decay_rate": {"value": 0.3, "unit": "per session", "source": "assumed",
                           "description": "Rate at which short-term memory decays between sessions"},
        "ltm_consolidation_rate": {"value": 0.05, "unit": "per session", "source": "assumed",
                                   "description": "Base rate of transfer from short-term to long-term memory"},
        "emotional_boost_factor": {"value": 0.6, "unit": "a.u.", "source": "extracted",
                                   "description": "Multiplicative boost to LTM consolidation when engagement is high"},
        "plateau_factor": {"value": 0.92, "unit": "a.u.", "source": "assumed",
                           "description": "Saturation term controlling asymptotic plateau in Law of Learning"},
        "session_duration": {"value": 1.0, "unit": "hour", "source": "assumed",
                             "description": "Duration of each practice session in hours"},
        "spacing_interval": {"value": 1.0, "unit": "days", "source": "assumed",
                             "description": "Number of days between practice sessions"},
        "engagement_decay": {"value": 0.05, "unit": "per session", "source": "assumed",
                             "description": "Gradual decay in emotional engagement over repetitive sessions"},
        "engagement_boost_activity": {"value": 0.2, "unit": "a.u.", "source": "extracted",
                                      "description": "Boost to engagement when activity type is active"},
        "n_sessions": {"value": 60, "unit": "sessions", "source": "assumed",
                       "description": "Total number of practice sessions simulated"},
        "open_skill_flexibility": {"value": 0.15, "unit": "a.u.", "source": "extracted",
                                   "description": "Additional variance/noise for open skills vs. closed skills"},
    },
    "scenarios": [
        {
            "label": "massed_practice_closed_skill",
            "description": "Long daily sessions (massed practice) learning a closed skill.",
            "activity_type": "passive",
            "param_overrides": {
                "session_duration": 3.0,
                "spacing_interval": 0.5,
                "open_skill_flexibility": 0.0,
                "emotional_boost_factor": 0.3,
                "stm_decay_rate": 0.35,
            },
        },
        {
            "label": "spaced_practice_closed_skill",
            "description": "Short, infrequent sessions spaced over days learning a closed skill.",
            "activity_type": "passive",
            "param_overrides": {
                "session_duration": 0.5,
                "spacing_interval": 3.0,
                "open_skill_flexibility": 0.0,
                "emotional_boost_factor": 0.4,
                "stm_decay_rate": 0.1,
            },
        },
        {
            "label": "high_engagement_open_skill",
            "description": "Emotionally engaging activities for an open skill (team sport).",
            "activity_type": "active",
            "param_overrides": {
                "session_duration": 1.0,
                "spacing_interval": 1.0,
                "open_skill_flexibility": 0.15,
                "emotional_boost_factor": 0.85,
                "engagement_boost_activity": 0.35,
            },
        },
        {
            "label": "low_engagement_passive_instruction",
            "description": "Traditional passive instruction with minimal kinesthetic involvement.",
            "activity_type": "passive",
            "param_overrides": {
                "session_duration": 1.0,
                "spacing_interval": 1.0,
                "open_skill_flexibility": 0.0,
                "emotional_boost_factor": 0.1,
                "engagement_boost_activity": 0.0,
                "learning_rate": 0.05,
                "plasticity_growth_rate": 0.02,
            },
        },
        {
            "label": "kinesthetic_game_based_learning",
            "description": "Game-based kinesthetic instruction (Twister, floor Tic-Tac-Toe, role-play).",
            "activity_type": "active",
            "param_overrides": {
                "session_duration": 1.0,
                "spacing_interval": 1.5,
                "emotional_boost_factor": 0.7,
                "engagement_boost_activity": 0.3,
                "learning_rate": 0.18,
                "plasticity_growth_rate": 0.1,
            },
        },
    ],
    "state_variables": {
        "skill_level": {"init": 0.0, "range": [0.0, 1.0]},
        "short_term_memory": {"init": 0.0, "range": [0.0, 1.0]},
        "long_term_memory": {"init": 0.0, "range": [0.0, 1.0]},
        "synaptic_plasticity": {"init": 0.0, "range": [0.0, 1.0]},
        "emotional_engagement": {"init": 0.5, "range": [0.0, 1.0]},
    },
}

# ============================================================
# COLORS
# ============================================================
SCENARIO_COLORS = {
    "massed_practice_closed_skill": "#e74c3c",
    "spaced_practice_closed_skill": "#3498db",
    "high_engagement_open_skill": "#2ecc71",
    "low_engagement_passive_instruction": "#95a5a6",
    "kinesthetic_game_based_learning": "#f39c12",
}

SCENARIO_LABELS = {
    "massed_practice_closed_skill": "Massed / Closed",
    "spaced_practice_closed_skill": "Spaced / Closed",
    "high_engagement_open_skill": "High Engagement / Open",
    "low_engagement_passive_instruction": "Passive Instruction",
    "kinesthetic_game_based_learning": "Game-Based",
}


# ============================================================
# CORE SIMULATION FUNCTION
# ============================================================
def get_params(scenario: Dict[str, Any]) -> Dict[str, Any]:
    """Build a parameter dict for a scenario by merging defaults with overrides."""
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    params.update(scenario.get("param_overrides", {}))
    return params


def run_simulation(
    scenario_label: str,
    params: Dict[str, Any],
    activity_type: str,
    run_id: int = 0,
    learning_rate_override: float = None,
    emotional_boost_override: float = None,
    rng_seed: int = None,
) -> List[Dict[str, Any]]:
    """
    Run a single simulation for a given scenario and return list of row dicts.
    """
    if rng_seed is not None:
        np.random.seed(rng_seed)

    n_sessions = int(params["n_sessions"])
    session_duration = float(params["session_duration"])
    spacing_interval = float(params["spacing_interval"])
    learning_rate = float(learning_rate_override if learning_rate_override is not None else params["learning_rate"])
    plasticity_growth_rate = float(params["plasticity_growth_rate"])
    stm_decay_rate = float(params["stm_decay_rate"])
    ltm_consolidation_rate = float(params["ltm_consolidation_rate"])
    emotional_boost_factor = float(
        emotional_boost_override if emotional_boost_override is not None else params["emotional_boost_factor"]
    )
    plateau_factor = float(params["plateau_factor"])
    engagement_decay = float(params["engagement_decay"])
    engagement_boost_activity = float(params["engagement_boost_activity"])
    open_skill_flexibility = float(params["open_skill_flexibility"])
    open_skill = open_skill_flexibility > 0.0

    # Initialize state
    skill = 0.0
    stm = 0.0
    ltm = 0.0
    plasticity = 0.0
    engagement = 0.5

    results = []

    for t in range(1, n_sessions + 1):
        # 1. EMOTIONAL ENGAGEMENT UPDATE
        engagement_decay_this_session = engagement_decay * session_duration
        engagement = max(0.0, engagement - engagement_decay_this_session)
        if activity_type == "active":
            engagement += engagement_boost_activity
        if t % 10 == 0:
            engagement = min(1.0, engagement + 0.15)
        engagement = min(1.0, max(0.0, engagement))

        # 2. SYNAPTIC PLASTICITY UPDATE (logistic)
        plasticity_gain = plasticity_growth_rate * session_duration * (1.0 - plasticity)
        plasticity = min(1.0, plasticity + plasticity_gain)

        # 3. SKILL LEVEL UPDATE (Law of Learning)
        effective_lr = learning_rate * (1.0 + plasticity) * (0.5 + 0.5 * engagement)
        skill_gain = effective_lr * (1.0 - skill) * plateau_factor
        open_skill_noise = 0.0
        if open_skill:
            noise = np.random.normal(0.0, open_skill_flexibility * 0.1)
            open_skill_noise = noise
            skill_gain += noise
        skill = float(np.clip(skill + skill_gain, 0.0, 1.0))
        # Recompute skill_gain as actual delta (after clipping)
        # skill_gain_this_session = actual skill_gain before noise clip issues
        skill_gain_recorded = float(np.clip(skill_gain, -1.0, 1.0))

        # 4. SHORT-TERM MEMORY UPDATE
        stm_input = skill_gain_recorded * session_duration
        stm_loss = stm * stm_decay_rate * spacing_interval
        stm = float(np.clip(stm + stm_input - stm_loss, 0.0, 1.0))

        # 5. LONG-TERM MEMORY CONSOLIDATION
        effective_consol = ltm_consolidation_rate * (1.0 + emotional_boost_factor * engagement)
        ltm_gain = effective_consol * stm * (1.0 - ltm)
        ltm = float(np.clip(ltm + ltm_gain, 0.0, 1.0))

        # 6. RECORD ROW
        row = {
            "scenario": scenario_label,
            "session_index": t,
            "session_duration_hr": session_duration,
            "spacing_interval_days": spacing_interval,
            "skill_level": skill,
            "short_term_memory": stm,
            "long_term_memory": ltm,
            "synaptic_plasticity": plasticity,
            "emotional_engagement": engagement,
            "ltm_consolidation_this_session": float(np.clip(ltm_gain, 0.0, 1.0)),
            "skill_gain_this_session": skill_gain_recorded,
            "open_skill_noise": open_skill_noise,
            "run_id": run_id,
        }
        results.append(row)

    return results


def run_all_scenarios() -> List[Dict[str, Any]]:
    """Run all scenarios and return combined results list."""
    all_results = []
    for idx, scenario in enumerate(MODEL_PROFILE["scenarios"]):
        np.random.seed(idx)
        params = get_params(scenario)
        results = run_simulation(
            scenario_label=scenario["label"],
            params=params,
            activity_type=scenario.get("activity_type", "passive"),
            run_id=0,
            rng_seed=idx,
        )
        all_results.extend(results)
    return all_results


# ============================================================
# HELPER: extract scenario time-series
# ============================================================
def extract_series(all_results: List[Dict], scenario_label: str, key: str) -> Tuple[np.ndarray, np.ndarray]:
    """Extract session_index and a state variable for a specific scenario."""
    rows = [r for r in all_results if r["scenario"] == scenario_label]
    rows_sorted = sorted(rows, key=lambda r: r["session_index"])
    x = np.array([r["session_index"] for r in rows_sorted])
    y = np.array([r[key] for r in rows_sorted])
    return x, y


# ============================================================
# FIGURE GENERATION
# ============================================================
def make_fig1(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Skill Acquisition Curves Across Scenarios (Law of Learning)"""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        for scenario in MODEL_PROFILE["scenarios"]:
            label = scenario["label"]
            x, y = extract_series(all_results, label, "skill_level")
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                print(f"Warning fig1: no data for {label}")
                continue
            ax.plot(x, y, color=SCENARIO_COLORS[label], label=SCENARIO_LABELS[label], linewidth=2)
        ax.set_xlabel("Practice Session", fontsize=12)
        ax.set_ylabel("Skill Level (a.u.)", fontsize=12)
        ax.set_title("Skill Acquisition Curves Across Scenarios (Law of Learning)", fontsize=13)
        ax.set_ylim(0.0, 1.05)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig1_skill_acquisition.png", dpi=150)
        plt.close(fig)
        print("Saved fig1_skill_acquisition.png")
    except Exception as e:
        print(f"Warning: fig1 failed: {e}")


def make_fig2(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Short-Term Memory Dynamics: Massed vs. Spaced Practice"""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        for label in ["massed_practice_closed_skill", "spaced_practice_closed_skill"]:
            x, y = extract_series(all_results, label, "short_term_memory")
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                print(f"Warning fig2: no data for {label}")
                continue
            ax.plot(x, y, color=SCENARIO_COLORS[label], label=SCENARIO_LABELS[label], linewidth=2)
        # STM ceiling dashed line
        n_sess = int(MODEL_PROFILE["parameters"]["n_sessions"]["value"])
        ax.axhline(y=1.0, color="black", linestyle="--", alpha=0.5, label="STM ceiling")
        ax.set_xlabel("Practice Session", fontsize=12)
        ax.set_ylabel("Short-Term Memory (a.u.)", fontsize=12)
        ax.set_title("Short-Term Memory Dynamics: Massed vs. Spaced Practice", fontsize=13)
        ax.set_ylim(0.0, 1.1)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig2_short_term_memory.png", dpi=150)
        plt.close(fig)
        print("Saved fig2_short_term_memory.png")
    except Exception as e:
        print(f"Warning: fig2 failed: {e}")


def make_fig3(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Long-Term Memory Consolidation: Effect of Emotional Engagement and Spacing"""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        for scenario in MODEL_PROFILE["scenarios"]:
            label = scenario["label"]
            x, y = extract_series(all_results, label, "long_term_memory")
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                print(f"Warning fig3: no data for {label}")
                continue
            ax.plot(x, y, color=SCENARIO_COLORS[label], label=SCENARIO_LABELS[label], linewidth=2)
        ax.set_xlabel("Practice Session", fontsize=12)
        ax.set_ylabel("Long-Term Memory (a.u.)", fontsize=12)
        ax.set_title("Long-Term Memory Consolidation: Effect of Emotional Engagement and Spacing", fontsize=13)
        ax.set_ylim(0.0, 1.05)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig3_long_term_memory.png", dpi=150)
        plt.close(fig)
        print("Saved fig3_long_term_memory.png")
    except Exception as e:
        print(f"Warning: fig3 failed: {e}")


def make_fig4(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Synaptic Plasticity Growth Over Practice Sessions"""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        for scenario in MODEL_PROFILE["scenarios"]:
            label = scenario["label"]
            x, y = extract_series(all_results, label, "synaptic_plasticity")
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                print(f"Warning fig4: no data for {label}")
                continue
            ax.plot(x, y, color=SCENARIO_COLORS[label], label=SCENARIO_LABELS[label], linewidth=2)
        # Annotate milestones
        for milestone in [10, 30, 50]:
            ax.axvline(x=milestone, color="gray", linestyle=":", alpha=0.5)
            ax.text(milestone + 0.5, 0.02, f"T={milestone}", fontsize=8, color="gray")
        ax.set_xlabel("Practice Session", fontsize=12)
        ax.set_ylabel("Synaptic Plasticity (a.u.)", fontsize=12)
        ax.set_title("Synaptic Plasticity Growth Over Practice Sessions", fontsize=13)
        ax.set_ylim(0.0, 1.05)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig4_synaptic_plasticity.png", dpi=150)
        plt.close(fig)
        print("Saved fig4_synaptic_plasticity.png")
    except Exception as e:
        print(f"Warning: fig4 failed: {e}")


def make_fig5(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Emotional Engagement Over Time by Scenario"""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        for scenario in MODEL_PROFILE["scenarios"]:
            label = scenario["label"]
            x, y = extract_series(all_results, label, "emotional_engagement")
            assert len(x) == len(y), f"Shape mismatch for {label}"
            if len(x) == 0:
                print(f"Warning fig5: no data for {label}")
                continue
            ax.plot(x, y, color=SCENARIO_COLORS[label], label=SCENARIO_LABELS[label], linewidth=2)
        ax.set_xlabel("Practice Session", fontsize=12)
        ax.set_ylabel("Emotional Engagement (a.u.)", fontsize=12)
        ax.set_title("Emotional Engagement Over Time by Scenario", fontsize=13)
        ax.set_ylim(0.0, 1.1)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig5_emotional_engagement.png", dpi=150)
        plt.close(fig)
        print("Saved fig5_emotional_engagement.png")
    except Exception as e:
        print(f"Warning: fig5 failed: {e}")


def make_fig6(out_dir: pathlib.Path) -> None:
    """Skill Level vs. Long-Term Memory at Session 60 (All Scenarios) — multi-seed scatter"""
    try:
        fig, ax = plt.subplots(figsize=(9, 7))
        n_seeds = 30
        for idx, scenario in enumerate(MODEL_PROFILE["scenarios"]):
            label = scenario["label"]
            params = get_params(scenario)
            ltm_finals = []
            skill_finals = []
            for seed in range(n_seeds):
                np.random.seed(idx * 1000 + seed)
                rows = run_simulation(
                    scenario_label=label,
                    params=params,
                    activity_type=scenario.get("activity_type", "passive"),
                    run_id=seed,
                    rng_seed=idx * 1000 + seed,
                )
                if rows:
                    ltm_finals.append(rows[-1]["long_term_memory"])
                    skill_finals.append(rows[-1]["skill_level"])
            ltm_arr = np.array(ltm_finals)
            skill_arr = np.array(skill_finals)
            assert len(ltm_arr) == len(skill_arr), f"Shape mismatch for {label}"
            if len(ltm_arr) == 0:
                print(f"Warning fig6: no data for {label}")
                continue
            ax.scatter(
                ltm_arr, skill_arr,
                color=SCENARIO_COLORS[label],
                label=SCENARIO_LABELS[label],
                alpha=0.7, s=60, edgecolors="white", linewidth=0.5,
            )
        ax.set_xlabel("Long-Term Memory at Session 60 (a.u.)", fontsize=12)
        ax.set_ylabel("Skill Level at Session 60 (a.u.)", fontsize=12)
        ax.set_title("Skill Level vs. Long-Term Memory at Session 60 (All Scenarios)", fontsize=12)
        ax.set_xlim(0.0, 1.05)
        ax.set_ylim(0.0, 1.05)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig6_skill_vs_ltm_scatter.png", dpi=150)
        plt.close(fig)
        print("Saved fig6_skill_vs_ltm_scatter.png")
    except Exception as e:
        print(f"Warning: fig6 failed: {e}")


def run_heatmap_cell(session_duration: float, spacing_interval: float) -> float:
    """Run simulation for one heatmap cell and return final LTM."""
    # Base params from high_engagement scenario
    scenario = MODEL_PROFILE["scenarios"][2]  # high_engagement_open_skill
    params = get_params(scenario)
    params["session_duration"] = session_duration
    params["spacing_interval"] = spacing_interval
    np.random.seed(42)
    rows = run_simulation(
        scenario_label="sweep",
        params=params,
        activity_type="active",
        run_id=0,
        rng_seed=42,
    )
    if rows:
        return float(np.clip(rows[-1]["long_term_memory"], 0.0, 1.0))
    return 0.0


def make_fig7(out_dir: pathlib.Path) -> None:
    """Long-Term Memory Heatmap: Session Duration vs. Spacing Interval"""
    try:
        durations = np.linspace(0.25, 4.0, 8)
        spacings = np.linspace(0.25, 7.0, 8)
        heatmap = np.zeros((len(spacings), len(durations)))
        for i, sp in enumerate(spacings):
            for j, dur in enumerate(durations):
                heatmap[i, j] = run_heatmap_cell(dur, sp)
        fig, ax = plt.subplots(figsize=(9, 7))
        im = ax.imshow(
            heatmap, origin="lower", aspect="auto",
            extent=[durations[0], durations[-1], spacings[0], spacings[-1]],
            cmap="RdYlBu_r", vmin=0.0, vmax=1.0,
        )
        cbar = fig.colorbar(im, ax=ax, label="Long-Term Memory at Session 60 (a.u.)")
        ax.set_xlabel("Session Duration (hours)", fontsize=12)
        ax.set_ylabel("Spacing Interval (days)", fontsize=12)
        ax.set_title("Long-Term Memory Heatmap: Session Duration vs. Spacing Interval", fontsize=12)
        # Mark optimal cell
        opt_idx = np.unravel_index(np.argmax(heatmap), heatmap.shape)
        opt_dur = durations[opt_idx[1]]
        opt_sp = spacings[opt_idx[0]]
        ax.plot(opt_dur, opt_sp, "w*", markersize=18, label=f"Optimal ({opt_dur:.2f}h, {opt_sp:.2f}d)")
        ax.legend(fontsize=9, loc="upper right")
        plt.tight_layout()
        fig.savefig(out_dir / "fig7_ltm_heatmap.png", dpi=150)
        plt.close(fig)
        print("Saved fig7_ltm_heatmap.png")
    except Exception as e:
        print(f"Warning: fig7 failed: {e}")


def make_fig8(out_dir: pathlib.Path) -> None:
    """Distribution of Final Skill Level Across Learner Populations (Monte Carlo)"""
    try:
        n_learners = 500
        fig, ax = plt.subplots(figsize=(11, 6))
        all_skill_finals: Dict[str, np.ndarray] = {}
        for idx, scenario in enumerate(MODEL_PROFILE["scenarios"]):
            label = scenario["label"]
            params = get_params(scenario)
            skill_finals_list = []
            np.random.seed(idx * 9999)
            lr_samples = np.random.normal(params["learning_rate"], 0.03, n_learners)
            lr_samples = np.clip(lr_samples, 0.01, 0.5)
            eb_samples = np.random.normal(params["emotional_boost_factor"], 0.1, n_learners)
            eb_samples = np.clip(eb_samples, 0.0, 1.0)
            for learner_i in range(n_learners):
                seed_i = idx * 100000 + learner_i
                np.random.seed(seed_i)
                rows = run_simulation(
                    scenario_label=label,
                    params=params,
                    activity_type=scenario.get("activity_type", "passive"),
                    run_id=learner_i,
                    learning_rate_override=float(lr_samples[learner_i]),
                    emotional_boost_override=float(eb_samples[learner_i]),
                    rng_seed=seed_i,
                )
                if rows:
                    skill_finals_list.append(rows[-1]["skill_level"])
            skill_arr = np.array(skill_finals_list, dtype=float)
            all_skill_finals[label] = skill_arr

        bins = np.linspace(0.0, 1.0, 30)
        for scenario in MODEL_PROFILE["scenarios"]:
            label = scenario["label"]
            if label not in all_skill_finals or len(all_skill_finals[label]) == 0:
                print(f"Warning fig8: no data for {label}")
                continue
            ax.hist(
                all_skill_finals[label], bins=bins,
                color=SCENARIO_COLORS[label], alpha=0.55,
                label=SCENARIO_LABELS[label], edgecolor="white",
            )
        ax.set_xlabel("Final Skill Level (a.u.)", fontsize=12)
        ax.set_ylabel("Frequency", fontsize=12)
        ax.set_title("Distribution of Final Skill Level Across Learner Populations (Monte Carlo, N=500)", fontsize=11)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig8_monte_carlo_histogram.png", dpi=150)
        plt.close(fig)
        print("Saved fig8_monte_carlo_histogram.png")
    except Exception as e:
        print(f"Warning: fig8 failed: {e}")


# ============================================================
# CSV WRITERS
# ============================================================
DATASET_COLUMNS = [
    "scenario", "session_index", "session_duration_hr", "spacing_interval_days",
    "skill_level", "short_term_memory", "long_term_memory", "synaptic_plasticity",
    "emotional_engagement", "ltm_consolidation_this_session", "skill_gain_this_session",
    "open_skill_noise", "run_id",
]


def write_simulation_outputs(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv — full time-series for all scenarios."""
    try:
        if not all_results:
            print("Warning: simulation_outputs.csv — no data to write.")
            return
        filepath = out_dir / "simulation_outputs.csv"
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=DATASET_COLUMNS)
            writer.writeheader()
            for row in all_results:
                writer.writerow({k: row[k] for k in DATASET_COLUMNS})
        print(f"Saved simulation_outputs.csv ({len(all_results)} rows)")
    except Exception as e:
        print(f"Warning: simulation_outputs.csv write failed: {e}")


def write_scenario_summary(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv — one row per scenario with aggregate metrics."""
    try:
        if not all_results:
            print("Warning: scenario_summary.csv — no data.")
            return
        state_vars = ["skill_level", "short_term_memory", "long_term_memory",
                      "synaptic_plasticity", "emotional_engagement"]
        summary_rows = []
        for scenario in MODEL_PROFILE["scenarios"]:
            label = scenario["label"]
            rows = [r for r in all_results if r["scenario"] == label]
            if not rows:
                continue
            summary = {"scenario": label}
            for var in state_vars:
                vals = np.array([r[var] for r in rows], dtype=float)
                summary[f"{var}_mean"] = float(np.mean(vals))
                summary[f"{var}_std"] = float(np.std(vals))
                summary[f"{var}_min"] = float(np.min(vals))
                summary[f"{var}_max"] = float(np.max(vals))
            # Final session metrics
            final_rows = [r for r in rows if r["session_index"] == max(r["session_index"] for r in rows)]
            if final_rows:
                summary["final_skill_level"] = float(np.mean([r["skill_level"] for r in final_rows]))
                summary["final_long_term_memory"] = float(np.mean([r["long_term_memory"] for r in final_rows]))
                summary["final_synaptic_plasticity"] = float(np.mean([r["synaptic_plasticity"] for r in final_rows]))
            summary["total_ltm_consolidation"] = float(
                np.sum([r["ltm_consolidation_this_session"] for r in rows])
            )
            summary_rows.append(summary)

        if not summary_rows:
            print("Warning: scenario_summary.csv — no summary rows computed.")
            return
        fieldnames = list(summary_rows[0].keys())
        filepath = out_dir / "scenario_summary.csv"
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(summary_rows)
        print(f"Saved scenario_summary.csv ({len(summary_rows)} rows)")
    except Exception as e:
        print(f"Warning: scenario_summary.csv write failed: {e}")


def write_parameters_used(out_dir: pathlib.Path) -> None:
    """Write parameters_used.csv — one row per parameter."""
    try:
        filepath = out_dir / "parameters_used.csv"
        params_data = MODEL_PROFILE["parameters"]
        fieldnames = ["name", "value", "unit", "source", "description"]
        rows = []
        for name, info in params_data.items():
            rows.append({
                "name": name,
                "value": info["value"],
                "unit": info["unit"],
                "source": info["source"],
                "description": info["description"],
            })
        if not rows:
            print("Warning: parameters_used.csv — no parameter rows.")
            return
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved parameters_used.csv ({len(rows)} rows)")
    except Exception as e:
        print(f"Warning: parameters_used.csv write failed: {e}")


# ============================================================
# SUMMARY JSON
# ============================================================
def write_summary_json(all_results: List[Dict], out_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    try:
        if not all_results:
            print("Warning: summary.json — no data.")
            return
        summary = {
            "title": "Kinesthetic Learning Simulator",
            "n_scenarios": len(MODEL_PROFILE["scenarios"]),
            "n_sessions_per_scenario": int(MODEL_PROFILE["parameters"]["n_sessions"]["value"]),
            "total_rows": len(all_results),
            "scenario_metrics": {},
        }
        for scenario in MODEL_PROFILE["scenarios"]:
            label = scenario["label"]
            rows = [r for r in all_results if r["scenario"] == label]
            if not rows:
                continue
            final_session = max(r["session_index"] for r in rows)
            final_rows = [r for r in rows if r["session_index"] == final_session]
            summary["scenario_metrics"][label] = {
                "final_skill_level": float(np.mean([r["skill_level"] for r in final_rows])),
                "final_long_term_memory": float(np.mean([r["long_term_memory"] for r in final_rows])),
                "final_synaptic_plasticity": float(np.mean([r["synaptic_plasticity"] for r in final_rows])),
                "mean_emotional_engagement": float(np.mean([r["emotional_engagement"] for r in rows])),
            }
        filepath = out_dir / "summary.json"
        with open(filepath, "w") as f:
            json.dump(summary, f, indent=2)
        print("Saved summary.json")
    except Exception as e:
        print(f"Warning: summary.json write failed: {e}")


# ============================================================
# MAIN
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="Kinesthetic Learning Simulator")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # --- Run all scenarios ---
    print("\n=== Running simulations ===")
    all_results = run_all_scenarios()
    print(f"Total simulation rows: {len(all_results)}")

    # --- Write CSVs ---
    print("\n=== Writing CSV files ===")
    write_simulation_outputs(all_results, out_dir)
    write_scenario_summary(all_results, out_dir)
    write_parameters_used(out_dir)

    # --- Generate figures ---
    print("\n=== Generating figures ===")
    make_fig1(all_results, out_dir)
    make_fig2(all_results, out_dir)
    make_fig3(all_results, out_dir)
    make_fig4(all_results, out_dir)
    make_fig5(all_results, out_dir)
    make_fig6(out_dir)
    make_fig7(out_dir)
    make_fig8(out_dir)

    # --- Write summary JSON ---
    print("\n=== Writing summary JSON ===")
    write_summary_json(all_results, out_dir)

    print("\n=== Simulation complete ===")
    print(f"All outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()