================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 5c27a8e9-5eab-479a-9118-8b0a24e52737
    Generated   : 2026-04-28  14:39:25 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Kinesthetic Learning

    CATEGORIES
    ----------
    Education and Learning Technologies, Biomedical and Health Sciences, Computational Intelligence

    KEYWORDS
    --------
    kinesthetic learning, skill acquisition, memory consolidation, synaptic plasticity, Law of Learning

    ABSTRACT
    --------
    This simulator models the dynamics of kinesthetic (physical/tactile) skill learning, capturing the Law of Learning (rapid initial skill acquisition followed by a plateau), short-term versus long-term memory consolidation, and synaptic plasticity growth in the basal ganglia and cerebral cortex as described in the source literature. The model encodes five distinct instructional scenarios ranging from passive traditional teaching to emotionally engaging game-based kinesthetic activities, enabling direct comparison of skill trajectories and memory outcomes. Emotional engagement modulates the transfer rate from working to long-term memory, and practice spacing controls the balance between rapid short-term gains and durable long-term retention. Researchers and educators can use the simulator to explore how instructional design choices (session frequency, duration, activity type, emotional context) interact to shape learner outcomes, generating synthetic datasets and publication-quality figures that faithfully reproduce theoretical predictions from VARK-model and neuroscience-based learning research.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Kinesthetic_learning.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    skill_level, short_term_memory, long_term_memory, synaptic_plasticity, emotional_engagement, session_index

    SCENARIOS  (5 total)
    ---------------------------------
        1. massed_practice_closed_skill — Long daily sessions (massed practice) learning a closed skill (e.g., ballet routine). Predicts rapid initial skill gain but primarily short-term retention with limited long-term memory consolidation.
2. spaced_practice_closed_skill — Short, infrequent sessions spaced over days learning a closed skill. Predicts slower initial learning but superior long-term memory consolidation per the Law of Learning.
3. high_engagement_open_skill — Emotionally engaging activities (drama, dance, role-play) for an open skill (team sport). High emotional engagement strongly boosts long-term consolidation. Open skill adds variability.
4. low_engagement_passive_instruction — Traditional passive instruction with minimal kinesthetic involvement. Low emotional engagement and low plasticity growth represent students not matched to their learning style.
5. kinesthetic_game_based_learning — Game-based kinesthetic instruction (Twister, floor Tic-Tac-Toe, role-play) as recommended by Favre (2009). Combines high engagement with moderate spacing.

    PARAMETERS
    ----------
    12 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This source covers kinesthetic (tactile/physical) learning theory, including the VARK model, brain substrates involved in motor skill acquisition, memory consolidation dynamics, and classroom strategies for engaging kinesthetic learners.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.