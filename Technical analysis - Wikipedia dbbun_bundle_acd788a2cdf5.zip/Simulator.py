# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-27T18:07:11.402197Z
# Run ID    : 2d528c9f-a186-449c-b9fe-669897483bae
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Technical Analysis Simulator
Based on: Technical Analysis - Wikipedia

This simulator models the core mechanics of technical analysis applied to synthetic
financial price series, implementing MACD, RSI, Bollinger Bands, ATR, SMA/EMA overlays,
support/resistance levels, OBV, and momentum across five distinct market regimes.
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "sma_short_window": {"value": 20.0, "unit": "periods", "source": "extracted",
                             "description": "Window length for short-term SMA and Bollinger Band center"},
        "sma_long_window": {"value": 50.0, "unit": "periods", "source": "extracted",
                            "description": "Window length for long-term SMA"},
        "ema_fast": {"value": 12.0, "unit": "periods", "source": "extracted",
                     "description": "Fast EMA period for MACD"},
        "ema_slow": {"value": 26.0, "unit": "periods", "source": "extracted",
                     "description": "Slow EMA period for MACD"},
        "macd_signal_period": {"value": 9.0, "unit": "periods", "source": "extracted",
                               "description": "Signal line EMA period for MACD"},
        "rsi_period": {"value": 14.0, "unit": "periods", "source": "extracted",
                       "description": "RSI calculation window"},
        "bb_std_multiplier": {"value": 2.0, "unit": "a.u.", "source": "extracted",
                              "description": "Standard deviations for Bollinger Bands"},
        "atr_period": {"value": 14.0, "unit": "periods", "source": "extracted",
                       "description": "ATR window"},
        "momentum_period": {"value": 10.0, "unit": "periods", "source": "extracted",
                            "description": "Lookback for momentum"},
        "support_resistance_window": {"value": 20.0, "unit": "periods", "source": "extracted",
                                      "description": "Rolling window for support/resistance"},
        "rsi_overbought": {"value": 70.0, "unit": "a.u.", "source": "extracted",
                           "description": "RSI overbought threshold"},
        "rsi_oversold": {"value": 30.0, "unit": "a.u.", "source": "extracted",
                         "description": "RSI oversold threshold"},
        "base_drift": {"value": 0.0003, "unit": "per period", "source": "assumed",
                       "description": "Base daily drift rate (mu) for GBM"},
        "base_volatility": {"value": 0.015, "unit": "per period", "source": "assumed",
                            "description": "Base daily volatility (sigma) for GBM"},
        "trend_strength": {"value": 0.002, "unit": "per period", "source": "assumed",
                           "description": "Additional drift during trend state"},
        "mean_reversion_speed": {"value": 0.05, "unit": "per period", "source": "assumed",
                                 "description": "Speed of mean reversion in sideways regime"},
        "volume_trend_factor": {"value": 1.5, "unit": "a.u.", "source": "assumed",
                                "description": "Volume multiplier during breakout events"},
        "transaction_cost": {"value": 0.005, "unit": "a.u.", "source": "extracted",
                             "description": "Round-trip transaction cost fraction"},
        "n_steps": {"value": 500.0, "unit": "periods", "source": "assumed",
                    "description": "Total simulation time steps"},
        "seed": {"value": 42.0, "unit": "a.u.", "source": "assumed",
                 "description": "Random seed for reproducibility"},
    },
    "scenarios": [
        {
            "label": "uptrend_low_volatility",
            "description": "Bull market with sustained uptrend and low volatility",
            "param_overrides": {"base_drift": 0.0008, "base_volatility": 0.008, "trend_strength": 0.003}
        },
        {
            "label": "downtrend_high_volatility",
            "description": "Bear market with sustained downtrend and high volatility",
            "param_overrides": {"base_drift": -0.0006, "base_volatility": 0.022, "trend_strength": -0.002}
        },
        {
            "label": "sideways_mean_reverting",
            "description": "Sideways market with strong mean reversion",
            "param_overrides": {"base_drift": 0.0, "base_volatility": 0.010,
                                "mean_reversion_speed": 0.12, "trend_strength": 0.0}
        },
        {
            "label": "trend_reversal_pattern",
            "description": "Market transitioning from uptrend to downtrend at step 250",
            "param_overrides": {"base_drift": 0.0005, "base_volatility": 0.014, "trend_strength": 0.002}
        },
        {
            "label": "high_volatility_breakout",
            "description": "Volatile market with periodic breakout events",
            "param_overrides": {"base_drift": 0.0002, "base_volatility": 0.025,
                                "volume_trend_factor": 2.5, "trend_strength": 0.004}
        }
    ]
}

SCENARIO_COLORS = ['#1f77b4', '#d62728', '#2ca02c', '#ff7f0e', '#9467bd']


def get_params(scenario_idx: int) -> Dict[str, float]:
    """Get merged parameters for a given scenario."""
    base = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    overrides = MODEL_PROFILE["scenarios"][scenario_idx]["param_overrides"]
    base.update(overrides)
    return base


def rolling_mean(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling mean; fill early values with expanding mean."""
    result = np.zeros(len(arr))
    for i in range(len(arr)):
        start = max(0, i - window + 1)
        result[i] = np.mean(arr[start:i+1])
    return result


def rolling_std(arr: np.ndarray, window: int) -> np.ndarray:
    """Compute rolling std; fill early values with expanding std."""
    result = np.zeros(len(arr))
    for i in range(len(arr)):
        start = max(0, i - window + 1)
        if i - start + 1 < 2:
            result[i] = 0.0
        else:
            result[i] = np.std(arr[start:i+1], ddof=0)
    return result


def rolling_min(arr: np.ndarray, window: int) -> np.ndarray:
    result = np.zeros(len(arr))
    for i in range(len(arr)):
        start = max(0, i - window + 1)
        result[i] = np.min(arr[start:i+1])
    return result


def rolling_max(arr: np.ndarray, window: int) -> np.ndarray:
    result = np.zeros(len(arr))
    for i in range(len(arr)):
        start = max(0, i - window + 1)
        result[i] = np.max(arr[start:i+1])
    return result


def run_scenario(scenario_idx: int) -> Dict[str, np.ndarray]:
    """Run full simulation for a single scenario, return all arrays."""
    np.random.seed(scenario_idx)
    params = get_params(scenario_idx)
    label = MODEL_PROFILE["scenarios"][scenario_idx]["label"]

    N = int(params["n_steps"])
    base_drift = params["base_drift"]
    base_vol = params["base_volatility"]
    trend_strength = params["trend_strength"]
    mean_rev_speed = params["mean_reversion_speed"]
    vol_trend_factor = params["volume_trend_factor"]
    transaction_cost = params["transaction_cost"]
    rsi_overbought = params["rsi_overbought"]
    rsi_oversold = params["rsi_oversold"]
    sma_short = int(params["sma_short_window"])
    sma_long = int(params["sma_long_window"])
    sr_window = int(params["support_resistance_window"])
    atr_period = int(params["atr_period"])
    rsi_period = int(params["rsi_period"])
    momentum_period = int(params["momentum_period"])
    bb_mult = params["bb_std_multiplier"]
    base_volume = 1_000_000.0

    # ------------------------------------------------
    # Step 1: Price series generation (GBM + regime)
    # ------------------------------------------------
    price = np.zeros(N)
    high_arr = np.zeros(N)
    low_arr = np.zeros(N)
    open_arr = np.zeros(N)
    volume_arr = np.zeros(N)

    price[0] = 100.0
    high_arr[0] = 101.0
    low_arr[0] = 99.0
    open_arr[0] = 100.0
    volume_arr[0] = base_volume

    # Pre-generate epsilons
    epsilons = np.random.normal(0, 1, N)
    open_epsilons = np.random.normal(0, 1, N)

    # Running SMA approximations for trend detection during price generation
    # We'll use simple expanding windows during generation
    sma20_run = np.zeros(N)
    sma50_run = np.zeros(N)
    sma20_run[0] = price[0]
    sma50_run[0] = price[0]

    # Track current drift (for trend reversal scenario)
    current_drift = base_drift

    for t in range(1, N):
        # Trend reversal: flip drift at step 250
        if label == "trend_reversal_pattern" and t == 250:
            current_drift = -abs(base_drift)

        # Breakout event for high_volatility_breakout
        vol_bump = False
        if label == "high_volatility_breakout":
            # Breakout every ~50 steps
            if t % 50 == 0:
                vol_bump = True

        vol_t = base_vol * vol_trend_factor if vol_bump else base_vol

        # Trend detection from running SMAs
        if sma20_run[t-1] > sma50_run[t-1] + 0.5:
            trend_state_t = 1
        elif sma20_run[t-1] < sma50_run[t-1] - 0.5:
            trend_state_t = -1
        else:
            trend_state_t = 0

        # Effective drift
        mu_eff = current_drift + trend_state_t * trend_strength
        if trend_state_t == 0:
            # Mean reversion
            if price[t-1] > 0:
                mu_eff -= mean_rev_speed * (price[t-1] - sma20_run[t-1]) / price[t-1]

        eps = epsilons[t]
        raw_price = price[t-1] * np.exp(mu_eff - 0.5 * vol_t**2 + vol_t * eps)

        # Clamp price to valid range
        price[t] = float(np.clip(raw_price, 50.0, 200.0))

        # Synthetic OHLC
        intraday_range = price[t] * vol_t * np.sqrt(1.0/252.0) * 2.0
        high_arr[t] = price[t] + 0.5 * abs(eps) * intraday_range
        low_arr[t] = price[t] - 0.5 * abs(eps) * intraday_range
        open_raw = price[t-1] * np.exp(open_epsilons[t] * vol_t * 0.3)
        open_arr[t] = float(np.clip(open_raw, 50.0, 200.0))

        # Volume
        vol_factor = vol_trend_factor if vol_bump else 1.0
        volume_arr[t] = float(np.clip(base_volume * vol_factor * abs(1.0 + 0.5*eps),
                                       100_000.0, 5_000_000.0))

        # Update running SMAs
        start20 = max(0, t - sma_short + 1)
        sma20_run[t] = np.mean(price[start20:t+1])
        start50 = max(0, t - sma_long + 1)
        sma50_run[t] = np.mean(price[start50:t+1])

    # ------------------------------------------------
    # Step 2: Moving Averages (full vectorized computation)
    # ------------------------------------------------
    sma_20 = rolling_mean(price, sma_short)
    sma_50 = rolling_mean(price, sma_long)

    # Clamp SMAs
    sma_20 = np.clip(sma_20, 50.0, 200.0)
    sma_50 = np.clip(sma_50, 50.0, 200.0)

    alpha_12 = 2.0 / (12.0 + 1.0)
    alpha_26 = 2.0 / (26.0 + 1.0)
    alpha_9 = 2.0 / (9.0 + 1.0)

    ema_12 = np.zeros(N)
    ema_26 = np.zeros(N)
    ema_12[0] = price[0]
    ema_26[0] = price[0]
    for t in range(1, N):
        ema_12[t] = alpha_12 * price[t] + (1.0 - alpha_12) * ema_12[t-1]
        ema_26[t] = alpha_26 * price[t] + (1.0 - alpha_26) * ema_26[t-1]

    ema_12 = np.clip(ema_12, 50.0, 200.0)
    ema_26 = np.clip(ema_26, 50.0, 200.0)

    macd_line = ema_12 - ema_26
    macd_line = np.clip(macd_line, -10.0, 10.0)

    macd_signal_arr = np.zeros(N)
    macd_signal_arr[0] = macd_line[0]
    for t in range(1, N):
        macd_signal_arr[t] = alpha_9 * macd_line[t] + (1.0 - alpha_9) * macd_signal_arr[t-1]
    macd_signal_arr = np.clip(macd_signal_arr, -10.0, 10.0)

    macd_histogram = macd_line - macd_signal_arr
    macd_histogram = np.clip(macd_histogram, -5.0, 5.0)

    # ------------------------------------------------
    # Step 3: RSI (14-period Wilder smoothing)
    # ------------------------------------------------
    delta = np.diff(price, prepend=price[0])  # length N
    gains = np.maximum(delta, 0.0)
    losses = np.abs(np.minimum(delta, 0.0))

    avg_gain = np.zeros(N)
    avg_loss = np.zeros(N)
    rsi_arr = np.full(N, 50.0)

    # Seed at period rsi_period - 1
    seed_idx = rsi_period - 1
    if seed_idx < N:
        avg_gain[seed_idx] = np.mean(gains[0:rsi_period])
        avg_loss[seed_idx] = np.mean(losses[0:rsi_period])
        rs = avg_gain[seed_idx] / (avg_loss[seed_idx] + 1e-9)
        rsi_arr[seed_idx] = 100.0 - 100.0 / (1.0 + rs)

        for t in range(seed_idx + 1, N):
            avg_gain[t] = (avg_gain[t-1] * (rsi_period - 1) + gains[t]) / rsi_period
            avg_loss[t] = (avg_loss[t-1] * (rsi_period - 1) + losses[t]) / rsi_period
            rs = avg_gain[t] / (avg_loss[t] + 1e-9)
            rsi_arr[t] = 100.0 - 100.0 / (1.0 + rs)

    rsi_arr = np.clip(rsi_arr, 0.0, 100.0)

    # ------------------------------------------------
    # Step 4: Bollinger Bands
    # ------------------------------------------------
    roll_std_20 = rolling_std(price, sma_short)
    bb_upper = sma_20 + bb_mult * roll_std_20
    bb_lower = sma_20 - bb_mult * roll_std_20
    bb_upper = np.clip(bb_upper, 50.0, 220.0)
    bb_lower = np.clip(bb_lower, 30.0, 180.0)
    bb_width = np.where(sma_20 > 0, (bb_upper - bb_lower) / sma_20, 0.1)
    bb_width = np.clip(bb_width, 0.0, 0.5)

    # ------------------------------------------------
    # Step 5: ATR (14-period)
    # ------------------------------------------------
    true_range = np.zeros(N)
    true_range[0] = high_arr[0] - low_arr[0]
    for t in range(1, N):
        tr1 = high_arr[t] - low_arr[t]
        tr2 = abs(high_arr[t] - price[t-1])
        tr3 = abs(low_arr[t] - price[t-1])
        true_range[t] = max(tr1, tr2, tr3)

    atr_arr = np.full(N, 2.0)
    atr_seed = atr_period - 1
    if atr_seed < N:
        atr_arr[atr_seed] = np.mean(true_range[0:atr_period])
        for t in range(atr_seed + 1, N):
            atr_arr[t] = (atr_arr[t-1] * (atr_period - 1) + true_range[t]) / atr_period

    atr_arr = np.clip(atr_arr, 0.1, 20.0)

    # ------------------------------------------------
    # Step 6: Momentum & OBV
    # ------------------------------------------------
    momentum_arr = np.zeros(N)
    for t in range(N):
        if t >= momentum_period:
            mom = price[t] - price[t - momentum_period]
            momentum_arr[t] = float(np.clip(mom, -20.0, 20.0))

    obv_arr = np.zeros(N)
    for t in range(1, N):
        if price[t] > price[t-1]:
            obv_arr[t] = obv_arr[t-1] + volume_arr[t]
        elif price[t] < price[t-1]:
            obv_arr[t] = obv_arr[t-1] - volume_arr[t]
        else:
            obv_arr[t] = obv_arr[t-1]
    obv_arr = np.clip(obv_arr, -100_000_000.0, 100_000_000.0)

    # ------------------------------------------------
    # Step 7: Support & Resistance
    # ------------------------------------------------
    support_level = rolling_min(price, sr_window)
    resistance_level = rolling_max(price, sr_window)
    support_level = np.clip(support_level, 40.0, 190.0)
    resistance_level = np.clip(resistance_level, 60.0, 210.0)

    # ------------------------------------------------
    # Step 8: Trend State
    # ------------------------------------------------
    diff_sma = sma_20 - sma_50
    trend_state_arr = np.where(diff_sma > 0.5, 1.0,
                               np.where(diff_sma < -0.5, -1.0, 0.0))

    # ------------------------------------------------
    # Step 9: Composite Trading Signal
    # ------------------------------------------------
    signal_arr = np.zeros(N)
    for t in range(1, N):
        # MACD crossover conditions
        buy_macd = (macd_histogram[t] > 0) and (macd_histogram[t-1] <= 0) and (rsi_arr[t] < 60.0)
        sell_macd = (macd_histogram[t] < 0) and (macd_histogram[t-1] >= 0) and (rsi_arr[t] > 40.0)
        # RSI override
        buy_rsi = rsi_arr[t] < rsi_oversold
        sell_rsi = rsi_arr[t] > rsi_overbought

        if buy_macd or buy_rsi:
            signal_arr[t] = 1.0
        elif sell_macd or sell_rsi:
            signal_arr[t] = -1.0
        else:
            signal_arr[t] = 0.0

    # ------------------------------------------------
    # Step 10: Portfolio Simulation
    # ------------------------------------------------
    portfolio_value = np.zeros(N)
    buy_hold_value = np.zeros(N)
    drawdown_arr = np.zeros(N)
    cumulative_return = np.zeros(N)
    position_arr = np.zeros(N)

    initial_portfolio = 10000.0
    cash = initial_portfolio
    shares = 0.0
    position = 0
    peak = initial_portfolio
    portfolio_value[0] = initial_portfolio

    for t in range(1, N):
        sig = signal_arr[t]
        if sig == 1.0 and position == 0:
            shares = cash * (1.0 - transaction_cost) / price[t]
            cash = 0.0
            position = 1
        elif sig == -1.0 and position == 1:
            cash = shares * price[t] * (1.0 - transaction_cost)
            shares = 0.0
            position = 0

        pv = cash + shares * price[t]
        portfolio_value[t] = float(np.clip(pv, 0.0, 100_000.0))
        peak = max(peak, portfolio_value[t])
        dd = (portfolio_value[t] - peak) / peak if peak > 0 else 0.0
        drawdown_arr[t] = float(np.clip(dd, -1.0, 0.0))
        buy_hold_value[t] = float(np.clip(10000.0 * price[t] / price[0], 0.0, 100_000.0))
        cumulative_return[t] = (portfolio_value[t] - initial_portfolio) / initial_portfolio
        position_arr[t] = float(position)

    # Handle t=0 for buy_hold
    buy_hold_value[0] = 10000.0

    # Daily returns
    daily_return = np.zeros(N)
    log_return = np.zeros(N)
    for t in range(1, N):
        if price[t-1] > 0:
            daily_return[t] = (price[t] - price[t-1]) / price[t-1]
            log_return[t] = float(np.log(price[t] / price[t-1]))

    return {
        "time_step": np.arange(N),
        "price": price,
        "open_price": open_arr,
        "high_price": high_arr,
        "low_price": low_arr,
        "volume": volume_arr,
        "daily_return": daily_return,
        "log_return": log_return,
        "sma_20": sma_20,
        "sma_50": sma_50,
        "ema_12": ema_12,
        "ema_26": ema_26,
        "macd_line": macd_line,
        "macd_signal": macd_signal_arr,
        "macd_histogram": macd_histogram,
        "rsi": rsi_arr,
        "bb_upper": bb_upper,
        "bb_lower": bb_lower,
        "bb_width": bb_width,
        "atr": atr_arr,
        "momentum": momentum_arr,
        "obv": obv_arr,
        "support_level": support_level,
        "resistance_level": resistance_level,
        "trend_state": trend_state_arr,
        "signal": signal_arr,
        "position": position_arr,
        "portfolio_value": portfolio_value,
        "buy_hold_value": buy_hold_value,
        "drawdown": drawdown_arr,
        "cumulative_return": cumulative_return,
    }


def compute_scenario_summary(label: str, data: Dict[str, np.ndarray]) -> Dict[str, Any]:
    """Compute aggregate metrics for one scenario."""
    pv = data["portfolio_value"]
    bh = data["buy_hold_value"]
    rsi = data["rsi"]
    atr = data["atr"]
    macd = data["macd_line"]
    sig = data["signal"]
    dd = data["drawdown"]
    lr = data["log_return"]

    total_return = (pv[-1] - 10000.0) / 10000.0
    bh_return = (bh[-1] - 10000.0) / 10000.0
    max_drawdown = float(np.min(dd))

    # Sharpe ratio (annualized, approx)
    daily_pnl = np.diff(pv)
    if len(daily_pnl) > 1 and np.std(daily_pnl) > 0:
        sharpe = float(np.mean(daily_pnl) / np.std(daily_pnl) * np.sqrt(252))
    else:
        sharpe = 0.0

    # Win rate: fraction of non-zero signals that are buys
    n_signals = int(np.sum(np.abs(sig) > 0))
    n_buys = int(np.sum(sig > 0))
    win_rate = float(n_buys / n_signals) if n_signals > 0 else 0.5

    return {
        "scenario": label,
        "total_return": round(total_return, 4),
        "buy_hold_return": round(bh_return, 4),
        "max_drawdown": round(max_drawdown, 4),
        "sharpe_ratio": round(sharpe, 4),
        "win_rate": round(win_rate, 4),
        "n_signals": n_signals,
        "mean_rsi": round(float(np.mean(rsi)), 4),
        "std_rsi": round(float(np.std(rsi)), 4),
        "min_rsi": round(float(np.min(rsi)), 4),
        "max_rsi": round(float(np.max(rsi)), 4),
        "mean_atr": round(float(np.mean(atr)), 4),
        "std_atr": round(float(np.std(atr)), 4),
        "min_atr": round(float(np.min(atr)), 4),
        "max_atr": round(float(np.max(atr)), 4),
        "mean_price": round(float(np.mean(data["price"])), 4),
        "std_price": round(float(np.std(data["price"])), 4),
        "min_price": round(float(np.min(data["price"])), 4),
        "max_price": round(float(np.max(data["price"])), 4),
        "mean_macd": round(float(np.mean(macd)), 4),
        "mean_volume": round(float(np.mean(data["volume"])), 2),
        "mean_log_return": round(float(np.mean(lr[1:])), 6),
        "std_log_return": round(float(np.std(lr[1:])), 6),
        "final_portfolio_value": round(float(pv[-1]), 2),
        "final_buy_hold_value": round(float(bh[-1]), 2),
    }


# ============================================================
# Figure generation
# ============================================================

def save_fig1_price_support_resistance(all_data: List[Dict], labels: List[str],
                                        output_dir: pathlib.Path) -> None:
    """Fig1: Price series with support and resistance levels (subplots per scenario)."""
    try:
        fig, axes = plt.subplots(5, 1, figsize=(14, 18), sharex=False)
        fig.suptitle("Simulated Price Series with Support and Resistance Levels", fontsize=14)
        for i, (data, label) in enumerate(zip(all_data, labels)):
            ax = axes[i]
            x = data["time_step"]
            y_price = data["price"]
            y_sup = data["support_level"]
            y_res = data["resistance_level"]
            assert len(x) == len(y_price) == len(y_sup) == len(y_res)
            ax.plot(x, y_price, color=SCENARIO_COLORS[i], linewidth=1.2, label="Price")
            ax.fill_between(x, y_sup, y_res, alpha=0.15, color=SCENARIO_COLORS[i],
                            label="Support-Resistance Band")
            ax.plot(x, y_sup, '--', color='green', linewidth=0.8, alpha=0.7, label="Support")
            ax.plot(x, y_res, '--', color='red', linewidth=0.8, alpha=0.7, label="Resistance")
            ax.set_title(label.replace("_", " ").title(), fontsize=10)
            ax.set_ylabel("Price (USD)")
            ax.legend(fontsize=7, loc="upper left")
            ax.grid(True, alpha=0.3)
        axes[-1].set_xlabel("Time Step")
        plt.tight_layout()
        fig.savefig(output_dir / "fig1_price_support_resistance.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig1_price_support_resistance.png")
    except Exception as e:
        print(f"Warning: fig1 failed: {e}")


def save_fig2_bollinger_bands(all_data: List[Dict], labels: List[str],
                               output_dir: pathlib.Path) -> None:
    """Fig2: Price with Bollinger Bands and SMA overlays."""
    try:
        fig, axes = plt.subplots(5, 1, figsize=(14, 18), sharex=False)
        fig.suptitle("Price with Bollinger Bands and SMA Overlays", fontsize=14)
        for i, (data, label) in enumerate(zip(all_data, labels)):
            ax = axes[i]
            x = data["time_step"]
            y_p = data["price"]
            y_sma = data["sma_20"]
            y_up = data["bb_upper"]
            y_lo = data["bb_lower"]
            assert len(x) == len(y_p) == len(y_sma) == len(y_up) == len(y_lo)
            ax.plot(x, y_p, color=SCENARIO_COLORS[i], linewidth=1.0, label="Close")
            ax.plot(x, y_sma, color='orange', linewidth=1.2, label="SMA-20")
            ax.plot(x, y_up, color='purple', linewidth=0.9, linestyle='--', label="BB Upper")
            ax.plot(x, y_lo, color='purple', linewidth=0.9, linestyle='--', label="BB Lower")
            ax.fill_between(x, y_lo, y_up, alpha=0.08, color='purple')
            ax.set_title(label.replace("_", " ").title(), fontsize=10)
            ax.set_ylabel("Price (USD)")
            ax.legend(fontsize=7, loc="upper left")
            ax.grid(True, alpha=0.3)
        axes[-1].set_xlabel("Time Step")
        plt.tight_layout()
        fig.savefig(output_dir / "fig2_bollinger_bands.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig2_bollinger_bands.png")
    except Exception as e:
        print(f"Warning: fig2 failed: {e}")


def save_fig3_macd(all_data: List[Dict], labels: List[str], output_dir: pathlib.Path) -> None:
    """Fig3: MACD, Signal Line, and Histogram for each scenario."""
    try:
        fig, axes = plt.subplots(5, 2, figsize=(16, 18))
        fig.suptitle("MACD, Signal Line, and Histogram", fontsize=14)
        for i, (data, label) in enumerate(zip(all_data, labels)):
            ax_top = axes[i, 0]
            ax_bot = axes[i, 1]
            x = data["time_step"]
            y_macd = data["macd_line"]
            y_sig = data["macd_signal"]
            y_hist = data["macd_histogram"]
            assert len(x) == len(y_macd) == len(y_sig) == len(y_hist)
            ax_top.plot(x, y_macd, color=SCENARIO_COLORS[i], linewidth=1.0, label="MACD")
            ax_top.plot(x, y_sig, color='black', linewidth=0.8, linestyle='--', label="Signal")
            ax_top.axhline(0, color='gray', linewidth=0.5, linestyle=':')
            ax_top.set_title(f"{label.replace('_', ' ').title()} - MACD", fontsize=9)
            ax_top.set_ylabel("USD")
            ax_top.legend(fontsize=7)
            ax_top.grid(True, alpha=0.3)
            # Histogram with color coding
            colors_hist = np.where(y_hist >= 0, '#2ca02c', '#d62728')
            ax_bot.bar(x, y_hist, color=colors_hist, width=1.0, alpha=0.7)
            ax_bot.axhline(0, color='gray', linewidth=0.5, linestyle=':')
            ax_bot.set_title(f"{label.replace('_', ' ').title()} - Histogram", fontsize=9)
            ax_bot.set_ylabel("USD")
            ax_bot.set_xlabel("Time Step")
            ax_bot.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig3_macd.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig3_macd.png")
    except Exception as e:
        print(f"Warning: fig3 failed: {e}")


def save_fig4_rsi(all_data: List[Dict], labels: List[str], output_dir: pathlib.Path) -> None:
    """Fig4: RSI across scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(14, 7))
        ax.set_title("Relative Strength Index (RSI-14) Across Scenarios", fontsize=14)
        for i, (data, label) in enumerate(zip(all_data, labels)):
            x = data["time_step"]
            y = data["rsi"]
            assert len(x) == len(y)
            ax.plot(x, y, color=SCENARIO_COLORS[i], linewidth=1.0,
                    label=label.replace("_", " ").title(), alpha=0.85)
        ax.axhline(70, color='red', linewidth=1.5, linestyle='--', label="Overbought (70)")
        ax.axhline(30, color='green', linewidth=1.5, linestyle='--', label="Oversold (30)")
        ax.axhline(50, color='gray', linewidth=0.8, linestyle=':', alpha=0.5)
        ax.set_xlabel("Time Step")
        ax.set_ylabel("RSI (a.u.)")
        ax.set_ylim(0, 100)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig4_rsi.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig4_rsi.png")
    except Exception as e:
        print(f"Warning: fig4 failed: {e}")


def save_fig5_portfolio(all_data: List[Dict], labels: List[str], output_dir: pathlib.Path) -> None:
    """Fig5: Portfolio value vs buy-and-hold."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(16, 7))
        axes[0].set_title("Technical Strategy Portfolio Value", fontsize=12)
        axes[1].set_title("Buy-and-Hold Portfolio Value", fontsize=12)
        for i, (data, label) in enumerate(zip(all_data, labels)):
            x = data["time_step"]
            y_pv = data["portfolio_value"]
            y_bh = data["buy_hold_value"]
            assert len(x) == len(y_pv) == len(y_bh)
            lbl = label.replace("_", " ").title()
            axes[0].plot(x, y_pv, color=SCENARIO_COLORS[i], linewidth=1.2, label=lbl)
            axes[1].plot(x, y_bh, color=SCENARIO_COLORS[i], linewidth=1.2,
                         linestyle='--', label=lbl)
        for ax in axes:
            ax.axhline(10000, color='black', linewidth=0.8, linestyle=':', alpha=0.5,
                       label="Initial (10000)")
            ax.set_xlabel("Time Step")
            ax.set_ylabel("Portfolio Value (USD)")
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
        plt.suptitle("Portfolio Value: Technical Strategy vs. Buy-and-Hold", fontsize=14)
        plt.tight_layout()
        fig.savefig(output_dir / "fig5_portfolio.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig5_portfolio.png")
    except Exception as e:
        print(f"Warning: fig5 failed: {e}")


def save_fig6_atr(all_data: List[Dict], labels: List[str], output_dir: pathlib.Path) -> None:
    """Fig6: ATR over time."""
    try:
        fig, ax = plt.subplots(figsize=(14, 6))
        ax.set_title("Average True Range (ATR-14): Volatility Over Time", fontsize=14)
        for i, (data, label) in enumerate(zip(all_data, labels)):
            x = data["time_step"]
            y = data["atr"]
            assert len(x) == len(y)
            ax.plot(x, y, color=SCENARIO_COLORS[i], linewidth=1.0,
                    label=label.replace("_", " ").title(), alpha=0.85)
        ax.set_xlabel("Time Step")
        ax.set_ylabel("ATR (USD)")
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig6_atr.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig6_atr.png")
    except Exception as e:
        print(f"Warning: fig6 failed: {e}")


def save_fig7_return_distribution(all_data: List[Dict], labels: List[str],
                                   output_dir: pathlib.Path) -> None:
    """Fig7: Histogram of daily log returns by scenario."""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))
        ax.set_title("Distribution of Daily Returns by Scenario", fontsize=14)

        all_returns = []
        for i, (data, label) in enumerate(zip(all_data, labels)):
            lr = data["log_return"][1:]  # skip t=0
            if len(lr) == 0:
                continue
            all_returns.extend(lr.tolist())
            ax.hist(lr, bins=50, alpha=0.5, color=SCENARIO_COLORS[i],
                    label=label.replace("_", " ").title(), density=True)

        # Normal reference overlay
        if len(all_returns) > 1:
            all_arr = np.array(all_returns)
            mu_all = np.mean(all_arr)
            sigma_all = np.std(all_arr)
            if sigma_all > 0:
                x_norm = np.linspace(mu_all - 4*sigma_all, mu_all + 4*sigma_all, 200)
                y_norm = (1.0 / (sigma_all * np.sqrt(2*np.pi))) * np.exp(
                    -0.5 * ((x_norm - mu_all) / sigma_all)**2)
                assert len(x_norm) == len(y_norm)
                ax.plot(x_norm, y_norm, 'k-', linewidth=2.0, label="Normal Reference")

        ax.set_xlabel("Log Return")
        ax.set_ylabel("Density")
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / "fig7_return_distribution.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig7_return_distribution.png")
    except Exception as e:
        print(f"Warning: fig7 failed: {e}")


def save_fig8_heatmap(summaries: List[Dict], output_dir: pathlib.Path) -> None:
    """Fig8: Performance metrics heatmap."""
    try:
        metrics = [
            "total_return", "buy_hold_return", "max_drawdown", "sharpe_ratio",
            "win_rate", "mean_rsi", "mean_atr", "n_signals", "mean_macd",
            "std_log_return"
        ]
        scenario_labels = [s["scenario"].replace("_", " ").title() for s in summaries]
        metric_labels = [m.replace("_", " ").title() for m in metrics]

        # Build matrix
        mat = np.zeros((len(metrics), len(summaries)))
        for j, s in enumerate(summaries):
            for i, m in enumerate(metrics):
                val = s.get(m, 0.0)
                mat[i, j] = float(val) if val is not None else 0.0

        # Normalize per row for visualization
        mat_norm = np.zeros_like(mat)
        for i in range(len(metrics)):
            row = mat[i, :]
            rng = np.max(row) - np.min(row)
            if rng > 0:
                mat_norm[i, :] = (row - np.min(row)) / rng
            else:
                mat_norm[i, :] = 0.5

        fig, ax = plt.subplots(figsize=(12, 8))
        im = ax.imshow(mat_norm, cmap='RdYlGn', aspect='auto', vmin=0, vmax=1)
        ax.set_xticks(np.arange(len(scenario_labels)))
        ax.set_yticks(np.arange(len(metric_labels)))
        ax.set_xticklabels(scenario_labels, rotation=30, ha='right', fontsize=9)
        ax.set_yticklabels(metric_labels, fontsize=9)
        ax.set_title("Performance Metrics Heatmap: Scenarios vs. Key Statistics", fontsize=13)

        # Annotate with raw values
        for i in range(len(metrics)):
            for j in range(len(summaries)):
                val = mat[i, j]
                txt = f"{val:.3f}" if abs(val) < 1000 else f"{val:.0f}"
                ax.text(j, i, txt, ha='center', va='center', fontsize=7,
                        color='black' if 0.2 < mat_norm[i, j] < 0.8 else 'white')

        plt.colorbar(im, ax=ax, label="Normalized Score")
        plt.tight_layout()
        fig.savefig(output_dir / "fig8_heatmap.png", dpi=100, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig8_heatmap.png")
    except Exception as e:
        print(f"Warning: fig8 failed: {e}")


# ============================================================
# CSV writers
# ============================================================

def write_simulation_outputs(all_data: List[Dict], labels: List[str],
                              output_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv with all scenario data combined."""
    schema = [
        "time_step", "scenario", "price", "open_price", "high_price", "low_price",
        "volume", "daily_return", "log_return", "sma_20", "sma_50", "ema_12", "ema_26",
        "macd_line", "macd_signal", "macd_histogram", "rsi", "bb_upper", "bb_lower",
        "bb_width", "atr", "momentum", "obv", "support_level", "resistance_level",
        "trend_state", "signal", "position", "portfolio_value", "buy_hold_value",
        "drawdown", "cumulative_return"
    ]
    rows = []
    for data, label in zip(all_data, labels):
        N = len(data["time_step"])
        for t in range(N):
            row = {
                "time_step": int(data["time_step"][t]),
                "scenario": label,
                "price": round(float(data["price"][t]), 4),
                "open_price": round(float(data["open_price"][t]), 4),
                "high_price": round(float(data["high_price"][t]), 4),
                "low_price": round(float(data["low_price"][t]), 4),
                "volume": round(float(data["volume"][t]), 2),
                "daily_return": round(float(data["daily_return"][t]), 6),
                "log_return": round(float(data["log_return"][t]), 6),
                "sma_20": round(float(data["sma_20"][t]), 4),
                "sma_50": round(float(data["sma_50"][t]), 4),
                "ema_12": round(float(data["ema_12"][t]), 4),
                "ema_26": round(float(data["ema_26"][t]), 4),
                "macd_line": round(float(data["macd_line"][t]), 4),
                "macd_signal": round(float(data["macd_signal"][t]), 4),
                "macd_histogram": round(float(data["macd_histogram"][t]), 4),
                "rsi": round(float(data["rsi"][t]), 4),
                "bb_upper": round(float(data["bb_upper"][t]), 4),
                "bb_lower": round(float(data["bb_lower"][t]), 4),
                "bb_width": round(float(data["bb_width"][t]), 6),
                "atr": round(float(data["atr"][t]), 4),
                "momentum": round(float(data["momentum"][t]), 4),
                "obv": round(float(data["obv"][t]), 2),
                "support_level": round(float(data["support_level"][t]), 4),
                "resistance_level": round(float(data["resistance_level"][t]), 4),
                "trend_state": float(data["trend_state"][t]),
                "signal": float(data["signal"][t]),
                "position": float(data["position"][t]),
                "portfolio_value": round(float(data["portfolio_value"][t]), 4),
                "buy_hold_value": round(float(data["buy_hold_value"][t]), 4),
                "drawdown": round(float(data["drawdown"][t]), 6),
                "cumulative_return": round(float(data["cumulative_return"][t]), 6),
            }
            rows.append(row)

    if not rows:
        print("Warning: No rows to write to simulation_outputs.csv")
        return

    filepath = output_dir / "simulation_outputs.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=schema)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved simulation_outputs.csv ({len(rows)} rows)")


def write_scenario_summary(summaries: List[Dict], output_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv."""
    if not summaries:
        print("Warning: No summaries to write.")
        return

    fieldnames = list(summaries[0].keys())
    filepath = output_dir / "scenario_summary.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summaries)
    print(f"Saved scenario_summary.csv ({len(summaries)} rows)")


def write_parameters_used(output_dir: pathlib.Path) -> None:
    """Write parameters_used.csv."""
    rows = []
    for name, info in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })

    if not rows:
        print("Warning: No parameters to write.")
        return

    filepath = output_dir / "parameters_used.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved parameters_used.csv ({len(rows)} rows)")


def write_summary_json(summaries: List[Dict], output_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    summary = {
        "title": "Technical Analysis Simulator - Summary",
        "n_scenarios": len(summaries),
        "scenarios": summaries,
        "overall": {
            "mean_total_return": round(float(np.mean([s["total_return"] for s in summaries])), 4),
            "mean_sharpe_ratio": round(float(np.mean([s["sharpe_ratio"] for s in summaries])), 4),
            "mean_max_drawdown": round(float(np.mean([s["max_drawdown"] for s in summaries])), 4),
            "best_scenario_return": max(summaries, key=lambda x: x["total_return"])["scenario"],
            "worst_scenario_return": min(summaries, key=lambda x: x["total_return"])["scenario"],
        }
    }
    filepath = output_dir / "summary.json"
    with open(filepath, "w") as f:
        json.dump(summary, f, indent=2)
    print("Saved summary.json")


# ============================================================
# Main
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Technical Analysis Simulator - synthetic market regime backtester"
    )
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir}")

    # Run all scenarios
    all_data = []
    labels = []
    summaries = []

    for i, scenario in enumerate(MODEL_PROFILE["scenarios"]):
        label = scenario["label"]
        print(f"\nRunning scenario [{i}]: {label}")
        data = run_scenario(i)
        all_data.append(data)
        labels.append(label)
        summary = compute_scenario_summary(label, data)
        summaries.append(summary)
        print(f"  total_return={summary['total_return']:.4f}, "
              f"sharpe={summary['sharpe_ratio']:.4f}, "
              f"max_dd={summary['max_drawdown']:.4f}, "
              f"n_signals={summary['n_signals']}")

    # Generate all figures
    print("\nGenerating figures...")
    save_fig1_price_support_resistance(all_data, labels, output_dir)
    save_fig2_bollinger_bands(all_data, labels, output_dir)
    save_fig3_macd(all_data, labels, output_dir)
    save_fig4_rsi(all_data, labels, output_dir)
    save_fig5_portfolio(all_data, labels, output_dir)
    save_fig6_atr(all_data, labels, output_dir)
    save_fig7_return_distribution(all_data, labels, output_dir)
    save_fig8_heatmap(summaries, output_dir)

    # Write CSV files
    print("\nWriting CSV files...")
    write_simulation_outputs(all_data, labels, output_dir)
    write_scenario_summary(summaries, output_dir)
    write_parameters_used(output_dir)

    # Write JSON summary
    write_summary_json(summaries, output_dir)

    print("\nSimulation complete. All outputs saved to:", output_dir)


if __name__ == "__main__":
    main()