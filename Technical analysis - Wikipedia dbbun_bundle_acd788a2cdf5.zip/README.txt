================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 2d528c9f-a186-449c-b9fe-669897483bae
    Generated   : 2026-04-27  18:07:11 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Technical Analysis - Wikipedia

    CATEGORIES
    ----------
    Financial, Signal Processing, Machine Learning

    KEYWORDS
    --------
    technical analysis, moving average, MACD, RSI, Bollinger Bands, backtesting, price trend, support resistance, trading signal, momentum

    ABSTRACT
    --------
    This simulator models the core mechanics of technical analysis as applied to synthetic financial price series, faithfully reproducing key indicators including MACD, RSI, Bollinger Bands, ATR, SMA/EMA overlays, support/resistance levels, OBV, and momentum across five distinct market regimes (uptrend, downtrend, sideways, trend-reversal, and breakout). Synthetic price data is generated via a Geometric Brownian Motion process with regime-specific drift, volatility, and mean-reversion overlays, producing OHLCV time series that exhibit the characteristic patterns described in technical analysis literature such as lower-high/lower-low sequences, band-walking, and RSI extremes. A composite trading strategy combining MACD crossover and RSI signals is backtested against a buy-and-hold benchmark with 0.5% transaction costs, mirroring the empirical findings reviewed in the source. Researchers can use the simulator to study indicator behavior under different market conditions, while educators can demonstrate how technical signals emerge from price dynamics and students can explore the profitability and limitations of rule-based trading strategies.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Technical analysis - Wikipedia.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    price, volume, sma_20, sma_50, ema_12, ema_26, macd_line, macd_signal, macd_histogram, rsi, bb_upper, bb_lower, bb_width, support_level, resistance_level, atr, obv, momentum, trend_state, signal, portfolio_value, drawdown

    SCENARIOS  (5 total)
    ---------------------------------
        1. uptrend_low_volatility — Sustained uptrend with low volatility simulating a bull market: positive drift, low noise, momentum indicators confirm buy signals
2. downtrend_high_volatility — Sustained downtrend with high volatility simulating a bear market: negative drift, high noise, RSI stays near oversold, series of lower highs and lower lows as described for AOL 2001-2002
3. sideways_mean_reverting — Sideways/flat market with strong mean reversion: price oscillates between support and resistance levels, RSI oscillates between 30 and 70, Bollinger Bands narrow
4. trend_reversal_pattern — Market that transitions from uptrend to downtrend mid-simulation, producing head-and-shoulders and double-top-like patterns; drift switches sign at step 250
5. high_volatility_breakout — Volatile market with periodic breakout events above resistance levels; volume spikes accompany breakouts as described in the breakout definition

    PARAMETERS
    ----------
    20 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    Technical analysis is a methodology for forecasting financial market price directions using historical price and volume data, employing indicators such as moving averages, RSI, MACD, Bollinger Bands, and pattern recognition to identify trends, support/resistance levels, and trading signals.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.