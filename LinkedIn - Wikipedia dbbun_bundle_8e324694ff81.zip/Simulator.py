# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T00:33:17.357064Z
# Run ID    : 9ffa5554-9482-4011-97e0-286eb9e5284c
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
LinkedIn Corporation Growth Simulator
Based on: 'LinkedIn Corporation - Wikipedia'

This simulator models the longitudinal growth dynamics of LinkedIn, the world's
largest professional social networking platform, from its founding in 2003 through
2026. It reproduces logistic membership growth anchored to historical milestones,
revenue scaling, employee headcount trajectories, geographic user distribution,
and demographic breakdowns across multiple scenarios.
"""

import argparse
import csv
import json
import pathlib
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm

# ---------------------------------------------------------------------------
# MODEL PROFILE
# ---------------------------------------------------------------------------
MODEL_PROFILE = {
    "title": "LinkedIn Corporation Growth Simulator",
    "domain": "Professional Social Networking Platform Economics",
    "parameters": {
        "founding_year": {"value": 2003.0, "unit": "year", "source": "extracted",
                          "description": "Year LinkedIn launched publicly (May 5, 2003)"},
        "members_2004": {"value": 1.0, "unit": "millions", "source": "extracted",
                         "description": "LinkedIn members in August 2004"},
        "members_2007": {"value": 10.0, "unit": "millions", "source": "extracted",
                         "description": "LinkedIn members in April 2007"},
        "members_2015": {"value": 400.0, "unit": "millions", "source": "extracted",
                         "description": "LinkedIn members in 2015"},
        "members_2020": {"value": 690.0, "unit": "millions", "source": "extracted",
                         "description": "LinkedIn members in 2020"},
        "members_2021": {"value": 774.0, "unit": "millions", "source": "extracted",
                         "description": "LinkedIn members in September 2021"},
        "members_2023": {"value": 1000.0, "unit": "millions", "source": "extracted",
                         "description": "LinkedIn members in November 2023 (1 billion)"},
        "members_2026": {"value": 1300.0, "unit": "millions", "source": "extracted",
                         "description": "LinkedIn members as of March 2026"},
        "mau_2023": {"value": 310.0, "unit": "millions", "source": "extracted",
                     "description": "Monthly active users in February 2023"},
        "revenue_2021": {"value": 10.3, "unit": "billion USD", "source": "extracted",
                         "description": "LinkedIn annual revenue in 2021"},
        "revenue_2022": {"value": 13.8, "unit": "billion USD", "source": "extracted",
                         "description": "LinkedIn annual revenue in 2022"},
        "revenue_2025": {"value": 17.8, "unit": "billion USD", "source": "extracted",
                         "description": "LinkedIn annual revenue in 2025"},
        "employees_2010": {"value": 500.0, "unit": "persons", "source": "extracted",
                           "description": "Employee count in 2010"},
        "employees_2011": {"value": 2100.0, "unit": "persons", "source": "extracted",
                           "description": "Employee count in 2011"},
        "employees_2024": {"value": 18500.0, "unit": "persons", "source": "extracted",
                           "description": "Employee count in February 2024"},
        "base_growth_rate": {"value": 0.38, "unit": "fraction per year", "source": "assumed",
                             "description": "Baseline annual member growth rate"},
        "saturation_level": {"value": 2000.0, "unit": "millions", "source": "assumed",
                             "description": "Logistic carrying capacity for global professional user base"},
        "premium_growth_rate_2019_2023": {"value": 0.85, "unit": "fraction total", "source": "extracted",
                                           "description": "85% increase in premium subscriptions from 2019 to 2023"},
        "age_share_25_34_final": {"value": 0.334, "unit": "fraction", "source": "extracted",
                                   "description": "Share of users aged 25-34 as of late 2025"},
        "age_share_18_24_final": {"value": 0.205, "unit": "fraction", "source": "extracted",
                                   "description": "Share of users aged 18-24 as of late 2025"},
        "age_share_35_54_final": {"value": 0.159, "unit": "fraction", "source": "extracted",
                                   "description": "Share of users aged 35-54 as of late 2025"},
        "age_share_55_plus_final": {"value": 0.018, "unit": "fraction", "source": "extracted",
                                     "description": "Share of users aged 55+ as of late 2025"},
        "male_share_final": {"value": 0.568, "unit": "fraction", "source": "extracted",
                             "description": "Male user share as of late 2025"},
        "us_users_final": {"value": 230.0, "unit": "millions", "source": "extracted",
                           "description": "US user count as of 2025/2026"},
        "india_users_final": {"value": 130.0, "unit": "millions", "source": "extracted",
                              "description": "India user count as of 2025/2026"},
        "brazil_users_final": {"value": 71.0, "unit": "millions", "source": "extracted",
                               "description": "Brazil user count as of 2025/2026"},
        "ipo_price": {"value": 45.0, "unit": "USD per share", "source": "extracted",
                      "description": "LinkedIn IPO price on May 19, 2011"},
        "ipo_close_price": {"value": 94.25, "unit": "USD per share", "source": "extracted",
                            "description": "LinkedIn first-day IPO closing price"},
        "microsoft_acquisition_price": {"value": 26.2, "unit": "billion USD", "source": "extracted",
                                         "description": "Microsoft acquisition price in December 2016"},
        "logistic_steepness": {"value": 0.45, "unit": "1/year", "source": "assumed",
                               "description": "Logistic growth steepness parameter"},
        "revenue_growth_rate": {"value": 0.28, "unit": "fraction per year", "source": "assumed",
                                "description": "Approximate annual revenue growth rate post-2016"},
        "connections_growth_rate": {"value": 0.12, "unit": "fraction per year", "source": "assumed",
                                    "description": "Annual growth rate of average connections per user"},
        "mau_to_total_ratio": {"value": 0.31, "unit": "fraction", "source": "assumed",
                               "description": "Approximate ratio of monthly active users to total registered members"},
    },
    "scenarios": [
        {
            "label": "historical_baseline",
            "description": "Reproduce historical LinkedIn growth using anchored membership milestones.",
            "param_overrides": {"base_growth_rate": 0.38, "saturation_level": 2000.0, "logistic_steepness": 0.45}
        },
        {
            "label": "accelerated_growth",
            "description": "Network effects double the effective growth rate, aggressive market expansion.",
            "param_overrides": {"base_growth_rate": 0.60, "saturation_level": 2500.0, "logistic_steepness": 0.60}
        },
        {
            "label": "slow_growth_saturation",
            "description": "LinkedIn reaches market saturation earlier due to competition and regulatory restrictions.",
            "param_overrides": {"base_growth_rate": 0.20, "saturation_level": 1200.0, "logistic_steepness": 0.30}
        },
        {
            "label": "premium_subscription_focus",
            "description": "Premium subscription revenue grows significantly faster.",
            "param_overrides": {"premium_growth_rate_2019_2023": 1.50, "revenue_growth_rate": 0.40}
        },
        {
            "label": "post_microsoft_acquisition",
            "description": "Accelerated revenue growth and employee scaling after Microsoft acquisition.",
            "param_overrides": {"base_growth_rate": 0.42, "revenue_growth_rate": 0.35, "saturation_level": 2000.0}
        },
    ]
}

# ---------------------------------------------------------------------------
# DATA ANCHORS
# ---------------------------------------------------------------------------
ANCHORS = {
    2004: 1.0,
    2007: 10.0,
    2015: 400.0,
    2020: 690.0,
    2021: 774.0,
    2023: 1000.0,
    2026: 1300.0,
}

ACQUISITION_EVENTS = [
    (2010, 'mspoke', 0.6),
    (2010, 'ChoiceVendor', 3.9),
    (2011, 'CardMunch', 1.7),
    (2011, 'Connected', None),
    (2011, 'IndexTank', None),
    (2012, 'Rapportive', 15.0),
    (2012, 'SlideShare', 119.0),
    (2013, 'Pulse', 90.0),
    (2014, 'Bright.com', 120.0),
    (2014, 'Newsle', None),
    (2014, 'Bizo', 175.0),
    (2015, 'Careerify', None),
    (2015, 'Refresh.io', None),
    (2015, 'Lynda.com', 1500.0),
    (2015, 'Fliptop', None),
    (2016, 'Connectifier', None),
    (2016, 'PointDrive', None),
    (2018, 'Glint', None),
    (2019, 'Drawbridge', None),
]

ACQUISITION_PRICES = [price for (_, _, price) in ACQUISITION_EVENTS if price is not None]

# ---------------------------------------------------------------------------
# SIMULATION FUNCTIONS
# ---------------------------------------------------------------------------

def logistic_members(t: float, K: float, r: float, t0: float) -> float:
    """Logistic growth model: N(t) = K / (1 + exp(-r*(t-t0)))"""
    val = K / (1.0 + np.exp(-r * (t - t0)))
    return float(np.clip(val, 0.0, 1300.0))


def fit_t0(K: float, r: float) -> float:
    """
    Fit logistic inflection point t0 to minimize error against historical anchors.
    Uses a simple grid search since scipy is not available per import restrictions.
    """
    anchor_years = np.array(list(ANCHORS.keys()), dtype=float)
    anchor_vals = np.array(list(ANCHORS.values()), dtype=float)

    best_t0 = 2014.0
    best_err = float('inf')

    for t0_candidate in np.linspace(2005.0, 2025.0, 1000):
        preds = K / (1.0 + np.exp(-r * (anchor_years - t0_candidate)))
        # Use log-space error to handle wide range of values
        err = np.sum((np.log1p(preds) - np.log1p(anchor_vals)) ** 2)
        if err < best_err:
            best_err = err
            best_t0 = t0_candidate

    return best_t0


def model_revenue(t: float, revenue_growth_rate: float) -> float:
    """Revenue model: exponential interpolation pre-2021, compound growth post-2021."""
    if t < 2011:
        val = 0.0
    elif t <= 2021:
        frac = (t - 2011) / (2021 - 2011)
        val = 0.154 * np.exp(frac * np.log(10.3 / 0.154))
    else:
        val = 10.3 * (1.0 + revenue_growth_rate) ** (t - 2021)
    return float(np.clip(val, 0.0, 20.0))


def model_employees(t: float) -> float:
    """Piecewise linear interpolation with layoff discontinuities."""
    anchor_years = [2003, 2010, 2011, 2024]
    anchor_counts = [50, 500, 2100, 18500]
    count = float(np.interp(t, anchor_years, anchor_counts))
    if 2020 <= t < 2021:
        count -= 960
    if 2023 <= t < 2024:
        count -= 716
    return float(np.clip(count, 0.0, 25000.0))


def model_premium(t: float, premium_growth_rate_total: float) -> float:
    """Premium subscribers model with compound growth from 2019 base."""
    base_2019 = 30.0
    annual_rate = (1.0 + premium_growth_rate_total) ** (1.0 / 4.0) - 1.0
    if t < 2015:
        val = 0.0
    elif t < 2019:
        # Grow backward from 2019 base using same rate
        years_before = t - 2019  # negative
        val = base_2019 * (1.0 + annual_rate) ** years_before
    else:
        val = base_2019 * (1.0 + annual_rate) ** (t - 2019)
    return float(np.clip(val, 0.0, 100.0))


def model_geo(t: float, total_members: float, country: str) -> float:
    """Geographic share model via linear interpolation of shares."""
    if country == 'us':
        share = float(np.interp(t, [2003, 2010, 2026], [0.50, 0.40, 0.177]))
    elif country == 'india':
        share = float(np.interp(t, [2003, 2009, 2026], [0.01, 0.02, 0.100]))
    elif country == 'brazil':
        share = float(np.interp(t, [2003, 2010, 2026], [0.005, 0.01, 0.055]))
    else:
        share = 0.0
    val = total_members * share
    if country == 'us':
        return float(np.clip(val, 0.0, 300.0))
    elif country == 'india':
        return float(np.clip(val, 0.0, 200.0))
    elif country == 'brazil':
        return float(np.clip(val, 0.0, 100.0))
    return val


def model_age_shares(t: float) -> Tuple[float, float, float, float]:
    """Age share model: linear interpolation from uniform 0.25 in 2003 to 2025 targets."""
    t_clamp = min(t, 2025.0)
    frac = max(0.0, (t_clamp - 2003.0) / (2025.0 - 2003.0))
    s25_34 = 0.25 + frac * (0.334 - 0.25)
    s18_24 = 0.25 + frac * (0.205 - 0.25)
    s35_54 = 0.25 + frac * (0.159 - 0.25)
    s55p = 0.25 + frac * (0.018 - 0.25)
    total = s25_34 + s18_24 + s35_54 + s55p
    if total <= 0:
        total = 1.0
    s18_24_n = float(np.clip(s18_24 / total, 0.0, 1.0))
    s25_34_n = float(np.clip(s25_34 / total, 0.0, 1.0))
    s35_54_n = float(np.clip(s35_54 / total, 0.0, 1.0))
    s55p_n = float(np.clip(s55p / total, 0.0, 1.0))
    return s18_24_n, s25_34_n, s35_54_n, s55p_n


def model_connections(t: float, connections_growth_rate: float) -> float:
    """Connections per user: compound growth capped at 500."""
    val = 1.0 * (1.0 + connections_growth_rate) ** (t - 2003.0)
    return float(np.clip(val, 1.0, 500.0))


def model_acquisitions(t: float) -> int:
    """Cumulative acquisitions up to year t."""
    count = sum(1 for (yr, _, _) in ACQUISITION_EVENTS if yr <= t)
    return int(np.clip(count, 0, 25))


# ---------------------------------------------------------------------------
# MAIN SIMULATION
# ---------------------------------------------------------------------------

def run_simulation(scenario_index: int, scenario_cfg: dict) -> List[dict]:
    """Run simulation for a single scenario and return list of row dicts."""
    np.random.seed(scenario_index)

    # Base parameter defaults
    params = {
        "base_growth_rate": 0.38,
        "saturation_level": 2000.0,
        "logistic_steepness": 0.45,
        "revenue_growth_rate": 0.28,
        "connections_growth_rate": 0.12,
        "mau_to_total_ratio": 0.31,
        "premium_growth_rate_2019_2023": 0.85,
    }

    # Apply scenario overrides
    for key, val in scenario_cfg.get("param_overrides", {}).items():
        params[key] = val

    K = params["saturation_level"]
    r = params["logistic_steepness"]
    rev_rate = params["revenue_growth_rate"]
    conn_rate = params["connections_growth_rate"]
    prem_rate = params["premium_growth_rate_2019_2023"]
    mau_ratio = params["mau_to_total_ratio"]

    # Add small noise to mau_ratio per scenario for differentiation
    mau_ratio = mau_ratio * (1.0 + np.random.uniform(-0.02, 0.02))

    # Fit t0
    t0 = fit_t0(K, r)

    years = np.arange(2003, 2027, 1, dtype=float)
    records = []

    for t in years:
        members = logistic_members(t, K, r, t0)
        mau = float(np.clip(mau_ratio * members, 0.0, 500.0))
        revenue = model_revenue(t, rev_rate)
        employees = model_employees(t)
        premium = model_premium(t, prem_rate)
        connections = model_connections(t, conn_rate)
        us = model_geo(t, members, 'us')
        india = model_geo(t, members, 'india')
        brazil = model_geo(t, members, 'brazil')
        s18_24, s25_34, s35_54, s55p = model_age_shares(t)
        male_share = float(np.clip(np.interp(t, [2003.0, 2025.0], [0.60, 0.568]), 0.0, 1.0))
        female_share = float(np.clip(1.0 - male_share, 0.0, 1.0))
        n_acq = model_acquisitions(t)
        rev_per_member = (revenue * 1e9) / (members * 1e6) if members > 0.001 else 0.0
        rev_per_member = float(np.clip(rev_per_member, 0.0, 1e6))
        # IPO share price: 94.25 at 2011, 45.0 leading up, 0 otherwise (use 0 to avoid NaN)
        if t == 2011.0:
            ipo_price = 94.25
        elif t < 2011.0:
            ipo_price = 45.0
        else:
            ipo_price = 94.25  # post-IPO reference price
        logistic_rate = r
        network_effect = float(np.clip(1.0 + np.log1p(members / 100.0), 1.0, 10.0))

        records.append({
            'scenario': scenario_cfg['label'],
            'year': int(t),
            'total_members_millions': round(float(np.clip(members, 0.0, 1300.0)), 4),
            'monthly_active_users_millions': round(float(np.clip(mau, 0.0, 500.0)), 4),
            'annual_revenue_billion_usd': round(float(np.clip(revenue, 0.0, 20.0)), 4),
            'employee_count': int(np.clip(employees, 0, 25000)),
            'premium_subscribers_millions': round(float(np.clip(premium, 0.0, 100.0)), 4),
            'connections_per_user': round(float(np.clip(connections, 1.0, 500.0)), 4),
            'age_share_18_24': round(float(np.clip(s18_24, 0.0, 1.0)), 6),
            'age_share_25_34': round(float(np.clip(s25_34, 0.0, 1.0)), 6),
            'age_share_35_54': round(float(np.clip(s35_54, 0.0, 1.0)), 6),
            'age_share_55_plus': round(float(np.clip(s55p, 0.0, 1.0)), 6),
            'male_share': round(male_share, 6),
            'female_share': round(female_share, 6),
            'us_users_millions': round(float(np.clip(us, 0.0, 300.0)), 4),
            'india_users_millions': round(float(np.clip(india, 0.0, 200.0)), 4),
            'brazil_users_millions': round(float(np.clip(brazil, 0.0, 100.0)), 4),
            'num_acquisitions_cumulative': n_acq,
            'revenue_per_member_usd': round(rev_per_member, 4),
            'ipo_share_price_usd': round(ipo_price, 2),
            'logistic_growth_rate': round(logistic_rate, 4),
            'network_effect_multiplier': round(network_effect, 4),
        })

    return records


# ---------------------------------------------------------------------------
# CSV WRITERS
# ---------------------------------------------------------------------------

def write_simulation_outputs(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv with all scenario data."""
    if not all_records:
        print("WARNING: No simulation records to write.")
        return

    fieldnames = [
        'scenario', 'year', 'total_members_millions', 'monthly_active_users_millions',
        'annual_revenue_billion_usd', 'employee_count', 'premium_subscribers_millions',
        'connections_per_user', 'age_share_18_24', 'age_share_25_34', 'age_share_35_54',
        'age_share_55_plus', 'male_share', 'female_share', 'us_users_millions',
        'india_users_millions', 'brazil_users_millions', 'num_acquisitions_cumulative',
        'revenue_per_member_usd', 'ipo_share_price_usd', 'logistic_growth_rate',
        'network_effect_multiplier'
    ]

    out_path = output_dir / 'simulation_outputs.csv'
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in all_records:
            writer.writerow({k: row.get(k, '') for k in fieldnames})
    print(f"Written: {out_path}")


def write_scenario_summary(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv with aggregate metrics per scenario."""
    if not all_records:
        print("WARNING: No records for scenario summary.")
        return

    scenarios_seen: Dict[str, List[dict]] = {}
    for row in all_records:
        sc = row['scenario']
        if sc not in scenarios_seen:
            scenarios_seen[sc] = []
        scenarios_seen[sc].append(row)

    numeric_fields = [
        'total_members_millions', 'monthly_active_users_millions', 'annual_revenue_billion_usd',
        'employee_count', 'premium_subscribers_millions', 'connections_per_user',
        'us_users_millions', 'india_users_millions', 'brazil_users_millions',
        'revenue_per_member_usd', 'network_effect_multiplier'
    ]

    summary_rows = []
    for sc, rows in scenarios_seen.items():
        summary = {'scenario': sc, 'n_steps': len(rows)}
        for field in numeric_fields:
            vals = np.array([r[field] for r in rows if isinstance(r[field], (int, float))], dtype=float)
            if len(vals) > 0:
                summary[f'{field}_mean'] = round(float(np.mean(vals)), 4)
                summary[f'{field}_std'] = round(float(np.std(vals)), 4)
                summary[f'{field}_min'] = round(float(np.min(vals)), 4)
                summary[f'{field}_max'] = round(float(np.max(vals)), 4)
            else:
                summary[f'{field}_mean'] = 0.0
                summary[f'{field}_std'] = 0.0
                summary[f'{field}_min'] = 0.0
                summary[f'{field}_max'] = 0.0
        summary_rows.append(summary)

    if not summary_rows:
        print("WARNING: No summary rows to write.")
        return

    fieldnames = list(summary_rows[0].keys())
    out_path = output_dir / 'scenario_summary.csv'
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in summary_rows:
            writer.writerow(row)
    print(f"Written: {out_path}")


def write_parameters_used(output_dir: pathlib.Path) -> None:
    """Write parameters_used.csv for reproducibility."""
    params = MODEL_PROFILE['parameters']
    rows = []
    for name, info in params.items():
        rows.append({
            'name': name,
            'value': info['value'],
            'unit': info['unit'],
            'source': info['source'],
            'description': info['description'],
        })

    if not rows:
        print("WARNING: No parameters to write.")
        return

    fieldnames = ['name', 'value', 'unit', 'source', 'description']
    out_path = output_dir / 'parameters_used.csv'
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    print(f"Written: {out_path}")


# ---------------------------------------------------------------------------
# FIGURE GENERATORS
# ---------------------------------------------------------------------------

SCENARIO_COLORS = {
    'historical_baseline': 'steelblue',
    'accelerated_growth': 'forestgreen',
    'slow_growth_saturation': 'firebrick',
    'premium_subscription_focus': 'darkorchid',
    'post_microsoft_acquisition': 'darkorange',
}


def get_scenario_data(all_records: List[dict], scenario_label: str) -> List[dict]:
    return [r for r in all_records if r['scenario'] == scenario_label]


def fig1_members_growth(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 1: LinkedIn Registered Members Growth (2003-2026)"""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))
        scenarios = list(dict.fromkeys(r['scenario'] for r in all_records))

        for sc in scenarios:
            sc_data = get_scenario_data(all_records, sc)
            if not sc_data:
                continue
            years = np.array([r['year'] for r in sc_data], dtype=float)
            members = np.array([r['total_members_millions'] for r in sc_data], dtype=float)
            assert len(years) == len(members), f"Length mismatch in fig1 for {sc}"
            if len(years) == 0:
                continue
            ax.plot(years, members, label=sc.replace('_', ' ').title(),
                    color=SCENARIO_COLORS.get(sc, 'gray'), linewidth=2.5, marker='o', markersize=3)

        # Historical anchors
        anchor_years = list(ANCHORS.keys())
        anchor_vals = list(ANCHORS.values())
        ax.scatter(anchor_years, anchor_vals, s=100, zorder=5, color='black',
                   marker='*', label='Historical Anchors')

        ax.set_xlabel('Year', fontsize=13)
        ax.set_ylabel('Total Members (Millions)', fontsize=13)
        ax.set_title('LinkedIn Registered Members Growth (2003–2026)', fontsize=15, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_xlim(2003, 2026)
        ax.set_ylim(0, None)
        plt.tight_layout()
        out_path = output_dir / 'fig1_members_growth.png'
        plt.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")
        plt.close('all')


def fig2_revenue(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 2: LinkedIn Annual Revenue (2011-2026)"""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))
        scenarios = list(dict.fromkeys(r['scenario'] for r in all_records))

        for sc in scenarios:
            sc_data = [r for r in get_scenario_data(all_records, sc) if r['year'] >= 2011]
            if not sc_data:
                continue
            years = np.array([r['year'] for r in sc_data], dtype=float)
            revenue = np.array([r['annual_revenue_billion_usd'] for r in sc_data], dtype=float)
            assert len(years) == len(revenue), f"Length mismatch in fig2 for {sc}"
            if len(years) == 0:
                continue
            ax.plot(years, revenue, label=sc.replace('_', ' ').title(),
                    color=SCENARIO_COLORS.get(sc, 'gray'), linewidth=2.5, marker='o', markersize=3)

        # Revenue anchors
        rev_anchors_y = [2021, 2022, 2025]
        rev_anchors_v = [10.3, 13.8, 17.8]
        ax.scatter(rev_anchors_y, rev_anchors_v, s=120, zorder=5, color='black',
                   marker='*', label='Historical Revenue Anchors')

        ax.axvline(x=2016, color='gray', linestyle='--', alpha=0.7, label='Microsoft Acquisition (2016)')
        ax.set_xlabel('Year', fontsize=13)
        ax.set_ylabel('Annual Revenue (Billion USD)', fontsize=13)
        ax.set_title('LinkedIn Annual Revenue (2011–2026)', fontsize=15, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_xlim(2011, 2026)
        ax.set_ylim(0, None)
        plt.tight_layout()
        out_path = output_dir / 'fig2_revenue.png'
        plt.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")
        plt.close('all')


def fig3_age_distribution(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 3: LinkedIn User Age Distribution (2025)"""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))

        # Left: Bar chart for 2025 by scenario
        scenarios = list(dict.fromkeys(r['scenario'] for r in all_records))
        age_groups = ['18-24', '25-34', '35-54', '55+']
        age_fields = ['age_share_18_24', 'age_share_25_34', 'age_share_35_54', 'age_share_55_plus']

        ax = axes[0]
        x = np.arange(len(age_groups))
        width = 0.15
        offsets = np.linspace(-(len(scenarios) - 1) * width / 2, (len(scenarios) - 1) * width / 2, len(scenarios))

        for i, sc in enumerate(scenarios):
            sc_2025 = [r for r in get_scenario_data(all_records, sc) if r['year'] == 2025]
            if not sc_2025:
                sc_2025 = [r for r in get_scenario_data(all_records, sc) if r['year'] == 2024]
            if not sc_2025:
                continue
            row = sc_2025[-1]
            vals = np.array([row[f] * 100 for f in age_fields])
            ax.bar(x + offsets[i], vals, width=width * 0.9,
                   label=sc.replace('_', ' ').title(),
                   color=SCENARIO_COLORS.get(sc, 'gray'), alpha=0.85)

        ax.set_xticks(x)
        ax.set_xticklabels(age_groups, fontsize=12)
        ax.set_xlabel('Age Group', fontsize=13)
        ax.set_ylabel('Percentage Share (%)', fontsize=13)
        ax.set_title('LinkedIn User Age Distribution (2025)\nBy Scenario', fontsize=13, fontweight='bold')
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3, axis='y')

        # Right: Evolution over time (baseline)
        ax2 = axes[1]
        baseline_data = get_scenario_data(all_records, 'historical_baseline')
        if baseline_data:
            years_arr = np.array([r['year'] for r in baseline_data], dtype=float)
            for field, label, color in zip(
                age_fields, age_groups,
                ['royalblue', 'forestgreen', 'darkorange', 'firebrick']
            ):
                vals_arr = np.array([r[field] * 100 for r in baseline_data], dtype=float)
                assert len(years_arr) == len(vals_arr)
                ax2.plot(years_arr, vals_arr, label=label, color=color, linewidth=2.5)
            ax2.set_xlabel('Year', fontsize=13)
            ax2.set_ylabel('Percentage Share (%)', fontsize=13)
            ax2.set_title('Age Share Evolution Over Time\n(Historical Baseline)', fontsize=13, fontweight='bold')
            ax2.legend(fontsize=10)
            ax2.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = output_dir / 'fig3_age_distribution.png'
        plt.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")
        plt.close('all')


def fig4_employee_count(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 4: LinkedIn Employee Count Growth (2003-2024)"""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))
        scenarios = list(dict.fromkeys(r['scenario'] for r in all_records))

        for sc in scenarios:
            sc_data = get_scenario_data(all_records, sc)
            if not sc_data:
                continue
            years = np.array([r['year'] for r in sc_data], dtype=float)
            emp = np.array([r['employee_count'] for r in sc_data], dtype=float)
            assert len(years) == len(emp), f"Length mismatch in fig4 for {sc}"
            if len(years) == 0:
                continue
            ax.plot(years, emp, label=sc.replace('_', ' ').title(),
                    color=SCENARIO_COLORS.get(sc, 'gray'), linewidth=2.5, marker='o', markersize=3)

        # Anchors
        emp_anchor_y = [2010, 2011, 2024]
        emp_anchor_v = [500, 2100, 18500]
        ax.scatter(emp_anchor_y, emp_anchor_v, s=120, zorder=5, color='black',
                   marker='*', label='Historical Anchors')

        # Annotate layoffs
        ax.axvline(x=2020, color='red', linestyle=':', alpha=0.5, label='2020 Layoffs (960)')
        ax.axvline(x=2023, color='darkred', linestyle=':', alpha=0.5, label='2023 Layoffs (716)')

        ax.set_xlabel('Year', fontsize=13)
        ax.set_ylabel('Employee Count', fontsize=13)
        ax.set_title('LinkedIn Employee Count Growth (2003–2024)', fontsize=15, fontweight='bold')
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_xlim(2003, 2026)
        ax.set_ylim(0, None)
        plt.tight_layout()
        out_path = output_dir / 'fig4_employee_count.png'
        plt.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")
        plt.close('all')


def fig5_revenue_vs_members(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 5: Revenue vs. Membership scatter colored by year."""
    try:
        fig, ax = plt.subplots(figsize=(12, 8))
        scenarios = list(dict.fromkeys(r['scenario'] for r in all_records))

        markers = ['o', 's', '^', 'D', 'v']
        all_years_flat = [r['year'] for r in all_records]
        year_min = min(all_years_flat)
        year_max = max(all_years_flat)

        for idx, sc in enumerate(scenarios):
            sc_data = [r for r in get_scenario_data(all_records, sc) if r['year'] >= 2011]
            if not sc_data:
                continue
            members_arr = np.array([r['total_members_millions'] for r in sc_data], dtype=float)
            revenue_arr = np.array([r['annual_revenue_billion_usd'] for r in sc_data], dtype=float)
            years_arr = np.array([r['year'] for r in sc_data], dtype=float)
            assert len(members_arr) == len(revenue_arr) == len(years_arr), f"Shape mismatch fig5 {sc}"
            if len(members_arr) == 0:
                continue
            norm_years = (years_arr - year_min) / max(year_max - year_min, 1)
            colors = plt.cm.viridis(norm_years)
            sc_marker = markers[idx % len(markers)]
            scatter = ax.scatter(members_arr, revenue_arr, c=norm_years, cmap='viridis',
                                 marker=sc_marker, s=60, alpha=0.8, label=sc.replace('_', ' ').title(),
                                 edgecolors='gray', linewidths=0.5)

        sm = plt.cm.ScalarMappable(cmap='viridis',
                                    norm=plt.Normalize(vmin=year_min, vmax=year_max))
        sm.set_array([])
        cbar = plt.colorbar(sm, ax=ax)
        cbar.set_label('Year', fontsize=12)

        ax.set_xlabel('Total Members (Millions)', fontsize=13)
        ax.set_ylabel('Annual Revenue (Billion USD)', fontsize=13)
        ax.set_title('LinkedIn Revenue vs. Membership (Scatter by Year)', fontsize=15, fontweight='bold')
        ax.legend(fontsize=9, loc='upper left')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        out_path = output_dir / 'fig5_revenue_vs_members.png'
        plt.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")
        plt.close('all')


def fig6_geographic_distribution(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 6: Geographic User Distribution: US, India, Brazil."""
    try:
        fig, axes = plt.subplots(1, len(MODEL_PROFILE['scenarios']), figsize=(18, 6), sharey=True)
        scenarios = [s['label'] for s in MODEL_PROFILE['scenarios']]

        for ax_idx, sc in enumerate(scenarios):
            ax = axes[ax_idx] if len(scenarios) > 1 else axes
            sc_data = get_scenario_data(all_records, sc)
            if not sc_data:
                continue
            years = np.array([r['year'] for r in sc_data], dtype=float)
            us_arr = np.array([r['us_users_millions'] for r in sc_data], dtype=float)
            india_arr = np.array([r['india_users_millions'] for r in sc_data], dtype=float)
            brazil_arr = np.array([r['brazil_users_millions'] for r in sc_data], dtype=float)
            assert len(years) == len(us_arr) == len(india_arr) == len(brazil_arr), f"Shape mismatch fig6 {sc}"
            if len(years) == 0:
                continue
            ax.plot(years, us_arr, label='United States', color='steelblue', linewidth=2.5)
            ax.plot(years, india_arr, label='India', color='darkorange', linewidth=2.5)
            ax.plot(years, brazil_arr, label='Brazil', color='forestgreen', linewidth=2.5)
            ax.set_title(sc.replace('_', ' ').title(), fontsize=10, fontweight='bold')
            ax.set_xlabel('Year', fontsize=11)
            if ax_idx == 0:
                ax.set_ylabel('Users (Millions)', fontsize=11)
            ax.legend(fontsize=8)
            ax.grid(True, alpha=0.3)
            ax.set_xlim(2003, 2026)

        fig.suptitle('Geographic User Distribution: US, India, Brazil (2003–2026)',
                     fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        out_path = output_dir / 'fig6_geographic_distribution.png'
        plt.savefig(out_path, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")
        plt.close('all')


def fig7_cumulative_acquisitions(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Fig 7: Cumulative LinkedIn Acquisitions (2010-2019)."""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))

        # Build acquisition step data
        acq_years_range = np.arange(2003, 2027, 1, dtype=float)
        acq_counts = np.array([model_acquisitions(t) for t in acq_years_range], dtype=float)
        assert len(acq_years_range) == len(acq_counts)

        ax.step(acq_years_range, acq_counts, where='post', color='steelblue', linewidth=2.5,
                label='Cumulative Acquisitions')
        ax.fill_between(acq_years_range, acq_counts, step='post', alpha=0.2, color='steelblue')

        # Annotate major acquisitions
        major_acqs = {
            2012: ('SlideShare\n$119M', 2.5),
            2015: ('Lynda.com\n$1.5B', 10.0),
            2014: ('Bizo\n$175M', 7.0),
        }
        for yr, (label, yoff) in major_acqs.items():
            cnt = model_acquisitions(yr)
            ax.annotate(label, xy=(yr, cnt), xytext=(yr + 0.2, cnt + 1.5),
                        fontsize=9, color='firebrick',
                        arrowprops=dict(arrowstyle='->', color='firebrick', lw=1.5))

        ax.set_xlabel('Year', fontsize=13)
        ax.set_ylabel('Cumulative Number of Acquisitions', fontsize=13)
        ax.set_title('Cumulative LinkedIn Acquisitions (2010–2019)', fontsize=15, fontweight='bold')
        ax.set_xlim(2009, 2022)
        ax.set_ylim(0, 22)
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        out_path = output_dir / 'fig7_cumulative_acquisitions.png'
        plt.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")
        plt.close('all')


def fig8_acquisition_prices(output_dir: pathlib.Path) -> None:
    """Fig 8: Distribution of LinkedIn Acquisition Prices."""
    try:
        prices = np.array(ACQUISITION_PRICES, dtype=float)
        if len(prices) == 0:
            print("WARNING: No acquisition prices available for fig8.")
            return

        fig, axes = plt.subplots(1, 2, figsize=(14, 6))

        # Left: full distribution
        ax = axes[0]
        ax.hist(prices, bins=10, color='steelblue', edgecolor='navy', alpha=0.85)
        ax.set_xlabel('Acquisition Price (Million USD)', fontsize=13)
        ax.set_ylabel('Count', fontsize=13)
        ax.set_title('Distribution of LinkedIn\nAcquisition Prices (All)', fontsize=13, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='y')

        # Right: log-scale for skew visualization
        ax2 = axes[1]
        ax2.hist(prices, bins=20, color='darkorchid', edgecolor='indigo', alpha=0.85)
        ax2.set_xscale('log')
        ax2.set_xlabel('Acquisition Price (Million USD, log scale)', fontsize=13)
        ax2.set_ylabel('Count', fontsize=13)
        ax2.set_title('Distribution of LinkedIn\nAcquisition Prices (Log Scale)', fontsize=13, fontweight='bold')
        ax2.grid(True, alpha=0.3, axis='y')

        plt.suptitle('LinkedIn Acquisition Price Distribution', fontsize=14, fontweight='bold')
        plt.tight_layout()
        out_path = output_dir / 'fig8_acquisition_prices.png'
        plt.savefig(out_path, dpi=150)
        plt.close(fig)
        print(f"Saved: {out_path}")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")
        plt.close('all')


# ---------------------------------------------------------------------------
# SUMMARY JSON
# ---------------------------------------------------------------------------

def write_summary_json(all_records: List[dict], output_dir: pathlib.Path) -> None:
    """Write summary.json with aggregate metrics."""
    try:
        scenarios = list(dict.fromkeys(r['scenario'] for r in all_records))
        summary = {
            "simulation_title": "LinkedIn Corporation Growth Simulator",
            "total_records": len(all_records),
            "scenarios": scenarios,
            "years_simulated": list(range(2003, 2027)),
            "scenario_metrics": {}
        }

        for sc in scenarios:
            sc_data = [r for r in all_records if r['scenario'] == sc]
            if not sc_data:
                continue
            final_row = sc_data[-1]
            members_vals = [r['total_members_millions'] for r in sc_data]
            revenue_vals = [r['annual_revenue_billion_usd'] for r in sc_data]
            summary["scenario_metrics"][sc] = {
                "final_year": final_row['year'],
                "final_total_members_millions": final_row['total_members_millions'],
                "final_revenue_billion_usd": final_row['annual_revenue_billion_usd'],
                "final_employee_count": final_row['employee_count'],
                "final_premium_subscribers_millions": final_row['premium_subscribers_millions'],
                "peak_members_millions": max(members_vals),
                "peak_revenue_billion_usd": max(revenue_vals),
                "mean_members_millions": round(float(np.mean(members_vals)), 2),
                "mean_revenue_billion_usd": round(float(np.mean(revenue_vals)), 2),
            }

        out_path = output_dir / 'summary.json'
        with open(out_path, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2)
        print(f"Written: {out_path}")
    except Exception as e:
        print(f"WARNING: summary.json failed: {e}")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description='LinkedIn Corporation Growth Simulator')
    parser.add_argument('--output', type=str, default='./sim_outputs',
                        help='Output directory for all generated files')
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    # Run all scenarios
    all_records: List[dict] = []
    scenarios = MODEL_PROFILE['scenarios']

    for scenario_index, scenario_cfg in enumerate(scenarios):
        print(f"\nRunning scenario [{scenario_index}]: {scenario_cfg['label']}")
        try:
            records = run_simulation(scenario_index, scenario_cfg)
            all_records.extend(records)
            print(f"  -> {len(records)} records generated.")
        except Exception as e:
            print(f"WARNING: Scenario {scenario_cfg['label']} failed: {e}")

    print(f"\nTotal records across all scenarios: {len(all_records)}")

    # Write CSVs
    print("\n--- Writing CSV files ---")
    write_simulation_outputs(all_records, output_dir)
    write_scenario_summary(all_records, output_dir)
    write_parameters_used(output_dir)

    # Generate figures
    print("\n--- Generating figures ---")
    fig1_members_growth(all_records, output_dir)
    fig2_revenue(all_records, output_dir)
    fig3_age_distribution(all_records, output_dir)
    fig4_employee_count(all_records, output_dir)
    fig5_revenue_vs_members(all_records, output_dir)
    fig6_geographic_distribution(all_records, output_dir)
    fig7_cumulative_acquisitions(all_records, output_dir)
    fig8_acquisition_prices(output_dir)

    # Write summary JSON
    print("\n--- Writing summary JSON ---")
    write_summary_json(all_records, output_dir)

    print(f"\nSimulation complete. All outputs in: {output_dir.resolve()}")


if __name__ == "__main__":
    main()