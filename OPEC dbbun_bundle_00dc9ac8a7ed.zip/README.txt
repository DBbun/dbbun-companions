================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : ee7e739b-c576-4ed3-b7f3-e754d1341d93
    Generated   : 2026-04-28  16:14:05 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Organization of the Petroleum Exporting Countries (OPEC) — Historical Oil Market Dynamics

    CATEGORIES
    ----------
    Financial, Power and Energy, Social Sciences, Climate Change/Environmental, Computational Intelligence

    KEYWORDS
    --------
    OPEC, oil price dynamics, cartel compliance, supply-demand model, energy economics

    ABSTRACT
    --------
    This simulator models the global oil market dynamics driven by OPEC's collective production decisions, member compliance behavior, and exogenous geopolitical shocks from 1960 to 2020. It reproduces key historical price events including the 1973 embargo quadrupling, the 1986 Saudi-induced price crash, the 2008 volatility spike to $147/bbl followed by a trough at $32/bbl, the 2014-2016 shale-induced glut, and the 2020 COVID demand collapse. Using coupled difference equations for supply, demand, inventory, and price with scenario-specific compliance rates grounded in Colgan's finding that 96% of OPEC commitments were cheated upon during 1982-2009, the simulator generates synthetic time series that mirror documented boom-bust cycles. Researchers, educators, and energy analysts can use the generated CSV datasets and publication-quality figures to study cartel theory, commodity price dynamics, geopolitical risk modeling, and energy transition scenarios.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    OPEC.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    oil_price, opec_production, opec_quota, non_opec_production, global_demand, compliance_rate, opec_revenue, inventory_surplus, opec_market_share, saudi_production

    SCENARIOS  (7 total)
    ---------------------------------
        1. baseline_historical — Simulate 1960-2020 historical trajectory with all documented shocks (1973 embargo, 1979 crisis, 1986 glut, 2008 spike, 2014-2016 glut, 2020 COVID crash) applied as exogenous impulses at correct dates
2. perfect_cartel_compliance — OPEC members fully comply with all quotas (compliance_rate=1.0), representing an idealized cartel — examine counterfactual price stability
3. high_cheating_opec — Maximum cheating scenario (compliance_rate near zero) representing full prisoner's dilemma outcome — all members maximize individual production
4. shale_revolution_impact — Simulate post-2008 shale boom with large non-OPEC supply shock, representing US fracking effect on OPEC market share and prices
5. demand_destruction_response — Model post-1973 industrial nation response: enhanced energy efficiency reduces baseline demand growth and increases price elasticity of demand
6. saudi_swing_producer — Saudi Arabia acts as active swing producer, adjusting production to stabilize price near target; models 1979-1985 Saudi unilateral cut strategy
7. covid_2020_shock — Apply COVID-19 demand collapse of ~10 mbpd alongside OPEC+ breakdown in March 2020 (production surge), then recovery cut agreement

    PARAMETERS
    ----------
    32 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig10

    DOMAIN SUMMARY
    --------------
    This source covers the history, structure, and market impact of OPEC from its founding in 1960 through 2020, including oil price shocks, production quota dynamics, cartel compliance behavior, and the interplay between OPEC supply decisions and global oil prices.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.