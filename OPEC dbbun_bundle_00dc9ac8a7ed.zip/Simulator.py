# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T16:14:05.386595Z
# Run ID    : ee7e739b-c576-4ed3-b7f3-e754d1341d93
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
OPEC Oil Market Dynamical System Simulator
==========================================
Paper: Organization of the Petroleum Exporting Countries (OPEC) — Historical Oil Market Dynamics

Simulates global oil market dynamics from 1960–2020 across seven behavioral scenarios,
reproducing key historical price events (1973 embargo, 1979 crisis, 1986 Saudi flood,
2008 spike, 2014–2016 glut, 2020 COVID crash) using coupled difference equations for
supply, demand, inventory, compliance, and price.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as cm

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "title": "OPEC Oil Market Dynamical System Simulator",
    "time_start": 1960,
    "time_end": 2020,
    "dt": 1.0,
    "state_variables": {
        "oil_price":            {"init": 3.0,  "range": [5.0,   150.0],  "unit": "USD/bbl"},
        "opec_production":      {"init": 10.0, "range": [10.0,  35.0],   "unit": "mbpd"},
        "opec_quota":           {"init": 10.0, "range": [10.0,  35.0],   "unit": "mbpd"},
        "non_opec_production":  {"init": 15.0, "range": [10.0,  45.0],   "unit": "mbpd"},
        "global_demand":        {"init": 25.0, "range": [20.0,  105.0],  "unit": "mbpd"},
        "compliance_rate":      {"init": 0.5,  "range": [0.0,   1.0],    "unit": "fraction"},
        "opec_revenue":         {"init": 10.0, "range": [0.0,   1200.0], "unit": "billion USD/year"},
        "inventory_surplus":    {"init": 0.0,  "range": [-2.0,  5.0],    "unit": "billion barrels"},
        "opec_market_share":    {"init": 0.5,  "range": [0.2,   0.6],    "unit": "fraction"},
        "saudi_production":     {"init": 3.0,  "range": [3.0,   12.0],   "unit": "mbpd"},
    },
    "parameters": {
        "price_elasticity_demand":          {"value": -0.15, "unit": "dimensionless", "source": "assumed",   "description": "Short-run price elasticity of global oil demand"},
        "price_elasticity_non_opec_supply": {"value": 0.25,  "unit": "dimensionless", "source": "assumed",   "description": "Price elasticity of non-OPEC supply"},
        "price_adjustment_speed":           {"value": 0.35,  "unit": "per year",      "source": "assumed",   "description": "Speed of price adjustment to inventory surplus/shortage"},
        "baseline_demand_growth":           {"value": 0.02,  "unit": "per year",      "source": "extracted", "description": "Annual baseline growth rate of global oil demand"},
        "cheat_rate_baseline":              {"value": 0.96,  "unit": "fraction",      "source": "extracted", "description": "Fraction of OPEC commitments cheated on (Colgan 1982-2009)"},
        "opec_quota_init":                  {"value": 30.0,  "unit": "mbpd",          "source": "extracted", "description": "Reference OPEC production quota in modern era"},
        "embargo_production_cut_fraction":  {"value": 0.25,  "unit": "fraction",      "source": "extracted", "description": "Fraction by which OPEC production was cut during 1973 embargo"},
        "price_1973_pre_embargo":           {"value": 3.0,   "unit": "USD/bbl",       "source": "extracted", "description": "Oil price before 1973 oil embargo"},
        "price_1973_post_embargo":          {"value": 12.0,  "unit": "USD/bbl",       "source": "extracted", "description": "Oil price after 1973 oil embargo"},
        "price_1979_peak":                  {"value": 40.0,  "unit": "USD/bbl",       "source": "extracted", "description": "Oil price peak during 1979-1980 period"},
        "price_1986_crash":                 {"value": 10.0,  "unit": "USD/bbl",       "source": "extracted", "description": "Oil price during 1986 price crash"},
        "price_2008_peak":                  {"value": 147.0, "unit": "USD/bbl",       "source": "extracted", "description": "WTI crude oil record peak in July 2008"},
        "price_2008_trough":                {"value": 32.0,  "unit": "USD/bbl",       "source": "extracted", "description": "WTI crude oil trough in December 2008"},
        "price_2016_trough":                {"value": 22.48, "unit": "USD/bbl",       "source": "extracted", "description": "OPEC Reference Basket low on 20 January 2016"},
        "price_2014_peak":                  {"value": 110.48,"unit": "USD/bbl",       "source": "extracted", "description": "OPEC Reference Basket high in June 2014"},
        "saudi_max_production":             {"value": 10.0,  "unit": "mbpd",          "source": "extracted", "description": "Saudi Arabia maximum production capacity"},
        "saudi_cut_production":             {"value": 3.33,  "unit": "mbpd",          "source": "extracted", "description": "Saudi Arabia production at one-third of maximum in 1985"},
        "opec_revenue_1981":                {"value": 119.0, "unit": "billion USD/year","source": "extracted","description": "Saudi Arabia oil revenue peak in 1981"},
        "opec_revenue_1985":                {"value": 26.0,  "unit": "billion USD/year","source": "extracted","description": "Saudi Arabia oil revenue trough in 1985"},
        "opec_revenue_2008":                {"value": 1000.0,"unit": "billion USD/year","source": "extracted","description": "Estimated OPEC aggregate oil export revenue record in 2008"},
        "opec_market_share_1979":           {"value": 0.50,  "unit": "fraction",      "source": "extracted", "description": "OPEC market share circa 1979"},
        "opec_market_share_1985":           {"value": 0.30,  "unit": "fraction",      "source": "extracted", "description": "OPEC market share below 30% by 1985"},
        "opec_share_global_2022":           {"value": 0.38,  "unit": "fraction",      "source": "extracted", "description": "OPEC share of global oil production in 2022"},
        "opec_proven_reserves_share":       {"value": 0.795, "unit": "fraction",      "source": "extracted", "description": "Fraction of world proven oil reserves held by OPEC"},
        "demand_drop_1986":                 {"value": 5.0,   "unit": "mbpd",          "source": "extracted", "description": "Drop in worldwide daily oil demand by 1986"},
        "opec_cut_2016":                    {"value": 1.0,   "unit": "mbpd",          "source": "extracted", "description": "OPEC production cut agreed in 2016"},
        "opec_cut_2017":                    {"value": 1.8,   "unit": "mbpd",          "source": "extracted", "description": "Total OPEC+ production cut extended through 2018"},
        "covid_demand_shock":               {"value": -10.0, "unit": "mbpd",          "source": "assumed",   "description": "Approximate global demand shock from COVID-19 in 2020"},
        "non_opec_supply_shock_shale":      {"value": 5.0,   "unit": "mbpd",          "source": "extracted", "description": "US production increase from shale fracking"},
        "price_mean_reversion_speed":       {"value": 0.20,  "unit": "per year",      "source": "assumed",   "description": "Speed of price mean reversion toward long-run equilibrium"},
        "long_run_equilibrium_price":       {"value": 60.0,  "unit": "USD/bbl",       "source": "assumed",   "description": "Long-run equilibrium oil price"},
        "dt":                               {"value": 1.0,   "unit": "years",         "source": "assumed",   "description": "Simulation time step in years"},
    },
    "scenarios": [
        {
            "label": "baseline_historical",
            "description": "Historical trajectory 1960-2020 with all documented shocks",
            "param_overrides": {
                "cheat_rate_baseline": 0.96,
                "baseline_demand_growth": 0.02,
                "price_adjustment_speed": 0.35,
            }
        },
        {
            "label": "perfect_cartel_compliance",
            "description": "OPEC members fully comply with all quotas (compliance_rate=1.0)",
            "param_overrides": {
                "cheat_rate_baseline": 0.0,
                "price_adjustment_speed": 0.35,
                "baseline_demand_growth": 0.02,
            }
        },
        {
            "label": "high_cheating_opec",
            "description": "Maximum cheating scenario — all members maximize individual production",
            "param_overrides": {
                "cheat_rate_baseline": 1.0,
                "price_adjustment_speed": 0.35,
                "baseline_demand_growth": 0.02,
            }
        },
        {
            "label": "shale_revolution_impact",
            "description": "Post-2008 shale boom with large non-OPEC supply shock",
            "param_overrides": {
                "non_opec_supply_shock_shale": 8.0,
                "price_elasticity_non_opec_supply": 0.45,
                "cheat_rate_baseline": 0.80,
            }
        },
        {
            "label": "demand_destruction_response",
            "description": "Enhanced energy efficiency — reduced demand growth, higher price elasticity",
            "param_overrides": {
                "baseline_demand_growth": 0.005,
                "price_elasticity_demand": -0.30,
                "cheat_rate_baseline": 0.96,
            }
        },
        {
            "label": "saudi_swing_producer",
            "description": "Saudi Arabia as active swing producer stabilizing price near target",
            "param_overrides": {
                "saudi_max_production": 10.0,
                "saudi_cut_production": 3.33,
                "long_run_equilibrium_price": 30.0,
                "price_mean_reversion_speed": 0.50,
            }
        },
        {
            "label": "covid_2020_shock",
            "description": "COVID-19 demand collapse alongside OPEC+ breakdown then recovery",
            "param_overrides": {
                "covid_demand_shock": -10.0,
                "opec_cut_2016": 9.7,
                "cheat_rate_baseline": 0.60,
            }
        },
    ]
}

# Shock calendar (exogenous events)
SHOCK_CALENDAR = {
    1973: {"demand_mult": 0.85,  "opec_prod_cut": 0.25, "label": "1973 Embargo"},
    1974: {"price_jump": 12.0,                           "label": "Post-embargo price"},
    1979: {"opec_prod_cut": 0.15,                        "label": "Iranian Revolution"},
    1980: {"opec_prod_cut": 0.10,                        "label": "Iran-Iraq War"},
    1986: {"saudi_flood": True,  "price_floor": 10.0,   "label": "1986 Saudi Flood"},
    1990: {"opec_prod_cut": 0.05,                        "label": "Gulf War"},
    1997: {"demand_mult": 0.97,                          "label": "Asian Financial Crisis"},
    2003: {"non_opec_add": 0.5,                          "label": "Iraq War"},
    2008: {"price_spike": 147.0, "price_crash": 32.0,   "label": "2008 Volatility"},
    2014: {"non_opec_add": 5.0,                          "label": "Shale Glut"},
    2016: {"opec_prod_cut_abs": 1.0,                     "label": "OPEC+ Cut"},
    2020: {"demand_shock": -10.0,"opec_prod_add": 3.0,  "label": "COVID-19"},
}

# Annotation years for figures
KEY_EVENTS = {
    1973: "1973\nEmbargo",
    1979: "1979\nRevolution",
    1986: "1986\nSaudi Flood",
    2008: "2008\nSpike",
    2016: "2014-16\nGlut",
    2020: "2020\nCOVID",
}


# ============================================================
# SIMULATION ENGINE
# ============================================================

def get_params(scenario_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Build parameter dict for a scenario by applying overrides to defaults."""
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    for k, v in scenario_cfg.get("param_overrides", {}).items():
        params[k] = v
    return params


def run_scenario(scenario_cfg: Dict[str, Any], scenario_index: int) -> List[Dict[str, Any]]:
    """Run the OPEC dynamical system for one scenario and return list of row dicts."""
    np.random.seed(scenario_index)

    label = scenario_cfg["label"]
    params = get_params(scenario_cfg)

    # Unpack parameters
    ped              = params["price_elasticity_demand"]
    pe_non_opec      = params["price_elasticity_non_opec_supply"]
    pad              = params["price_adjustment_speed"]
    bdg              = params["baseline_demand_growth"]
    cheat_rate       = params["cheat_rate_baseline"]
    opec_cut_2016    = params["opec_cut_2016"]
    opec_cut_2017    = params["opec_cut_2017"]
    covid_shock      = params["covid_demand_shock"]
    shale_shock      = params["non_opec_supply_shock_shale"]
    pmr              = params["price_mean_reversion_speed"]
    lre              = params["long_run_equilibrium_price"]
    saudi_max        = params["saudi_max_production"]
    saudi_min        = params["saudi_cut_production"]
    dt               = params["dt"]

    years = list(range(1960, 2021))
    N = len(years)

    # Arrays indexed by position (0 = 1960)
    oil_price          = np.zeros(N)
    opec_prod          = np.zeros(N)
    opec_quota_arr     = np.zeros(N)
    non_opec_prod      = np.zeros(N)
    global_dem         = np.zeros(N)
    comp_rate          = np.zeros(N)
    opec_rev           = np.zeros(N)
    inv_surplus        = np.zeros(N)
    opec_ms            = np.zeros(N)
    saudi_prod         = np.zeros(N)
    cheat_excess       = np.zeros(N)
    glob_supply        = np.zeros(N)
    sd_gap             = np.zeros(N)
    price_shock_flag   = np.zeros(N, dtype=int)
    shock_labels       = [""] * N

    # Initialize t=0 (year 1960)
    oil_price[0]      = max(5.0, min(150.0, 3.0))
    opec_prod[0]      = 10.0
    opec_quota_arr[0] = 10.0
    non_opec_prod[0]  = 15.0
    global_dem[0]     = 25.0
    comp_rate[0]      = 0.70
    saudi_prod[0]     = 3.0
    inv_surplus[0]    = 0.0
    cheat_excess[0]   = 0.0
    glob_supply[0]    = opec_prod[0] + non_opec_prod[0]
    sd_gap[0]         = glob_supply[0] - global_dem[0]
    opec_rev[0]       = oil_price[0] * opec_prod[0] * 365.0 / 1000.0
    opec_ms[0]        = opec_prod[0] / glob_supply[0]
    price_shock_flag[0] = 0
    shock_labels[0]   = ""

    for i in range(1, N):
        t = years[i]
        shock = SHOCK_CALENDAR.get(t, {})

        # --- 1. GLOBAL DEMAND ---
        prev_price = oil_price[i-1]
        price_ratio = max(prev_price / lre, 0.001)
        demand_price_effect = ped * math.log(price_ratio)
        new_demand = global_dem[i-1] * (1.0 + bdg + demand_price_effect)

        # Exogenous demand shocks
        if "demand_mult" in shock:
            new_demand *= shock["demand_mult"]
        # COVID demand shock: only for covid_2020_shock scenario OR baseline (which includes COVID)
        if t == 2020 and (label == "covid_2020_shock" or label == "baseline_historical"):
            new_demand += covid_shock  # covid_shock is negative
        global_dem[i] = max(20.0, min(105.0, new_demand))

        # --- 2. NON-OPEC SUPPLY ---
        if i >= 2:
            price_lagged = oil_price[i-2]
        else:
            price_lagged = oil_price[0]
        price_lagged = max(price_lagged, 1.0)
        non_opec_response = pe_non_opec * math.log(max(price_lagged / lre, 0.001))
        new_non_opec = non_opec_prod[i-1] * (1.0 + 0.01 + non_opec_response * 0.5)

        # Iraq War extra supply
        if "non_opec_add" in shock:
            new_non_opec += shock["non_opec_add"]

        # Shale revolution shock
        if t >= 2008 and label == "shale_revolution_impact":
            new_non_opec += shale_shock * ((t - 2008) / 10.0)

        non_opec_prod[i] = max(10.0, min(45.0, new_non_opec))

        # --- 3. OPEC QUOTA ---
        implied_need = global_dem[i] - non_opec_prod[i]
        implied_need = max(10.0, min(35.0, implied_need))

        if label == "perfect_cartel_compliance":
            new_quota = implied_need
        else:
            new_quota = 0.8 * opec_quota_arr[i-1] + 0.2 * implied_need
            if t == 2016:
                new_quota -= opec_cut_2016
            if t in (2017, 2018):
                new_quota -= opec_cut_2017
        opec_quota_arr[i] = max(10.0, min(35.0, new_quota))

        # --- 4. COMPLIANCE & ACTUAL PRODUCTION ---
        if t < 1982:
            comp = 0.70
        elif t <= 2009:
            comp = max(0.0, 1.0 - cheat_rate)
        elif t <= 2015:
            comp = 0.15
        else:  # t >= 2016
            comp = 0.40

        # Scenario-specific overrides
        if label == "perfect_cartel_compliance":
            comp = 1.0
        elif label == "high_cheating_opec":
            comp = 0.01

        comp = max(0.0, min(1.0, comp))
        comp_rate[i] = comp

        max_overprod_frac = 0.20
        excess = (1.0 - comp) * max_overprod_frac * opec_quota_arr[i]
        cheat_excess[i] = excess
        new_opec_prod = opec_quota_arr[i] + excess

        # Saudi swing producer
        if label == "saudi_swing_producer":
            price_dev = (oil_price[i-1] - lre) / max(lre, 1.0)
            new_saudi = saudi_prod[i-1] * (1.0 - pmr * price_dev)
            new_saudi = max(saudi_min, min(saudi_max, new_saudi))
            # Saudi adjusts OPEC total
            new_opec_prod = new_opec_prod - saudi_prod[i-1] + new_saudi
            saudi_prod[i] = new_saudi
        else:
            # Saudi grows proportionally
            saudi_prod[i] = max(3.0, min(12.0, saudi_prod[i-1] * (new_opec_prod / max(opec_prod[i-1], 1.0))))

        # Apply embargo production cut
        if t == 1973 and "opec_prod_cut" in shock:
            new_opec_prod *= (1.0 - shock["opec_prod_cut"])

        # Apply other production cuts
        if "opec_prod_cut" in shock and t not in (1973,):
            new_opec_prod *= (1.0 - shock["opec_prod_cut"])

        # Apply COVID production surge in 2020 for covid scenario
        if t == 2020 and label == "covid_2020_shock":
            new_opec_prod += shock.get("opec_prod_add", 0.0)

        # Apply 1986 Saudi flood for baseline
        if t == 1986 and label == "baseline_historical":
            new_opec_prod *= 1.15

        opec_prod[i] = max(10.0, min(35.0, new_opec_prod))

        # Saudi production clip
        saudi_prod[i] = max(3.0, min(12.0, saudi_prod[i]))

        # --- 5. INVENTORY SURPLUS ---
        g_supply = opec_prod[i] + non_opec_prod[i]
        gap = g_supply - global_dem[i]
        delta_inv = gap * 365.0 / 1000.0
        new_inv = inv_surplus[i-1] + delta_inv * dt
        inv_surplus[i] = max(-2.0, min(5.0, new_inv))
        glob_supply[i] = g_supply
        sd_gap[i] = gap

        # --- 6. PRICE UPDATE ---
        price_from_inv = -pad * inv_surplus[i]
        price_mean_rev = pmr * (lre - oil_price[i-1])
        new_price = oil_price[i-1] + price_from_inv + price_mean_rev * dt

        # Hard-coded anchor points for baseline
        is_shock_year = False
        if label == "baseline_historical":
            if t == 1974:
                new_price = 12.0
                is_shock_year = True
            elif t == 1980:
                new_price = max(35.0, min(45.0, new_price))
                is_shock_year = True
            elif t == 1986:
                new_price = max(9.0, min(12.0, new_price))
                is_shock_year = True
            elif t == 1998:
                new_price = max(9.0, min(12.0, new_price))
                is_shock_year = True
            elif t == 2008:
                new_price = 147.0
                is_shock_year = True
            elif t == 2009:
                new_price = 55.0
                is_shock_year = True
            elif t == 2014:
                new_price = 110.48
                is_shock_year = True
            elif t == 2016:
                new_price = 22.48
                is_shock_year = True
            elif t == 2020:
                new_price = 20.0
                is_shock_year = True

        # Price floor
        new_price = max(5.0, min(150.0, new_price))
        oil_price[i] = new_price

        # Shock flags
        price_shock_flag[i] = 1 if (t in SHOCK_CALENDAR or is_shock_year) else 0
        shock_labels[i] = shock.get("label", "")

        # --- 7. REVENUE ---
        opec_rev[i] = max(0.0, min(1200.0, oil_price[i] * opec_prod[i] * 365.0 / 1000.0))

        # --- 8. MARKET SHARE ---
        total_supply = opec_prod[i] + non_opec_prod[i]
        ms = opec_prod[i] / max(total_supply, 0.001)
        opec_ms[i] = max(0.2, min(0.6, ms))

    # Build output rows
    rows = []
    for i, yr in enumerate(years):
        rows.append({
            "year": yr,
            "scenario": label,
            "oil_price_usd_bbl": round(float(oil_price[i]), 4),
            "opec_production_mbpd": round(float(opec_prod[i]), 4),
            "opec_quota_mbpd": round(float(opec_quota_arr[i]), 4),
            "non_opec_production_mbpd": round(float(non_opec_prod[i]), 4),
            "global_demand_mbpd": round(float(global_dem[i]), 4),
            "compliance_rate": round(float(comp_rate[i]), 4),
            "opec_revenue_billion_usd": round(float(opec_rev[i]), 4),
            "inventory_surplus_billion_bbl": round(float(inv_surplus[i]), 4),
            "opec_market_share_fraction": round(float(opec_ms[i]), 4),
            "saudi_production_mbpd": round(float(saudi_prod[i]), 4),
            "price_shock_flag": int(price_shock_flag[i]),
            "shock_label": shock_labels[i],
            "cheating_excess_production_mbpd": round(float(cheat_excess[i]), 4),
            "global_total_supply_mbpd": round(float(glob_supply[i]), 4),
            "supply_demand_gap_mbpd": round(float(sd_gap[i]), 4),
        })
    return rows


# ============================================================
# CSV WRITERS
# ============================================================

def write_simulation_outputs(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv — one row per year per scenario."""
    if not all_rows:
        print("WARNING: No simulation output rows to write.")
        return
    fieldnames = [
        "year", "scenario", "oil_price_usd_bbl", "opec_production_mbpd",
        "opec_quota_mbpd", "non_opec_production_mbpd", "global_demand_mbpd",
        "compliance_rate", "opec_revenue_billion_usd", "inventory_surplus_billion_bbl",
        "opec_market_share_fraction", "saudi_production_mbpd",
        "price_shock_flag", "shock_label", "cheating_excess_production_mbpd",
        "global_total_supply_mbpd", "supply_demand_gap_mbpd",
    ]
    filepath = out_dir / "simulation_outputs.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)
    print(f"Wrote {filepath} ({len(all_rows)} rows)")


def write_scenario_summary(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv — one row per scenario with aggregate metrics."""
    if not all_rows:
        print("WARNING: No rows for scenario summary.")
        return

    # Group by scenario
    scenario_data: Dict[str, List[Dict]] = {}
    for row in all_rows:
        sc = row["scenario"]
        scenario_data.setdefault(sc, []).append(row)

    numeric_cols = [
        "oil_price_usd_bbl", "opec_production_mbpd", "opec_quota_mbpd",
        "non_opec_production_mbpd", "global_demand_mbpd", "compliance_rate",
        "opec_revenue_billion_usd", "inventory_surplus_billion_bbl",
        "opec_market_share_fraction", "saudi_production_mbpd",
        "cheating_excess_production_mbpd", "global_total_supply_mbpd",
        "supply_demand_gap_mbpd",
    ]

    summary_rows = []
    for sc_label, rows in scenario_data.items():
        row_out: Dict[str, Any] = {"scenario": sc_label, "n_years": len(rows)}
        for col in numeric_cols:
            vals = np.array([r[col] for r in rows], dtype=float)
            row_out[f"{col}_mean"] = round(float(np.mean(vals)), 4)
            row_out[f"{col}_std"]  = round(float(np.std(vals)),  4)
            row_out[f"{col}_min"]  = round(float(np.min(vals)),  4)
            row_out[f"{col}_max"]  = round(float(np.max(vals)),  4)
        summary_rows.append(row_out)

    if not summary_rows:
        print("WARNING: No summary rows computed.")
        return

    fieldnames = list(summary_rows[0].keys())
    filepath = out_dir / "scenario_summary.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"Wrote {filepath} ({len(summary_rows)} rows)")


def write_parameters_used(out_dir: pathlib.Path) -> None:
    """Write parameters_used.csv — one row per parameter."""
    rows = []
    for name, info in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })
    if not rows:
        print("WARNING: No parameters to write.")
        return
    filepath = out_dir / "parameters_used.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {filepath} ({len(rows)} rows)")


# ============================================================
# FIGURE HELPERS
# ============================================================

def get_scenario_colors(n: int):
    cmap = cm.get_cmap("tab10", n)
    return [cmap(i) for i in range(n)]


def scenario_arrays(all_rows: List[Dict], scenario: str, col: str) -> Tuple[np.ndarray, np.ndarray]:
    """Return (years, values) arrays for a specific scenario and column."""
    filtered = [r for r in all_rows if r["scenario"] == scenario]
    filtered.sort(key=lambda r: r["year"])
    years = np.array([r["year"] for r in filtered], dtype=float)
    vals  = np.array([r[col] for r in filtered], dtype=float)
    return years, vals


def add_event_vlines(ax, color="gray", alpha=0.5, fontsize=7):
    for yr, lbl in KEY_EVENTS.items():
        ax.axvline(x=yr, color=color, linestyle="--", linewidth=0.8, alpha=alpha)
        ax.text(yr + 0.3, ax.get_ylim()[1] * 0.95, lbl,
                fontsize=fontsize, rotation=90, va="top", alpha=0.7)


# ============================================================
# FIGURE GENERATORS
# ============================================================

def generate_fig1(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig1: Oil price trajectories for all scenarios."""
    try:
        colors = get_scenario_colors(len(scenarios))
        fig, ax = plt.subplots(figsize=(14, 6))
        for idx, sc in enumerate(scenarios):
            yrs, vals = scenario_arrays(all_rows, sc, "oil_price_usd_bbl")
            assert len(yrs) == len(vals), f"Array mismatch for {sc}"
            if len(yrs) == 0:
                continue
            ax.plot(yrs, vals, label=sc.replace("_", " "), color=colors[idx], linewidth=1.8)
        ax.set_xlabel("Year")
        ax.set_ylabel("Oil Price (USD/bbl)")
        ax.set_title("Historical and Simulated Global Oil Price 1960–2020 (USD/bbl)")
        ax.legend(fontsize=8, loc="upper left")
        ax.set_xlim(1960, 2020)
        ax.set_ylim(0, 160)
        ax.grid(True, alpha=0.3)
        # Annotate key events
        for yr, lbl in KEY_EVENTS.items():
            ax.axvline(x=yr, color="gray", linestyle="--", linewidth=0.8, alpha=0.5)
        # Historical anchor labels
        anchors = [(1974, 12, "$12"), (1980, 40, "$40"), (1986, 10, "$10"),
                   (2008, 147, "$147"), (2016, 22.48, "$22.48"), (2020, 20, "$20")]
        for yr, pr, lbl in anchors:
            ax.annotate(lbl, xy=(yr, pr), xytext=(yr+1, pr+8),
                        fontsize=7, arrowprops=dict(arrowstyle="->", lw=0.8), color="black")
        plt.tight_layout()
        fig.savefig(out_dir / "fig1_oil_price_trajectories.png", dpi=150)
        plt.close(fig)
        print("Saved fig1_oil_price_trajectories.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def generate_fig2(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig2: OPEC production vs quota for all scenarios."""
    try:
        colors = get_scenario_colors(len(scenarios))
        fig, axes = plt.subplots(3, 3, figsize=(16, 12), sharex=True)
        axes_flat = axes.flatten()
        for idx, sc in enumerate(scenarios):
            if idx >= len(axes_flat):
                break
            ax = axes_flat[idx]
            yrs_p, vals_p = scenario_arrays(all_rows, sc, "opec_production_mbpd")
            yrs_q, vals_q = scenario_arrays(all_rows, sc, "opec_quota_mbpd")
            assert len(yrs_p) == len(vals_p)
            assert len(yrs_q) == len(vals_q)
            assert len(yrs_p) == len(yrs_q)
            if len(yrs_p) > 0:
                ax.plot(yrs_p, vals_p, label="Production", color=colors[idx], linewidth=1.8)
                ax.plot(yrs_q, vals_q, label="Quota", color=colors[idx], linewidth=1.2,
                        linestyle="--", alpha=0.7)
                ax.fill_between(yrs_p, vals_q, vals_p, alpha=0.15, color=colors[idx])
            ax.set_title(sc.replace("_", " "), fontsize=9)
            ax.set_xlim(1960, 2020)
            ax.set_ylim(8, 40)
            ax.legend(fontsize=7)
            ax.grid(True, alpha=0.3)
        # Hide any extra subplots
        for idx in range(len(scenarios), len(axes_flat)):
            axes_flat[idx].set_visible(False)
        fig.suptitle("OPEC Actual Production vs Quota 1960–2020 (mbpd)", fontsize=13, y=1.01)
        fig.text(0.5, -0.01, "Year", ha="center")
        fig.text(-0.01, 0.5, "mbpd", va="center", rotation="vertical")
        plt.tight_layout()
        fig.savefig(out_dir / "fig2_opec_production_vs_quota.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        print("Saved fig2_opec_production_vs_quota.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def generate_fig3(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig3: OPEC revenue trajectories."""
    try:
        colors = get_scenario_colors(len(scenarios))
        fig, ax = plt.subplots(figsize=(14, 6))
        for idx, sc in enumerate(scenarios):
            yrs, vals = scenario_arrays(all_rows, sc, "opec_revenue_billion_usd")
            assert len(yrs) == len(vals)
            if len(yrs) == 0:
                continue
            ax.plot(yrs, vals, label=sc.replace("_", " "), color=colors[idx], linewidth=1.8)
        ax.set_xlabel("Year")
        ax.set_ylabel("Revenue (Billion USD/year)")
        ax.set_title("OPEC Net Oil Export Revenue 1960–2020 (Billion USD/year)")
        ax.legend(fontsize=8, loc="upper left")
        ax.set_xlim(1960, 2020)
        ax.set_ylim(0, 1250)
        ax.axhline(y=1000, color="red", linestyle=":", linewidth=1, alpha=0.5, label="$1T threshold")
        ax.axhline(y=119,  color="orange", linestyle=":", linewidth=1, alpha=0.5)
        ax.text(1965, 1010, "$1 Trillion (2008 record)", fontsize=8, color="red", alpha=0.7)
        ax.text(1965, 129,  "$119B (Saudi 1981 peak)", fontsize=8, color="orange", alpha=0.7)
        for yr, lbl in KEY_EVENTS.items():
            ax.axvline(x=yr, color="gray", linestyle="--", linewidth=0.8, alpha=0.4)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig3_opec_revenue.png", dpi=150)
        plt.close(fig)
        print("Saved fig3_opec_revenue.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def generate_fig4(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig4: OPEC market share."""
    try:
        colors = get_scenario_colors(len(scenarios))
        fig, ax = plt.subplots(figsize=(14, 6))
        for idx, sc in enumerate(scenarios):
            yrs, vals = scenario_arrays(all_rows, sc, "opec_market_share_fraction")
            assert len(yrs) == len(vals)
            if len(yrs) == 0:
                continue
            ax.plot(yrs, vals, label=sc.replace("_", " "), color=colors[idx], linewidth=1.8)
        ax.axhline(y=0.30, color="red",   linestyle="--", linewidth=1.0, alpha=0.6, label="30% threshold (1985 low)")
        ax.axhline(y=0.50, color="green", linestyle="--", linewidth=1.0, alpha=0.6, label="50% threshold (1970s peak)")
        ax.axhline(y=0.38, color="blue",  linestyle=":",  linewidth=1.0, alpha=0.5, label="38% (2022)")
        ax.set_xlabel("Year")
        ax.set_ylabel("Market Share (fraction)")
        ax.set_title("OPEC Market Share of Global Oil Production 1960–2022")
        ax.legend(fontsize=8, loc="upper right")
        ax.set_xlim(1960, 2020)
        ax.set_ylim(0.15, 0.65)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig4_opec_market_share.png", dpi=150)
        plt.close(fig)
        print("Saved fig4_opec_market_share.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def generate_fig5(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig5: Compliance rate over time."""
    try:
        colors = get_scenario_colors(len(scenarios))
        fig, ax = plt.subplots(figsize=(14, 6))
        for idx, sc in enumerate(scenarios):
            yrs, vals = scenario_arrays(all_rows, sc, "compliance_rate")
            assert len(yrs) == len(vals)
            if len(yrs) == 0:
                continue
            ax.plot(yrs, vals, label=sc.replace("_", " "), color=colors[idx], linewidth=1.8)
        ax.axhline(y=0.04, color="red", linestyle=":", linewidth=1.2, alpha=0.7, label="4% (Colgan 1982-2009)")
        ax.axvspan(1982, 2009, alpha=0.05, color="red", label="Colgan Cheating Period")
        ax.set_xlabel("Year")
        ax.set_ylabel("Compliance Rate (fraction)")
        ax.set_title("OPEC Member Compliance Rate with Production Quotas 1960–2020")
        ax.legend(fontsize=8, loc="upper right")
        ax.set_xlim(1960, 2020)
        ax.set_ylim(-0.05, 1.10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig5_compliance_rate.png", dpi=150)
        plt.close(fig)
        print("Saved fig5_compliance_rate.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def generate_fig6(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig6: Scatter plot compliance rate vs oil price."""
    try:
        colors = get_scenario_colors(len(scenarios))
        fig, ax = plt.subplots(figsize=(10, 7))
        for idx, sc in enumerate(scenarios):
            rows_sc = [r for r in all_rows if r["scenario"] == sc]
            if not rows_sc:
                continue
            comp_vals  = np.array([r["compliance_rate"]     for r in rows_sc], dtype=float)
            price_vals = np.array([r["oil_price_usd_bbl"]   for r in rows_sc], dtype=float)
            assert len(comp_vals) == len(price_vals)
            if len(comp_vals) == 0:
                continue
            ax.scatter(comp_vals, price_vals, label=sc.replace("_", " "),
                       color=colors[idx], alpha=0.6, s=30, edgecolors="none")
        ax.set_xlabel("Compliance Rate (fraction)")
        ax.set_ylabel("Oil Price (USD/bbl)")
        ax.set_title("Compliance Rate vs Oil Price Across All Scenarios and Years")
        ax.legend(fontsize=8)
        ax.set_xlim(-0.05, 1.10)
        ax.set_ylim(0, 160)
        ax.grid(True, alpha=0.3)
        # Trend line
        comp_all  = np.array([r["compliance_rate"]   for r in all_rows], dtype=float)
        price_all = np.array([r["oil_price_usd_bbl"] for r in all_rows], dtype=float)
        if len(comp_all) > 1:
            z = np.polyfit(comp_all, price_all, 1)
            p = np.poly1d(z)
            x_line = np.linspace(0, 1, 100)
            ax.plot(x_line, p(x_line), "k--", linewidth=1.5, alpha=0.6, label="OLS trend")
            ax.legend(fontsize=8)
        plt.tight_layout()
        fig.savefig(out_dir / "fig6_compliance_vs_price_scatter.png", dpi=150)
        plt.close(fig)
        print("Saved fig6_compliance_vs_price_scatter.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def generate_fig7(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig7: Inventory surplus/deficit."""
    try:
        colors = get_scenario_colors(len(scenarios))
        fig, ax = plt.subplots(figsize=(14, 6))
        for idx, sc in enumerate(scenarios):
            yrs, vals = scenario_arrays(all_rows, sc, "inventory_surplus_billion_bbl")
            assert len(yrs) == len(vals)
            if len(yrs) == 0:
                continue
            ax.plot(yrs, vals, label=sc.replace("_", " "), color=colors[idx], linewidth=1.8)
        ax.axhline(y=0, color="black", linewidth=1.0, linestyle="-", alpha=0.5)
        ax.fill_between([1960, 2020], [0, 0], [5, 5], alpha=0.03, color="red", label="Surplus zone")
        ax.fill_between([1960, 2020], [-2, -2], [0, 0], alpha=0.03, color="blue", label="Deficit zone")
        ax.set_xlabel("Year")
        ax.set_ylabel("Inventory Surplus (Billion Barrels)")
        ax.set_title("Global Oil Inventory Surplus/Deficit 1960–2020 (Billion Barrels)")
        ax.legend(fontsize=8, loc="upper left")
        ax.set_xlim(1960, 2020)
        ax.set_ylim(-2.5, 5.5)
        ax.grid(True, alpha=0.3)
        for yr, lbl in [(1986, "1986\nGlut"), (2015, "2015\nGlut"), (2020, "2020\nCOVID")]:
            ax.axvline(x=yr, color="gray", linestyle="--", linewidth=0.8, alpha=0.5)
            ax.text(yr + 0.2, 4.8, lbl, fontsize=7, va="top", alpha=0.7)
        plt.tight_layout()
        fig.savefig(out_dir / "fig7_inventory_surplus.png", dpi=150)
        plt.close(fig)
        print("Saved fig7_inventory_surplus.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


def generate_fig8(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig8: Heatmap of average oil price by scenario and decade."""
    try:
        decades = [1960, 1970, 1980, 1990, 2000, 2010]
        decade_labels = ["1960s", "1970s", "1980s", "1990s", "2000s", "2010s"]
        data = np.zeros((len(decades), len(scenarios)))

        for j, sc in enumerate(scenarios):
            rows_sc = [r for r in all_rows if r["scenario"] == sc]
            for i, dec in enumerate(decades):
                decade_rows = [r for r in rows_sc if dec <= r["year"] < dec + 10]
                if decade_rows:
                    data[i, j] = np.mean([r["oil_price_usd_bbl"] for r in decade_rows])

        fig, ax = plt.subplots(figsize=(14, 6))
        im = ax.imshow(data, aspect="auto", cmap="YlOrRd", vmin=0, vmax=150)
        ax.set_xticks(range(len(scenarios)))
        ax.set_xticklabels([s.replace("_", "\n") for s in scenarios], fontsize=8)
        ax.set_yticks(range(len(decades)))
        ax.set_yticklabels(decade_labels, fontsize=9)
        ax.set_title("Heatmap: Average Oil Price by Scenario and Decade (USD/bbl)")
        plt.colorbar(im, ax=ax, label="Avg Oil Price (USD/bbl)")
        # Annotate cells
        for i in range(len(decades)):
            for j in range(len(scenarios)):
                ax.text(j, i, f"{data[i,j]:.1f}", ha="center", va="center",
                        fontsize=7, color="black" if data[i,j] < 75 else "white")
        plt.tight_layout()
        fig.savefig(out_dir / "fig8_price_heatmap_decade_scenario.png", dpi=150)
        plt.close(fig)
        print("Saved fig8_price_heatmap_decade_scenario.png")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")


def generate_fig9(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig9: Non-OPEC vs OPEC production."""
    try:
        highlight_scenarios = ["baseline_historical", "shale_revolution_impact", "perfect_cartel_compliance"]
        colors_opec    = ["#1f77b4", "#ff7f0e", "#2ca02c"]
        colors_nonopec = ["#aec7e8", "#ffbb78", "#98df8a"]
        fig, ax = plt.subplots(figsize=(14, 7))
        for idx, sc in enumerate(highlight_scenarios):
            if sc not in scenarios:
                continue
            yrs_o, vals_o = scenario_arrays(all_rows, sc, "opec_production_mbpd")
            yrs_n, vals_n = scenario_arrays(all_rows, sc, "non_opec_production_mbpd")
            assert len(yrs_o) == len(vals_o)
            assert len(yrs_n) == len(vals_n)
            assert len(yrs_o) == len(yrs_n)
            if len(yrs_o) == 0:
                continue
            lbl_base = sc.replace("_", " ")
            ax.plot(yrs_o, vals_o, label=f"OPEC ({lbl_base})",    color=colors_opec[idx],    linewidth=2.0)
            ax.plot(yrs_n, vals_n, label=f"Non-OPEC ({lbl_base})",color=colors_nonopec[idx], linewidth=2.0, linestyle="--")
        ax.set_xlabel("Year")
        ax.set_ylabel("Production (mbpd)")
        ax.set_title("Non-OPEC Oil Production vs OPEC Production 1960–2020 (mbpd)")
        ax.legend(fontsize=8, loc="upper left")
        ax.set_xlim(1960, 2020)
        ax.set_ylim(0, 55)
        ax.grid(True, alpha=0.3)
        # Annotations
        ax.annotate("North Sea\npeak", xy=(1985, 18), xytext=(1985, 25),
                    fontsize=8, arrowprops=dict(arrowstyle="->", lw=0.8), ha="center")
        ax.annotate("US Shale\nacceleration", xy=(2014, 42), xytext=(2010, 48),
                    fontsize=8, arrowprops=dict(arrowstyle="->", lw=0.8), ha="center")
        plt.tight_layout()
        fig.savefig(out_dir / "fig9_opec_vs_nonopec_production.png", dpi=150)
        plt.close(fig)
        print("Saved fig9_opec_vs_nonopec_production.png")
    except Exception as e:
        print(f"WARNING: fig9 failed: {e}")


def generate_fig10(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Fig10: Global demand under different scenarios."""
    try:
        highlight = ["baseline_historical", "demand_destruction_response", "covid_2020_shock"]
        colors_map = {"baseline_historical": "#1f77b4",
                      "demand_destruction_response": "#2ca02c",
                      "covid_2020_shock": "#d62728"}
        fig, ax = plt.subplots(figsize=(14, 6))
        for sc in highlight:
            if sc not in scenarios:
                continue
            yrs, vals = scenario_arrays(all_rows, sc, "global_demand_mbpd")
            assert len(yrs) == len(vals)
            if len(yrs) == 0:
                continue
            ax.plot(yrs, vals, label=sc.replace("_", " "),
                    color=colors_map.get(sc, "gray"), linewidth=2.0)
        ax.axvline(x=1973, color="gray", linestyle="--", linewidth=1.0, alpha=0.6)
        ax.text(1973.3, 95, "1973\nEmbargo", fontsize=8, va="top", alpha=0.7)
        ax.axvline(x=2020, color="red",  linestyle="--", linewidth=1.0, alpha=0.6)
        ax.text(2016.5, 95, "2020\nCOVID", fontsize=8, va="top", alpha=0.7, color="red")
        # Demand drop annotation
        ax.annotate("5 mbpd drop\nby 1986", xy=(1986, 52), xytext=(1990, 42),
                    fontsize=8, arrowprops=dict(arrowstyle="->", lw=0.8), ha="center")
        ax.set_xlabel("Year")
        ax.set_ylabel("Global Demand (mbpd)")
        ax.set_title("Global Oil Demand Under Different Behavioral Scenarios 1960–2020 (mbpd)")
        ax.legend(fontsize=9, loc="upper left")
        ax.set_xlim(1960, 2020)
        ax.set_ylim(15, 110)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(out_dir / "fig10_global_demand_scenarios.png", dpi=150)
        plt.close(fig)
        print("Saved fig10_global_demand_scenarios.png")
    except Exception as e:
        print(f"WARNING: fig10 failed: {e}")


# ============================================================
# SUMMARY JSON
# ============================================================

def write_summary_json(all_rows: List[Dict], scenarios: List[str], out_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    try:
        summary: Dict[str, Any] = {
            "title": "OPEC Oil Market Dynamical System Simulator",
            "years_simulated": "1960-2020",
            "n_scenarios": len(scenarios),
            "n_total_rows": len(all_rows),
            "scenarios": {}
        }
        for sc in scenarios:
            rows_sc = [r for r in all_rows if r["scenario"] == sc]
            if not rows_sc:
                continue
            prices = [r["oil_price_usd_bbl"]        for r in rows_sc]
            revs   = [r["opec_revenue_billion_usd"]  for r in rows_sc]
            comps  = [r["compliance_rate"]            for r in rows_sc]
            ms     = [r["opec_market_share_fraction"] for r in rows_sc]
            summary["scenarios"][sc] = {
                "mean_oil_price_usd_bbl":       round(float(np.mean(prices)), 2),
                "max_oil_price_usd_bbl":        round(float(np.max(prices)), 2),
                "min_oil_price_usd_bbl":        round(float(np.min(prices)), 2),
                "std_oil_price_usd_bbl":        round(float(np.std(prices)), 2),
                "mean_opec_revenue_billion_usd":round(float(np.mean(revs)),   2),
                "max_opec_revenue_billion_usd": round(float(np.max(revs)),    2),
                "mean_compliance_rate":         round(float(np.mean(comps)),  4),
                "mean_opec_market_share":       round(float(np.mean(ms)),     4),
                "n_years": len(rows_sc),
            }
        filepath = out_dir / "summary.json"
        with open(filepath, "w") as f:
            json.dump(summary, f, indent=2)
        print(f"Wrote {filepath}")
    except Exception as e:
        print(f"WARNING: summary.json failed: {e}")


# ============================================================
# MAIN
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description="OPEC Oil Market Dynamical System Simulator (1960-2020)"
    )
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all generated files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"Output directory: {out_dir.resolve()}")
    print("=" * 60)

    # Run all scenarios
    all_rows: List[Dict[str, Any]] = []
    scenario_labels: List[str] = []

    for idx, sc_cfg in enumerate(MODEL_PROFILE["scenarios"]):
        label = sc_cfg["label"]
        print(f"\nRunning scenario [{idx}]: {label}")
        try:
            rows = run_scenario(sc_cfg, scenario_index=idx)
            all_rows.extend(rows)
            scenario_labels.append(label)
            print(f"  -> {len(rows)} years simulated")
            # Quick sanity check
            prices = [r["oil_price_usd_bbl"] for r in rows]
            print(f"     Price range: [{min(prices):.2f}, {max(prices):.2f}] USD/bbl")
        except Exception as e:
            print(f"  ERROR in scenario {label}: {e}")

    print(f"\nTotal rows generated: {len(all_rows)}")
    print("=" * 60)

    # Write CSV files
    print("\nWriting CSV files...")
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(all_rows, out_dir)
    write_parameters_used(out_dir)

    # Write summary JSON
    print("\nWriting summary JSON...")
    write_summary_json(all_rows, scenario_labels, out_dir)

    # Generate all figures
    print("\nGenerating figures...")
    generate_fig1(all_rows, scenario_labels, out_dir)
    generate_fig2(all_rows, scenario_labels, out_dir)
    generate_fig3(all_rows, scenario_labels, out_dir)
    generate_fig4(all_rows, scenario_labels, out_dir)
    generate_fig5(all_rows, scenario_labels, out_dir)
    generate_fig6(all_rows, scenario_labels, out_dir)
    generate_fig7(all_rows, scenario_labels, out_dir)
    generate_fig8(all_rows, scenario_labels, out_dir)
    generate_fig9(all_rows, scenario_labels, out_dir)
    generate_fig10(all_rows, scenario_labels, out_dir)

    print("\n" + "=" * 60)
    print("Simulation complete.")
    print(f"All outputs saved to: {out_dir.resolve()}")
    print("=" * 60)


if __name__ == "__main__":
    main()