================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 5108716b-4776-4cb6-8fab-e3029ac390a1
    Generated   : 2026-04-28  12:20:42 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Bond (finance)

    CATEGORIES
    ----------
    Financial

    KEYWORDS
    --------
    bond valuation, yield to maturity, duration, fixed income, price-yield relationship

    ABSTRACT
    --------
    This simulator models the pricing, yield dynamics, and risk characteristics of fixed-income bonds as described in foundational finance literature. It implements exact present-value discounting to compute bond prices, accrued interest, Macaulay and modified duration, and convexity across a range of bond types including government, corporate, zero-coupon, inflation-linked, and high-yield instruments. Eight distinct scenarios spanning par bonds, discount/premium bonds, zero-coupon bonds, Methuselah ultra-long bonds, TIPS, and junk bonds are simulated over their full lifetimes, generating synthetic price trajectories and cash flow profiles. Researchers, students, and financial engineers can use the outputs to visualize pull-to-par convergence, yield curve shapes, credit spread impacts, and the accuracy of duration and convexity approximations for interest rate risk management.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Bond_(finance).pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    bond_price, ytm, current_yield, accrued_interest, dirty_price, duration, modified_duration, convexity, time_to_maturity, market_interest_rate

    SCENARIOS  (8 total)
    ---------------------------------
        1. Par_Bond_Baseline — Bond issued at par with coupon rate equal to market rate; tracks price over time as market rates remain constant, demonstrating pull-to-par at maturity
2. Rising_Rates_Discount_Bond — Market interest rates rise 200 bps after issuance, causing bond to trade at a discount; illustrates inverse price-yield relationship and interest rate risk
3. Falling_Rates_Premium_Bond — Market interest rates fall 200 bps after issuance, causing bond to trade at a premium; demonstrates upward price appreciation and reinvestment risk
4. Zero_Coupon_Bond — Zero-coupon bond issued at deep discount, accretes to par at maturity; highest duration and price volatility for given maturity
5. High_Yield_Junk_Bond — Below-investment-grade bond with large credit spread over risk-free rate; higher yield, lower price, elevated default risk profile
6. Short_Term_Note — Two-year note showing low duration, limited price sensitivity to rate changes, and rapid pull-to-par
7. Methuselah_Ultra_Long — 50-year ultra-long bond showing extreme duration, very high price sensitivity to yield changes, near-zero present value of principal
8. Inflation_Linked_TIPS — Inflation-indexed bond where principal adjusts with inflation rate of 2.5% per year; lower nominal coupon but protected real purchasing power

    PARAMETERS
    ----------
    15 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig01, fig02, fig03, fig04, fig05, fig06, fig07, fig08, fig09, fig10

    DOMAIN SUMMARY
    --------------
    This source covers the fundamental mechanics, valuation, and risk characteristics of bonds as fixed-income financial instruments, including coupon payments, yield-to-maturity, price-yield relationships, duration, and the dynamics of bond pricing across different issuer types and market conditions.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.