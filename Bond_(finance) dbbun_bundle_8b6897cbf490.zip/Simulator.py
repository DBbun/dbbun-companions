# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-28T12:20:42.595683Z
# Run ID    : 5108716b-4776-4cb6-8fab-e3029ac390a1
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Bond (finance) Simulator
========================
Paper: "Bond (finance)" — foundational fixed-income mechanics, valuation, and risk.

Simulates bond pricing, yield dynamics, duration, convexity, accrued interest,
pull-to-par convergence, and inflation-linked adjustments across eight scenarios.
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import List, Dict, Any, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# =============================================================================
# MODEL PROFILE
# =============================================================================
MODEL_PROFILE = {
    "parameters": {
        "face_value":            {"value": 1000.0,  "unit": "USD",               "source": "extracted", "description": "Par/nominal/principal value"},
        "coupon_rate":           {"value": 0.05,    "unit": "decimal/year",      "source": "assumed",   "description": "Annual coupon rate"},
        "coupon_frequency":      {"value": 2.0,     "unit": "payments/year",     "source": "extracted", "description": "Semi-annual coupon frequency"},
        "maturity_years":        {"value": 10.0,    "unit": "years",             "source": "assumed",   "description": "Time to maturity"},
        "initial_market_rate":   {"value": 0.05,    "unit": "decimal",           "source": "assumed",   "description": "Market rate at issuance"},
        "credit_spread":         {"value": 0.01,    "unit": "decimal",           "source": "assumed",   "description": "Yield spread over risk-free"},
        "inflation_rate":        {"value": 0.025,   "unit": "decimal/year",      "source": "assumed",   "description": "Annual inflation rate"},
        "rate_shock_magnitude":  {"value": 0.02,    "unit": "decimal",           "source": "assumed",   "description": "200 bps stress test shift"},
        "dt":                    {"value": 0.5,      "unit": "years",             "source": "assumed",   "description": "Semi-annual time step"},
        "recovery_rate":         {"value": 0.357,   "unit": "decimal",           "source": "extracted", "description": "Recovery in default (WorldCom)"},
        "junk_spread":           {"value": 0.05,    "unit": "decimal",           "source": "assumed",   "description": "High-yield additional spread"},
        "call_price":            {"value": 100.0,   "unit": "% of par",          "source": "extracted", "description": "Callable bond redemption price"},
        "short_maturity_years":  {"value": 2.0,     "unit": "years",             "source": "extracted", "description": "Short-term note maturity"},
        "long_maturity_years":   {"value": 30.0,    "unit": "years",             "source": "extracted", "description": "Long bond maturity"},
        "ultra_long_maturity_years": {"value": 50.0, "unit": "years",            "source": "extracted", "description": "Methuselah bond maturity"},
    },
    "scenarios": [
        {"label": "Par_Bond_Baseline",        "coupon_rate": 0.05, "initial_market_rate": 0.05, "maturity_years": 10.0, "credit_spread": 0.00, "inflation_rate": 0.0},
        {"label": "Rising_Rates_Discount_Bond","coupon_rate": 0.05, "initial_market_rate": 0.07, "maturity_years": 10.0, "credit_spread": 0.00, "inflation_rate": 0.0},
        {"label": "Falling_Rates_Premium_Bond","coupon_rate": 0.05, "initial_market_rate": 0.03, "maturity_years": 10.0, "credit_spread": 0.00, "inflation_rate": 0.0},
        {"label": "Zero_Coupon_Bond",          "coupon_rate": 0.00, "initial_market_rate": 0.05, "maturity_years": 10.0, "credit_spread": 0.00, "inflation_rate": 0.0},
        {"label": "High_Yield_Junk_Bond",      "coupon_rate": 0.08, "initial_market_rate": 0.05, "maturity_years": 10.0, "credit_spread": 0.05, "inflation_rate": 0.0},
        {"label": "Short_Term_Note",           "coupon_rate": 0.05, "initial_market_rate": 0.05, "maturity_years":  2.0, "credit_spread": 0.00, "inflation_rate": 0.0},
        {"label": "Methuselah_Ultra_Long",     "coupon_rate": 0.04, "initial_market_rate": 0.05, "maturity_years": 50.0, "credit_spread": 0.00, "inflation_rate": 0.0},
        {"label": "Inflation_Linked_TIPS",     "coupon_rate": 0.025,"initial_market_rate": 0.025,"maturity_years": 10.0, "credit_spread": 0.00, "inflation_rate": 0.025},
    ],
}

# =============================================================================
# CORE BOND MATH FUNCTIONS
# =============================================================================

def calc_bond_price(face_value: float, coupon_rate: float, ytm: float,
                    time_to_maturity: float, freq: int = 2) -> Tuple[float, float, float]:
    """
    Returns (clean_price_pct, pv_coupons_pct, pv_principal_pct) as % of par.
    Handles zero-coupon and near-zero rate edge cases.
    """
    N = max(int(round(time_to_maturity * freq)), 1)
    r = ytm / freq
    C = (coupon_rate * face_value) / freq

    if abs(r) < 1e-12:
        pv_coupons = C * N
    else:
        pv_coupons = C * (1.0 - (1.0 + r) ** (-N)) / r

    pv_principal = face_value * (1.0 + r) ** (-N)
    price = pv_coupons + pv_principal

    pct = 100.0 / face_value
    return (
        float(np.clip(price * pct, 50.0, 150.0)),
        float(pv_coupons * pct),
        float(pv_principal * pct),
    )


def calc_accrued_interest(coupon_rate: float, face_value: float,
                          freq: int, t: float) -> float:
    """Accrued interest as % of par (currency units per 100 face)."""
    if coupon_rate == 0.0:
        return 0.0
    period = 1.0 / freq
    fraction = (t % period) / period        # 0..1 within current coupon period
    periodic_coupon = coupon_rate * face_value / freq
    ai = periodic_coupon * fraction         # in currency units
    ai_pct = ai / face_value * 100.0        # as % of par
    return float(np.clip(ai_pct, 0.0, 5.0))


def calc_macaulay_duration(face_value: float, coupon_rate: float,
                            ytm: float, time_to_maturity: float,
                            freq: int = 2) -> float:
    """Macaulay duration in years."""
    N = max(int(round(time_to_maturity * freq)), 1)
    r = ytm / freq
    C = (coupon_rate * face_value) / freq

    weighted_pv = 0.0
    total_pv = 0.0
    for i in range(1, N + 1):
        t_i = i / freq
        cf = C if i < N else C + face_value
        if abs(1.0 + r) < 1e-12:
            pv = cf
        else:
            pv = cf / (1.0 + r) ** i
        weighted_pv += t_i * pv
        total_pv += pv

    if total_pv < 1e-12:
        return float(time_to_maturity)
    dur = weighted_pv / total_pv
    return float(np.clip(dur, 0.5, 30.0))


def calc_modified_duration(mac_dur: float, ytm: float, freq: int = 2) -> float:
    denom = 1.0 + ytm / freq
    if abs(denom) < 1e-12:
        return mac_dur
    md = mac_dur / denom
    return float(np.clip(md, 0.4, 28.0))


def calc_convexity(face_value: float, coupon_rate: float,
                   ytm: float, time_to_maturity: float,
                   freq: int = 2) -> float:
    """Convexity in years^2."""
    N = max(int(round(time_to_maturity * freq)), 1)
    r = ytm / freq
    C = (coupon_rate * face_value) / freq

    total_pv = 0.0
    convex_sum = 0.0
    for i in range(1, N + 1):
        cf = C if i < N else C + face_value
        if abs(1.0 + r) < 1e-12:
            pv = cf
        else:
            pv = cf / (1.0 + r) ** i
        total_pv += pv
        convex_sum += pv * i * (i + 1)

    if total_pv < 1e-12:
        return 1.0
    denom = total_pv * (1.0 + r) ** 2 * (freq ** 2)
    if abs(denom) < 1e-12:
        return 1.0
    conv = convex_sum / denom
    return float(np.clip(conv, 1.0, 600.0))


def tips_principal(face_value: float, inflation_rate: float, t: float) -> float:
    return face_value * (1.0 + inflation_rate) ** t


# =============================================================================
# SIMULATION
# =============================================================================

def run_scenario(scenario_cfg: dict, scenario_index: int) -> List[dict]:
    """Run one scenario and return list of row dicts."""
    np.random.seed(scenario_index)

    label = scenario_cfg["label"]
    coupon_rate = float(scenario_cfg["coupon_rate"])
    market_rate = float(scenario_cfg["initial_market_rate"])
    maturity_years = float(scenario_cfg["maturity_years"])
    credit_spread = float(scenario_cfg["credit_spread"])
    inflation_rate = float(scenario_cfg.get("inflation_rate", 0.0))
    face_value = float(MODEL_PROFILE["parameters"]["face_value"]["value"])
    freq = int(MODEL_PROFILE["parameters"]["coupon_frequency"]["value"])
    dt = float(MODEL_PROFILE["parameters"]["dt"]["value"])

    ytm = float(np.clip(market_rate + credit_spread, 0.001, 0.20))
    credit_spread_bps = credit_spread * 10000.0

    # Build time grid — include maturity endpoint
    t_grid = np.arange(0.0, maturity_years + dt * 0.5, dt)
    # Ensure maturity is in grid
    if abs(t_grid[-1] - maturity_years) > 1e-9:
        t_grid = np.append(t_grid, maturity_years)

    rows = []
    cumulative_coupon = 0.0
    coupon_period = 1.0 / freq
    last_coupon_t = 0.0
    initial_price, _, _ = calc_bond_price(face_value, coupon_rate, ytm, maturity_years, freq)

    for t in t_grid:
        time_to_mat = max(maturity_years - t, 0.0)

        # For TIPS, inflate principal
        effective_face = face_value
        if inflation_rate > 0.0:
            effective_face = tips_principal(face_value, inflation_rate, t)
        infl_adj_principal = effective_face
        infl_adj_coupon_annual = coupon_rate * effective_face
        infl_adj_coupon_periodic = infl_adj_coupon_annual / freq

        # Determine effective coupon rate (for TIPS, coupon is on inflated principal)
        eff_coupon_rate = coupon_rate  # real coupon rate applied to inflated principal
        # Price using effective face
        if time_to_mat <= dt * 0.1:
            # At or past maturity: price = par (100%)
            clean_price_pct = 100.0
            pv_coupons_pct = 0.0
            pv_principal_pct = 100.0
        else:
            # For TIPS: price the bond using effective face but express as % of original face
            N_temp = max(int(round(time_to_mat * freq)), 1)
            r_temp = ytm / freq
            C_temp = eff_coupon_rate * effective_face / freq
            if abs(r_temp) < 1e-12:
                pv_c = C_temp * N_temp
            else:
                pv_c = C_temp * (1.0 - (1.0 + r_temp) ** (-N_temp)) / r_temp
            pv_p = effective_face * (1.0 + r_temp) ** (-N_temp)
            price_currency = pv_c + pv_p
            clean_price_pct = float(np.clip((price_currency / face_value) * 100.0, 50.0, 150.0))
            pv_coupons_pct = float((pv_c / face_value) * 100.0)
            pv_principal_pct = float((pv_p / face_value) * 100.0)

        # Accrued interest (based on original face for display)
        ai_pct = calc_accrued_interest(coupon_rate, face_value, freq, t)
        dirty_price_pct = float(np.clip(clean_price_pct + ai_pct, 50.0, 155.0))

        # Check if coupon payment is due this step
        coupon_payment = 0.0
        if t > 0.0 and (t - last_coupon_t) >= coupon_period - 1e-9:
            coupon_payment = infl_adj_coupon_periodic / face_value * 100.0  # as % of par
            cumulative_coupon += coupon_payment
            last_coupon_t = t

        # Duration and convexity (use effective face for TIPS)
        if time_to_mat > dt * 0.1:
            mac_dur = calc_macaulay_duration(effective_face, eff_coupon_rate, ytm, time_to_mat, freq)
            mod_dur = calc_modified_duration(mac_dur, ytm, freq)
            conv = calc_convexity(effective_face, eff_coupon_rate, ytm, time_to_mat, freq)
        else:
            mac_dur = 0.5
            mod_dur = 0.4
            conv = 1.0

        # Current yield
        if clean_price_pct > 0.1 and coupon_rate > 0.0:
            current_yield_val = float(np.clip(
                (coupon_rate * face_value) / (clean_price_pct / 100.0 * face_value),
                0.001, 0.25
            ))
        else:
            current_yield_val = 0.001

        # Price changes (approximations vs exact) for a hypothetical +100 bps shock
        dy = 0.01  # 100 bps reference
        price_ch_dur = float(-mod_dur * dy * 100.0)  # % change
        price_ch_conv = float(0.5 * conv * dy * dy * 100.0)
        if time_to_mat > dt * 0.1:
            shocked_price, _, _ = calc_bond_price(face_value, coupon_rate,
                                                   ytm + dy, time_to_mat, freq)
            exact_price_ch = float(shocked_price - clean_price_pct)
        else:
            exact_price_ch = 0.0

        row = {
            "scenario": label,
            "time_years": float(round(t, 6)),
            "time_to_maturity_years": float(round(time_to_mat, 6)),
            "market_interest_rate": float(np.clip(market_rate, 0.001, 0.20)),
            "coupon_rate": coupon_rate,
            "face_value": face_value,
            "maturity_years": maturity_years,
            "coupon_frequency": float(freq),
            "credit_spread": credit_spread,
            "ytm": float(np.clip(ytm, 0.001, 0.20)),
            "bond_price": clean_price_pct,
            "clean_price": clean_price_pct,
            "accrued_interest": ai_pct,
            "dirty_price": dirty_price_pct,
            "current_yield": current_yield_val,
            "macaulay_duration": mac_dur,
            "modified_duration": mod_dur,
            "convexity": conv,
            "coupon_payment": round(coupon_payment, 6),
            "cumulative_coupon_received": round(cumulative_coupon, 6),
            "inflation_adjusted_principal": round(infl_adj_principal / face_value * 100.0, 6),
            "inflation_adjusted_coupon": round(infl_adj_coupon_periodic / face_value * 100.0, 6),
            "pv_principal": pv_principal_pct,
            "pv_coupons": pv_coupons_pct,
            "price_change_from_duration": price_ch_dur,
            "price_change_from_convexity": price_ch_conv,
            "exact_price_change": exact_price_ch,
            "credit_spread_bps": credit_spread_bps,
        }
        rows.append(row)

    return rows


def run_all_scenarios() -> List[dict]:
    all_rows = []
    for idx, sc in enumerate(MODEL_PROFILE["scenarios"]):
        rows = run_scenario(sc, idx)
        all_rows.extend(rows)
        print(f"  Scenario [{idx}] {sc['label']}: {len(rows)} steps.")
    return all_rows


# =============================================================================
# FIGURE GENERATION
# =============================================================================

def save_fig(fig, path: pathlib.Path, dpi: int = 150):
    fig.savefig(str(path), dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved: {path.name}")


def fig01_price_yield_curve(out_dir: pathlib.Path):
    """Bond Price vs. YTM for different maturities."""
    try:
        ytm_range = np.linspace(0.001, 0.20, 500)
        maturities = [2, 10, 30, 50]
        colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]

        fig, ax = plt.subplots(figsize=(9, 6))
        for mat, col in zip(maturities, colors):
            prices = np.array([calc_bond_price(1000.0, 0.05, y, mat, 2)[0] for y in ytm_range])
            assert len(ytm_range) == len(prices), "Shape mismatch fig01"
            ax.plot(ytm_range * 100.0, prices, color=col, lw=2, label=f"{mat}-year")

        ax.axvline(x=5.0, color="gray", linestyle="--", alpha=0.6, label="Coupon rate (5%)")
        ax.axhline(y=100.0, color="black", linestyle=":", alpha=0.5, label="Par (100)")
        ax.set_xlabel("Yield to Maturity (%)", fontsize=12)
        ax.set_ylabel("Bond Price (% of par)", fontsize=12)
        ax.set_title("Bond Price vs. Yield to Maturity (Price-Yield Curve)", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)
        ax.set_xlim(0, 20)
        ax.set_ylim(0, 250)
        save_fig(fig, out_dir / "fig01_price_yield_curve.png")
    except Exception as e:
        print(f"  WARNING fig01 failed: {e}")


def fig02_pull_to_par(out_dir: pathlib.Path):
    """Pull-to-Par: bond price convergence over time."""
    try:
        maturity = 10.0
        freq = 2
        face = 1000.0
        coupon = 0.05
        dt = 0.5

        t_vals = np.arange(0.0, maturity + dt * 0.5, dt)
        scenarios_p2p = [
            ("Discount Bond (YTM=7%)", 0.07, "#d62728"),
            ("Par Bond (YTM=5%)",      0.05, "#2ca02c"),
            ("Premium Bond (YTM=3%)",  0.03, "#1f77b4"),
        ]

        fig, ax = plt.subplots(figsize=(9, 6))
        for label, ytm, col in scenarios_p2p:
            prices = np.zeros(len(t_vals))
            for k, t in enumerate(t_vals):
                ttm = max(maturity - t, 0.0)
                if ttm < dt * 0.1:
                    prices[k] = 100.0
                else:
                    prices[k] = calc_bond_price(face, coupon, ytm, ttm, freq)[0]
            assert len(t_vals) == len(prices)
            ax.plot(t_vals, prices, color=col, lw=2, label=label)

        ax.axhline(y=100.0, color="black", linestyle=":", alpha=0.5, label="Par (100)")
        ax.set_xlabel("Time (years from issuance)", fontsize=12)
        ax.set_ylabel("Bond Price (% of par)", fontsize=12)
        ax.set_title("Pull-to-Par: Bond Price Convergence to Face Value Over Time", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)
        save_fig(fig, out_dir / "fig02_pull_to_par.png")
    except Exception as e:
        print(f"  WARNING fig02 failed: {e}")


def fig03_cumulative_cash_flows(out_dir: pathlib.Path):
    """Cumulative Cash Flows: coupon bond vs zero-coupon."""
    try:
        face = 1000.0
        coupon_rate = 0.05
        ytm_coupon = 0.05
        ytm_zcb = 0.05
        maturity = 10.0
        freq = 2

        # Issue price of zero-coupon bond
        zcb_issue_price = face * (1.0 + ytm_zcb / freq) ** (-int(maturity * freq))
        zcb_issue_pct = zcb_issue_price / face * 100.0

        # Build time points at coupon dates
        coupon_times = np.arange(0.5, maturity + 0.25, 0.5)  # every 6 months
        n_steps = len(coupon_times)

        # Coupon bond: accumulate coupons
        coupon_cf = np.zeros(n_steps)
        cum_coupon = np.zeros(n_steps)
        periodic_coupon = coupon_rate * face / freq
        running = 0.0
        for i, t in enumerate(coupon_times):
            cf = periodic_coupon
            if abs(t - maturity) < 0.01:
                cf += face  # principal at maturity
            coupon_cf[i] = cf
            running += cf
            cum_coupon[i] = running

        # Zero-coupon bond
        zcb_cum = np.zeros(n_steps)
        for i, t in enumerate(coupon_times):
            if abs(t - maturity) < 0.01:
                zcb_cum[i:] = face + (face - zcb_issue_price)  # total received
                zcb_cum[i] = face
            else:
                zcb_cum[i] = 0.0

        # Fix zcb cumulative (it's 0 until maturity, then face)
        zcb_cumulative = np.zeros(n_steps)
        for i, t in enumerate(coupon_times):
            zcb_cumulative[i] = face if t >= maturity - 0.01 else 0.0

        assert len(coupon_times) == len(cum_coupon)
        assert len(coupon_times) == len(zcb_cumulative)

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.step(coupon_times, cum_coupon / face * 100.0, where="post",
                color="#1f77b4", lw=2, label="Coupon Bond (5% coupon)")
        ax.step(coupon_times, zcb_cumulative / face * 100.0, where="post",
                color="#d62728", lw=2, label="Zero-Coupon Bond")

        ax.axhline(y=100.0, color="gray", linestyle=":", alpha=0.5)
        ax.annotate(f"ZCB issue price: {zcb_issue_pct:.1f}% of par",
                    xy=(0.5, zcb_issue_pct / (face / face * 100.0)),
                    xytext=(2.5, 30.0), fontsize=9,
                    arrowprops=dict(arrowstyle="->", color="red"),
                    color="red")

        ax.set_xlabel("Time (years)", fontsize=12)
        ax.set_ylabel("Cumulative Cash Flow (% of par)", fontsize=12)
        ax.set_title("Cumulative Cash Flows: Coupon vs. Zero-Coupon Bond", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)
        save_fig(fig, out_dir / "fig03_cumulative_cash_flows.png")
    except Exception as e:
        print(f"  WARNING fig03 failed: {e}")


def fig04_yield_curve(out_dir: pathlib.Path):
    """Yield Curve: term structure shapes."""
    try:
        maturities = np.array([0.25, 0.5, 1.0, 2.0, 3.0, 5.0, 7.0, 10.0, 20.0, 30.0])

        # Normal (upward sloping)
        normal_yields = 0.02 + 0.03 * (1.0 - np.exp(-maturities / 5.0))
        # Flat
        flat_yields = np.full_like(maturities, 0.04)
        # Inverted (downward sloping)
        inverted_yields = 0.07 - 0.03 * (1.0 - np.exp(-maturities / 5.0))

        assert len(maturities) == len(normal_yields)
        assert len(maturities) == len(flat_yields)
        assert len(maturities) == len(inverted_yields)

        fig, ax = plt.subplots(figsize=(9, 6))
        ax.plot(maturities, normal_yields * 100.0, "b-o", lw=2, ms=5, label="Normal (upward sloping)")
        ax.plot(maturities, flat_yields * 100.0,   "g-s", lw=2, ms=5, label="Flat")
        ax.plot(maturities, inverted_yields * 100.0,"r-^", lw=2, ms=5, label="Inverted (downward sloping)")

        ax.set_xlabel("Maturity (years)", fontsize=12)
        ax.set_ylabel("Yield (%)", fontsize=12)
        ax.set_title("Yield Curve: Term Structure of Interest Rates", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)
        save_fig(fig, out_dir / "fig04_yield_curve.png")
    except Exception as e:
        print(f"  WARNING fig04 failed: {e}")


def fig05_duration_vs_maturity(out_dir: pathlib.Path):
    """Macaulay Duration vs Maturity for different coupon rates."""
    try:
        maturities = np.arange(1.0, 31.0, 1.0)
        face = 1000.0
        ytm = 0.05
        freq = 2

        coupon_configs = [
            (0.02, "#1f77b4", "Coupon 2%"),
            (0.05, "#ff7f0e", "Coupon 5%"),
            (0.08, "#2ca02c", "Coupon 8%"),
            (0.00, "#d62728", "Zero Coupon"),
        ]

        fig, ax = plt.subplots(figsize=(9, 6))
        for cr, col, lbl in coupon_configs:
            durations = np.zeros(len(maturities))
            for k, mat in enumerate(maturities):
                if cr == 0.0:
                    durations[k] = mat  # zero coupon: duration = maturity
                else:
                    durations[k] = calc_macaulay_duration(face, cr, ytm, mat, freq)
            assert len(maturities) == len(durations)
            ax.plot(maturities, durations, color=col, lw=2, label=lbl)

        # Reference diagonal
        ax.plot(maturities, maturities, "k--", alpha=0.3, label="Duration = Maturity (reference)")
        ax.set_xlabel("Bond Maturity (years)", fontsize=12)
        ax.set_ylabel("Macaulay Duration (years)", fontsize=12)
        ax.set_title("Macaulay Duration vs. Maturity for Different Bond Types", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)
        save_fig(fig, out_dir / "fig05_duration_vs_maturity.png")
    except Exception as e:
        print(f"  WARNING fig05 failed: {e}")


def fig06_price_sensitivity(out_dir: pathlib.Path):
    """Price sensitivity: duration vs duration+convexity vs exact."""
    try:
        face = 1000.0
        coupon_rate = 0.05
        freq = 2
        base_ytm = 0.05

        bond_configs = [
            (10.0, "#1f77b4", "10-year"),
            (30.0, "#d62728", "30-year"),
        ]

        dy_bps = np.linspace(-300, 300, 121)
        dy = dy_bps / 10000.0

        fig, ax = plt.subplots(figsize=(10, 6))

        for mat, col, lbl in bond_configs:
            base_price, _, _ = calc_bond_price(face, coupon_rate, base_ytm, mat, freq)
            mac_dur = calc_macaulay_duration(face, coupon_rate, base_ytm, mat, freq)
            mod_dur = calc_modified_duration(mac_dur, base_ytm, freq)
            conv = calc_convexity(face, coupon_rate, base_ytm, mat, freq)

            # Arrays same length as dy_bps
            exact_ch = np.zeros(len(dy_bps))
            dur_approx = np.zeros(len(dy_bps))
            dur_conv_approx = np.zeros(len(dy_bps))

            for i, dyi in enumerate(dy):
                new_ytm = float(np.clip(base_ytm + dyi, 0.001, 0.20))
                new_price, _, _ = calc_bond_price(face, coupon_rate, new_ytm, mat, freq)
                exact_ch[i] = (new_price - base_price) / base_price * 100.0
                dur_approx[i] = -mod_dur * dyi * 100.0
                dur_conv_approx[i] = (-mod_dur * dyi + 0.5 * conv * dyi ** 2) * 100.0

            assert len(dy_bps) == len(exact_ch)
            assert len(dy_bps) == len(dur_approx)
            assert len(dy_bps) == len(dur_conv_approx)

            ax.plot(dy_bps, exact_ch, color=col, lw=2.5, label=f"{lbl} Exact")
            ax.plot(dy_bps, dur_approx, color=col, lw=1.5, linestyle="--", label=f"{lbl} Duration only")
            ax.plot(dy_bps, dur_conv_approx, color=col, lw=1.5, linestyle=":", label=f"{lbl} Dur+Convexity")

        ax.axhline(y=0, color="black", linestyle="-", alpha=0.3)
        ax.axvline(x=0, color="black", linestyle="-", alpha=0.3)
        ax.set_xlabel("Yield Change (basis points)", fontsize=12)
        ax.set_ylabel("Price Change (%)", fontsize=12)
        ax.set_title("Price Sensitivity: Duration vs. Duration+Convexity vs. Exact", fontsize=13)
        ax.legend(fontsize=8, ncol=2)
        ax.grid(alpha=0.3)
        save_fig(fig, out_dir / "fig06_price_sensitivity.png")
    except Exception as e:
        print(f"  WARNING fig06 failed: {e}")


def fig07_tips_vs_nominal(out_dir: pathlib.Path):
    """TIPS vs Nominal Bond: principal and coupon over time."""
    try:
        face = 1000.0
        inflation = 0.025
        tips_coupon = 0.025
        nominal_coupon = 0.05
        freq = 2
        maturity = 10.0

        coupon_times = np.arange(0.5, maturity + 0.25, 0.5)
        n = len(coupon_times)

        tips_principals = np.zeros(n)
        tips_coupons = np.zeros(n)
        nominal_principals = np.zeros(n)
        nominal_coupons = np.zeros(n)

        for i, t in enumerate(coupon_times):
            infl_p = tips_principal(face, inflation, t)
            tips_principals[i] = infl_p / face * 100.0
            tips_coupons[i] = tips_coupon * infl_p / freq / face * 100.0
            nominal_principals[i] = 100.0
            nominal_coupons[i] = nominal_coupon * face / freq / face * 100.0

        assert len(coupon_times) == len(tips_principals)
        assert len(coupon_times) == len(nominal_principals)

        fig, axes = plt.subplots(1, 2, figsize=(13, 6))

        # Principal
        ax = axes[0]
        ax.plot(coupon_times, tips_principals, "b-o", lw=2, ms=4, label="TIPS Principal")
        ax.plot(coupon_times, nominal_principals, "r--s", lw=2, ms=4, label="Nominal Principal")
        ax.set_xlabel("Time (years)", fontsize=11)
        ax.set_ylabel("Principal (% of original par)", fontsize=11)
        ax.set_title("Principal Over Time", fontsize=12)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)

        # Coupon payments
        ax2 = axes[1]
        ax2.step(coupon_times, tips_coupons, where="post", color="blue", lw=2,
                 label="TIPS Coupon (growing)")
        ax2.step(coupon_times, nominal_coupons, where="post", color="red", lw=2,
                 linestyle="--", label="Nominal Coupon (fixed)")
        ax2.set_xlabel("Time (years)", fontsize=11)
        ax2.set_ylabel("Coupon Payment (% of original par)", fontsize=11)
        ax2.set_title("Coupon Payments Over Time", fontsize=12)
        ax2.legend(fontsize=10)
        ax2.grid(alpha=0.3)

        fig.suptitle("TIPS vs. Nominal Bond: Principal & Coupon with Inflation (2.5%/yr)", fontsize=13)
        save_fig(fig, out_dir / "fig07_tips_vs_nominal.png")
    except Exception as e:
        print(f"  WARNING fig07 failed: {e}")


def fig08_price_heatmap(out_dir: pathlib.Path):
    """Bond price heatmap over maturity and market rate."""
    try:
        face = 1000.0
        coupon_rate = 0.05
        freq = 2

        mats = np.linspace(1.0, 30.0, 40)
        rates = np.linspace(0.01, 0.15, 40)

        Z = np.zeros((len(rates), len(mats)))
        for i, r in enumerate(rates):
            for j, m in enumerate(mats):
                Z[i, j] = calc_bond_price(face, coupon_rate, r, m, freq)[0]

        fig, ax = plt.subplots(figsize=(10, 7))
        im = ax.imshow(Z, aspect="auto", origin="lower",
                       extent=[mats[0], mats[-1], rates[0] * 100.0, rates[-1] * 100.0],
                       cmap="RdYlBu_r", vmin=50, vmax=150)
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_label("Bond Price (% of par)", fontsize=11)

        # Contour at par
        cs = ax.contour(mats, rates * 100.0, Z, levels=[100.0], colors=["black"], linewidths=2)
        ax.clabel(cs, fmt="Par (100)", fontsize=9)

        ax.set_xlabel("Maturity (years)", fontsize=12)
        ax.set_ylabel("Market Interest Rate (%)", fontsize=12)
        ax.set_title("Bond Price Heatmap: Maturity × Market Rate (Coupon=5%)", fontsize=13)
        save_fig(fig, out_dir / "fig08_price_heatmap.png")
    except Exception as e:
        print(f"  WARNING fig08 failed: {e}")


def fig09_credit_spread_price(out_dir: pathlib.Path):
    """Credit spread vs bond price scatter."""
    try:
        face = 1000.0
        coupon_rate = 0.05
        risk_free = 0.04
        freq = 2

        spreads_bps = np.linspace(0, 800, 81)
        maturities_scatter = [5.0, 10.0, 20.0]
        colors_s = ["#1f77b4", "#ff7f0e", "#2ca02c"]
        markers = ["o", "s", "^"]

        fig, ax = plt.subplots(figsize=(10, 6))

        for mat, col, mk in zip(maturities_scatter, colors_s, markers):
            prices_s = np.zeros(len(spreads_bps))
            for i, sp_bps in enumerate(spreads_bps):
                ytm_s = risk_free + sp_bps / 10000.0
                prices_s[i] = calc_bond_price(face, coupon_rate, ytm_s, mat, freq)[0]
            assert len(spreads_bps) == len(prices_s)
            ax.scatter(spreads_bps, prices_s, color=col, marker=mk, s=30,
                       label=f"{int(mat)}-year", alpha=0.8)

        # Reference lines for credit categories
        ax.axvline(x=200, color="gray", linestyle="--", alpha=0.7)
        ax.axvline(x=500, color="gray", linestyle=":",  alpha=0.7)
        ax.text(100, 55,  "Inv. Grade",  ha="center", fontsize=8, color="gray")
        ax.text(350, 55,  "High Yield",  ha="center", fontsize=8, color="gray")
        ax.text(650, 55,  "Distressed",  ha="center", fontsize=8, color="gray")
        ax.axhline(y=100.0, color="black", linestyle=":", alpha=0.4)

        ax.set_xlabel("Credit Spread (basis points)", fontsize=12)
        ax.set_ylabel("Bond Price (% of par)", fontsize=12)
        ax.set_title("Credit Spread vs. Bond Price: Investment Grade to Junk", fontsize=13)
        ax.legend(fontsize=10)
        ax.grid(alpha=0.3)
        ax.set_ylim(50, 110)
        save_fig(fig, out_dir / "fig09_credit_spread_price.png")
    except Exception as e:
        print(f"  WARNING fig09 failed: {e}")


def fig10_multi_scenario_trajectories(all_rows: List[dict], out_dir: pathlib.Path):
    """Multi-scenario bond price trajectories."""
    try:
        scenarios = [sc["label"] for sc in MODEL_PROFILE["scenarios"]]
        colors_m = plt.cm.tab10(np.linspace(0, 1, len(scenarios)))

        fig, ax = plt.subplots(figsize=(12, 7))

        for sc_label, col in zip(scenarios, colors_m):
            rows_sc = [r for r in all_rows if r["scenario"] == sc_label]
            if not rows_sc:
                continue
            t_arr = np.array([r["time_years"] for r in rows_sc])
            p_arr = np.array([r["bond_price"] for r in rows_sc])
            assert len(t_arr) == len(p_arr)
            if len(t_arr) > 0:
                ax.plot(t_arr, p_arr, lw=2, color=col,
                        label=sc_label.replace("_", " "))

        ax.axhline(y=100.0, color="black", linestyle=":", alpha=0.5, label="Par (100)")
        ax.set_xlabel("Time (years from issuance)", fontsize=12)
        ax.set_ylabel("Bond Price (% of par)", fontsize=12)
        ax.set_title("Multi-Scenario Bond Price Trajectories Over Time", fontsize=13)
        ax.legend(fontsize=8, loc="upper right", ncol=2)
        ax.grid(alpha=0.3)
        save_fig(fig, out_dir / "fig10_multi_scenario_trajectories.png")
    except Exception as e:
        print(f"  WARNING fig10 failed: {e}")


# =============================================================================
# CSV OUTPUT
# =============================================================================

SCHEMA_COLUMNS = [
    "scenario", "time_years", "time_to_maturity_years", "market_interest_rate",
    "coupon_rate", "face_value", "maturity_years", "coupon_frequency",
    "credit_spread", "ytm", "bond_price", "clean_price", "accrued_interest",
    "dirty_price", "current_yield", "macaulay_duration", "modified_duration",
    "convexity", "coupon_payment", "cumulative_coupon_received",
    "inflation_adjusted_principal", "inflation_adjusted_coupon",
    "pv_principal", "pv_coupons",
    "price_change_from_duration", "price_change_from_convexity",
    "exact_price_change", "credit_spread_bps",
]


def write_simulation_outputs(all_rows: List[dict], out_dir: pathlib.Path):
    path = out_dir / "simulation_outputs.csv"
    if not all_rows:
        print("  WARNING: no rows to write for simulation_outputs.csv")
        return
    try:
        with open(str(path), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=SCHEMA_COLUMNS)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({k: row.get(k, "") for k in SCHEMA_COLUMNS})
        print(f"  Saved: simulation_outputs.csv ({len(all_rows)} rows)")
    except Exception as e:
        print(f"  WARNING simulation_outputs.csv failed: {e}")


def write_scenario_summary(all_rows: List[dict], out_dir: pathlib.Path):
    path = out_dir / "scenario_summary.csv"
    if not all_rows:
        print("  WARNING: no rows for scenario_summary.csv")
        return

    numeric_cols = [
        "bond_price", "ytm", "current_yield", "accrued_interest", "dirty_price",
        "macaulay_duration", "modified_duration", "convexity",
        "cumulative_coupon_received", "inflation_adjusted_principal",
        "pv_principal", "pv_coupons",
    ]

    scenarios_labels = list(dict.fromkeys(r["scenario"] for r in all_rows))

    fieldnames = ["scenario", "n_steps"]
    for col in numeric_cols:
        fieldnames += [f"{col}_mean", f"{col}_std", f"{col}_min", f"{col}_max"]

    try:
        with open(str(path), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for sc in scenarios_labels:
                sc_rows = [r for r in all_rows if r["scenario"] == sc]
                row_out: Dict[str, Any] = {"scenario": sc, "n_steps": len(sc_rows)}
                for col in numeric_cols:
                    vals = np.array([r[col] for r in sc_rows if isinstance(r.get(col), (int, float))])
                    if len(vals) > 0:
                        row_out[f"{col}_mean"] = round(float(np.mean(vals)), 6)
                        row_out[f"{col}_std"]  = round(float(np.std(vals)), 6)
                        row_out[f"{col}_min"]  = round(float(np.min(vals)), 6)
                        row_out[f"{col}_max"]  = round(float(np.max(vals)), 6)
                    else:
                        row_out[f"{col}_mean"] = 0.0
                        row_out[f"{col}_std"]  = 0.0
                        row_out[f"{col}_min"]  = 0.0
                        row_out[f"{col}_max"]  = 0.0
                writer.writerow(row_out)
        print(f"  Saved: scenario_summary.csv ({len(scenarios_labels)} scenarios)")
    except Exception as e:
        print(f"  WARNING scenario_summary.csv failed: {e}")


def write_parameters_used(out_dir: pathlib.Path):
    path = out_dir / "parameters_used.csv"
    fieldnames = ["name", "value", "unit", "source", "description"]
    try:
        with open(str(path), "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for name, info in MODEL_PROFILE["parameters"].items():
                writer.writerow({
                    "name": name,
                    "value": info["value"],
                    "unit": info["unit"],
                    "source": info["source"],
                    "description": info["description"],
                })
        print(f"  Saved: parameters_used.csv")
    except Exception as e:
        print(f"  WARNING parameters_used.csv failed: {e}")


def write_summary_json(all_rows: List[dict], out_dir: pathlib.Path):
    path = out_dir / "summary.json"
    try:
        scenarios_labels = list(dict.fromkeys(r["scenario"] for r in all_rows))
        summary = {
            "total_rows": len(all_rows),
            "n_scenarios": len(scenarios_labels),
            "scenarios": scenarios_labels,
            "scenario_metrics": {},
        }
        for sc in scenarios_labels:
            sc_rows = [r for r in all_rows if r["scenario"] == sc]
            prices = [r["bond_price"] for r in sc_rows]
            ytms   = [r["ytm"] for r in sc_rows]
            durs   = [r["macaulay_duration"] for r in sc_rows]
            summary["scenario_metrics"][sc] = {
                "n_steps": len(sc_rows),
                "initial_price": round(prices[0], 4) if prices else 0,
                "final_price":   round(prices[-1], 4) if prices else 0,
                "mean_ytm":      round(float(np.mean(ytms)), 6) if ytms else 0,
                "mean_duration": round(float(np.mean(durs)), 6) if durs else 0,
                "price_range":   [round(min(prices), 4), round(max(prices), 4)] if prices else [0, 0],
            }
        with open(str(path), "w") as f:
            json.dump(summary, f, indent=2)
        print(f"  Saved: summary.json")
    except Exception as e:
        print(f"  WARNING summary.json failed: {e}")


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="Bond Finance Simulator")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files")
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # --- Run simulations ---
    print("\n=== Running Scenarios ===")
    all_rows = run_all_scenarios()
    print(f"Total simulation rows: {len(all_rows)}")

    # --- Save CSV files ---
    print("\n=== Writing CSV Files ===")
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(all_rows, out_dir)
    write_parameters_used(out_dir)

    # --- Save JSON ---
    print("\n=== Writing JSON Summary ===")
    write_summary_json(all_rows, out_dir)

    # --- Generate figures ---
    print("\n=== Generating Figures ===")
    fig01_price_yield_curve(out_dir)
    fig02_pull_to_par(out_dir)
    fig03_cumulative_cash_flows(out_dir)
    fig04_yield_curve(out_dir)
    fig05_duration_vs_maturity(out_dir)
    fig06_price_sensitivity(out_dir)
    fig07_tips_vs_nominal(out_dir)
    fig08_price_heatmap(out_dir)
    fig09_credit_spread_price(out_dir)
    fig10_multi_scenario_trajectories(all_rows, out_dir)

    print("\n=== Simulation Complete ===")
    print(f"All outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()