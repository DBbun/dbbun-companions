# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-24T13:58:55.655275Z
# Run ID    : fb141855-22cf-4195-983b-ce8d980c523b
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Simulator for: Cellular behavior and extracellular matrix turnover in bovine
annulus fibrosus cells under hydrostatic pressure and deviatoric strain.

Models mechanobiological responses (gene expression RQ values) of inner and outer
bovine AF cells under hydrostatic pressure (HP), arc-bending deviatoric strain,
and their combination over 6 days in a 3D collagen gel culture system.

Reference: Cellular behavior and extracellular matrix turnover in bovine annulus
fibrosus cells under hydrostatic pressure and deviatoric strain.
"""

import argparse
import csv
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ---------------------------------------------------------------------------
# MODEL PROFILE
# ---------------------------------------------------------------------------
MODEL_PROFILE = {
    "title": "Cellular behavior and extracellular matrix turnover in bovine annulus fibrosus cells under hydrostatic pressure and deviatoric strain",
    "parameters": {
        "HP_magnitude_cyclic_min": {"value": 0.2, "unit": "MPa", "source": "extracted",
            "description": "Minimum cyclic hydrostatic pressure applied during HP loading phase"},
        "HP_magnitude_cyclic_max": {"value": 0.7, "unit": "MPa", "source": "extracted",
            "description": "Maximum cyclic hydrostatic pressure applied during HP loading phase"},
        "HP_magnitude_constant": {"value": 0.3, "unit": "MPa", "source": "extracted",
            "description": "Constant hydrostatic pressure applied during sustained HP phase"},
        "HP_frequency": {"value": 0.5, "unit": "Hz", "source": "extracted",
            "description": "Frequency of cyclic hydrostatic pressure application"},
        "strain_magnitude": {"value": 0.4, "unit": "percent", "source": "extracted",
            "description": "Peak arc-bending strain magnitude (0-0.4% range)"},
        "strain_frequency": {"value": 0.5, "unit": "Hz", "source": "extracted",
            "description": "Frequency of reciprocated arc-bending strain"},
        "perfusion_rate": {"value": 0.1, "unit": "mL/min", "source": "extracted",
            "description": "Medium perfusion rate through culture chamber"},
        "n_samples": {"value": 5.0, "unit": "dimensionless", "source": "extracted",
            "description": "Number of biological replicates per condition (n=5)"},
        "noise_cv": {"value": 0.25, "unit": "dimensionless", "source": "assumed",
            "description": "Coefficient of variation for biological noise in gene expression"},
        "inner_Acan_baseline": {"value": 1.0, "unit": "a.u.", "source": "extracted",
            "description": "Inner AF Acan RQ at Day 3 unloaded control (reference=1.0)"},
        "outer_Acan_fold_vs_inner": {"value": 0.15, "unit": "a.u.", "source": "extracted",
            "description": "Outer AF Acan ~15% of inner AF"},
        "HP_Acan_fold_day6_vs_day3_inner": {"value": 2.0, "unit": "fold", "source": "extracted",
            "description": "Inner AF Acan under HP at Day 6 is ~2x Day 3"},
        "HP_Csgalnact1_fold_day6_vs_day3_inner": {"value": 2.0, "unit": "fold", "source": "extracted",
            "description": "Inner AF Csgalnact1 under HP at Day 6 is ~2x Day 3"},
        "Unloaded_Csgalnact1_fold_day6_vs_day3_inner": {"value": 2.0, "unit": "fold", "source": "extracted",
            "description": "Inner AF Csgalnact1 under unloaded at Day 6 is ~2x Day 3"},
        "HPStrain_Csgalnact1_downreg_vs_ctrl_day6": {"value": 0.34, "unit": "fold", "source": "extracted",
            "description": "Combined HP/Strain suppresses Csgalnact1 by 66% vs unloaded at Day 6"},
        "HPStrain_Has2_fold_day6_vs_day3_inner": {"value": 1.5, "unit": "fold", "source": "extracted",
            "description": "Inner AF Has2 under HP/Strain at Day 6 significantly increased vs Day 3"},
        "inner_Col2_HPStrain_fold_day6_vs_day3": {"value": 0.15, "unit": "fold", "source": "extracted",
            "description": "Inner AF Col-2 under HP/Strain declined 85% by Day 6 vs Day 3"},
        "outer_Col2_Strain_fold_day6_vs_day3": {"value": 0.25, "unit": "fold", "source": "extracted",
            "description": "Outer AF Col-2 under Strain declined 75% by Day 6 vs Day 3"},
        "outer_Col2_HPStrain_fold_day6_vs_day3": {"value": 0.09, "unit": "fold", "source": "extracted",
            "description": "Outer AF Col-2 under HP/Strain declined 91% by Day 6 vs Day 3"},
        "outer_Col1_inner_ratio": {"value": 4.0, "unit": "fold", "source": "extracted",
            "description": "Outer AF Col-1 expression ~4x inner AF"},
        "Mmp13_fold_day6_vs_day3_all": {"value": 3.5, "unit": "fold", "source": "assumed",
            "description": "Mmp13 shows dramatic increase from Day 3 to Day 6 under all conditions"},
        "inner_Timp2_HPStrain_downreg_vs_ctrl_day6": {"value": 0.43, "unit": "fold", "source": "extracted",
            "description": "Inner AF Timp2 under HP/Strain downregulated 57% vs unloaded at Day 6"},
        "outer_Timp2_HPStrain_downreg_vs_ctrl_day6": {"value": 0.35, "unit": "fold", "source": "extracted",
            "description": "Outer AF Timp2 under HP/Strain downregulated 65% vs unloaded at Day 6"},
        "Timp2_fold_increase_nonHPStrain_day6": {"value": 2.5, "unit": "fold", "source": "assumed",
            "description": "Timp2 increased under unloaded, HP, Strain from Day 3 to Day 6"},
        "inner_Pcna_Strain_fold_day6_vs_day3": {"value": 1.5, "unit": "fold", "source": "extracted",
            "description": "Inner AF Pcna under Strain increased 1.5x at Day 6 vs Day 3"},
        "inner_Pcna_HPStrain_fold_day6_vs_day3": {"value": 3.0, "unit": "fold", "source": "extracted",
            "description": "Inner AF Pcna under HP/Strain increased 3x at Day 6 vs Day 3"},
        "outer_Pcna_unloaded_fold_day6_vs_day3": {"value": 0.49, "unit": "fold", "source": "extracted",
            "description": "Outer AF Pcna under unloaded decreased 51% at Day 6 vs Day 3"},
        "outer_Pcna_HP_fold_day6_vs_day3": {"value": 0.55, "unit": "fold", "source": "extracted",
            "description": "Outer AF Pcna under HP decreased 45% at Day 6 vs Day 3"},
    },
    "scenarios": [
        {"label": "Inner_AF_Unloaded", "cell_type": 0, "loading_condition": 0},
        {"label": "Inner_AF_HP", "cell_type": 0, "loading_condition": 1},
        {"label": "Inner_AF_Strain", "cell_type": 0, "loading_condition": 2},
        {"label": "Inner_AF_HPStrain", "cell_type": 0, "loading_condition": 3},
        {"label": "Outer_AF_Unloaded", "cell_type": 1, "loading_condition": 0},
        {"label": "Outer_AF_HP", "cell_type": 1, "loading_condition": 1},
        {"label": "Outer_AF_Strain", "cell_type": 1, "loading_condition": 2},
        {"label": "Outer_AF_HPStrain", "cell_type": 1, "loading_condition": 3},
    ],
    "genes": ["Acan", "Csgalnact1", "Has2", "Col2", "Col1", "Eln", "Mmp13", "Timp2", "Pcna"],
    "gene_ranges": {
        "Acan": (0.0, 5.0), "Csgalnact1": (0.0, 5.0), "Has2": (0.0, 4.0),
        "Col2": (0.0, 3.0), "Col1": (0.0, 6.0), "Eln": (0.0, 4.0),
        "Mmp13": (0.0, 8.0), "Timp2": (0.0, 6.0), "Pcna": (0.0, 5.0),
    },
    "days": [3, 6],
    "n_replicates": 5,
    "noise_cv": 0.25,
    "loading_names": {0: "Unloaded", 1: "HP", 2: "Strain", 3: "HP_Strain"},
    "cell_type_names": {0: "Inner_AF", 1: "Outer_AF"},
}

# ---------------------------------------------------------------------------
# BASELINE AND FOLD-CHANGE TABLES
# ---------------------------------------------------------------------------

def get_baseline_day3(cell_type_int: int, gene: str) -> float:
    """Return Day 3 baseline RQ for a given cell type and gene."""
    # Inner AF reference baselines (Day 3)
    inner_baselines = {
        "Acan": 1.0, "Csgalnact1": 1.0, "Has2": 1.0, "Col2": 1.0,
        "Col1": 1.0, "Eln": 1.0, "Mmp13": 1.0, "Timp2": 1.0, "Pcna": 1.0,
    }
    # Outer AF baseline ratios relative to inner
    outer_ratios = {
        "Acan": 0.15, "Csgalnact1": 0.5, "Has2": 0.8, "Col2": 0.6,
        "Col1": 4.0, "Eln": 1.0, "Mmp13": 1.0, "Timp2": 1.0, "Pcna": 1.0,
    }
    base = inner_baselines[gene]
    if cell_type_int == 1:  # Outer AF
        base = base * outer_ratios[gene]
    return base


def get_fold_change_day6(cell_type_int: int, loading_condition: int, gene: str) -> float:
    """Return fold change from Day 3 to Day 6 for given cell type, loading, gene."""
    # INNER AF fold changes
    inner_fc = {
        "Acan":       {0: 1.0, 1: 2.0, 2: 1.0,  3: 0.9},
        "Csgalnact1": {0: 2.0, 1: 2.0, 2: 1.6,  3: 0.68},
        "Has2":       {0: 1.0, 1: 1.1, 2: 1.1,  3: 1.5},
        "Col2":       {0: 1.0, 1: 1.0, 2: 1.0,  3: 0.15},
        "Col1":       {0: 1.0, 1: 1.0, 2: 0.85, 3: 0.70},
        "Eln":        {0: 1.0, 1: 1.0, 2: 0.85, 3: 0.75},
        "Mmp13":      {0: 3.5, 1: 3.5, 2: 3.5,  3: 3.5},
        "Timp2":      {0: 2.5, 1: 2.5, 2: 2.2,  3: 1.075},
        "Pcna":       {0: 1.0, 1: 1.0, 2: 1.5,  3: 3.0},
    }
    # OUTER AF fold changes
    outer_fc = {
        "Acan":       {0: 1.0, 1: 1.0,  2: 1.0,  3: 0.9},
        "Csgalnact1": {0: 1.2, 1: 1.2,  2: 1.1,  3: 0.8},
        "Has2":       {0: 1.0, 1: 1.0,  2: 1.0,  3: 1.0},
        "Col2":       {0: 1.0, 1: 1.0,  2: 0.25, 3: 0.09},
        "Col1":       {0: 1.0, 1: 1.0,  2: 0.85, 3: 0.75},
        "Eln":        {0: 1.0, 1: 1.0,  2: 0.80, 3: 0.70},
        "Mmp13":      {0: 3.5, 1: 3.5,  2: 3.5,  3: 3.5},
        "Timp2":      {0: 2.5, 1: 2.5,  2: 2.2,  3: 0.875},
        "Pcna":       {0: 0.49, 1: 0.55, 2: 1.0, 3: 1.0},
    }
    if cell_type_int == 0:
        return inner_fc[gene][loading_condition]
    else:
        return outer_fc[gene][loading_condition]


def compute_mean_RQ(cell_type_int: int, loading_condition: int, gene: str, day: int) -> float:
    """Compute deterministic mean RQ for given condition, gene, and day."""
    baseline = get_baseline_day3(cell_type_int, gene)
    if day == 3:
        return baseline
    fc = get_fold_change_day6(cell_type_int, loading_condition, gene)
    return baseline * fc


def clamp_rq(value: float, gene: str) -> float:
    """Clamp RQ value to gene-specific valid range."""
    lo, hi = MODEL_PROFILE["gene_ranges"][gene]
    return float(max(lo, min(hi, value)))


# ---------------------------------------------------------------------------
# SIMULATION
# ---------------------------------------------------------------------------

def run_simulation() -> List[dict]:
    """Run simulation for all scenarios and return list of row dicts."""
    all_rows = []
    scenarios = MODEL_PROFILE["scenarios"]
    genes = MODEL_PROFILE["genes"]
    days = MODEL_PROFILE["days"]
    n = MODEL_PROFILE["n_replicates"]
    noise_cv = MODEL_PROFILE["noise_cv"]
    loading_names = MODEL_PROFILE["loading_names"]
    cell_type_names = MODEL_PROFILE["cell_type_names"]

    for scenario_idx, scenario in enumerate(scenarios):
        np.random.seed(scenario_idx)
        label = scenario["label"]
        ct = scenario["cell_type"]
        lc = scenario["loading_condition"]

        ct_name = cell_type_names[ct]
        lc_name = loading_names[lc]

        # HP and Strain active flags / physical values
        hp_active = 1 if lc in (1, 3) else 0
        strain_active = 1 if lc in (2, 3) else 0
        hp_pressure = MODEL_PROFILE["parameters"]["HP_magnitude_cyclic_min"]["value"] if hp_active else 0.0
        strain_pct = MODEL_PROFILE["parameters"]["strain_magnitude"]["value"] if strain_active else 0.0

        # Precompute group means and SDs per (day, gene)
        group_means: Dict[Tuple[int, str], float] = {}
        for day in days:
            for gene in genes:
                mu = compute_mean_RQ(ct, lc, gene, day)
                group_means[(day, gene)] = mu

        # Compute group SDs from n replicates
        group_sds: Dict[Tuple[int, str], float] = {}
        for (day, gene), mu in group_means.items():
            samples = mu * np.exp(np.random.normal(0, noise_cv, size=50))
            group_sds[(day, gene)] = float(np.std(samples))

        # Generate replicate rows
        for day in days:
            for rep in range(1, n + 1):
                row: dict = {
                    "scenario": label,
                    "scenario_label": label,
                    "cell_type": ct_name,
                    "loading_condition": lc_name,
                    "day": day,
                    "replicate_id": rep,
                    "HP_active": hp_active,
                    "Strain_active": strain_active,
                    "HP_pressure_MPa": hp_pressure,
                    "Strain_percent": strain_pct,
                }
                for gene in genes:
                    mu = group_means[(day, gene)]
                    rq_sample = mu * np.exp(np.random.normal(0, noise_cv))
                    rq_sample = clamp_rq(rq_sample, gene)
                    row[f"{gene}_RQ"] = round(rq_sample, 6)
                # Add mean and SD columns
                for gene in genes:
                    row[f"{gene}_RQ_mean"] = round(group_means[(day, gene)], 6)
                    row[f"{gene}_RQ_sd"] = round(group_sds[(day, gene)], 6)
                all_rows.append(row)

    return all_rows


# ---------------------------------------------------------------------------
# AGGREGATE METRICS
# ---------------------------------------------------------------------------

def compute_scenario_summary(all_rows: List[dict]) -> List[dict]:
    """Compute per-scenario summary statistics."""
    genes = MODEL_PROFILE["genes"]
    gene_cols = [f"{g}_RQ" for g in genes]

    # Group rows by scenario
    scenario_data: Dict[str, List[dict]] = {}
    for row in all_rows:
        s = row["scenario"]
        if s not in scenario_data:
            scenario_data[s] = []
        scenario_data[s].append(row)

    summaries = []
    for label, rows in scenario_data.items():
        if not rows:
            continue
        summary = {
            "scenario": label,
            "cell_type": rows[0]["cell_type"],
            "loading_condition": rows[0]["loading_condition"],
            "n_rows": len(rows),
        }
        for col in gene_cols:
            vals = np.array([r[col] for r in rows])
            summary[f"{col}_mean"] = round(float(np.mean(vals)), 6)
            summary[f"{col}_std"] = round(float(np.std(vals)), 6)
            summary[f"{col}_min"] = round(float(np.min(vals)), 6)
            summary[f"{col}_max"] = round(float(np.max(vals)), 6)
        summaries.append(summary)
    return summaries


# ---------------------------------------------------------------------------
# HELPER: extract mean RQ table for plotting
# ---------------------------------------------------------------------------

def build_mean_rq_table() -> Dict:
    """Build dict: mean_rq[(cell_type_int, lc_int, gene, day)] = float"""
    genes = MODEL_PROFILE["genes"]
    days = MODEL_PROFILE["days"]
    table = {}
    for ct in [0, 1]:
        for lc in [0, 1, 2, 3]:
            for gene in genes:
                for day in days:
                    table[(ct, lc, gene, day)] = compute_mean_RQ(ct, lc, gene, day)
    return table


def build_sd_table(all_rows: List[dict]) -> Dict:
    """Build dict: sd_table[(scenario_label, gene, day)] = float"""
    genes = MODEL_PROFILE["genes"]
    # Group by scenario, gene, day
    from collections import defaultdict
    groups: Dict = defaultdict(list)
    for row in all_rows:
        s = row["scenario"]
        day = row["day"]
        for gene in genes:
            groups[(s, gene, day)].append(row[f"{gene}_RQ"])
    sd_table = {}
    for key, vals in groups.items():
        sd_table[key] = float(np.std(vals)) if vals else 0.0
    return sd_table


# ---------------------------------------------------------------------------
# FIGURES
# ---------------------------------------------------------------------------

LOADING_COLORS = {0: "#4878CF", 1: "#6ACC65", 2: "#D65F5F", 3: "#B47CC7"}
LOADING_LABELS = {0: "Unloaded", 1: "HP", 2: "Strain", 3: "HP/Strain"}
GENE_MARKERS = ["o", "s", "^", "D", "v", "P", "*", "X", "h"]
GENE_LIST = MODEL_PROFILE["genes"]
DAYS = [3, 6]


def _bar_group_cartilaginous(ax, ct_int: int, genes_subset: List[str],
                              mean_rq: Dict, sd_table: Dict,
                              cell_type_name: str):
    """Draw grouped bar chart for a subset of genes across 4 loading conditions at Day 3 and Day 6."""
    n_genes = len(genes_subset)
    n_lc = 4
    n_days = 2
    bar_width = 0.18
    group_gap = 0.3
    scenario_label_map = {
        (0, 0): "Inner_AF_Unloaded", (0, 1): "Inner_AF_HP",
        (0, 2): "Inner_AF_Strain", (0, 3): "Inner_AF_HPStrain",
        (1, 0): "Outer_AF_Unloaded", (1, 1): "Outer_AF_HP",
        (1, 2): "Outer_AF_Strain", (1, 3): "Outer_AF_HPStrain",
    }
    # x positions: one group per gene
    x_centers = np.arange(n_genes) * (n_lc * n_days * bar_width + group_gap)
    day_hatch = {3: "", 6: "//"}
    day_alpha = {3: 0.6, 6: 1.0}

    handles = []
    for d_idx, day in enumerate(DAYS):
        for lc in range(n_lc):
            color = LOADING_COLORS[lc]
            hatch = day_hatch[day]
            alpha = day_alpha[day]
            offsets = ((d_idx * n_lc) + lc) * bar_width - (n_lc * n_days * bar_width / 2)
            vals = []
            errs = []
            for gene in genes_subset:
                mu = mean_rq.get((ct_int, lc, gene, day), 0.0)
                scen = scenario_label_map[(ct_int, lc)]
                sd = sd_table.get((scen, gene, day), 0.0)
                vals.append(mu)
                errs.append(sd)
            bars = ax.bar(x_centers + offsets, vals, width=bar_width,
                          color=color, hatch=hatch, alpha=alpha,
                          edgecolor="black", linewidth=0.5,
                          yerr=errs, capsize=2, error_kw={"elinewidth": 0.8})
            if d_idx == 1:  # only add to legend once per condition
                handles.append(mpatches.Patch(color=color, label=LOADING_LABELS[lc]))

    ax.set_xticks(x_centers)
    ax.set_xticklabels(genes_subset, fontsize=9)
    ax.set_ylabel("Relative Quantity (a.u.)", fontsize=9)
    ax.set_title(f"{cell_type_name} — {'&'.join(genes_subset)}", fontsize=10)
    ax.legend(handles=handles, fontsize=7, ncol=2, loc="upper right")
    # Add day indicator text
    ax.text(0.01, 0.97, "Light=Day3, Dark/hatched=Day6", transform=ax.transAxes,
            fontsize=7, va="top", color="gray")


def fig1_cartilaginous_inner(all_rows: List[dict], mean_rq: Dict,
                               sd_table: Dict, out_dir: Path):
    """Fig 1: Cartilaginous ECM gene expression in Inner AF cells."""
    try:
        genes_subset = ["Acan", "Csgalnact1", "Has2", "Col2"]
        fig, ax = plt.subplots(figsize=(12, 5))
        _bar_group_cartilaginous(ax, ct_int=0, genes_subset=genes_subset,
                                  mean_rq=mean_rq, sd_table=sd_table,
                                  cell_type_name="Inner AF")
        fig.suptitle("Cartilaginous ECM Gene Expression in Inner AF Cells (Days 3 and 6)",
                     fontsize=12, fontweight="bold")
        plt.tight_layout()
        fpath = out_dir / "fig1_cartilaginous_inner.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig1_cartilaginous_inner failed: {e}")


def fig2_cartilaginous_outer(all_rows: List[dict], mean_rq: Dict,
                               sd_table: Dict, out_dir: Path):
    """Fig 2: Cartilaginous ECM gene expression in Outer AF cells."""
    try:
        genes_subset = ["Acan", "Csgalnact1", "Has2", "Col2"]
        fig, ax = plt.subplots(figsize=(12, 5))
        _bar_group_cartilaginous(ax, ct_int=1, genes_subset=genes_subset,
                                  mean_rq=mean_rq, sd_table=sd_table,
                                  cell_type_name="Outer AF")
        fig.suptitle("Cartilaginous ECM Gene Expression in Outer AF Cells (Days 3 and 6)",
                     fontsize=12, fontweight="bold")
        plt.tight_layout()
        fpath = out_dir / "fig2_cartilaginous_outer.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig2_cartilaginous_outer failed: {e}")


def fig3_fibrous_molecules(mean_rq: Dict, sd_table: Dict, out_dir: Path):
    """Fig 3: Fibrous ECM (Col1 and Eln) in Inner and Outer AF cells."""
    try:
        genes_subset = ["Col1", "Eln"]
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        cell_names = {0: "Inner AF", 1: "Outer AF"}
        for ax, ct_int in zip(axes, [0, 1]):
            _bar_group_cartilaginous(ax, ct_int=ct_int, genes_subset=genes_subset,
                                      mean_rq=mean_rq, sd_table=sd_table,
                                      cell_type_name=cell_names[ct_int])
        fig.suptitle("Fibrous ECM Gene Expression (Col-1 and Elastin) in Inner and Outer AF Cells",
                     fontsize=12, fontweight="bold")
        plt.tight_layout()
        fpath = out_dir / "fig3_fibrous_molecules.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig3_fibrous_molecules failed: {e}")


def fig4_catabolic_turnover(mean_rq: Dict, sd_table: Dict, out_dir: Path):
    """Fig 4: MMP-13 and TIMP-2 in Inner and Outer AF cells."""
    try:
        genes_subset = ["Mmp13", "Timp2"]
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        cell_names = {0: "Inner AF", 1: "Outer AF"}
        for ax, ct_int in zip(axes, [0, 1]):
            _bar_group_cartilaginous(ax, ct_int=ct_int, genes_subset=genes_subset,
                                      mean_rq=mean_rq, sd_table=sd_table,
                                      cell_type_name=cell_names[ct_int])
        fig.suptitle("Catabolic Turnover: MMP-13 and TIMP-2 Gene Expression in Inner and Outer AF Cells",
                     fontsize=12, fontweight="bold")
        plt.tight_layout()
        fpath = out_dir / "fig4_catabolic_turnover.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig4_catabolic_turnover failed: {e}")


def fig5_cell_proliferation(mean_rq: Dict, sd_table: Dict, out_dir: Path):
    """Fig 5: PCNA expression in Inner and Outer AF cells."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(12, 5))
        cell_names = {0: "Inner AF", 1: "Outer AF"}
        scenario_label_map = {
            (0, 0): "Inner_AF_Unloaded", (0, 1): "Inner_AF_HP",
            (0, 2): "Inner_AF_Strain", (0, 3): "Inner_AF_HPStrain",
            (1, 0): "Outer_AF_Unloaded", (1, 1): "Outer_AF_HP",
            (1, 2): "Outer_AF_Strain", (1, 3): "Outer_AF_HPStrain",
        }
        for ax, ct_int in zip(axes, [0, 1]):
            for lc in range(4):
                x_vals = np.array(DAYS, dtype=float)
                y_vals = np.array([mean_rq[(ct_int, lc, "Pcna", d)] for d in DAYS])
                y_err = np.array([sd_table.get((scenario_label_map[(ct_int, lc)], "Pcna", d), 0.0)
                                  for d in DAYS])
                assert len(x_vals) == len(y_vals) == len(y_err), "Array length mismatch"
                ax.plot(x_vals, y_vals, color=LOADING_COLORS[lc],
                        marker="o", linewidth=2, label=LOADING_LABELS[lc])
                ax.fill_between(x_vals, y_vals - y_err, y_vals + y_err,
                                alpha=0.2, color=LOADING_COLORS[lc])
            ax.set_xlabel("Day", fontsize=9)
            ax.set_ylabel("PCNA RQ (a.u.)", fontsize=9)
            ax.set_title(f"{cell_names[ct_int]}", fontsize=10)
            ax.set_xticks(DAYS)
            ax.legend(fontsize=7)
        fig.suptitle("Cell Proliferation (PCNA) Gene Expression in Inner and Outer AF Cells",
                     fontsize=12, fontweight="bold")
        plt.tight_layout()
        fpath = out_dir / "fig5_cell_proliferation.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig5_cell_proliferation failed: {e}")


def fig6_heatmap_day6_summary(mean_rq: Dict, out_dir: Path):
    """Fig 6: Heatmap of normalized gene expression at Day 6."""
    try:
        genes = MODEL_PROFILE["genes"]
        n_genes = len(genes)
        # 8 conditions: 4 lc x 2 ct
        conditions = []
        for ct in [0, 1]:
            for lc in [0, 1, 2, 3]:
                ct_name = MODEL_PROFILE["cell_type_names"][ct]
                lc_name = MODEL_PROFILE["loading_names"][lc]
                conditions.append(f"{ct_name}\n{lc_name}")

        # Build data matrix: rows=genes, cols=conditions
        data = np.zeros((n_genes, len(conditions)))
        col_idx = 0
        for ct in [0, 1]:
            for lc in [0, 1, 2, 3]:
                for g_idx, gene in enumerate(genes):
                    data[g_idx, col_idx] = mean_rq[(ct, lc, gene, 6)]
                col_idx += 1

        # Normalize per gene to max
        row_max = data.max(axis=1, keepdims=True)
        row_max[row_max == 0] = 1.0
        data_norm = data / row_max

        fig, ax = plt.subplots(figsize=(14, 6))
        im = ax.imshow(data_norm, aspect="auto", cmap="RdYlBu_r", vmin=0, vmax=1)
        ax.set_xticks(range(len(conditions)))
        ax.set_xticklabels(conditions, fontsize=8)
        ax.set_yticks(range(n_genes))
        ax.set_yticklabels(genes, fontsize=9)
        plt.colorbar(im, ax=ax, label="Normalized RQ (0-1)")
        # Annotate cells
        for i in range(n_genes):
            for j in range(len(conditions)):
                ax.text(j, i, f"{data_norm[i, j]:.2f}", ha="center", va="center",
                        fontsize=6, color="black")
        ax.set_title("Heatmap of Normalized Gene Expression at Day 6: All Conditions × All Genes",
                     fontsize=11, fontweight="bold")
        plt.tight_layout()
        fpath = out_dir / "fig6_heatmap_day6_summary.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig6_heatmap_day6_summary failed: {e}")


def fig7_inner_outer_comparison_day6(mean_rq: Dict, out_dir: Path):
    """Fig 7: Scatter of inner vs outer AF RQ at Day 6."""
    try:
        genes = MODEL_PROFILE["genes"]
        condition_colors = {0: "#4878CF", 1: "#6ACC65", 2: "#D65F5F", 3: "#B47CC7"}
        gene_markers = {g: GENE_MARKERS[i % len(GENE_MARKERS)] for i, g in enumerate(genes)}

        fig, ax = plt.subplots(figsize=(9, 8))

        x_all = []
        y_all = []

        for lc in [0, 1, 2, 3]:
            for gene in genes:
                inner_rq = mean_rq[(0, lc, gene, 6)]
                outer_rq = mean_rq[(1, lc, gene, 6)]
                x_all.append(inner_rq)
                y_all.append(outer_rq)
                ax.scatter(inner_rq, outer_rq,
                           color=condition_colors[lc],
                           marker=gene_markers[gene],
                           s=80, alpha=0.85, edgecolors="black", linewidth=0.5,
                           label=f"{LOADING_LABELS[lc]}-{gene}")

        assert len(x_all) == len(y_all), "Array length mismatch in scatter"

        if len(x_all) > 0 and len(y_all) > 0:
            all_vals = x_all + y_all
            v_max = max(all_vals) * 1.1
            v_min = min(0, min(all_vals))
            diag = np.linspace(v_min, v_max, 100)
            ax.plot(diag, diag, "k--", linewidth=1, alpha=0.5, label="y=x (equal)")

        ax.set_xlabel("Inner AF RQ at Day 6 (a.u.)", fontsize=10)
        ax.set_ylabel("Outer AF RQ at Day 6 (a.u.)", fontsize=10)
        ax.set_title("Inner vs. Outer AF Gene Expression at Day 6: Phenotypic Contrast",
                     fontsize=11, fontweight="bold")

        # Custom legend: conditions
        cond_handles = [mpatches.Patch(color=condition_colors[lc], label=LOADING_LABELS[lc])
                        for lc in range(4)]
        # Gene markers
        gene_handles = [plt.Line2D([0], [0], marker=gene_markers[g], color="gray",
                                   linestyle="None", markersize=8, label=g) for g in genes]
        leg1 = ax.legend(handles=cond_handles, title="Loading", loc="upper left",
                         fontsize=8, framealpha=0.7)
        ax.add_artist(leg1)
        ax.legend(handles=gene_handles, title="Gene", loc="lower right",
                  fontsize=7, framealpha=0.7, ncol=2)

        plt.tight_layout()
        fpath = out_dir / "fig7_inner_outer_comparison_day6.png"
        plt.savefig(fpath, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: fig7_inner_outer_comparison_day6 failed: {e}")


# ---------------------------------------------------------------------------
# CSV WRITERS
# ---------------------------------------------------------------------------

def write_simulation_outputs(all_rows: List[dict], out_dir: Path):
    """Write simulation_outputs.csv with full time-series for all scenarios."""
    if not all_rows:
        print("WARNING: No rows to write for simulation_outputs.csv")
        return
    try:
        fpath = out_dir / "simulation_outputs.csv"
        fieldnames = [
            "scenario", "scenario_label", "cell_type", "loading_condition",
            "day", "replicate_id", "HP_active", "Strain_active",
            "HP_pressure_MPa", "Strain_percent",
        ]
        genes = MODEL_PROFILE["genes"]
        for g in genes:
            fieldnames.append(f"{g}_RQ")
        for g in genes:
            fieldnames.append(f"{g}_RQ_mean")
        for g in genes:
            fieldnames.append(f"{g}_RQ_sd")

        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for row in all_rows:
                writer.writerow(row)
        print(f"Saved {fpath} ({len(all_rows)} rows)")
    except Exception as e:
        print(f"WARNING: Failed to write simulation_outputs.csv: {e}")


def write_scenario_summary(summaries: List[dict], out_dir: Path):
    """Write scenario_summary.csv with one row per scenario."""
    if not summaries:
        print("WARNING: No summary rows to write.")
        return
    try:
        fpath = out_dir / "scenario_summary.csv"
        genes = MODEL_PROFILE["genes"]
        fieldnames = ["scenario", "cell_type", "loading_condition", "n_rows"]
        for g in genes:
            for stat in ["mean", "std", "min", "max"]:
                fieldnames.append(f"{g}_RQ_{stat}")

        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for row in summaries:
                writer.writerow(row)
        print(f"Saved {fpath} ({len(summaries)} rows)")
    except Exception as e:
        print(f"WARNING: Failed to write scenario_summary.csv: {e}")


def write_parameters_used(out_dir: Path):
    """Write parameters_used.csv with all model parameters."""
    try:
        fpath = out_dir / "parameters_used.csv"
        params = MODEL_PROFILE["parameters"]
        fieldnames = ["name", "value", "unit", "source", "description"]
        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for name, info in params.items():
                writer.writerow({
                    "name": name,
                    "value": info["value"],
                    "unit": info["unit"],
                    "source": info["source"],
                    "description": info["description"],
                })
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: Failed to write parameters_used.csv: {e}")


def write_summary_json(all_rows: List[dict], summaries: List[dict], out_dir: Path):
    """Write summary.json with key aggregate metrics."""
    try:
        genes = MODEL_PROFILE["genes"]
        # Overall means across all scenarios
        gene_overall_means = {}
        for gene in genes:
            vals = [r[f"{gene}_RQ"] for r in all_rows]
            gene_overall_means[f"{gene}_overall_mean"] = round(float(np.mean(vals)), 4)

        # Best scenario for each gene (highest Day 6 mean)
        best_scenario_per_gene = {}
        for gene in genes:
            best_val = -1.0
            best_scen = ""
            for summ in summaries:
                val = summ.get(f"{gene}_RQ_mean", 0.0)
                if val > best_val:
                    best_val = val
                    best_scen = summ["scenario"]
            best_scenario_per_gene[f"{gene}_best_scenario"] = best_scen

        summary = {
            "title": MODEL_PROFILE["title"],
            "n_scenarios": len(MODEL_PROFILE["scenarios"]),
            "n_genes": len(genes),
            "n_replicates": MODEL_PROFILE["n_replicates"],
            "time_points": MODEL_PROFILE["days"],
            "total_rows": len(all_rows),
            "gene_overall_means": gene_overall_means,
            "best_scenario_per_gene": best_scenario_per_gene,
            "key_findings": {
                "Mmp13_fold_day3_to_day6": 3.5,
                "Inner_AF_Pcna_HPStrain_fold": 3.0,
                "Inner_AF_Col2_HPStrain_decline_pct": 85.0,
                "Outer_AF_Col2_HPStrain_decline_pct": 91.0,
                "Inner_AF_Csgalnact1_HP_fold": 2.0,
            }
        }
        fpath = out_dir / "summary.json"
        with open(fpath, "w") as f:
            json.dump(summary, f, indent=2)
        print(f"Saved {fpath}")
    except Exception as e:
        print(f"WARNING: Failed to write summary.json: {e}")


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Simulator for AF cell mechanobiology under HP and deviatoric strain"
    )
    parser.add_argument("--output", default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # --- Run simulation ---
    print("\n=== Running simulation ===")
    all_rows = run_simulation()
    print(f"Generated {len(all_rows)} total rows across all scenarios.")

    # --- Build mean RQ and SD tables for plotting ---
    mean_rq = build_mean_rq_table()
    sd_table = build_sd_table(all_rows)

    # --- Compute scenario summary ---
    summaries = compute_scenario_summary(all_rows)

    # --- Write CSV files ---
    print("\n=== Writing CSV files ===")
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(summaries, out_dir)
    write_parameters_used(out_dir)

    # --- Write JSON summary ---
    print("\n=== Writing JSON summary ===")
    write_summary_json(all_rows, summaries, out_dir)

    # --- Generate figures ---
    print("\n=== Generating figures ===")
    fig1_cartilaginous_inner(all_rows, mean_rq, sd_table, out_dir)
    fig2_cartilaginous_outer(all_rows, mean_rq, sd_table, out_dir)
    fig3_fibrous_molecules(mean_rq, sd_table, out_dir)
    fig4_catabolic_turnover(mean_rq, sd_table, out_dir)
    fig5_cell_proliferation(mean_rq, sd_table, out_dir)
    fig6_heatmap_day6_summary(mean_rq, out_dir)
    fig7_inner_outer_comparison_day6(mean_rq, out_dir)

    print("\n=== Simulation complete ===")
    print(f"All outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()