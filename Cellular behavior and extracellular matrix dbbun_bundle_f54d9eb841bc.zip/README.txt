================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : fb141855-22cf-4195-983b-ce8d980c523b
    Generated   : 2026-04-24  13:58:55 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Cellular behavior and extracellular matrix turnover in bovine annulus fibrosus cells under hydrostatic pressure and deviatoric strain

    CATEGORIES
    ----------
    Biomedical and Health Sciences, Biophysiological Signals

    KEYWORDS
    --------
    annulus fibrosus, hydrostatic pressure, deviatoric strain, extracellular matrix, intervertebral disc

    ABSTRACT
    --------
    This simulator models the mechanobiological responses of inner and outer bovine annulus fibrosus (AF) cells to three distinct loading regimes—hydrostatic pressure (HP), arc-bending deviatoric strain, and their combination (HP/Strain)—over a 6-day in vitro culture period. It reproduces the gene expression dynamics of nine ECM and cellular markers (Acan, Csgalnact1, Has2, Col-2, Col-1, Elastin, MMP-13, TIMP-2, PCNA) as measured by RT-qPCR using the 2-ΔΔCt method, faithfully capturing the key findings that combined HP/Strain suppresses synthetic ECM activity while paradoxically elevating cell proliferation (PCNA) in inner AF cells. The simulator generates synthetic replicate-level datasets with biologically realistic lognormal noise (n=5 replicates per condition) and produces publication-quality figures including grouped bar charts with error bars and significance annotations, a comprehensive heatmap, and inner-versus-outer AF scatter comparisons. Researchers studying intervertebral disc mechanobiology, tissue engineers designing AF repair strategies, and educators teaching mechanotransduction can use this simulator to explore how loading magnitude and type modulate the balance between anabolic, catabolic, and proliferative cellular activities.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Journal Orthopaedic Research - 2023 - Taiji - Cellular behavior and extracellular matrix turnover in bovine annulus.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    Acan_RQ, Csgalnact1_RQ, Has2_RQ, Col2_RQ, Col1_RQ, Eln_RQ, Mmp13_RQ, Timp2_RQ, Pcna_RQ, day, cell_type, loading_condition

    SCENARIOS  (8 total)
    ---------------------------------
        1. Inner_AF_Unloaded — Inner AF cells under unloaded control condition, perfusion only, Days 3-6
2. Inner_AF_HP — Inner AF cells under cyclic HP (0.2-0.7 MPa, 0.5 Hz, 2 days) + constant HP (0.3 MPa, 1 day) repeated, Days 3-6
3. Inner_AF_Strain — Inner AF cells under continuous arc-bending strain (0-0.4%, 0.5 Hz), Days 3-6
4. Inner_AF_HPStrain — Inner AF cells under combined HP + deviatoric strain, Days 3-6
5. Outer_AF_Unloaded — Outer AF cells under unloaded control condition, perfusion only, Days 3-6
6. Outer_AF_HP — Outer AF cells under cyclic HP (0.2-0.7 MPa, 0.5 Hz), Days 3-6
7. Outer_AF_Strain — Outer AF cells under continuous arc-bending strain (0-0.4%, 0.5 Hz), Days 3-6
8. Outer_AF_HPStrain — Outer AF cells under combined HP + deviatoric strain, Days 3-6

    PARAMETERS
    ----------
    33 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1_cartilaginous_inner, fig2_cartilaginous_outer, fig3_fibrous_molecules, fig4_catabolic_turnover, fig5_cell_proliferation, fig6_heatmap_day6_summary, fig7_inner_outer_comparison_day6

    DOMAIN SUMMARY
    --------------
    This paper investigates how hydrostatic pressure (HP), arc-bending deviatoric strain, and their combination affect extracellular matrix (ECM) gene expression and cell proliferation in inner and outer bovine annulus fibrosus (AF) cells over 6 days in a 3D collagen gel culture system mimicking spinal loading conditions.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.