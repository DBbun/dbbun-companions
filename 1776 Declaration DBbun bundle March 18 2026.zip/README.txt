================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.0.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 8a551a30-8b7c-4679-8bce-2d30d8671a2d
    Generated   : 2026-03-18  10:36:52 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    US Declaration of Independence 1776 (HHRG-117-GO00-20220929-SD010)

    CATEGORIES
    ----------
    Social Sciences, Demographic, Other

    KEYWORDS
    --------
    Declaration of Independence, historical political process, colonial deliberation timeline, agent-based historical simulation, consensus dynamics

    ABSTRACT
    --------
    This simulator models the political and deliberative process documented in the US Declaration of Independence (1776), reproducing the timeline of events from the May 10 1776 recommendation resolution through the final signing by Matthew Thornton in November 1776. Using logistic growth functions for colonial support, step-function finite-state machines for resolution stages, and extracted signer counts per colony, the simulator generates synthetic time-series data capturing grievance accumulation (27 total), delegate signature progression (1 on July 4, 55 on August 2, 56 by November), and the formal commitment of all 13 colonies to independence. Researchers and educators can use the simulator to visualize the deliberation process, explore counterfactual scenarios (rapid versus slow consensus, partial British response to petitions), and generate publication-quality figures illustrating how political consensus forms under conditions of accumulated grievances and peer colony influence. Engineers and social scientists can adapt the agent-based colony model to study general collective decision-making dynamics in multi-agent political systems.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    US Declaration of Independence 1776 HHRG-117-GO00-20220929-SD010.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    colony_support, grievance_count, delegate_signatures, resolution_stage, days_elapsed, colonies_committed, petition_rounds

    SCENARIOS  (5 total)
    ---------------------------------
        1. historical_baseline — Reproduce the exact historical timeline from May 10 to August 2 1776 as extracted from the document, showing grievance accumulation, colonial support growth, and delegate signature accumulation.
2. rapid_consensus — Hypothetical scenario where colonial support grows faster (e.g., unanimous early agreement), compressing the deliberation timeline by 50%.
3. slow_consensus — Hypothetical scenario where colonial support grows slowly due to greater internal dissent, extending deliberation significantly.
4. partial_petition_response — Counterfactual scenario where the British Crown responds to some petitions (inefficacy=0.5), reducing grievance accumulation rate and slowing colonial support.
5. delegate_signature_race — Focus on the August 2 signing event: model the rate at which 55 delegates sign the parchment copy on a single day versus Thornton's late signing in November.

    PARAMETERS
    ----------
    33 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This document is the US Declaration of Independence (1776), a historical-political text enumerating grievances against the British Crown and declaring colonial independence. It contains no quantitative scientific data, experiments, or measurable phenomena.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.