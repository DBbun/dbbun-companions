# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.0.0
# Generated : 2026-03-18T14:36:52.552944Z
# Run ID    : 8a551a30-8b7c-4679-8bce-2d30d8671a2d
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Declaration of Independence 1776 Agent-Based Simulator

Paper: US Declaration of Independence 1776 (HHRG-117-GO00-20220929-SD010)

This simulator models the political and deliberative process documented in the
US Declaration of Independence (1776), reproducing the timeline of events from
the May 10 1776 recommendation resolution through the final signing by Matthew
Thornton in November 1776.
"""

import argparse
import csv
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Any, Optional
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import date, timedelta

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "total_colonies": {"value": 13.0, "unit": "count", "source": "extracted",
                           "description": "Total number of united colonies represented in Congress"},
        "total_signers": {"value": 56.0, "unit": "count", "source": "extracted",
                          "description": "Total number of delegates who ultimately signed the Declaration"},
        "committee_size": {"value": 5.0, "unit": "count", "source": "extracted",
                           "description": "Size of the drafting committee"},
        "board_of_war_size": {"value": 5.0, "unit": "count", "source": "extracted",
                              "description": "Size of the Board of War and Ordnance committee"},
        "day_recommendation": {"value": 0.0, "unit": "days", "source": "extracted",
                               "description": "Day 0: May 10 1776, resolution recommending colonial governments adopted"},
        "day_preamble": {"value": 5.0, "unit": "days", "source": "extracted",
                         "description": "Day 5: May 15 1776, preamble agreed to"},
        "day_independence_moved": {"value": 28.0, "unit": "days", "source": "extracted",
                                   "description": "Day 28: June 7 1776, independence resolutions moved"},
        "day_committee_formed": {"value": 31.0, "unit": "days", "source": "extracted",
                                 "description": "Day 31: June 10-11 1776, drafting committee appointed"},
        "day_confederation_committee": {"value": 32.0, "unit": "days", "source": "extracted",
                                        "description": "Day 32: June 11 1776, confederation committee appointed"},
        "day_war_board": {"value": 33.0, "unit": "days", "source": "extracted",
                          "description": "Day 33: June 12 1776, Board of War formed"},
        "day_pennsylvania_concurrence": {"value": 46.0, "unit": "days", "source": "extracted",
                                         "description": "Day 46: June 25 1776, Pennsylvania deputies concur"},
        "day_draft_tabled": {"value": 49.0, "unit": "days", "source": "extracted",
                             "description": "Day 49: June 28 1776, draft declaration tabled"},
        "day_maryland_authorization": {"value": 52.0, "unit": "days", "source": "extracted",
                                       "description": "Day 52: July 1 1776, Maryland authorizes"},
        "day_resolution_adopted": {"value": 53.0, "unit": "days", "source": "extracted",
                                   "description": "Day 53: July 2 1776, resolution adopted"},
        "day_declaration_agreed": {"value": 55.0, "unit": "days", "source": "extracted",
                                   "description": "Day 55: July 4 1776, Declaration agreed to"},
        "day_parchment_signed": {"value": 84.0, "unit": "days", "source": "extracted",
                                 "description": "Day 84: August 2 1776, parchment copy signed"},
        "day_thornton_signed": {"value": 185.0, "unit": "days", "source": "extracted",
                                "description": "Day 185: November 1776, Thornton signs"},
        "grievance_accumulation_rate": {"value": 0.49, "unit": "grievances/day", "source": "assumed",
                                        "description": "Rate of grievance enumeration"},
        "support_growth_rate": {"value": 0.08, "unit": "per day", "source": "assumed",
                                "description": "Logistic growth rate of colonial support"},
        "petition_inefficacy": {"value": 1.0, "unit": "a.u.", "source": "extracted",
                                "description": "Inefficacy of petition rounds"},
        "nh_delegates": {"value": 3.0, "unit": "count", "source": "extracted",
                         "description": "Signers from New Hampshire"},
        "ma_delegates": {"value": 4.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Massachusetts Bay"},
        "ri_delegates": {"value": 2.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Rhode Island"},
        "ct_delegates": {"value": 4.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Connecticut"},
        "ny_delegates": {"value": 4.0, "unit": "count", "source": "extracted",
                         "description": "Signers from New York"},
        "nj_delegates": {"value": 5.0, "unit": "count", "source": "extracted",
                         "description": "Signers from New Jersey"},
        "pa_delegates": {"value": 9.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Pennsylvania"},
        "de_delegates": {"value": 3.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Delaware"},
        "md_delegates": {"value": 4.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Maryland"},
        "va_delegates": {"value": 7.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Virginia"},
        "nc_delegates": {"value": 3.0, "unit": "count", "source": "extracted",
                         "description": "Signers from North Carolina"},
        "sc_delegates": {"value": 4.0, "unit": "count", "source": "extracted",
                         "description": "Signers from South Carolina"},
        "ga_delegates": {"value": 3.0, "unit": "count", "source": "extracted",
                         "description": "Signers from Georgia"},
    },
    "scenarios": [
        {
            "label": "historical_baseline",
            "description": "Reproduce the exact historical timeline from May 10 to August 2 1776.",
            "param_overrides": {
                "support_growth_rate": 0.08,
                "grievance_accumulation_rate": 0.49,
                "petition_inefficacy": 1.0
            }
        },
        {
            "label": "rapid_consensus",
            "description": "Hypothetical scenario where colonial support grows faster.",
            "param_overrides": {
                "support_growth_rate": 0.16,
                "grievance_accumulation_rate": 0.98,
                "petition_inefficacy": 1.0
            }
        },
        {
            "label": "slow_consensus",
            "description": "Hypothetical scenario where colonial support grows slowly.",
            "param_overrides": {
                "support_growth_rate": 0.03,
                "grievance_accumulation_rate": 0.25,
                "petition_inefficacy": 1.0
            }
        },
        {
            "label": "partial_petition_response",
            "description": "Counterfactual where British Crown responds to some petitions.",
            "param_overrides": {
                "support_growth_rate": 0.04,
                "grievance_accumulation_rate": 0.20,
                "petition_inefficacy": 0.5
            }
        },
        {
            "label": "delegate_signature_race",
            "description": "Focus on the August 2 signing event.",
            "param_overrides": {
                "support_growth_rate": 0.08,
                "grievance_accumulation_rate": 0.49,
                "petition_inefficacy": 1.0
            }
        },
    ]
}

# Colony data
COLONIES = [
    {"abbr": "NH", "name": "New Hampshire", "signers": 3, "committed_day": 0},
    {"abbr": "MA", "name": "Massachusetts Bay", "signers": 4, "committed_day": 5},
    {"abbr": "RI", "name": "Rhode Island", "signers": 2, "committed_day": 10},
    {"abbr": "CT", "name": "Connecticut", "signers": 4, "committed_day": 15},
    {"abbr": "NY", "name": "New York", "signers": 4, "committed_day": 55},  # NY abstained initially
    {"abbr": "NJ", "name": "New Jersey", "signers": 5, "committed_day": 40},
    {"abbr": "PA", "name": "Pennsylvania", "signers": 9, "committed_day": 46},
    {"abbr": "DE", "name": "Delaware", "signers": 3, "committed_day": 30},
    {"abbr": "MD", "name": "Maryland", "signers": 4, "committed_day": 52},
    {"abbr": "VA", "name": "Virginia", "signers": 7, "committed_day": 0},
    {"abbr": "NC", "name": "North Carolina", "signers": 3, "committed_day": 20},
    {"abbr": "SC", "name": "South Carolina", "signers": 4, "committed_day": 35},
    {"abbr": "GA", "name": "Georgia", "signers": 3, "committed_day": 25},
]

STAGE_LABELS = {
    0: "pre-resolution",
    1: "recommendation passed",
    2: "draft tabled",
    3: "resolution adopted",
    4: "declaration adopted",
    5: "fully signed",
}

BASE_DATE = date(1776, 5, 10)
T_MID = 40  # Logistic inflection point (mid-June deliberations)
SIM_DAYS = 186  # 0 to 185 inclusive


def logistic(t: float, k: float, t_mid: float = T_MID) -> float:
    """Compute logistic function value, normalized to [0, 1]."""
    exponent = -k * (t - t_mid)
    # Clamp exponent to avoid overflow
    exponent = max(-500.0, min(500.0, exponent))
    return 1.0 / (1.0 + math.exp(exponent))


def compute_colony_support_fraction(t: int, k: float) -> float:
    """Compute normalized colony support fraction in [0, 1]."""
    val = logistic(t, k, T_MID)
    return max(0.0, min(1.0, val))


def compute_grievance_count(t: int, r_g: float) -> float:
    """Compute cumulative grievances in [0, 27]."""
    if t < 31:
        return 0.0
    if t >= 55:
        return 27.0
    val = r_g * (t - 31)
    return max(0.0, min(27.0, val))


def compute_delegate_signatures(t: int) -> float:
    """Compute cumulative delegate signatures in [0, 56]."""
    if t < 55:
        return 0.0
    elif t == 55:
        return 1.0
    elif t < 84:
        # Linear interpolation from 1 to 55
        val = 1.0 + 54.0 * (t - 55) / (84 - 55)
        return max(1.0, min(55.0, val))
    elif t < 185:
        return 55.0
    else:
        return 56.0


def compute_resolution_stage(t: int) -> int:
    """Compute resolution stage FSM in {0,1,2,3,4,5}."""
    if t < 0:
        return 0
    elif t < 49:
        return 1
    elif t < 53:
        return 2
    elif t < 55:
        return 3
    elif t < 84:
        return 4
    else:
        return 5


def compute_colonies_committed(t: int, support_fraction: float) -> int:
    """Compute number of colonies committed in [0, 13]."""
    # Use milestone overrides at key historical points
    if t >= 53:
        return 13
    if t >= 52:
        return 12  # Maryland + others
    if t >= 46:
        return 11  # Pennsylvania + others
    # Otherwise use logistic interpolation via support_fraction
    val = round(support_fraction * 13)
    return max(0, min(13, val))


def compute_petition_rounds(t: int, inefficacy: float) -> float:
    """Compute petition rounds in [0, 10]."""
    if t <= 55:
        val = min(math.floor(t / 10), 6)
    else:
        val = 6
    # Scale by inefficacy (full inefficacy = all rounds unanswered)
    return max(0.0, min(10.0, float(val) * inefficacy))


def compute_colony_support_bit(colony: dict, t: int, support_fraction: float,
                                rng: np.random.RandomState) -> int:
    """Compute per-colony binary support bit."""
    committed_day = colony["committed_day"]
    if t >= 53:
        return 1  # All committed after resolution adopted
    if t >= committed_day:
        return 1
    # Probabilistic support based on overall fraction
    prob = support_fraction
    return int(rng.random() < prob)


def run_scenario(scenario: dict, scenario_index: int) -> List[dict]:
    """Run simulation for a single scenario, returning list of row dicts."""
    np.random.seed(scenario_index)
    rng = np.random.RandomState(scenario_index)

    label = scenario["label"]
    overrides = scenario["param_overrides"]

    k = overrides.get("support_growth_rate", 0.08)
    r_g = overrides.get("grievance_accumulation_rate", 0.49)
    petition_inefficacy = overrides.get("petition_inefficacy", 1.0)

    rows = []

    for t in range(SIM_DAYS):
        calendar_date = (BASE_DATE + timedelta(days=t)).isoformat()

        support_fraction = compute_colony_support_fraction(t, k)
        grievance_count = compute_grievance_count(t, r_g)
        delegate_signatures = compute_delegate_signatures(t)
        resolution_stage = compute_resolution_stage(t)
        colonies_committed = compute_colonies_committed(t, support_fraction)
        petition_rounds = compute_petition_rounds(t, petition_inefficacy)
        stage_label = STAGE_LABELS.get(resolution_stage, "unknown")

        # Per-colony support bits
        colony_bits = {}
        for colony in COLONIES:
            bit = compute_colony_support_bit(colony, t, support_fraction, rng)
            colony_bits[colony["abbr"]] = bit

        row = {
            "scenario": label,
            "days_elapsed": t,
            "calendar_date": calendar_date,
            "resolution_stage": resolution_stage,
            "resolution_stage_label": stage_label,
            "colony_support_fraction": round(support_fraction, 6),
            "colonies_committed": colonies_committed,
            "grievance_count": round(grievance_count, 4),
            "delegate_signatures": round(delegate_signatures, 4),
            "petition_rounds": round(petition_rounds, 4),
            "petition_inefficacy": petition_inefficacy,
            "support_growth_rate": k,
            "grievance_accumulation_rate": r_g,
            "colony_NH": colony_bits["NH"],
            "colony_MA": colony_bits["MA"],
            "colony_RI": colony_bits["RI"],
            "colony_CT": colony_bits["CT"],
            "colony_NY": colony_bits["NY"],
            "colony_NJ": colony_bits["NJ"],
            "colony_PA": colony_bits["PA"],
            "colony_DE": colony_bits["DE"],
            "colony_MD": colony_bits["MD"],
            "colony_VA": colony_bits["VA"],
            "colony_NC": colony_bits["NC"],
            "colony_SC": colony_bits["SC"],
            "colony_GA": colony_bits["GA"],
        }
        rows.append(row)

    return rows


def extract_arrays(rows: List[dict], x_key: str, y_key: str):
    """Extract matched x and y numpy arrays from rows."""
    x_vals = []
    y_vals = []
    for row in rows:
        if x_key in row and y_key in row:
            x_vals.append(row[x_key])
            y_vals.append(row[y_key])
    x_arr = np.array(x_vals, dtype=float)
    y_arr = np.array(y_vals, dtype=float)
    return x_arr, y_arr


def get_scenario_rows(all_rows: List[dict], label: str) -> List[dict]:
    """Filter rows by scenario label."""
    return [r for r in all_rows if r["scenario"] == label]


def generate_figures(all_rows: List[dict], scenarios: List[dict], output_dir: Path) -> None:
    """Generate all 8 figures and save as PNG."""

    # --- Figure 1: Logistic Growth of Colonial Support (historical_baseline) ---
    try:
        baseline_rows = get_scenario_rows(all_rows, "historical_baseline")
        x_arr, y_arr = extract_arrays(baseline_rows, "days_elapsed", "colony_support_fraction")
        assert len(x_arr) == len(y_arr), "Array length mismatch fig1"
        if len(x_arr) > 0:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(x_arr, y_arr, 'b-', linewidth=2, label="Historical Baseline")
            ax.axvline(x=53, color='r', linestyle='--', alpha=0.7, label="Day 53: Resolution Adopted (Jul 2)")
            ax.axvline(x=55, color='g', linestyle='--', alpha=0.7, label="Day 55: Declaration Agreed (Jul 4)")
            ax.set_xlabel("Days Elapsed (from May 10, 1776)")
            ax.set_ylabel("Colony Support Fraction [0–1]")
            ax.set_title("Logistic Growth of Colonial Support for Independence (May–July 1776)")
            ax.legend()
            ax.set_ylim(0.0, 1.0)
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(output_dir / "fig1_colony_support_logistic.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig1 - no data to plot")
    except Exception as e:
        print(f"Warning: fig1 failed: {e}")

    # --- Figure 2: Cumulative Grievances ---
    try:
        baseline_rows = get_scenario_rows(all_rows, "historical_baseline")
        x_arr, y_arr = extract_arrays(baseline_rows, "days_elapsed", "grievance_count")
        assert len(x_arr) == len(y_arr), "Array length mismatch fig2"
        if len(x_arr) > 0:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(x_arr, y_arr, 'darkred', linewidth=2)
            ax.axvline(x=31, color='orange', linestyle='--', alpha=0.8, label="Day 31: Committee Formed (Jun 10)")
            ax.axvline(x=55, color='green', linestyle='--', alpha=0.8, label="Day 55: Declaration Agreed (Jul 4)")
            ax.axhline(y=27, color='gray', linestyle=':', alpha=0.7, label="27 Grievances (max)")
            ax.set_xlabel("Days Elapsed (from May 10, 1776)")
            ax.set_ylabel("Cumulative Grievances Enumerated")
            ax.set_title("Cumulative Enumerated Grievances Against the British Crown Over Time")
            ax.legend()
            ax.set_ylim(0.0, 28.0)
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(output_dir / "fig2_grievance_accumulation.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig2 - no data to plot")
    except Exception as e:
        print(f"Warning: fig2 failed: {e}")

    # --- Figure 3: Delegate Signatures ---
    try:
        baseline_rows = get_scenario_rows(all_rows, "historical_baseline")
        x_arr, y_arr = extract_arrays(baseline_rows, "days_elapsed", "delegate_signatures")
        assert len(x_arr) == len(y_arr), "Array length mismatch fig3"
        if len(x_arr) > 0:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(x_arr, y_arr, 'purple', linewidth=2)
            ax.axvline(x=55, color='green', linestyle='--', alpha=0.8, label="Day 55: Hancock Signs (Jul 4)")
            ax.axvline(x=84, color='blue', linestyle='--', alpha=0.8, label="Day 84: 55 Sign Parchment (Aug 2)")
            ax.axvline(x=185, color='red', linestyle='--', alpha=0.8, label="Day 185: Thornton Signs (Nov)")
            ax.set_xlabel("Days Elapsed (from May 10, 1776)")
            ax.set_ylabel("Cumulative Delegate Signatures")
            ax.set_title("Cumulative Delegate Signatures on the Declaration (May–November 1776)")
            ax.legend()
            ax.set_ylim(0.0, 57.0)
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(output_dir / "fig3_delegate_signatures.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig3 - no data to plot")
    except Exception as e:
        print(f"Warning: fig3 failed: {e}")

    # --- Figure 4: Colonies Committed ---
    try:
        baseline_rows = get_scenario_rows(all_rows, "historical_baseline")
        x_arr, y_arr = extract_arrays(baseline_rows, "days_elapsed", "colonies_committed")
        assert len(x_arr) == len(y_arr), "Array length mismatch fig4"
        if len(x_arr) > 0:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(x_arr, y_arr, 'teal', linewidth=2)
            ax.axvline(x=46, color='orange', linestyle='--', alpha=0.8, label="Day 46: Pennsylvania Concurs (Jun 25)")
            ax.axvline(x=52, color='blue', linestyle='--', alpha=0.8, label="Day 52: Maryland Authorizes (Jul 1)")
            ax.axvline(x=53, color='red', linestyle='--', alpha=0.8, label="Day 53: Resolution Adopted (Jul 2)")
            ax.set_xlabel("Days Elapsed (from May 10, 1776)")
            ax.set_ylabel("Colonies Committed (count)")
            ax.set_title("Number of Colonies Formally Authorizing Independence Vote Over Time")
            ax.legend()
            ax.set_ylim(0.0, 14.0)
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(output_dir / "fig4_colonies_committed.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig4 - no data to plot")
    except Exception as e:
        print(f"Warning: fig4 failed: {e}")

    # --- Figure 5: Signers per Colony (scatter) ---
    try:
        colony_abbrs = [c["abbr"] for c in COLONIES]
        colony_signers = np.array([c["signers"] for c in COLONIES], dtype=float)
        x_indices = np.arange(len(colony_abbrs), dtype=float)
        assert len(x_indices) == len(colony_signers), "Array length mismatch fig5"
        if len(x_indices) > 0:
            fig, ax = plt.subplots(figsize=(12, 6))
            ax.scatter(x_indices, colony_signers, s=150, c='navy', zorder=5)
            for i, (abbr, n) in enumerate(zip(colony_abbrs, colony_signers)):
                ax.annotate(f"{abbr}\n{int(n)}", (x_indices[i], n),
                            textcoords="offset points", xytext=(0, 8),
                            ha='center', fontsize=9)
            ax.set_xticks(x_indices)
            ax.set_xticklabels(colony_abbrs, rotation=45, ha='right')
            ax.set_xlabel("Colony")
            ax.set_ylabel("Number of Signers")
            ax.set_title("Number of Signers per Colony")
            ax.set_ylim(0, max(colony_signers) + 2)
            ax.grid(True, alpha=0.3, axis='y')
            fig.tight_layout()
            fig.savefig(output_dir / "fig5_signers_per_colony_scatter.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig5 - no data to plot")
    except Exception as e:
        print(f"Warning: fig5 failed: {e}")

    # --- Figure 6: Resolution Stage Progression ---
    try:
        baseline_rows = get_scenario_rows(all_rows, "historical_baseline")
        x_arr, y_arr = extract_arrays(baseline_rows, "days_elapsed", "resolution_stage")
        assert len(x_arr) == len(y_arr), "Array length mismatch fig6"
        if len(x_arr) > 0:
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.step(x_arr, y_arr, where='post', color='darkblue', linewidth=2)
            # Annotate stages
            stage_annotations = [
                (0, 1, "Stage 1:\nRecommendation"),
                (49, 2, "Stage 2:\nDraft Tabled"),
                (53, 3, "Stage 3:\nResolution Adopted"),
                (55, 4, "Stage 4:\nDeclaration Agreed"),
                (84, 5, "Stage 5:\nParchment Signed"),
            ]
            for day, stage, label in stage_annotations:
                ax.annotate(label, (day, stage), textcoords="offset points",
                            xytext=(5, 5), fontsize=7, color='darkred')
            ax.set_yticks([0, 1, 2, 3, 4, 5])
            ax.set_yticklabels([STAGE_LABELS[i] for i in range(6)], fontsize=8)
            ax.set_xlabel("Days Elapsed (from May 10, 1776)")
            ax.set_ylabel("Resolution Stage")
            ax.set_title("Resolution Stage Progression: From Recommendation to Full Ratification")
            ax.set_ylim(-0.2, 5.5)
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(output_dir / "fig6_resolution_stage.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig6 - no data to plot")
    except Exception as e:
        print(f"Warning: fig6 failed: {e}")

    # --- Figure 7: Scenario Comparison of Colony Support ---
    try:
        scenario_labels_to_plot = [
            ("historical_baseline", "Historical Baseline (k=0.08)", "blue"),
            ("rapid_consensus", "Rapid Consensus (k=0.16)", "green"),
            ("slow_consensus", "Slow Consensus (k=0.03)", "red"),
            ("partial_petition_response", "Partial Petition Response (k=0.04)", "orange"),
        ]
        fig, ax = plt.subplots(figsize=(12, 7))
        plotted_any = False
        for sc_label, sc_display, sc_color in scenario_labels_to_plot:
            sc_rows = get_scenario_rows(all_rows, sc_label)
            if len(sc_rows) == 0:
                print(f"Warning: fig7 - no rows for scenario {sc_label}")
                continue
            x_arr, y_arr = extract_arrays(sc_rows, "days_elapsed", "colony_support_fraction")
            if len(x_arr) != len(y_arr):
                print(f"Warning: fig7 - mismatched arrays for {sc_label}")
                continue
            if len(x_arr) == 0:
                continue
            ax.plot(x_arr, y_arr, color=sc_color, linewidth=2, label=sc_display)
            plotted_any = True
        if plotted_any:
            ax.axvline(x=55, color='gray', linestyle='--', alpha=0.5, label="Day 55: Jul 4 (Declaration)")
            ax.set_xlabel("Days Elapsed (from May 10, 1776)")
            ax.set_ylabel("Colony Support Fraction [0–1]")
            ax.set_title("Scenario Comparison: Colonial Support Under Fast, Historical, and Slow Consensus")
            ax.legend()
            ax.set_ylim(0.0, 1.05)
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            fig.savefig(output_dir / "fig7_scenario_comparison_support.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig7 - nothing plotted")
            plt.close(fig)
    except Exception as e:
        print(f"Warning: fig7 failed: {e}")

    # --- Figure 8: Distribution of Signers (histogram/bar) ---
    try:
        colony_abbrs = [c["abbr"] for c in COLONIES]
        colony_signers = np.array([c["signers"] for c in COLONIES], dtype=float)
        x_indices = np.arange(len(colony_abbrs), dtype=float)
        assert len(x_indices) == len(colony_signers), "Array length mismatch fig8"
        if len(x_indices) > 0:
            fig, ax = plt.subplots(figsize=(12, 6))
            bars = ax.bar(x_indices, colony_signers, color='steelblue', edgecolor='black', alpha=0.8)
            ax.set_xticks(x_indices)
            ax.set_xticklabels(colony_abbrs, rotation=45, ha='right')
            ax.set_xlabel("Colony")
            ax.set_ylabel("Number of Signers")
            ax.set_title("Distribution of Signers Across 13 Colonies")
            ax.set_ylim(0, max(colony_signers) + 1.5)
            for bar, val in zip(bars, colony_signers):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.1,
                        str(int(val)), ha='center', va='bottom', fontsize=9)
            ax.grid(True, alpha=0.3, axis='y')
            fig.tight_layout()
            fig.savefig(output_dir / "fig8_signers_distribution.png", dpi=150)
            plt.close(fig)
        else:
            print("Warning: fig8 - no data to plot")
    except Exception as e:
        print(f"Warning: fig8 failed: {e}")


def compute_scenario_summary(all_rows: List[dict]) -> List[dict]:
    """Compute one summary row per scenario."""
    summaries = []
    scenario_labels = list(dict.fromkeys(r["scenario"] for r in all_rows))

    numeric_keys = [
        "colony_support_fraction", "grievance_count", "delegate_signatures",
        "resolution_stage", "colonies_committed", "petition_rounds"
    ]

    for label in scenario_labels:
        sc_rows = [r for r in all_rows if r["scenario"] == label]
        if not sc_rows:
            continue
        summary = {"scenario": label, "n_steps": len(sc_rows)}
        for key in numeric_keys:
            vals = np.array([r[key] for r in sc_rows if key in r], dtype=float)
            if len(vals) > 0:
                summary[f"{key}_mean"] = float(round(np.mean(vals), 6))
                summary[f"{key}_std"] = float(round(np.std(vals), 6))
                summary[f"{key}_min"] = float(round(np.min(vals), 6))
                summary[f"{key}_max"] = float(round(np.max(vals), 6))
            else:
                summary[f"{key}_mean"] = 0.0
                summary[f"{key}_std"] = 0.0
                summary[f"{key}_min"] = 0.0
                summary[f"{key}_max"] = 0.0
        # KPIs
        support_vals = np.array([r["colony_support_fraction"] for r in sc_rows], dtype=float)
        day_half_support = next(
            (r["days_elapsed"] for r in sc_rows if r["colony_support_fraction"] >= 0.5), SIM_DAYS
        )
        summary["day_half_support"] = day_half_support
        summary["support_growth_rate"] = sc_rows[0]["support_growth_rate"]
        summary["grievance_accumulation_rate"] = sc_rows[0]["grievance_accumulation_rate"]
        summary["petition_inefficacy"] = sc_rows[0]["petition_inefficacy"]
        summaries.append(summary)

    return summaries


def write_simulation_outputs_csv(all_rows: List[dict], output_dir: Path) -> None:
    """Write simulation_outputs.csv with all rows from all scenarios."""
    if not all_rows:
        print("Warning: simulation_outputs.csv - no data to write")
        return

    fieldnames = [
        "scenario", "days_elapsed", "calendar_date", "resolution_stage",
        "resolution_stage_label", "colony_support_fraction", "colonies_committed",
        "grievance_count", "delegate_signatures", "petition_rounds",
        "petition_inefficacy", "support_growth_rate", "grievance_accumulation_rate",
        "colony_NH", "colony_MA", "colony_RI", "colony_CT", "colony_NY", "colony_NJ",
        "colony_PA", "colony_DE", "colony_MD", "colony_VA", "colony_NC", "colony_SC", "colony_GA"
    ]

    filepath = output_dir / "simulation_outputs.csv"
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in all_rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})
    print(f"Written: {filepath} ({len(all_rows)} rows)")


def write_scenario_summary_csv(summaries: List[dict], output_dir: Path) -> None:
    """Write scenario_summary.csv."""
    if not summaries:
        print("Warning: scenario_summary.csv - no data to write")
        return

    # Gather all keys
    all_keys = []
    for s in summaries:
        for k in s.keys():
            if k not in all_keys:
                all_keys.append(k)

    filepath = output_dir / "scenario_summary.csv"
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=all_keys)
        writer.writeheader()
        for row in summaries:
            writer.writerow({k: row.get(k, "") for k in all_keys})
    print(f"Written: {filepath} ({len(summaries)} rows)")


def write_parameters_csv(output_dir: Path) -> None:
    """Write parameters_used.csv."""
    params = MODEL_PROFILE["parameters"]
    rows = []
    for name, info in params.items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })

    if not rows:
        print("Warning: parameters_used.csv - no data to write")
        return

    filepath = output_dir / "parameters_used.csv"
    fieldnames = ["name", "value", "unit", "source", "description"]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    print(f"Written: {filepath} ({len(rows)} rows)")


def write_summary_json(all_rows: List[dict], summaries: List[dict], output_dir: Path) -> None:
    """Write summary.json with aggregate metrics."""
    summary = {
        "paper": "US Declaration of Independence 1776 (HHRG-117-GO00-20220929-SD010)",
        "total_rows": len(all_rows),
        "n_scenarios": len(summaries),
        "simulation_days": SIM_DAYS,
        "base_date": BASE_DATE.isoformat(),
        "colony_data": [
            {"abbr": c["abbr"], "name": c["name"], "signers": c["signers"]}
            for c in COLONIES
        ],
        "total_signers": sum(c["signers"] for c in COLONIES),
        "total_colonies": len(COLONIES),
        "scenario_summaries": []
    }

    for s in summaries:
        entry = {
            "scenario": s.get("scenario", ""),
            "support_growth_rate": s.get("support_growth_rate", 0),
            "grievance_accumulation_rate": s.get("grievance_accumulation_rate", 0),
            "petition_inefficacy": s.get("petition_inefficacy", 0),
            "day_half_support": s.get("day_half_support", 0),
            "colony_support_fraction_mean": s.get("colony_support_fraction_mean", 0),
            "grievance_count_max": s.get("grievance_count_max", 0),
            "delegate_signatures_max": s.get("delegate_signatures_max", 0),
        }
        summary["scenario_summaries"].append(entry)

    filepath = output_dir / "summary.json"
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"Written: {filepath}")


def main() -> None:
    """Main entry point for the Declaration of Independence simulator."""
    parser = argparse.ArgumentParser(
        description="US Declaration of Independence 1776 Agent-Based Simulator"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    # Run all scenarios
    all_rows: List[dict] = []
    scenarios = MODEL_PROFILE["scenarios"]

    for scenario_index, scenario in enumerate(scenarios):
        print(f"Running scenario [{scenario_index}]: {scenario['label']}")
        rows = run_scenario(scenario, scenario_index)
        all_rows.extend(rows)
        print(f"  -> {len(rows)} rows generated")

    print(f"\nTotal rows across all scenarios: {len(all_rows)}")

    # Compute summaries
    summaries = compute_scenario_summary(all_rows)

    # Write CSV files
    write_simulation_outputs_csv(all_rows, output_dir)
    write_scenario_summary_csv(summaries, output_dir)
    write_parameters_csv(output_dir)

    # Generate figures
    print("\nGenerating figures...")
    generate_figures(all_rows, scenarios, output_dir)

    # Write JSON summary
    write_summary_json(all_rows, summaries, output_dir)

    print("\nSimulation complete.")
    print(f"All outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()