# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-26T19:29:36.640686Z
# Run ID    : 138d73b7-5020-403d-80a0-6382ac0f75f9
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
SPDR Gold Trust (GLD) Intraday Price Action – April 24, 2026

Simulator for intraday price dynamics of the SPDR Gold Trust ETF (NYSE: GLD)
using multi-regime stochastic processes: GBM during opening surge and after-hours,
Ornstein-Uhlenbeck mean-reverting process during midday consolidation.

Paper: SPDR Gold Trust (GLD) Intraday Price Action – April 24, 2026
"""

import argparse
import csv
import json
import math
import pathlib
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "title": "SPDR Gold Trust (GLD) Intraday Price Action – April 24, 2026",
    "parameters": {
        "open_price": {"value": 431.36, "unit": "USD", "source": "extracted",
                       "description": "Official market open price on April 24, 2026"},
        "close_price": {"value": 433.25, "unit": "USD", "source": "extracted",
                        "description": "Regular session close price at 4:00 PM EDT"},
        "high_price": {"value": 435.28, "unit": "USD", "source": "extracted",
                       "description": "Intraday high price reached during the session"},
        "low_price": {"value": 430.66, "unit": "USD", "source": "extracted",
                      "description": "Intraday low price reached during the session"},
        "previous_close": {"value": 431.04, "unit": "USD", "source": "extracted",
                           "description": "Previous day closing price shown as dotted reference line"},
        "after_hours_close": {"value": 433.25, "unit": "USD", "source": "extracted",
                              "description": "After-hours price at 8:00 PM EDT (approx same as close)"},
        "daily_change_pct": {"value": 0.51, "unit": "%", "source": "extracted",
                             "description": "Percentage price change on the day"},
        "daily_change_abs": {"value": 2.21, "unit": "USD", "source": "extracted",
                             "description": "Absolute price change on the day"},
        "market_cap": {"value": 159350000000.0, "unit": "USD", "source": "extracted",
                       "description": "Market capitalization of GLD at close"},
        "pe_ratio": {"value": 2.81, "unit": "a.u.", "source": "extracted",
                     "description": "Price-to-earnings ratio of the trust"},
        "week_52_high": {"value": 514.17, "unit": "USD", "source": "extracted",
                         "description": "52-week high price"},
        "week_52_low": {"value": 291.80, "unit": "USD", "source": "extracted",
                        "description": "52-week low price"},
        "base_volatility": {"value": 0.12, "unit": "annualized fraction", "source": "assumed",
                            "description": "Base annualized volatility for GBM, typical for gold ETFs"},
        "open_surge_duration_min": {"value": 15.0, "unit": "minutes", "source": "assumed",
                                    "description": "Duration of the opening surge regime after market open"},
        "open_surge_drift": {"value": 0.18, "unit": "USD/min", "source": "assumed",
                             "description": "Average drift per minute during opening surge"},
        "consolidation_mean_price": {"value": 433.8, "unit": "USD", "source": "assumed",
                                     "description": "Mean reversion level during midday consolidation regime"},
        "mean_reversion_speed": {"value": 0.05, "unit": "per minute", "source": "assumed",
                                 "description": "Ornstein-Uhlenbeck mean-reversion coefficient during consolidation"},
        "after_hours_vol_factor": {"value": 0.3, "unit": "a.u.", "source": "assumed",
                                   "description": "Volatility multiplier for after-hours trading (lower volume)"},
        "vol_intraday_minutes": {"value": 390.0, "unit": "minutes", "source": "assumed",
                                 "description": "Total regular trading session length in minutes"},
        "dt": {"value": 1.0, "unit": "minutes", "source": "assumed",
               "description": "Simulation time step in minutes"},
        "num_simulations": {"value": 500.0, "unit": "count", "source": "assumed",
                            "description": "Number of Monte Carlo simulation paths for ensemble analysis"},
    },
    "scenarios": [
        {
            "label": "baseline_april24",
            "index": 0,
            "param_overrides": {
                "base_volatility": 0.12,
                "open_surge_drift": 0.18,
                "mean_reversion_speed": 0.05,
                "after_hours_vol_factor": 0.3,
                "consolidation_mean_price": 433.8,
            }
        },
        {
            "label": "high_volatility_day",
            "index": 1,
            "param_overrides": {
                "base_volatility": 0.24,
                "open_surge_drift": 0.25,
                "mean_reversion_speed": 0.03,
                "after_hours_vol_factor": 0.3,
                "consolidation_mean_price": 433.8,
            }
        },
        {
            "label": "low_volatility_day",
            "index": 2,
            "param_overrides": {
                "base_volatility": 0.06,
                "open_surge_drift": 0.10,
                "mean_reversion_speed": 0.08,
                "after_hours_vol_factor": 0.3,
                "consolidation_mean_price": 433.8,
            }
        },
        {
            "label": "bearish_reversal",
            "index": 3,
            "param_overrides": {
                "open_surge_drift": 0.20,
                "consolidation_mean_price": 431.5,
                "mean_reversion_speed": 0.07,
                "base_volatility": 0.14,
                "after_hours_vol_factor": 0.3,
            }
        },
        {
            "label": "monte_carlo_ensemble",
            "index": 4,
            "param_overrides": {
                "num_simulations": 500,
                "base_volatility": 0.12,
                "mean_reversion_speed": 0.05,
                "open_surge_drift": 0.18,
                "after_hours_vol_factor": 0.3,
                "consolidation_mean_price": 433.8,
            }
        },
    ]
}

# ============================================================
# CONSTANTS
# ============================================================
OPEN_PRICE = 431.36
PREV_CLOSE = 431.04
OBSERVED_HIGH = 435.28
OBSERVED_LOW = 430.66
OBSERVED_CLOSE = 433.25
DT = 1.0
T_REGULAR = 390
T_AFTERHOURS = 240
T_TOTAL = T_REGULAR + T_AFTERHOURS  # 630
TRADING_DAYS = 252
MINUTES_PER_YEAR = TRADING_DAYS * 390  # 98280

# Per-minute sigma base (for base_vol=0.12)
SIGMA_PER_MIN_BASE = 0.12 / math.sqrt(MINUTES_PER_YEAR)

# Price range clamps
PRICE_LO = 425.0
PRICE_HI = 450.0


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def get_default_params() -> Dict:
    """Return default scenario parameters merged from MODEL_PROFILE."""
    return {
        "base_volatility": 0.12,
        "open_surge_drift": 0.18,
        "mean_reversion_speed": 0.05,
        "after_hours_vol_factor": 0.3,
        "consolidation_mean_price": 433.8,
        "num_simulations": 500,
    }


def volume_profile(t: int) -> float:
    """U-shaped intraday volume profile. Returns relative volume index."""
    if t <= T_REGULAR:
        val = 4.0 * math.exp(-0.03 * t) + 2.0 * math.exp(-0.05 * (T_REGULAR - t)) + 0.3
    else:
        val = 0.15
    return float(np.clip(val, 0.2, 5.0))


def bid_ask_spread(t: int) -> float:
    """Bid-ask spread based on volume (wider at low volume)."""
    vol_0 = volume_profile(0)
    vol_t = volume_profile(t)
    spread = 0.05 * vol_0 / max(vol_t, 0.01)
    return float(np.clip(spread, 0.01, 0.25))


def simulate_path(seed: int, scenario_params: Dict) -> Tuple[np.ndarray, List[str]]:
    """
    Simulate a single GLD intraday price path using multi-regime stochastic process.

    Returns:
        prices: np.ndarray of shape (T_TOTAL+1,)
        regimes: list of regime labels for steps 0..T_TOTAL-1
    """
    np.random.seed(seed)

    base_vol = scenario_params["base_volatility"]
    surge_drift = scenario_params["open_surge_drift"]
    theta = scenario_params["mean_reversion_speed"]
    mu_ou = scenario_params["consolidation_mean_price"]
    ah_vol_factor = scenario_params["after_hours_vol_factor"]

    minutes_per_year = float(MINUTES_PER_YEAR)
    sigma_base = base_vol / math.sqrt(minutes_per_year)

    prices = np.zeros(T_TOTAL + 1)
    prices[0] = OPEN_PRICE
    regimes = []

    for t in range(T_TOTAL):
        P = prices[t]
        eps = np.random.normal(0.0, 1.0)

        if t < 15:
            # Regime 1: Opening surge (GBM with positive drift)
            mu = surge_drift / OPEN_PRICE  # proportional drift per minute
            sigma = 2.5 * sigma_base
            dP = mu * P * DT + sigma * P * math.sqrt(DT) * eps
            regime = "surge"

        elif t < 240:
            # Regime 2: OU mean reversion (consolidation)
            sigma = sigma_base
            dP = theta * (mu_ou - P) * DT + sigma * P * math.sqrt(DT) * eps
            regime = "consolidation"

        elif t < 390:
            # Regime 3: Afternoon drift (slight negative drift)
            mu = -0.00005
            sigma = 0.8 * sigma_base
            dP = mu * P * DT + sigma * P * math.sqrt(DT) * eps
            regime = "afternoon_drift"

        else:
            # Regime 4: After-hours (low vol, near-zero drift)
            mu = 0.00001
            sigma = ah_vol_factor * sigma_base
            dP = mu * P * DT + sigma * P * math.sqrt(DT) * eps
            regime = "after_hours"

        new_price = P + dP
        new_price = float(np.clip(new_price, PRICE_LO, PRICE_HI))
        prices[t + 1] = new_price
        regimes.append(regime)

    return prices, regimes


def compute_rolling_vol(log_returns: np.ndarray, window: int = 15) -> np.ndarray:
    """Compute rolling std of log returns, annualized. Returns array same length as log_returns."""
    n = len(log_returns)
    rolling = np.zeros(n)
    minutes_per_year = float(MINUTES_PER_YEAR)
    for i in range(n):
        start = max(0, i - window + 1)
        segment = log_returns[start: i + 1]
        if len(segment) >= 2:
            rolling[i] = float(np.std(segment, ddof=1)) * math.sqrt(minutes_per_year)
        else:
            rolling[i] = 0.0
    return rolling


def build_datetime_strings(n_steps: int) -> List[str]:
    """Build datetime strings starting at 09:30:00 EDT, 1-minute increments."""
    from datetime import datetime, timedelta
    base = datetime(2026, 4, 24, 9, 30, 0)
    return [(base + timedelta(minutes=i)).strftime("%Y-%m-%d %H:%M:%S EDT")
            for i in range(n_steps)]


def get_session_label(t: int) -> str:
    """Return session label for minute t (0-indexed from open)."""
    if t < T_REGULAR:
        return "regular"
    else:
        return "after_hours"


def local_volatility_annualized(t: int, scenario_params: Dict) -> float:
    """Return local annualized volatility at time t based on regime."""
    base_vol = scenario_params["base_volatility"]
    ah_factor = scenario_params["after_hours_vol_factor"]
    if t < 15:
        return min(0.3, float(np.clip(2.5 * base_vol, 0.05, 0.3)))
    elif t < 240:
        return float(np.clip(base_vol, 0.05, 0.3))
    elif t < 390:
        return float(np.clip(0.8 * base_vol, 0.05, 0.3))
    else:
        return float(np.clip(ah_factor * base_vol, 0.05, 0.3))


# ============================================================
# SIMULATION RUNNER
# ============================================================

def run_single_scenario(scenario_label: str, scenario_index: int,
                        scenario_params: Dict, sim_id: int = 0) -> Dict:
    """
    Run a single simulation path and return structured result dict.
    """
    np.random.seed(scenario_index * 1000 + sim_id)
    seed = scenario_index * 1000 + sim_id

    prices, regimes = simulate_path(seed, scenario_params)

    n_steps = T_TOTAL  # number of transitions (630)
    # prices has T_TOTAL+1 = 631 elements
    # We'll use prices[0..T_TOTAL] — price at end of each step is prices[t+1]
    # For output, we record price at time t for t in 0..T_TOTAL (inclusive)
    # But log_return at t requires price[t] and price[t-1], so t from 1..T_TOTAL

    datetimes = build_datetime_strings(T_TOTAL + 1)

    log_returns_arr = np.diff(np.log(np.maximum(prices, 1e-10)))  # length T_TOTAL
    rolling_vol_arr = compute_rolling_vol(log_returns_arr, window=15)  # length T_TOTAL

    rows = []
    for t in range(T_TOTAL + 1):
        price_val = float(np.clip(prices[t], PRICE_LO, PRICE_HI))
        cum_ret = float(np.clip(100.0 * (price_val - OPEN_PRICE) / OPEN_PRICE, -1.0, 2.0))

        if t == 0:
            lr = 0.0
            rv = 0.0
            regime = "surge"
        else:
            lr = float(np.clip(log_returns_arr[t - 1], -0.005, 0.005))
            rv = float(rolling_vol_arr[t - 1])
            regime = regimes[t - 1]

        vol_local = local_volatility_annualized(t if t < T_TOTAL else T_TOTAL - 1, scenario_params)
        vol_px = float(np.clip(volume_profile(t), 0.2, 5.0))
        ba_spread = float(np.clip(bid_ask_spread(t), 0.01, 0.25))
        pvc = float((price_val - PREV_CLOSE) / PREV_CLOSE * 100.0)
        above_open = 1 if price_val >= OPEN_PRICE else 0

        rows.append({
            "scenario": scenario_label,
            "simulation_id": sim_id,
            "datetime_edt": datetimes[t],
            "minutes_from_open": t,
            "session": get_session_label(t),
            "price": round(price_val, 4),
            "log_return": round(lr, 6),
            "cumulative_return_pct": round(cum_ret, 4),
            "volatility_local": round(vol_local, 6),
            "volume_proxy": round(vol_px, 4),
            "bid_ask_spread": round(ba_spread, 4),
            "rolling_volatility_15min": round(rv, 6),
            "drift_regime": regime,
            "price_vs_prev_close_pct": round(pvc, 4),
            "is_above_open": above_open,
        })

    return {
        "label": scenario_label,
        "prices": prices,
        "log_returns": log_returns_arr,
        "rolling_vol": rolling_vol_arr,
        "regimes": regimes,
        "rows": rows,
        "params": scenario_params,
    }


def run_monte_carlo(scenario_params: Dict, n_sims: int = 500) -> Dict:
    """
    Run Monte Carlo ensemble of n_sims paths.
    Returns array of shape (n_sims, T_TOTAL+1) and list of all rows.
    """
    all_prices = np.zeros((n_sims, T_TOTAL + 1))
    all_rows = []

    for sim_id in range(n_sims):
        seed = 4 * 1000 + sim_id
        prices, regimes = simulate_path(seed, scenario_params)
        all_prices[sim_id, :] = prices

        # Only store rows for first 10 simulations to keep CSV manageable
        if sim_id < 10:
            datetimes = build_datetime_strings(T_TOTAL + 1)
            log_returns_arr = np.diff(np.log(np.maximum(prices, 1e-10)))
            rolling_vol_arr = compute_rolling_vol(log_returns_arr, window=15)

            for t in range(T_TOTAL + 1):
                price_val = float(np.clip(prices[t], PRICE_LO, PRICE_HI))
                cum_ret = float(np.clip(100.0 * (price_val - OPEN_PRICE) / OPEN_PRICE, -1.0, 2.0))

                if t == 0:
                    lr = 0.0
                    rv = 0.0
                    regime = "surge"
                else:
                    lr = float(np.clip(log_returns_arr[t - 1], -0.005, 0.005))
                    rv = float(rolling_vol_arr[t - 1])
                    regime = regimes[t - 1]

                vol_local = local_volatility_annualized(
                    t if t < T_TOTAL else T_TOTAL - 1, scenario_params)
                vol_px = float(np.clip(volume_profile(t), 0.2, 5.0))
                ba_spread = float(np.clip(bid_ask_spread(t), 0.01, 0.25))
                pvc = float((price_val - PREV_CLOSE) / PREV_CLOSE * 100.0)
                above_open = 1 if price_val >= OPEN_PRICE else 0

                all_rows.append({
                    "scenario": "monte_carlo_ensemble",
                    "simulation_id": sim_id,
                    "datetime_edt": datetimes[t],
                    "minutes_from_open": t,
                    "session": get_session_label(t),
                    "price": round(price_val, 4),
                    "log_return": round(lr, 6),
                    "cumulative_return_pct": round(cum_ret, 4),
                    "volatility_local": round(vol_local, 6),
                    "volume_proxy": round(vol_px, 4),
                    "bid_ask_spread": round(ba_spread, 4),
                    "rolling_volatility_15min": round(rv, 6),
                    "drift_regime": regime,
                    "price_vs_prev_close_pct": round(pvc, 4),
                    "is_above_open": above_open,
                })

    # Compute percentile bands
    pcts = np.percentile(all_prices, [10, 25, 50, 75, 90], axis=0)  # shape (5, T_TOTAL+1)
    close_prices = all_prices[:, T_REGULAR]  # closing prices at minute 390

    return {
        "all_prices": all_prices,
        "pct_10": pcts[0],
        "pct_25": pcts[1],
        "pct_50": pcts[2],
        "pct_75": pcts[3],
        "pct_90": pcts[4],
        "close_prices": close_prices,
        "rows": all_rows,
    }


# ============================================================
# FIGURE GENERATION
# ============================================================

def fig1_intraday_price(result: Dict, output_dir: pathlib.Path) -> None:
    """Fig1: GLD Intraday Price – April 24, 2026 (Simulated vs Reference)"""
    try:
        prices = result["prices"]
        t_arr = np.arange(T_TOTAL + 1)
        assert len(t_arr) == len(prices), f"Shape mismatch: {len(t_arr)} vs {len(prices)}"

        fig, ax = plt.subplots(figsize=(14, 6))

        # Regular session
        t_reg = t_arr[:T_REGULAR + 1]
        p_reg = prices[:T_REGULAR + 1]
        assert len(t_reg) == len(p_reg)

        # After hours
        t_ah = t_arr[T_REGULAR:]
        p_ah = prices[T_REGULAR:]
        assert len(t_ah) == len(p_ah)

        ax.fill_between(t_reg, OPEN_PRICE - 2, p_reg, alpha=0.25, color='green', label='_nolegend_')
        ax.plot(t_reg, p_reg, color='green', linewidth=1.5, label='Regular Session (Simulated)')
        ax.fill_between(t_ah, OPEN_PRICE - 2, p_ah, alpha=0.10, color='gray', label='_nolegend_')
        ax.plot(t_ah, p_ah, color='gray', linewidth=1.2, alpha=0.7, label='After-Hours (Simulated)')

        # Reference lines
        ax.axhline(PREV_CLOSE, color='blue', linestyle=':', linewidth=1.5,
                   label=f'Prev Close: ${PREV_CLOSE:.2f}')
        ax.axhline(OBSERVED_HIGH, color='darkgreen', linestyle='--', linewidth=1.0,
                   alpha=0.7, label=f'High: ${OBSERVED_HIGH:.2f}')
        ax.axhline(OBSERVED_LOW, color='darkred', linestyle='--', linewidth=1.0,
                   alpha=0.7, label=f'Low: ${OBSERVED_LOW:.2f}')
        ax.axvline(T_REGULAR, color='black', linestyle='--', linewidth=1.0,
                   alpha=0.5, label='Market Close (4:00 PM)')

        # Annotations
        ax.annotate(f'Open: ${OPEN_PRICE:.2f}', xy=(0, OPEN_PRICE),
                    xytext=(15, OPEN_PRICE + 0.3), fontsize=8,
                    arrowprops=dict(arrowstyle='->', color='black', lw=1.0))
        ax.annotate(f'Close: ${OBSERVED_CLOSE:.2f}', xy=(T_REGULAR, OBSERVED_CLOSE),
                    xytext=(T_REGULAR - 60, OBSERVED_CLOSE + 0.5), fontsize=8,
                    arrowprops=dict(arrowstyle='->', color='green', lw=1.0))

        # X-axis labels (time)
        tick_positions = [0, 60, 120, 180, 240, 300, 360, 390, 450, 510, 570, 630]
        tick_labels = ['9:30', '10:30', '11:30', '12:30', '1:30', '2:30', '3:30',
                       '4:00', '5:00', '6:00', '7:00', '8:00']
        tick_positions = [p for p in tick_positions if p <= T_TOTAL]
        tick_labels = tick_labels[:len(tick_positions)]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=45, fontsize=8)

        ax.set_xlabel('Time (EDT)', fontsize=11)
        ax.set_ylabel('Price (USD)', fontsize=11)
        ax.set_title('GLD Intraday Price – April 24, 2026 (Simulated vs Reference)', fontsize=13)
        ax.legend(fontsize=9, loc='upper right')
        ax.grid(True, alpha=0.3)

        # Stats box
        stats_text = (f"Open: ${OPEN_PRICE:.2f}  |  High: ${OBSERVED_HIGH:.2f}  |  "
                      f"Low: ${OBSERVED_LOW:.2f}  |  Close: ${OBSERVED_CLOSE:.2f}  |  "
                      f"Mkt Cap: $159.35B  |  P/E: 2.81")
        ax.text(0.5, -0.15, stats_text, transform=ax.transAxes,
                fontsize=8, ha='center', color='gray')

        plt.tight_layout()
        fpath = output_dir / "fig1_intraday_price.png"
        fig.savefig(fpath, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"  WARNING: fig1 failed: {e}")


def fig2_scenario_comparison(scenario_results: Dict[str, Dict], output_dir: pathlib.Path) -> None:
    """Fig2: GLD Scenario Comparison"""
    try:
        fig, ax = plt.subplots(figsize=(14, 6))

        scenario_styles = {
            "baseline_april24": ("green", "-", "Baseline (April 24)", 2.0),
            "high_volatility_day": ("orange", "-", "High Volatility", 1.5),
            "low_volatility_day": ("steelblue", "-", "Low Volatility", 1.5),
            "bearish_reversal": ("red", "-", "Bearish Reversal", 1.5),
        }

        t_arr = np.arange(T_TOTAL + 1)

        for label, style in scenario_styles.items():
            if label not in scenario_results:
                continue
            prices = scenario_results[label]["prices"]
            assert len(t_arr) == len(prices), f"Shape mismatch for {label}"
            color, ls, name, lw = style
            ax.plot(t_arr, prices, color=color, linestyle=ls, linewidth=lw, label=name, alpha=0.85)

        # Reference lines
        ax.axhline(OPEN_PRICE, color='black', linestyle='--', linewidth=1.0,
                   alpha=0.6, label=f'Open: ${OPEN_PRICE:.2f}')
        ax.axhline(OBSERVED_CLOSE, color='green', linestyle=':', linewidth=1.0,
                   alpha=0.6, label=f'Close: ${OBSERVED_CLOSE:.2f}')
        ax.axhline(OBSERVED_HIGH, color='darkgreen', linestyle='-.', linewidth=0.8,
                   alpha=0.5, label=f'High: ${OBSERVED_HIGH:.2f}')
        ax.axhline(OBSERVED_LOW, color='darkred', linestyle='-.', linewidth=0.8,
                   alpha=0.5, label=f'Low: ${OBSERVED_LOW:.2f}')
        ax.axhline(PREV_CLOSE, color='blue', linestyle=':', linewidth=1.0,
                   alpha=0.5, label=f'Prev Close: ${PREV_CLOSE:.2f}')
        ax.axvline(T_REGULAR, color='black', linestyle='--', linewidth=1.0,
                   alpha=0.4, label='Market Close')

        tick_positions = [0, 60, 120, 180, 240, 300, 360, 390, 450, 510, 570, 630]
        tick_labels = ['9:30', '10:30', '11:30', '12:30', '1:30', '2:30', '3:30',
                       '4:00', '5:00', '6:00', '7:00', '8:00']
        tick_positions = [p for p in tick_positions if p <= T_TOTAL]
        tick_labels = tick_labels[:len(tick_positions)]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=45, fontsize=8)

        ax.set_xlabel('Time (EDT)', fontsize=11)
        ax.set_ylabel('Price (USD)', fontsize=11)
        ax.set_title('GLD Scenario Comparison: Baseline vs High/Low Volatility vs Bearish', fontsize=13)
        ax.legend(fontsize=9, loc='upper right', ncol=2)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        fpath = output_dir / "fig2_scenario_comparison.png"
        fig.savefig(fpath, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"  WARNING: fig2 failed: {e}")


def fig3_monte_carlo_bands(mc_result: Dict, output_dir: pathlib.Path) -> None:
    """Fig3: GLD Monte Carlo Ensemble with Percentile Bands"""
    try:
        t_arr = np.arange(T_TOTAL + 1)
        pct_10 = mc_result["pct_10"]
        pct_25 = mc_result["pct_25"]
        pct_50 = mc_result["pct_50"]
        pct_75 = mc_result["pct_75"]
        pct_90 = mc_result["pct_90"]

        assert len(t_arr) == len(pct_50), f"Shape mismatch: {len(t_arr)} vs {len(pct_50)}"

        fig, ax = plt.subplots(figsize=(14, 6))

        ax.fill_between(t_arr, pct_10, pct_90, alpha=0.2, color='green', label='10th–90th pct')
        ax.fill_between(t_arr, pct_25, pct_75, alpha=0.35, color='green', label='25th–75th pct')
        ax.plot(t_arr, pct_50, color='darkgreen', linewidth=2.0, label='Median Path')

        # Observed close marker
        ax.scatter([T_REGULAR], [OBSERVED_CLOSE], color='red', s=80, zorder=5,
                   label=f'Observed Close: ${OBSERVED_CLOSE:.2f}')

        # Reference lines
        ax.axhline(OBSERVED_HIGH, color='darkgreen', linestyle='--', linewidth=0.8,
                   alpha=0.5, label=f'Obs High: ${OBSERVED_HIGH:.2f}')
        ax.axhline(OBSERVED_LOW, color='darkred', linestyle='--', linewidth=0.8,
                   alpha=0.5, label=f'Obs Low: ${OBSERVED_LOW:.2f}')
        ax.axvline(T_REGULAR, color='black', linestyle='--', linewidth=1.0, alpha=0.4,
                   label='Market Close')

        tick_positions = [0, 60, 120, 180, 240, 300, 360, 390, 450, 510, 570, 630]
        tick_labels = ['9:30', '10:30', '11:30', '12:30', '1:30', '2:30', '3:30',
                       '4:00', '5:00', '6:00', '7:00', '8:00']
        tick_positions = [p for p in tick_positions if p <= T_TOTAL]
        tick_labels = tick_labels[:len(tick_positions)]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=45, fontsize=8)

        ax.set_xlabel('Time (EDT)', fontsize=11)
        ax.set_ylabel('Price (USD)', fontsize=11)
        ax.set_title('GLD Monte Carlo Ensemble: 500 Simulated Paths with Percentile Bands', fontsize=13)
        ax.legend(fontsize=9, loc='upper right')
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        fpath = output_dir / "fig3_monte_carlo_bands.png"
        fig.savefig(fpath, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"  WARNING: fig3 failed: {e}")


def fig4_close_distribution(mc_result: Dict, output_dir: pathlib.Path) -> None:
    """Fig4: Distribution of Simulated GLD Close Prices"""
    try:
        close_prices = mc_result["close_prices"]
        assert len(close_prices) > 0, "No close prices"

        fig, ax = plt.subplots(figsize=(10, 6))

        ax.hist(close_prices, bins=40, color='green', alpha=0.7, edgecolor='darkgreen',
                label='Simulated Close Prices')
        ax.axvline(OBSERVED_CLOSE, color='red', linestyle='--', linewidth=2.0,
                   label=f'Observed Close: ${OBSERVED_CLOSE:.2f}')

        pct5 = float(np.percentile(close_prices, 5))
        pct95 = float(np.percentile(close_prices, 95))
        ax.axvline(pct5, color='orange', linestyle=':', linewidth=1.5,
                   label=f'5th pct: ${pct5:.2f}')
        ax.axvline(pct95, color='purple', linestyle=':', linewidth=1.5,
                   label=f'95th pct: ${pct95:.2f}')

        # Annotation
        mean_close = float(np.mean(close_prices))
        std_close = float(np.std(close_prices))
        ax.text(0.98, 0.95,
                f'Mean: ${mean_close:.2f}\nStd: ${std_close:.2f}\n'
                f'5th: ${pct5:.2f}\n95th: ${pct95:.2f}',
                transform=ax.transAxes, fontsize=9,
                verticalalignment='top', horizontalalignment='right',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

        ax.set_xlabel('Closing Price (USD)', fontsize=11)
        ax.set_ylabel('Frequency', fontsize=11)
        ax.set_title('Distribution of Simulated GLD Close Prices Across 500 MC Paths', fontsize=13)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        fpath = output_dir / "fig4_close_distribution.png"
        fig.savefig(fpath, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"  WARNING: fig4 failed: {e}")


def fig5_log_returns_volatility(result: Dict, output_dir: pathlib.Path) -> None:
    """Fig5: GLD 1-Minute Log Returns and Rolling Volatility"""
    try:
        log_returns = result["log_returns"]  # length T_TOTAL
        rolling_vol = result["rolling_vol"]  # length T_TOTAL
        t_arr = np.arange(T_TOTAL)  # 0..629

        assert len(t_arr) == len(log_returns), f"log_returns shape: {len(t_arr)} vs {len(log_returns)}"
        assert len(t_arr) == len(rolling_vol), f"rolling_vol shape: {len(t_arr)} vs {len(rolling_vol)}"

        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 8), sharex=True)

        # Top: log returns as bar chart
        colors = ['green' if r >= 0 else 'red' for r in log_returns]
        ax1.bar(t_arr, log_returns, color=colors, width=1.0, alpha=0.7, label='1-min Log Return')
        mean_lr = float(np.mean(log_returns))
        std_lr = float(np.std(log_returns))
        ax1.axhline(mean_lr + 2 * std_lr, color='orange', linestyle='--', linewidth=1.0,
                    label=f'Mean ± 2σ')
        ax1.axhline(mean_lr - 2 * std_lr, color='orange', linestyle='--', linewidth=1.0)
        ax1.axhline(0, color='black', linewidth=0.5)
        ax1.axvline(T_REGULAR, color='black', linestyle='--', linewidth=1.0, alpha=0.5)
        ax1.set_ylabel('Log Return', fontsize=10)
        ax1.set_title('GLD 1-Minute Log Returns and Rolling Volatility – April 24, 2026', fontsize=12)
        ax1.legend(fontsize=9)
        ax1.grid(True, alpha=0.3)

        # Bottom: rolling volatility
        ax2.plot(t_arr, rolling_vol, color='blue', linewidth=1.5, label='15-min Rolling Vol (Annualized)')
        ax2.axvline(T_REGULAR, color='black', linestyle='--', linewidth=1.0,
                    alpha=0.5, label='Market Close')
        ax2.set_ylabel('Realized Volatility (Annualized)', fontsize=10)
        ax2.set_xlabel('Time (EDT)', fontsize=10)
        ax2.legend(fontsize=9)
        ax2.grid(True, alpha=0.3)

        tick_positions = [0, 60, 120, 180, 240, 300, 360, 390, 450, 510, 570]
        tick_labels = ['9:30', '10:30', '11:30', '12:30', '1:30', '2:30', '3:30',
                       '4:00', '5:00', '6:00', '7:00']
        tick_positions = [p for p in tick_positions if p < T_TOTAL]
        tick_labels = tick_labels[:len(tick_positions)]
        ax2.set_xticks(tick_positions)
        ax2.set_xticklabels(tick_labels, rotation=45, fontsize=8)

        plt.tight_layout()
        fpath = output_dir / "fig5_log_returns_volatility.png"
        fig.savefig(fpath, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"  WARNING: fig5 failed: {e}")


def fig6_volume_profile(result: Dict, output_dir: pathlib.Path) -> None:
    """Fig6: Simulated Intraday Volume Profile"""
    try:
        t_arr = np.arange(T_TOTAL + 1)
        vol_arr = np.array([volume_profile(t) for t in t_arr])

        assert len(t_arr) == len(vol_arr), f"vol_arr shape: {len(t_arr)} vs {len(vol_arr)}"

        fig, ax = plt.subplots(figsize=(14, 5))

        # Regular session
        t_reg = t_arr[:T_REGULAR + 1]
        v_reg = vol_arr[:T_REGULAR + 1]
        assert len(t_reg) == len(v_reg)

        # After hours
        t_ah = t_arr[T_REGULAR:]
        v_ah = vol_arr[T_REGULAR:]
        assert len(t_ah) == len(v_ah)

        ax.scatter(t_reg, v_reg, color='steelblue', s=8, alpha=0.7, label='Regular Session Volume')
        ax.scatter(t_ah, v_ah, color='gray', s=8, alpha=0.5, label='After-Hours Volume')
        ax.axhline(1.0, color='black', linestyle='--', linewidth=1.0,
                   alpha=0.5, label='Average Volume (1.0)')
        ax.axvline(T_REGULAR, color='black', linestyle='--', linewidth=1.0,
                   alpha=0.4, label='Market Close (4:00 PM)')

        tick_positions = [0, 60, 120, 180, 240, 300, 360, 390, 450, 510, 570, 630]
        tick_labels = ['9:30', '10:30', '11:30', '12:30', '1:30', '2:30', '3:30',
                       '4:00', '5:00', '6:00', '7:00', '8:00']
        tick_positions = [p for p in tick_positions if p <= T_TOTAL]
        tick_labels = tick_labels[:len(tick_positions)]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=45, fontsize=8)

        ax.set_xlabel('Time (EDT)', fontsize=11)
        ax.set_ylabel('Relative Volume (1.0 = average)', fontsize=11)
        ax.set_title('Simulated Intraday Volume Profile for GLD – April 24, 2026', fontsize=13)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        fpath = output_dir / "fig6_volume_profile.png"
        fig.savefig(fpath, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"  WARNING: fig6 failed: {e}")


# ============================================================
# CSV WRITERS
# ============================================================

def write_simulation_outputs(all_rows: List[Dict], output_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv"""
    if not all_rows:
        print("  WARNING: No rows to write to simulation_outputs.csv")
        return

    fieldnames = [
        "scenario", "simulation_id", "datetime_edt", "minutes_from_open",
        "session", "price", "log_return", "cumulative_return_pct",
        "volatility_local", "volume_proxy", "bid_ask_spread",
        "rolling_volatility_15min", "drift_regime", "price_vs_prev_close_pct",
        "is_above_open"
    ]

    fpath = output_dir / "simulation_outputs.csv"
    try:
        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({k: row.get(k, "") for k in fieldnames})
        print(f"  Saved {fpath} ({len(all_rows)} rows)")
    except Exception as e:
        print(f"  WARNING: Failed to write simulation_outputs.csv: {e}")


def write_scenario_summary(scenario_results: Dict[str, Dict],
                           mc_result: Dict,
                           output_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv"""
    fieldnames = [
        "scenario", "price_mean", "price_std", "price_min", "price_max",
        "log_return_mean", "log_return_std", "cumulative_return_mean",
        "final_regular_close", "intraday_range", "above_open_pct",
        "base_volatility", "open_surge_drift", "mean_reversion_speed"
    ]

    rows = []

    for label, result in scenario_results.items():
        if label == "monte_carlo_ensemble":
            continue
        prices = result["prices"]
        lr = result["log_returns"]
        params = result["params"]

        price_mean = float(np.mean(prices))
        price_std = float(np.std(prices))
        price_min = float(np.min(prices))
        price_max = float(np.max(prices))
        lr_mean = float(np.mean(lr))
        lr_std = float(np.std(lr))
        cum_ret_mean = float(np.mean(100.0 * (prices - OPEN_PRICE) / OPEN_PRICE))
        final_close = float(prices[T_REGULAR])
        intraday_range = float(np.max(prices[:T_REGULAR + 1]) - np.min(prices[:T_REGULAR + 1]))
        above_open_pct = float(np.mean(prices >= OPEN_PRICE) * 100.0)

        rows.append({
            "scenario": label,
            "price_mean": round(price_mean, 4),
            "price_std": round(price_std, 6),
            "price_min": round(price_min, 4),
            "price_max": round(price_max, 4),
            "log_return_mean": round(lr_mean, 8),
            "log_return_std": round(lr_std, 8),
            "cumulative_return_mean": round(cum_ret_mean, 4),
            "final_regular_close": round(final_close, 4),
            "intraday_range": round(intraday_range, 4),
            "above_open_pct": round(above_open_pct, 2),
            "base_volatility": params.get("base_volatility", 0.12),
            "open_surge_drift": params.get("open_surge_drift", 0.18),
            "mean_reversion_speed": params.get("mean_reversion_speed", 0.05),
        })

    # Add Monte Carlo summary
    if mc_result:
        all_prices = mc_result["all_prices"]
        close_prices = mc_result["close_prices"]
        rows.append({
            "scenario": "monte_carlo_ensemble",
            "price_mean": round(float(np.mean(all_prices[:, :T_REGULAR + 1])), 4),
            "price_std": round(float(np.std(all_prices[:, :T_REGULAR + 1])), 6),
            "price_min": round(float(np.min(all_prices[:, :T_REGULAR + 1])), 4),
            "price_max": round(float(np.max(all_prices[:, :T_REGULAR + 1])), 4),
            "log_return_mean": 0.0,
            "log_return_std": 0.0,
            "cumulative_return_mean": round(float(np.mean(100.0 * (close_prices - OPEN_PRICE) / OPEN_PRICE)), 4),
            "final_regular_close": round(float(np.mean(close_prices)), 4),
            "intraday_range": round(float(np.mean(
                np.max(all_prices[:, :T_REGULAR + 1], axis=1) -
                np.min(all_prices[:, :T_REGULAR + 1], axis=1))), 4),
            "above_open_pct": round(float(np.mean(close_prices >= OPEN_PRICE) * 100.0), 2),
            "base_volatility": 0.12,
            "open_surge_drift": 0.18,
            "mean_reversion_speed": 0.05,
        })

    if not rows:
        print("  WARNING: No scenario summary rows to write")
        return

    fpath = output_dir / "scenario_summary.csv"
    try:
        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
        print(f"  Saved {fpath} ({len(rows)} rows)")
    except Exception as e:
        print(f"  WARNING: Failed to write scenario_summary.csv: {e}")


def write_parameters_used(output_dir: pathlib.Path) -> None:
    """Write parameters_used.csv"""
    fieldnames = ["name", "value", "unit", "source", "description"]
    rows = []
    for name, info in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"],
        })

    if not rows:
        print("  WARNING: No parameter rows to write")
        return

    fpath = output_dir / "parameters_used.csv"
    try:
        with open(fpath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
        print(f"  Saved {fpath} ({len(rows)} rows)")
    except Exception as e:
        print(f"  WARNING: Failed to write parameters_used.csv: {e}")


# ============================================================
# SUMMARY JSON
# ============================================================

def write_summary_json(scenario_results: Dict[str, Dict],
                       mc_result: Dict,
                       output_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    summary = {
        "title": "SPDR Gold Trust (GLD) Intraday Price Action – April 24, 2026",
        "date": "2026-04-24",
        "observed_metrics": {
            "open_price": OPEN_PRICE,
            "close_price": OBSERVED_CLOSE,
            "high_price": OBSERVED_HIGH,
            "low_price": OBSERVED_LOW,
            "prev_close": PREV_CLOSE,
            "daily_change_pct": 0.51,
            "market_cap_usd": 159350000000.0,
            "pe_ratio": 2.81,
        },
        "scenarios": {}
    }

    for label, result in scenario_results.items():
        if label == "monte_carlo_ensemble":
            continue
        prices = result["prices"]
        summary["scenarios"][label] = {
            "final_regular_close": round(float(prices[T_REGULAR]), 4),
            "intraday_high": round(float(np.max(prices[:T_REGULAR + 1])), 4),
            "intraday_low": round(float(np.min(prices[:T_REGULAR + 1])), 4),
            "total_range": round(float(np.max(prices[:T_REGULAR + 1]) - np.min(prices[:T_REGULAR + 1])), 4),
            "mean_price_regular": round(float(np.mean(prices[:T_REGULAR + 1])), 4),
        }

    if mc_result:
        close_prices = mc_result["close_prices"]
        summary["monte_carlo"] = {
            "n_simulations": len(close_prices),
            "close_price_mean": round(float(np.mean(close_prices)), 4),
            "close_price_std": round(float(np.std(close_prices)), 4),
            "close_price_p5": round(float(np.percentile(close_prices, 5)), 4),
            "close_price_p95": round(float(np.percentile(close_prices, 95)), 4),
            "prob_above_observed_close": round(float(np.mean(close_prices > OBSERVED_CLOSE)), 4),
            "prob_above_open": round(float(np.mean(close_prices > OPEN_PRICE)), 4),
        }

    fpath = output_dir / "summary.json"
    try:
        with open(fpath, "w") as f:
            json.dump(summary, f, indent=2)
        print(f"  Saved {fpath}")
    except Exception as e:
        print(f"  WARNING: Failed to write summary.json: {e}")


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="GLD Intraday Price Action Simulator – April 24, 2026")
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    output_dir = pathlib.Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    # -------------------------------------------------------
    # Run all scenarios
    # -------------------------------------------------------
    scenario_results: Dict[str, Dict] = {}
    all_rows: List[Dict] = []
    mc_result: Optional[Dict] = None

    default_params = get_default_params()
    scenarios = MODEL_PROFILE["scenarios"]

    for scenario_cfg in scenarios:
        label = scenario_cfg["label"]
        idx = scenario_cfg["index"]
        overrides = scenario_cfg["param_overrides"]

        print(f"\nRunning scenario: {label} (index={idx})")

        # Merge default params with overrides
        params = dict(default_params)
        params.update(overrides)

        # Set numpy seed per scenario
        np.random.seed(idx)

        if label == "monte_carlo_ensemble":
            n_sims = int(params.get("num_simulations", 500))
            print(f"  Running {n_sims} Monte Carlo paths...")
            mc_result = run_monte_carlo(params, n_sims=n_sims)
            scenario_results[label] = {
                "prices": mc_result["pct_50"],  # Use median as representative path
                "log_returns": np.diff(np.log(np.maximum(mc_result["pct_50"], 1e-10))),
                "rolling_vol": compute_rolling_vol(
                    np.diff(np.log(np.maximum(mc_result["pct_50"], 1e-10)))),
                "regimes": [],
                "rows": mc_result["rows"],
                "params": params,
            }
            all_rows.extend(mc_result["rows"])
        else:
            result = run_single_scenario(label, idx, params, sim_id=0)
            scenario_results[label] = result
            all_rows.extend(result["rows"])
            print(f"  Simulated {len(result['prices'])} time steps, "
                  f"close=${result['prices'][T_REGULAR]:.2f}")

    # -------------------------------------------------------
    # Generate figures
    # -------------------------------------------------------
    print("\nGenerating figures...")

    # Fig 1: Baseline intraday price
    if "baseline_april24" in scenario_results:
        fig1_intraday_price(scenario_results["baseline_april24"], output_dir)

    # Fig 2: Scenario comparison
    fig2_scenario_comparison(scenario_results, output_dir)

    # Fig 3: Monte Carlo bands
    if mc_result is not None:
        fig3_monte_carlo_bands(mc_result, output_dir)

    # Fig 4: Close price distribution
    if mc_result is not None:
        fig4_close_distribution(mc_result, output_dir)

    # Fig 5: Log returns and volatility
    if "baseline_april24" in scenario_results:
        fig5_log_returns_volatility(scenario_results["baseline_april24"], output_dir)

    # Fig 6: Volume profile
    if "baseline_april24" in scenario_results:
        fig6_volume_profile(scenario_results["baseline_april24"], output_dir)

    # -------------------------------------------------------
    # Write CSV files
    # -------------------------------------------------------
    print("\nWriting CSV files...")
    write_simulation_outputs(all_rows, output_dir)
    write_scenario_summary(scenario_results, mc_result or {}, output_dir)
    write_parameters_used(output_dir)

    # -------------------------------------------------------
    # Write JSON summary
    # -------------------------------------------------------
    print("\nWriting summary JSON...")
    write_summary_json(scenario_results, mc_result or {}, output_dir)

    print(f"\n✓ Simulation complete. All outputs in: {output_dir.resolve()}")


if __name__ == "__main__":
    main()