================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 138d73b7-5020-403d-80a0-6382ac0f75f9
    Generated   : 2026-04-26  19:29:36 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    SPDR Gold Trust (GLD) Intraday Price Action – April 24, 2026

    CATEGORIES
    ----------
    Financial

    KEYWORDS
    --------
    GLD ETF, intraday price simulation, geometric Brownian motion, Ornstein-Uhlenbeck, gold price dynamics, Monte Carlo finance, stochastic volatility

    ABSTRACT
    --------
    This simulator models the intraday price dynamics of the SPDR Gold Trust ETF (GLD) as observed on April 24, 2026, when the fund opened at $431.36, surged to a high of $435.28, and closed at $433.25 (+0.51%). The simulator combines a multi-regime stochastic process — geometric Brownian motion during the opening surge and after-hours, and an Ornstein-Uhlenbeck mean-reverting process during midday consolidation — calibrated to match the observed open, high, low, and close prices extracted from the source. A Monte Carlo ensemble of 500 paths provides distributional uncertainty bands, and four additional scenarios (high volatility, low volatility, bearish reversal, and baseline) allow systematic exploration of gold ETF behavior under different market conditions. Researchers, quantitative analysts, and finance educators can use this simulator to study intraday ETF price behavior, test trading strategies, and generate synthetic market data for backtesting and model validation.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    SPDR Gold Trust April 24 2026.png

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    price, log_return, volatility, drift, volume_proxy, bid_ask_spread, cumulative_return

    SCENARIOS  (5 total)
    ---------------------------------
        1. baseline_april24 — Single deterministic + stochastic path calibrated exactly to April 24 OHLC: open surge to ~434-435, midday oscillation around 433.8, gradual close at 433.25, then flat after-hours around 433
2. high_volatility_day — Same open price but 2x volatility, simulating a high-uncertainty gold trading session (e.g., macro news day). Wider intraday range expected, potentially touching 52-week extremes more frequently.
3. low_volatility_day — Calm session with 0.5x volatility. Price drifts slowly upward with minimal oscillation, staying in a tight range around 432-433.
4. bearish_reversal — Opening gap up followed by reversal: negative drift during consolidation phase drags price toward previous close and low. Tests downside scenario toward 430.66.
5. monte_carlo_ensemble — 500 simulated GBM paths from the same open using calibrated parameters to produce distributional cone, showing median, 10th/90th percentile price bands across the trading day.

    PARAMETERS
    ----------
    21 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6

    DOMAIN SUMMARY
    --------------
    Intraday price dynamics of the SPDR Gold Trust ETF (NYSE: GLD) on April 24, 2026, showing tick-level price movement from market open through after-hours trading, with key market statistics including open, high, low, close, market cap, and P/E ratio.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.