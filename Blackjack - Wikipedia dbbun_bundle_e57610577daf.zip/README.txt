================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : c270d50c-11c8-4824-946f-197c28c76d84
    Generated   : 2026-04-27  17:05:55 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Blackjack - Wikipedia

    CATEGORIES
    ----------
    Computational Intelligence, Financial, Social Sciences

    KEYWORDS
    --------
    blackjack, card counting, basic strategy, house edge, Monte Carlo simulation

    ABSTRACT
    --------
    This simulator models the card game of Blackjack as described in the Wikipedia source, faithfully reproducing the rules, probabilities, and strategic dynamics of the game across multiple deck configurations and rule variants. The simulator implements a full agent-based Monte Carlo engine in which a player agent follows basic strategy (encoded from the source strategy table) or Hi-Lo card counting with variable bet spreading, while the dealer follows fixed house rules including optional hit-on-soft-17. Synthetic data spanning tens of thousands of rounds enables measurement of house edge convergence, bankroll trajectories, hand total distributions, and the quantitative impact of rule variations such as payout ratios (3:2 vs 6:5) and deck count on player expected value. Researchers, educators, and game analysts can use this simulator to visualize and validate the mathematical claims in the source, explore 'what-if' rule variants, or teach probability and expected value concepts with realistic game data.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Blackjack - Wikipedia.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    player_hand, dealer_hand, player_total, dealer_total, player_bankroll, running_count, true_count, decks_remaining, current_bet, hand_outcome, round_number, shoe_penetration

    SCENARIOS  (6 total)
    ---------------------------------
        1. single_deck_basic_strategy — Single-deck game with 3:2 blackjack payout, player uses basic strategy, flat betting, H17 rule
2. six_deck_basic_strategy — Six-deck shoe game with 3:2 blackjack payout, player uses basic strategy, flat betting, H17 rule
3. six_deck_reduced_payout — Six-deck shoe game with reduced 6:5 blackjack payout, simulating common modern table conditions damaging to players
4. six_deck_card_counting — Six-deck shoe game with Hi-Lo card counting, bet spread of 1 to 8 units based on true count, basic strategy deviations
5. eight_deck_s17 — Eight-deck shoe game with stand-on-soft-17 (S17) rule, demonstrating house edge reduction vs H17
6. multi_deck_comparison — Compare house edge across all deck counts (1,2,4,6,8) from the Wikipedia source table under identical rulesets

    PARAMETERS
    ----------
    19 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6

    DOMAIN SUMMARY
    --------------
    Blackjack is a casino banking card game where players compete against the dealer to reach a hand total closest to 21 without exceeding it, governed by well-defined rules, probability, and optimal strategies including basic strategy and card counting.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.