# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-27T17:05:55.914988Z
# Run ID    : c270d50c-11c8-4824-946f-197c28c76d84
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Blackjack Monte Carlo Simulator
Based on: 'Blackjack - Wikipedia'
Simulates blackjack across multiple scenarios with basic strategy, card counting,
and various rule configurations to reproduce house edge statistics and strategic dynamics.
"""

import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional

# ---------------------------------------------------------------------------
# MODEL PROFILE
# ---------------------------------------------------------------------------
MODEL_PROFILE = {
    "parameters": {
        "num_decks": {"value": 6.0, "unit": "decks", "source": "extracted",
                      "description": "Number of standard 52-card decks in the shoe"},
        "house_edge_1deck": {"value": 0.0016, "unit": "fraction", "source": "extracted",
                             "description": "House edge for single-deck game: 0.16%"},
        "house_edge_2deck": {"value": 0.0046, "unit": "fraction", "source": "extracted",
                             "description": "House edge for double-deck game: 0.46%"},
        "house_edge_4deck": {"value": 0.006, "unit": "fraction", "source": "extracted",
                             "description": "House edge for four-deck game: 0.60%"},
        "house_edge_6deck": {"value": 0.0064, "unit": "fraction", "source": "extracted",
                             "description": "House edge for six-deck game: 0.64%"},
        "house_edge_8deck": {"value": 0.0066, "unit": "fraction", "source": "extracted",
                             "description": "House edge for eight-deck game: 0.66%"},
        "blackjack_payout": {"value": 1.5, "unit": "multiplier", "source": "extracted",
                             "description": "Payout ratio for player blackjack: 3:2 = 1.5x"},
        "blackjack_payout_reduced": {"value": 1.2, "unit": "multiplier", "source": "extracted",
                                     "description": "Reduced payout 6:5 = 1.2x"},
        "dealer_hits_soft17": {"value": 1.0, "unit": "boolean", "source": "extracted",
                               "description": "1 = dealer hits on soft 17 (H17)"},
        "shuffle_penetration": {"value": 0.75, "unit": "fraction", "source": "assumed",
                                "description": "Fraction of shoe dealt before reshuffling"},
        "num_rounds": {"value": 10000.0, "unit": "rounds", "source": "assumed",
                       "description": "Number of rounds simulated per scenario"},
        "base_bet": {"value": 1.0, "unit": "units", "source": "assumed",
                     "description": "Base betting unit"},
        "hi_lo_spread": {"value": 8.0, "unit": "multiplier", "source": "assumed",
                         "description": "Bet spread for card counting (1 to 8 units)"},
        "blackjack_frequency": {"value": 0.048, "unit": "fraction", "source": "extracted",
                                "description": "Probability of a natural blackjack: ~4.8%"},
        "insurance_payout": {"value": 2.0, "unit": "multiplier", "source": "extracted",
                             "description": "Insurance side bet payout is 2:1"},
        "soft17_edge_reduction": {"value": 0.002, "unit": "fraction", "source": "extracted",
                                  "description": "S17 rule reduces house edge by ~0.2%"},
        "counting_player_edge": {"value": 0.02, "unit": "fraction", "source": "extracted",
                                 "description": "Card counting can give player edge of up to ~2%"},
        "double_after_split_allowed": {"value": 1.0, "unit": "boolean", "source": "extracted",
                                       "description": "Allows doubling down after a split"},
        "late_surrender_allowed": {"value": 1.0, "unit": "boolean", "source": "assumed",
                                   "description": "Late surrender option available to player"},
    },
    "scenarios": [
        {
            "label": "single_deck_basic_strategy",
            "description": "Single-deck game with 3:2 blackjack payout, basic strategy, flat betting, H17",
            "strategy": "basic",
            "param_overrides": {"num_decks": 1.0, "blackjack_payout": 1.5, "dealer_hits_soft17": 1.0},
        },
        {
            "label": "six_deck_basic_strategy",
            "description": "Six-deck shoe with 3:2 payout, basic strategy, flat betting, H17",
            "strategy": "basic",
            "param_overrides": {"num_decks": 6.0, "blackjack_payout": 1.5, "dealer_hits_soft17": 1.0},
        },
        {
            "label": "six_deck_reduced_payout",
            "description": "Six-deck shoe with 6:5 payout, basic strategy",
            "strategy": "basic",
            "param_overrides": {"num_decks": 6.0, "blackjack_payout": 1.2, "dealer_hits_soft17": 1.0},
        },
        {
            "label": "six_deck_card_counting",
            "description": "Six-deck shoe with Hi-Lo card counting, bet spread 1-8",
            "strategy": "counting",
            "param_overrides": {"num_decks": 6.0, "blackjack_payout": 1.5, "dealer_hits_soft17": 1.0,
                                "hi_lo_spread": 8.0},
        },
        {
            "label": "eight_deck_s17",
            "description": "Eight-deck shoe with S17 rule",
            "strategy": "basic",
            "param_overrides": {"num_decks": 8.0, "blackjack_payout": 1.5, "dealer_hits_soft17": 0.0},
        },
        {
            "label": "multi_deck_comparison",
            "description": "Six-deck baseline for multi-deck comparison",
            "strategy": "basic",
            "param_overrides": {"num_decks": 6.0, "blackjack_payout": 1.5, "dealer_hits_soft17": 1.0},
        },
    ],
}

# Hi-Lo card count values
HI_LO = {2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 0, 8: 0, 9: 0, 10: -1, 11: -1}

# Theoretical house edges by deck count
THEORETICAL_EDGES = {1: 0.16, 2: 0.46, 4: 0.60, 6: 0.64, 8: 0.66}

# ---------------------------------------------------------------------------
# DATACLASS FOR SCENARIO PARAMETERS
# ---------------------------------------------------------------------------
@dataclass
class ScenarioParams:
    label: str
    strategy: str
    num_decks: float = 6.0
    blackjack_payout: float = 1.5
    dealer_hits_soft17: float = 1.0
    shuffle_penetration: float = 0.75
    num_rounds: int = 10000
    base_bet: float = 1.0
    hi_lo_spread: float = 8.0
    late_surrender_allowed: float = 1.0

# ---------------------------------------------------------------------------
# CARD / SHOE FUNCTIONS
# ---------------------------------------------------------------------------
def build_shoe(num_decks: int) -> List[int]:
    """Build and shuffle a shoe of num_decks standard decks."""
    single_deck = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11] * 4
    shoe = single_deck * num_decks
    np.random.shuffle(shoe)
    return list(shoe)

def hand_value(hand: List[int]) -> int:
    """Compute best valid hand total (ace counted as 11 or 1)."""
    total = sum(hand)
    aces = hand.count(11)
    while total > 21 and aces > 0:
        total -= 10
        aces -= 1
    return total

def is_soft(hand: List[int]) -> bool:
    """Return True if hand contains an ace counted as 11."""
    total = sum(hand)
    aces = hand.count(11)
    if aces == 0:
        return False
    # If reducing one ace by 10 keeps us <= 21, it's soft
    while total > 21 and aces > 0:
        total -= 10
        aces -= 1
    # Soft means an ace is still counted as 11
    return (11 in hand) and (total <= 21) and (sum(hand) - total < aces * 10 + 10 or
            (sum(hand) <= 21))

def is_soft_proper(hand: List[int]) -> bool:
    """Properly check if a hand is soft (has an ace counted as 11)."""
    total = sum(hand)
    aces = hand.count(11)
    if aces == 0:
        return False
    # Count how many aces are used as 11
    reduced = 0
    t = total
    a = aces
    while t > 21 and a > 0:
        t -= 10
        a -= 1
        reduced += 1
    # If any ace is still at 11, the hand is soft
    return (aces - reduced) > 0 and t <= 21

def update_count(card: int, running_count: int) -> int:
    """Update Hi-Lo running count for a dealt card."""
    return running_count + HI_LO.get(card, 0)

def get_true_count(running_count: int, cards_remaining: int) -> float:
    """Compute true count = running count / decks remaining."""
    decks_remaining = max(0.5, cards_remaining / 52.0)
    return running_count / decks_remaining

# ---------------------------------------------------------------------------
# BASIC STRATEGY ENGINE
# ---------------------------------------------------------------------------
def basic_strategy_action(player_total: int, player_hand: List[int],
                           dealer_upcard: int, soft: bool,
                           can_split: bool, can_double: bool,
                           can_surrender: bool) -> str:
    """Return the basic strategy action for the given situation."""
    # Pairs
    if can_split and len(player_hand) == 2 and player_hand[0] == player_hand[1]:
        pair_val = player_hand[0]
        if pair_val == 11:
            return 'split'
        if pair_val == 10:
            return 'stand'
        if pair_val == 9:
            if dealer_upcard in [7, 10, 11]:
                return 'stand'
            else:
                return 'split'
        if pair_val == 8:
            if dealer_upcard in [10, 11] and can_surrender:
                return 'surrender'
            return 'split'
        if pair_val == 7:
            if dealer_upcard <= 7:
                return 'split'
            return 'hit'
        if pair_val == 6:
            if dealer_upcard <= 6:
                return 'split'
            return 'hit'
        if pair_val == 5:
            if dealer_upcard <= 9 and can_double:
                return 'double'
            return 'hit'
        if pair_val == 4:
            if dealer_upcard in [5, 6]:
                return 'split'
            return 'hit'
        if pair_val in [2, 3]:
            if dealer_upcard <= 7:
                return 'split'
            return 'hit'

    # Soft totals
    if soft:
        if player_total >= 19:
            return 'stand'
        if player_total == 18:
            if dealer_upcard in [2, 3, 4, 5, 6] and can_double:
                return 'double'
            if dealer_upcard in [7, 8]:
                return 'stand'
            return 'hit'
        if player_total == 17:
            if dealer_upcard in [3, 4, 5, 6] and can_double:
                return 'double'
            return 'hit'
        if player_total in [15, 16]:
            if dealer_upcard in [4, 5, 6] and can_double:
                return 'double'
            return 'hit'
        if player_total in [13, 14]:
            if dealer_upcard in [5, 6] and can_double:
                return 'double'
            return 'hit'
        return 'hit'

    # Hard totals
    if player_total >= 17:
        return 'stand'
    if player_total == 16:
        if dealer_upcard in [9, 10, 11] and can_surrender:
            return 'surrender'
        if dealer_upcard >= 7:
            return 'hit'
        return 'stand'
    if player_total == 15:
        if dealer_upcard in [10, 11] and can_surrender:
            return 'surrender'
        if dealer_upcard >= 7:
            return 'hit'
        return 'stand'
    if player_total in [13, 14]:
        if dealer_upcard >= 7:
            return 'hit'
        return 'stand'
    if player_total == 12:
        if dealer_upcard in [4, 5, 6]:
            return 'stand'
        return 'hit'
    if player_total == 11:
        if can_double:
            return 'double'
        return 'hit'
    if player_total == 10:
        if dealer_upcard <= 9 and can_double:
            return 'double'
        return 'hit'
    if player_total == 9:
        if dealer_upcard in [3, 4, 5, 6] and can_double:
            return 'double'
        return 'hit'
    return 'hit'

def random_strategy_action(player_total: int, player_hand: List[int],
                           dealer_upcard: int, soft: bool,
                           can_split: bool, can_double: bool,
                           can_surrender: bool) -> str:
    """Random strategy: hit on < 15, stand on >= 15 with some noise."""
    if player_total >= 19:
        return 'stand'
    if player_total <= 11:
        return 'hit'
    # Random decision for middle totals
    if np.random.random() < 0.5:
        return 'hit'
    return 'stand'

# ---------------------------------------------------------------------------
# DETERMINE BET
# ---------------------------------------------------------------------------
def determine_bet(strategy: str, true_count: float, base_bet: float, hi_lo_spread: float) -> float:
    """Determine bet size based on strategy and count."""
    if strategy in ('flat', 'basic', 'random'):
        return base_bet
    if strategy == 'counting':
        if true_count <= 1:
            return base_bet
        elif true_count <= 2:
            return base_bet * 2
        elif true_count <= 3:
            return base_bet * 4
        elif true_count <= 4:
            return base_bet * 6
        else:
            return base_bet * hi_lo_spread
    return base_bet

# ---------------------------------------------------------------------------
# DEALER PLAY
# ---------------------------------------------------------------------------
def dealer_play(dealer_hand: List[int], shoe: List[int],
                running_count: int, dealer_hits_soft17: bool) -> Tuple[List[int], int]:
    """Execute dealer's fixed strategy."""
    safety = 0
    while safety < 20:
        safety += 1
        total = hand_value(dealer_hand)
        soft = is_soft_proper(dealer_hand)
        if total > 17:
            break
        if total == 17 and (not soft or not dealer_hits_soft17):
            break
        if len(shoe) == 0:
            break
        card = shoe.pop()
        running_count = update_count(card, running_count)
        dealer_hand.append(card)
    return dealer_hand, running_count

# ---------------------------------------------------------------------------
# SIMULATE A SINGLE ROUND
# ---------------------------------------------------------------------------
def simulate_round(shoe: List[int], running_count: int,
                   strategy: str, params: ScenarioParams) -> Dict[str, Any]:
    """Simulate one round of blackjack. Returns a dict of round data."""
    if len(shoe) < 10:
        # Safety: rebuild shoe if too few cards
        shoe_new = build_shoe(int(params.num_decks))
        shoe.clear()
        shoe.extend(shoe_new)
        running_count = 0

    true_count_pre = get_true_count(running_count, len(shoe))
    true_count_pre = float(np.clip(true_count_pre, -20.0, 20.0))

    bet = determine_bet(strategy, true_count_pre, params.base_bet, params.hi_lo_spread)
    bet = float(np.clip(bet, 1.0, 20.0))

    # Deal initial cards
    player_hand = [shoe.pop(), shoe.pop()]
    dealer_hand = [shoe.pop(), shoe.pop()]

    # Update count for player cards and dealer upcard (visible card)
    for card in [player_hand[0], player_hand[1], dealer_hand[0]]:
        running_count = update_count(card, running_count)

    dealer_upcard = dealer_hand[0]

    # Check blackjacks
    player_bj = (hand_value(player_hand) == 21 and len(player_hand) == 2)
    dealer_bj = (hand_value(dealer_hand) == 21 and len(dealer_hand) == 2)

    action_taken = 'none'
    net = 0.0
    outcome = 'push'

    if player_bj and dealer_bj:
        outcome = 'push'
        net = 0.0
        action_taken = 'blackjack_push'
    elif player_bj:
        outcome = 'blackjack'
        net = bet * params.blackjack_payout
        action_taken = 'blackjack'
    elif dealer_bj:
        outcome = 'loss'
        net = -bet
        action_taken = 'dealer_blackjack'
    else:
        can_double = True
        can_split = (len(player_hand) == 2 and player_hand[0] == player_hand[1])
        can_surrender = bool(params.late_surrender_allowed)

        if strategy == 'random':
            action = random_strategy_action(
                hand_value(player_hand), player_hand, dealer_upcard,
                is_soft_proper(player_hand), can_split, can_double, can_surrender)
        else:
            action = basic_strategy_action(
                hand_value(player_hand), player_hand, dealer_upcard,
                is_soft_proper(player_hand), can_split, can_double, can_surrender)

        action_taken = action

        if action == 'surrender':
            outcome = 'surrender'
            net = -bet * 0.5

        elif action == 'double':
            if len(shoe) > 0:
                card = shoe.pop()
                running_count = update_count(card, running_count)
                player_hand.append(card)
                bet *= 2
                bet = float(np.clip(bet, 1.0, 40.0))  # doubled bet can exceed 20
            player_total = hand_value(player_hand)
            if player_total > 21:
                outcome = 'loss'
                net = -bet
            else:
                dealer_hand, running_count = dealer_play(
                    dealer_hand, shoe, running_count, bool(params.dealer_hits_soft17))
                dealer_total = hand_value(dealer_hand)
                if dealer_total > 21 or player_total > dealer_total:
                    outcome = 'win'
                    net = bet
                elif player_total < dealer_total:
                    outcome = 'loss'
                    net = -bet
                else:
                    outcome = 'push'
                    net = 0.0

        elif action == 'split':
            # Simplified: play first split hand only
            if len(shoe) > 0:
                hand1 = [player_hand[0], shoe.pop()]
                running_count = update_count(hand1[1], running_count)
            else:
                hand1 = [player_hand[0], player_hand[0]]

            safety = 0
            while hand_value(hand1) < 21 and len(shoe) > 3 and safety < 10:
                safety += 1
                next_action = basic_strategy_action(
                    hand_value(hand1), hand1, dealer_upcard,
                    is_soft_proper(hand1), False, False, False)
                if next_action in ['stand', 'surrender']:
                    break
                card = shoe.pop()
                running_count = update_count(card, running_count)
                hand1.append(card)
                if hand_value(hand1) > 21:
                    break

            player_hand = hand1
            player_total = hand_value(player_hand)
            if player_total > 21:
                outcome = 'loss'
                net = -bet
            else:
                dealer_hand, running_count = dealer_play(
                    dealer_hand, shoe, running_count, bool(params.dealer_hits_soft17))
                dealer_total = hand_value(dealer_hand)
                if dealer_total > 21 or player_total > dealer_total:
                    outcome = 'win'
                    net = bet
                elif player_total < dealer_total:
                    outcome = 'loss'
                    net = -bet
                else:
                    outcome = 'push'
                    net = 0.0

        else:
            # Hit or stand sequence
            surrendered = False
            safety = 0
            while safety < 15:
                safety += 1
                pt = hand_value(player_hand)
                if pt > 21:
                    break
                if strategy == 'random':
                    act = random_strategy_action(
                        pt, player_hand, dealer_upcard,
                        is_soft_proper(player_hand), False, False, can_surrender)
                else:
                    act = basic_strategy_action(
                        pt, player_hand, dealer_upcard,
                        is_soft_proper(player_hand), False, False, can_surrender)
                if act == 'stand':
                    break
                if act == 'surrender':
                    net = -bet * 0.5
                    outcome = 'surrender'
                    action_taken = 'surrender'
                    surrendered = True
                    break
                if len(shoe) == 0:
                    break
                card = shoe.pop()
                running_count = update_count(card, running_count)
                player_hand.append(card)

            if not surrendered:
                player_total = hand_value(player_hand)
                if player_total > 21:
                    outcome = 'loss'
                    net = -bet
                else:
                    dealer_hand, running_count = dealer_play(
                        dealer_hand, shoe, running_count, bool(params.dealer_hits_soft17))
                    dealer_total = hand_value(dealer_hand)
                    if dealer_total > 21 or player_total > dealer_total:
                        outcome = 'win'
                        net = bet
                    elif player_total < dealer_total:
                        outcome = 'loss'
                        net = -bet
                    else:
                        outcome = 'push'
                        net = 0.0

    # Compute final state variables
    final_player_total = hand_value(player_hand)
    final_dealer_total = hand_value(dealer_hand)

    # For busted hands, record actual total but clamp for output
    player_busted = final_player_total > 21
    dealer_busted = final_dealer_total > 21

    # Clamp totals to valid range for state variable output
    player_total_out = int(np.clip(final_player_total, 2, 22))  # 22 = bust marker
    dealer_total_out = int(np.clip(final_dealer_total, 2, 22))

    true_count_post = get_true_count(running_count, len(shoe))
    true_count_post = float(np.clip(true_count_post, -20.0, 20.0))
    decks_rem = max(0.25, len(shoe) / 52.0)
    decks_rem = float(np.clip(decks_rem, 0.25, 8.0))
    rc_clamped = float(np.clip(running_count, -50.0, 50.0))

    return {
        'outcome': outcome,
        'net': net,
        'running_count': running_count,
        'player_hand': player_hand,
        'dealer_hand': dealer_hand,
        'bet': bet,
        'player_total': player_total_out,
        'dealer_total': dealer_total_out,
        'player_busted': player_busted,
        'dealer_busted': dealer_busted,
        'player_is_soft': is_soft_proper(player_hand),
        'dealer_is_soft': is_soft_proper(dealer_hand),
        'player_blackjack': player_bj,
        'dealer_blackjack': dealer_bj,
        'action_taken': action_taken,
        'true_count': true_count_post,
        'decks_remaining': decks_rem,
        'running_count_clamped': rc_clamped,
    }

# ---------------------------------------------------------------------------
# RUN SCENARIO
# ---------------------------------------------------------------------------
def run_scenario(scenario_cfg: Dict[str, Any], scenario_idx: int,
                 num_rounds: int = 10000) -> Tuple[List[Dict], ScenarioParams]:
    """Run a full scenario and return list of row dicts and params."""
    np.random.seed(scenario_idx)

    # Build params from defaults + overrides
    params = ScenarioParams(
        label=scenario_cfg['label'],
        strategy=scenario_cfg.get('strategy', 'basic'),
        num_decks=6.0,
        blackjack_payout=1.5,
        dealer_hits_soft17=1.0,
        shuffle_penetration=0.75,
        num_rounds=num_rounds,
        base_bet=1.0,
        hi_lo_spread=8.0,
        late_surrender_allowed=1.0,
    )
    overrides = scenario_cfg.get('param_overrides', {})
    for k, v in overrides.items():
        if hasattr(params, k):
            setattr(params, k, float(v))

    num_decks_int = max(1, int(round(params.num_decks)))
    shoe_size = num_decks_int * 52
    reshuffle_threshold = int(shoe_size * (1.0 - params.shuffle_penetration))

    shoe = build_shoe(num_decks_int)
    running_count = 0
    bankroll = 0.0
    rows = []
    total_cards_dealt_in_shoe = 0
    initial_shoe_size = len(shoe)

    for round_idx in range(num_rounds):
        # Check if we need to reshuffle
        if len(shoe) <= reshuffle_threshold or len(shoe) < 15:
            shoe = build_shoe(num_decks_int)
            running_count = 0
            total_cards_dealt_in_shoe = 0
            initial_shoe_size = len(shoe)

        cards_before = len(shoe)
        shoe_pen = float(np.clip(1.0 - len(shoe) / max(1, initial_shoe_size), 0.0, 1.0))

        result = simulate_round(shoe, running_count, params.strategy, params)
        running_count = result['running_count']

        net = result['net']
        bankroll += net
        bankroll = float(np.clip(bankroll, -10000.0, 10000.0))

        # Hand outcome encoding: win=0, loss=1, push=2, blackjack=3, surrender=4
        outcome_map = {'win': 0, 'loss': 1, 'push': 2, 'blackjack': 3,
                       'surrender': 4, 'blackjack_push': 2, 'dealer_blackjack': 1}
        outcome_code = outcome_map.get(result['outcome'], 1)

        row = {
            'scenario': params.label,
            'round_number': round_idx + 1,
            'num_decks': params.num_decks,
            'blackjack_payout': params.blackjack_payout,
            'dealer_hits_soft17': params.dealer_hits_soft17,
            'player_strategy': params.strategy,
            'player_hand_str': str(result['player_hand']),
            'dealer_hand_str': str(result['dealer_hand']),
            'player_total': result['player_total'],
            'dealer_total': result['dealer_total'],
            'player_is_soft': int(result['player_is_soft']),
            'dealer_is_soft': int(result['dealer_is_soft']),
            'player_blackjack': int(result['player_blackjack']),
            'dealer_blackjack': int(result['dealer_blackjack']),
            'player_busted': int(result['player_busted']),
            'dealer_busted': int(result['dealer_busted']),
            'action_taken': result['action_taken'],
            'current_bet': float(np.clip(result['bet'], 1.0, 20.0)),
            'hand_outcome': result['outcome'],
            'net_gain_loss': float(net),
            'cumulative_bankroll': float(bankroll),
            'running_count': result['running_count_clamped'],
            'true_count': result['true_count'],
            'decks_remaining': result['decks_remaining'],
            'shoe_penetration': float(shoe_pen),
        }
        rows.append(row)

    return rows, params

# ---------------------------------------------------------------------------
# FIGURE GENERATION
# ---------------------------------------------------------------------------

def figure1_bankroll(all_scenario_rows: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig1: Cumulative Bankroll Over Rounds by Strategy."""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))

        strategy_scenarios = {
            'Random Play': None,
            'Basic Strategy': 'six_deck_basic_strategy',
            'Card Counting': 'six_deck_card_counting',
        }

        colors = {'Random Play': 'red', 'Basic Strategy': 'blue', 'Card Counting': 'green'}

        # For random play, run 3 mini simulations
        np.random.seed(999)
        for run_i in range(3):
            np.random.seed(900 + run_i)
            params_r = ScenarioParams(label='random_play', strategy='random',
                                      num_decks=6, blackjack_payout=1.5,
                                      dealer_hits_soft17=1.0, num_rounds=10000)
            shoe = build_shoe(6)
            rc = 0
            bankroll = 0.0
            rounds_x = np.zeros(10000, dtype=int)
            bankroll_y = np.zeros(10000, dtype=float)
            for i in range(10000):
                if len(shoe) <= 156 or len(shoe) < 15:
                    shoe = build_shoe(6)
                    rc = 0
                result = simulate_round(shoe, rc, 'random', params_r)
                rc = result['running_count']
                bankroll += result['net']
                bankroll = float(np.clip(bankroll, -10000.0, 10000.0))
                rounds_x[i] = i + 1
                bankroll_y[i] = bankroll
            assert len(rounds_x) == len(bankroll_y)
            alpha = 0.4 if run_i > 0 else 0.8
            lw = 1.0 if run_i > 0 else 1.5
            label = 'Random Play' if run_i == 0 else None
            ax.plot(rounds_x, bankroll_y, color=colors['Random Play'],
                    alpha=alpha, linewidth=lw, label=label)

        # Basic strategy and card counting from scenario data
        for label, scenario_key in [('Basic Strategy', 'six_deck_basic_strategy'),
                                     ('Card Counting', 'six_deck_card_counting')]:
            if scenario_key in all_scenario_rows:
                rows = all_scenario_rows[scenario_key]
                if len(rows) > 0:
                    rounds_x = np.array([r['round_number'] for r in rows], dtype=int)
                    bankroll_y = np.array([r['cumulative_bankroll'] for r in rows], dtype=float)
                    assert len(rounds_x) == len(bankroll_y)
                    ax.plot(rounds_x, bankroll_y, color=colors[label],
                            linewidth=2.0, label=label, alpha=0.9)

        ax.axhline(y=0, color='black', linestyle='--', linewidth=0.8, alpha=0.5)
        ax.set_xlabel('Round Number', fontsize=12)
        ax.set_ylabel('Cumulative Bankroll (units)', fontsize=12)
        ax.set_title('Cumulative Bankroll Over Rounds by Strategy', fontsize=14)
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig1_bankroll_by_strategy.png', dpi=150)
        plt.close(fig)
        print("Saved fig1_bankroll_by_strategy.png")
    except Exception as e:
        print(f"Warning: fig1 failed: {e}")


def figure2_house_edge_vs_decks(sim_edges: Dict[int, float], output_dir: Path) -> None:
    """Fig2: House Edge vs Number of Decks."""
    try:
        fig, ax = plt.subplots(figsize=(9, 6))

        deck_counts = np.array([1, 2, 4, 6, 8], dtype=float)
        theoretical = np.array([0.16, 0.46, 0.60, 0.64, 0.66], dtype=float)

        sim_vals = np.array([sim_edges.get(int(d), 0.0) for d in deck_counts], dtype=float)

        assert len(deck_counts) == len(theoretical)
        assert len(deck_counts) == len(sim_vals)

        ax.plot(deck_counts, theoretical, 'k-o', linewidth=2, markersize=7,
                label='Theoretical (Wikipedia)', zorder=3)
        ax.scatter(deck_counts, sim_vals, color='royalblue', s=100, zorder=4,
                   label='Simulated', marker='D')

        # Error bars (approximate std from binomial)
        n_rounds = 10000
        for i, (d, se) in enumerate(zip(deck_counts, sim_vals)):
            # Rough standard error
            p = se / 100.0
            std = np.sqrt(p * (1 - p) / n_rounds) * 100
            ax.errorbar(d, se, yerr=std * 2, fmt='none', color='royalblue',
                        capsize=5, linewidth=1.5)

        ax.set_xlabel('Number of Decks', fontsize=12)
        ax.set_ylabel('House Edge (%)', fontsize=12)
        ax.set_title('House Edge vs. Number of Decks (Basic Strategy)', fontsize=14)
        ax.set_xticks([1, 2, 4, 6, 8])
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0, max(1.5, max(theoretical) * 1.5))
        plt.tight_layout()
        fig.savefig(output_dir / 'fig2_house_edge_vs_decks.png', dpi=150)
        plt.close(fig)
        print("Saved fig2_house_edge_vs_decks.png")
    except Exception as e:
        print(f"Warning: fig2 failed: {e}")


def figure3_hand_total_distribution(all_scenario_rows: Dict[str, List[Dict]],
                                    output_dir: Path) -> None:
    """Fig3: Distribution of Final Hand Totals."""
    try:
        # Use six_deck_basic_strategy data
        rows = all_scenario_rows.get('six_deck_basic_strategy', [])
        if len(rows) == 0:
            print("Warning: fig3 skipped - no data for six_deck_basic_strategy")
            return

        player_totals = np.array([r['player_total'] for r in rows], dtype=int)
        dealer_totals = np.array([r['dealer_total'] for r in rows], dtype=int)

        # Bust = 22+
        player_totals = np.where(player_totals > 21, 22, player_totals)
        dealer_totals = np.where(dealer_totals > 21, 22, dealer_totals)

        bins = np.arange(2, 24) - 0.5  # edges from 1.5 to 23.5
        x_ticks = list(range(2, 22)) + [22]
        x_labels = [str(i) for i in range(2, 22)] + ['Bust']

        fig, ax = plt.subplots(figsize=(12, 6))
        n_total = len(rows)
        p_counts, _ = np.histogram(player_totals, bins=bins)
        d_counts, _ = np.histogram(dealer_totals, bins=bins)

        x_centers = np.arange(2, 23, dtype=float)
        assert len(x_centers) == len(p_counts)
        assert len(x_centers) == len(d_counts)

        width = 0.4
        ax.bar(x_centers - width / 2, p_counts / n_total * 100, width=width,
               alpha=0.7, color='steelblue', label='Player', edgecolor='white')
        ax.bar(x_centers + width / 2, d_counts / n_total * 100, width=width,
               alpha=0.7, color='tomato', label='Dealer', edgecolor='white')

        ax.set_xticks(x_centers)
        ax.set_xticklabels(x_labels, rotation=45, fontsize=9)
        ax.set_xlabel('Final Hand Total', fontsize=12)
        ax.set_ylabel('Frequency (%)', fontsize=12)
        ax.set_title('Distribution of Final Hand Totals: Player vs. Dealer\n(Six-Deck Basic Strategy)', fontsize=13)
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3, axis='y')
        plt.tight_layout()
        fig.savefig(output_dir / 'fig3_hand_total_distribution.png', dpi=150)
        plt.close(fig)
        print("Saved fig3_hand_total_distribution.png")
    except Exception as e:
        print(f"Warning: fig3 failed: {e}")


def figure4_basic_strategy_heatmap(output_dir: Path) -> None:
    """Fig4: Basic Strategy Heatmap for Hard Totals."""
    try:
        player_totals = list(range(5, 22))  # 5 to 21
        dealer_upcards = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]  # 11 = Ace

        action_map = {'stand': 0, 'hit': 1, 'double': 2, 'surrender': 3, 'split': 1}
        action_names = ['Stand', 'Hit', 'Double/Hit', 'Surrender/Hit']
        colors_list = ['#2ecc71', '#3498db', '#e67e22', '#e74c3c']
        cmap = mcolors.ListedColormap(colors_list)

        matrix = np.zeros((len(player_totals), len(dealer_upcards)), dtype=int)

        for i, pt in enumerate(player_totals):
            for j, du in enumerate(dealer_upcards):
                # Build a simple hard hand with the given total
                # (no pair, no soft)
                dummy_hand = [pt - 2, 2] if pt > 4 else [2, 2]
                action = basic_strategy_action(pt, dummy_hand, du, False,
                                               False, True, True)
                matrix[i, j] = action_map.get(action, 1)

        fig, ax = plt.subplots(figsize=(12, 10))
        im = ax.imshow(matrix, cmap=cmap, vmin=0, vmax=3, aspect='auto')

        ax.set_xticks(range(len(dealer_upcards)))
        ax.set_xticklabels(['2', '3', '4', '5', '6', '7', '8', '9', '10', 'A'], fontsize=11)
        ax.set_yticks(range(len(player_totals)))
        ax.set_yticklabels([str(t) for t in player_totals], fontsize=11)

        ax.set_xlabel('Dealer Upcard', fontsize=13)
        ax.set_ylabel('Player Hard Total', fontsize=13)
        ax.set_title('Basic Strategy Action Heatmap (Hard Totals)', fontsize=14)

        # Add text annotations
        for i in range(len(player_totals)):
            for j in range(len(dealer_upcards)):
                action_code = matrix[i, j]
                short = ['S', 'H', 'D', 'R'][action_code]
                ax.text(j, i, short, ha='center', va='center',
                        fontsize=9, fontweight='bold',
                        color='white' if action_code == 1 else 'black')

        # Colorbar legend
        from matplotlib.patches import Patch
        legend_elements = [Patch(facecolor=colors_list[k], label=action_names[k])
                           for k in range(4)]
        ax.legend(handles=legend_elements, loc='lower right', fontsize=10,
                  bbox_to_anchor=(1.25, 0))

        plt.tight_layout()
        fig.savefig(output_dir / 'fig4_basic_strategy_heatmap.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig4_basic_strategy_heatmap.png")
    except Exception as e:
        print(f"Warning: fig4 failed: {e}")


def figure5_true_count_evolution(output_dir: Path) -> None:
    """Fig5: Hi-Lo True Count Evolution Through a Six-Deck Shoe."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        num_shoes = 5
        all_counts = []

        for shoe_i in range(num_shoes):
            np.random.seed(200 + shoe_i)
            shoe = build_shoe(6)
            rc = 0
            rounds = []
            true_counts = []
            round_num = 0

            params = ScenarioParams(label='shoe_trace', strategy='basic', num_decks=6,
                                    shuffle_penetration=0.75, num_rounds=5000, base_bet=1.0)
            initial_size = len(shoe)
            reshuffle_threshold = int(initial_size * 0.25)

            safety_counter = 0
            while len(shoe) > reshuffle_threshold and len(shoe) >= 15 and safety_counter < 500:
                safety_counter += 1
                round_num += 1
                result = simulate_round(shoe, rc, 'basic', params)
                rc = result['running_count']
                tc = result['true_count']
                rounds.append(round_num)
                true_counts.append(tc)

            if len(rounds) > 1 and len(true_counts) > 1:
                assert len(rounds) == len(true_counts)
                rounds_arr = np.array(rounds, dtype=int)
                tc_arr = np.array(true_counts, dtype=float)
                color = plt.cm.tab10(shoe_i / num_shoes)
                ax.plot(rounds_arr, tc_arr, color=color, alpha=0.4, linewidth=1.0,
                        label=f'Shoe {shoe_i + 1}')
                all_counts.append((rounds_arr, tc_arr))

        # Mean trajectory
        if len(all_counts) > 1:
            min_len = min(len(r) for r, _ in all_counts)
            if min_len > 1:
                mean_tc = np.zeros(min_len, dtype=float)
                for r_arr, tc_arr in all_counts:
                    mean_tc += tc_arr[:min_len]
                mean_tc /= len(all_counts)
                mean_rounds = all_counts[0][0][:min_len]
                assert len(mean_rounds) == len(mean_tc)
                ax.plot(mean_rounds, mean_tc, 'k-', linewidth=2.5, label='Mean True Count', zorder=5)

        ax.axhline(y=2.0, color='orange', linestyle='--', linewidth=1.5,
                   label='TC = +2 (raise bet)', alpha=0.8)
        ax.axhline(y=0.0, color='gray', linestyle=':', linewidth=1.0, alpha=0.5)
        ax.set_xlabel('Round Number Within Shoe', fontsize=12)
        ax.set_ylabel('True Count', fontsize=12)
        ax.set_title('Hi-Lo True Count Evolution Through a Six-Deck Shoe', fontsize=14)
        ax.legend(fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.set_ylim(-10, 10)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig5_true_count_evolution.png', dpi=150)
        plt.close(fig)
        print("Saved fig5_true_count_evolution.png")
    except Exception as e:
        print(f"Warning: fig5 failed: {e}")


def figure6_payout_vs_house_edge(output_dir: Path) -> None:
    """Fig6: Effect of Blackjack Payout Rule on House Edge."""
    try:
        payouts = [1.0, 1.1, 1.2, 1.3, 1.4, 1.5]
        sim_edges = []

        for payout_i, payout in enumerate(payouts):
            np.random.seed(300 + payout_i)
            params = ScenarioParams(label=f'payout_{payout}', strategy='basic',
                                    num_decks=6, blackjack_payout=payout,
                                    dealer_hits_soft17=1.0, num_rounds=5000, base_bet=1.0)
            shoe = build_shoe(6)
            rc = 0
            bankroll = 0.0
            total_wagered = 0.0
            reshuffle_threshold = int(6 * 52 * 0.25)

            for _ in range(5000):
                if len(shoe) <= reshuffle_threshold or len(shoe) < 15:
                    shoe = build_shoe(6)
                    rc = 0
                result = simulate_round(shoe, rc, 'basic', params)
                rc = result['running_count']
                bankroll += result['net']
                total_wagered += result['bet']

            if total_wagered > 0:
                edge = -bankroll / total_wagered * 100
            else:
                edge = 0.0
            sim_edges.append(float(edge))

        payout_arr = np.array(payouts, dtype=float)
        edge_arr = np.array(sim_edges, dtype=float)

        assert len(payout_arr) == len(edge_arr)

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(payout_arr, edge_arr, 'b-o', linewidth=2, markersize=8, label='Simulated House Edge')

        # Annotate key payouts
        for pv, label_str in [(1.0, '1:1\n(+2.3%)'), (1.2, '6:5\n(+1.4%)'), (1.5, '3:2\n(baseline)')]:
            if pv in payouts:
                idx = payouts.index(pv)
                ax.axvline(x=pv, color='gray', linestyle='--', alpha=0.6)
                ax.annotate(label_str, xy=(pv, edge_arr[idx]),
                            xytext=(pv + 0.02, edge_arr[idx] + 0.3),
                            fontsize=9, ha='left',
                            arrowprops=dict(arrowstyle='->', color='gray'))

        ax.set_xlabel('Blackjack Natural Payout Multiplier', fontsize=12)
        ax.set_ylabel('Simulated House Edge (%)', fontsize=12)
        ax.set_title('Effect of Blackjack Payout Rule on House Edge\n(Six-Deck, Basic Strategy)', fontsize=13)
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig6_payout_vs_house_edge.png', dpi=150)
        plt.close(fig)
        print("Saved fig6_payout_vs_house_edge.png")
    except Exception as e:
        print(f"Warning: fig6 failed: {e}")

# ---------------------------------------------------------------------------
# CSV WRITING
# ---------------------------------------------------------------------------

def write_simulation_outputs_csv(all_rows: List[Dict], output_dir: Path) -> None:
    """Write simulation_outputs.csv with all rounds across all scenarios."""
    fieldnames = [
        'scenario', 'round_number', 'num_decks', 'blackjack_payout',
        'dealer_hits_soft17', 'player_strategy', 'player_hand_str', 'dealer_hand_str',
        'player_total', 'dealer_total', 'player_is_soft', 'dealer_is_soft',
        'player_blackjack', 'dealer_blackjack', 'player_busted', 'dealer_busted',
        'action_taken', 'current_bet', 'hand_outcome', 'net_gain_loss',
        'cumulative_bankroll', 'running_count', 'true_count', 'decks_remaining',
        'shoe_penetration',
    ]
    if len(all_rows) == 0:
        print("Warning: No rows to write to simulation_outputs.csv")
        return
    try:
        filepath = output_dir / 'simulation_outputs.csv'
        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in all_rows:
                writer.writerow({k: row.get(k, '') for k in fieldnames})
        print(f"Saved simulation_outputs.csv ({len(all_rows)} rows)")
    except Exception as e:
        print(f"Warning: simulation_outputs.csv write failed: {e}")


def write_scenario_summary_csv(summary_data: List[Dict], output_dir: Path) -> None:
    """Write scenario_summary.csv with aggregate metrics per scenario."""
    if len(summary_data) == 0:
        print("Warning: No summary data to write")
        return
    try:
        filepath = output_dir / 'scenario_summary.csv'
        fieldnames = list(summary_data[0].keys())
        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in summary_data:
                writer.writerow(row)
        print(f"Saved scenario_summary.csv ({len(summary_data)} rows)")
    except Exception as e:
        print(f"Warning: scenario_summary.csv write failed: {e}")


def write_parameters_used_csv(output_dir: Path) -> None:
    """Write parameters_used.csv."""
    params_list = []
    for name, info in MODEL_PROFILE['parameters'].items():
        params_list.append({
            'name': name,
            'value': info['value'],
            'unit': info['unit'],
            'source': info['source'],
            'description': info['description'],
        })
    if len(params_list) == 0:
        print("Warning: No parameters to write")
        return
    try:
        filepath = output_dir / 'parameters_used.csv'
        fieldnames = ['name', 'value', 'unit', 'source', 'description']
        with open(filepath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in params_list:
                writer.writerow(row)
        print(f"Saved parameters_used.csv ({len(params_list)} rows)")
    except Exception as e:
        print(f"Warning: parameters_used.csv write failed: {e}")


def write_summary_json(summary_data: List[Dict], sim_edges: Dict[int, float],
                       output_dir: Path) -> None:
    """Write summary.json with key aggregate metrics."""
    try:
        summary = {
            'title': 'Blackjack Monte Carlo Simulation',
            'source': 'Blackjack - Wikipedia',
            'scenarios_run': len(summary_data),
            'theoretical_house_edges': THEORETICAL_EDGES,
            'simulated_house_edges_by_deck': {str(k): v for k, v in sim_edges.items()},
            'scenario_results': [],
        }
        for row in summary_data:
            summary['scenario_results'].append({
                'scenario': row.get('scenario', ''),
                'num_rounds': row.get('num_rounds', 0),
                'final_bankroll': row.get('final_bankroll', 0.0),
                'house_edge_pct': row.get('house_edge_pct', 0.0),
                'win_rate_pct': row.get('win_rate_pct', 0.0),
                'blackjack_rate_pct': row.get('blackjack_rate_pct', 0.0),
            })
        filepath = output_dir / 'summary.json'
        with open(filepath, 'w') as f:
            json.dump(summary, f, indent=2)
        print("Saved summary.json")
    except Exception as e:
        print(f"Warning: summary.json write failed: {e}")

# ---------------------------------------------------------------------------
# COMPUTE SCENARIO SUMMARY
# ---------------------------------------------------------------------------

def compute_summary(rows: List[Dict], params: ScenarioParams) -> Dict[str, Any]:
    """Compute aggregate metrics for a scenario."""
    if len(rows) == 0:
        return {}

    bankrolls = np.array([r['cumulative_bankroll'] for r in rows], dtype=float)
    player_totals = np.array([r['player_total'] for r in rows], dtype=float)
    dealer_totals = np.array([r['dealer_total'] for r in rows], dtype=float)
    nets = np.array([r['net_gain_loss'] for r in rows], dtype=float)
    bets = np.array([r['current_bet'] for r in rows], dtype=float)
    true_counts = np.array([r['true_count'] for r in rows], dtype=float)
    running_counts = np.array([r['running_count'] for r in rows], dtype=float)

    total_wagered = float(np.sum(bets))
    final_bankroll = float(bankrolls[-1]) if len(bankrolls) > 0 else 0.0

    if total_wagered > 0:
        house_edge_pct = float(-np.sum(nets) / total_wagered * 100)
    else:
        house_edge_pct = 0.0

    outcomes = [r['hand_outcome'] for r in rows]
    win_count = sum(1 for o in outcomes if o in ('win', 'blackjack'))
    loss_count = sum(1 for o in outcomes if o == 'loss')
    push_count = sum(1 for o in outcomes if o == 'push')
    bj_count = sum(1 for o in outcomes if o == 'blackjack')
    surrender_count = sum(1 for o in outcomes if o == 'surrender')

    n = len(rows)
    return {
        'scenario': params.label,
        'strategy': params.strategy,
        'num_decks': params.num_decks,
        'blackjack_payout': params.blackjack_payout,
        'dealer_hits_soft17': params.dealer_hits_soft17,
        'num_rounds': n,
        'final_bankroll': round(final_bankroll, 4),
        'house_edge_pct': round(house_edge_pct, 4),
        'total_wagered': round(total_wagered, 2),
        'mean_net_per_round': round(float(np.mean(nets)), 6),
        'std_net_per_round': round(float(np.std(nets)), 6),
        'win_rate_pct': round(win_count / n * 100, 3),
        'loss_rate_pct': round(loss_count / n * 100, 3),
        'push_rate_pct': round(push_count / n * 100, 3),
        'blackjack_rate_pct': round(bj_count / n * 100, 3),
        'surrender_rate_pct': round(surrender_count / n * 100, 3),
        'mean_player_total': round(float(np.mean(player_totals)), 3),
        'std_player_total': round(float(np.std(player_totals)), 3),
        'mean_dealer_total': round(float(np.mean(dealer_totals)), 3),
        'std_dealer_total': round(float(np.std(dealer_totals)), 3),
        'mean_true_count': round(float(np.mean(true_counts)), 4),
        'std_true_count': round(float(np.std(true_counts)), 4),
        'mean_running_count': round(float(np.mean(running_counts)), 4),
        'min_bankroll': round(float(np.min(bankrolls)), 4),
        'max_bankroll': round(float(np.max(bankrolls)), 4),
    }

# ---------------------------------------------------------------------------
# MULTI-DECK COMPARISON
# ---------------------------------------------------------------------------

def run_multi_deck_comparison(num_rounds: int = 5000) -> Dict[int, float]:
    """Run basic strategy simulations for 1, 2, 4, 6, 8 decks and return house edges."""
    deck_edges = {}
    for deck_i, nd in enumerate([1, 2, 4, 6, 8]):
        np.random.seed(500 + deck_i)
        params = ScenarioParams(label=f'deck_{nd}', strategy='basic',
                                num_decks=float(nd), blackjack_payout=1.5,
                                dealer_hits_soft17=1.0, num_rounds=num_rounds, base_bet=1.0)
        shoe = build_shoe(nd)
        rc = 0
        bankroll = 0.0
        total_wagered = 0.0
        reshuffle_threshold = int(nd * 52 * 0.25)

        for _ in range(num_rounds):
            if len(shoe) <= reshuffle_threshold or len(shoe) < 15:
                shoe = build_shoe(nd)
                rc = 0
            result = simulate_round(shoe, rc, 'basic', params)
            rc = result['running_count']
            bankroll += result['net']
            total_wagered += result['bet']

        if total_wagered > 0:
            edge = -bankroll / total_wagered * 100
        else:
            edge = 0.0
        deck_edges[nd] = float(edge)
        print(f"  {nd} deck(s): simulated house edge = {edge:.3f}%")

    return deck_edges

# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description='Blackjack Monte Carlo Simulator')
    parser.add_argument('--output', type=str, default='./sim_outputs',
                        help='Output directory for results (default: ./sim_outputs)')
    parser.add_argument('--rounds', type=int, default=10000,
                        help='Number of rounds per scenario (default: 10000)')
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir}")

    num_rounds = args.rounds
    all_rows: List[Dict] = []
    all_scenario_rows: Dict[str, List[Dict]] = {}
    summary_data: List[Dict] = []

    # Run all scenarios
    print("\n=== Running Scenarios ===")
    for scenario_idx, scenario_cfg in enumerate(MODEL_PROFILE['scenarios']):
        print(f"\nScenario {scenario_idx}: {scenario_cfg['label']}")
        try:
            rows, params = run_scenario(scenario_cfg, scenario_idx, num_rounds)
            all_rows.extend(rows)
            all_scenario_rows[scenario_cfg['label']] = rows

            summary = compute_summary(rows, params)
            summary_data.append(summary)
            print(f"  Completed {len(rows)} rounds | "
                  f"Final bankroll: {summary.get('final_bankroll', 0):.1f} | "
                  f"House edge: {summary.get('house_edge_pct', 0):.3f}%")
        except Exception as e:
            print(f"Warning: Scenario {scenario_cfg['label']} failed: {e}")

    # Multi-deck comparison for fig2
    print("\n=== Running Multi-Deck Comparison ===")
    try:
        sim_edges = run_multi_deck_comparison(num_rounds=min(num_rounds, 8000))
    except Exception as e:
        print(f"Warning: Multi-deck comparison failed: {e}")
        sim_edges = {1: 0.2, 2: 0.5, 4: 0.6, 6: 0.65, 8: 0.67}

    # Write CSV files
    print("\n=== Writing CSV Files ===")
    write_simulation_outputs_csv(all_rows, output_dir)
    write_scenario_summary_csv(summary_data, output_dir)
    write_parameters_used_csv(output_dir)

    # Generate figures
    print("\n=== Generating Figures ===")
    figure1_bankroll(all_scenario_rows, output_dir)
    figure2_house_edge_vs_decks(sim_edges, output_dir)
    figure3_hand_total_distribution(all_scenario_rows, output_dir)
    figure4_basic_strategy_heatmap(output_dir)
    figure5_true_count_evolution(output_dir)
    figure6_payout_vs_house_edge(output_dir)

    # Write summary JSON
    print("\n=== Writing Summary JSON ===")
    write_summary_json(summary_data, sim_edges, output_dir)

    print(f"\n=== Simulation Complete ===")
    print(f"All outputs saved to: {output_dir}")
    print(f"Total rounds simulated: {len(all_rows)}")


if __name__ == "__main__":
    main()