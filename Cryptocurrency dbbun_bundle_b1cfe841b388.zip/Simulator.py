# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-26T19:07:19.152901Z
# Run ID    : 596e45c0-60b1-40f6-9899-f7a7291101cf
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Cryptocurrency/Token Price Chart: Buy/Sell Price Dynamics Over 30-Day Period (Feb 14 - Mar 13)

Simulator implementing regime-switching geometric Brownian motion with Ornstein-Uhlenbeck
spread dynamics to reproduce the characteristic drawdown-then-spike pattern observed in
a 30-day crypto token price chart.

Reference: "Cryptocurrency/Token Price Chart: Buy/Sell Price Dynamics Over 30-Day Period
(Feb 14 - Mar 13)" — synthetic data simulator based on extracted chart parameters.
"""

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ── Model profile ──────────────────────────────────────────────────────────────
MODEL_PROFILE = {
    "parameters": {
        "mu_bear": -0.025,
        "mu_bull": 0.18,
        "sigma_bear": 0.025,
        "sigma_bull": 0.045,
        "regime_switch_day": 23.0,
        "spread_base": 0.055,
        "spread_volatility": 0.005,
        "volume_bear_mean": 80000.0,
        "volume_bull_mean": 400000.0,
        "volume_noise_scale": 0.4,
        "dt": 0.1,
        "T_total": 30.0,
        "undulation_amplitude": 0.06,
        "undulation_period": 6.0,
        "n_simulations": 50,
        "kappa_spread": 1.0,
    },
    "state_variables": {
        "buy_price":  {"init": 1.02, "range": [0.45, 1.10], "unit": "USD"},
        "sell_price": {"init": 0.97, "range": [0.42, 1.05], "unit": "USD"},
        "spread":     {"init": 0.05, "range": [0.02, 0.12], "unit": "USD"},
        "volume":     {"init": 80000.0, "range": [20000.0, 600000.0], "unit": "USD"},
        "regime":     {"init": 0.0,  "range": [0.0,  1.0],  "unit": "a.u."},
        "time_days":  {"init": 0.0,  "range": [0.0,  30.0], "unit": "days"},
    },
    "scenarios": [
        {
            "label": "baseline_observed",
            "description": "Bearish drawdown Feb 14–Mar 9 then sharp spike to Mar 13.",
            "param_overrides": {
                "mu_bear": -0.025, "mu_bull": 0.18,
                "sigma_bear": 0.025, "sigma_bull": 0.045,
                "regime_switch_day": 23.0,
            },
        },
        {
            "label": "no_recovery_continued_bear",
            "description": "Regime never switches; prices keep declining.",
            "param_overrides": {
                "mu_bear": -0.025, "mu_bull": -0.015,
                "sigma_bear": 0.025, "sigma_bull": 0.025,
                "regime_switch_day": 30.0,
            },
        },
        {
            "label": "early_recovery",
            "description": "Bullish switch at day 15 — shallower trough, earlier spike.",
            "param_overrides": {
                "mu_bear": -0.025, "mu_bull": 0.18,
                "sigma_bear": 0.025, "sigma_bull": 0.045,
                "regime_switch_day": 15.0,
            },
        },
        {
            "label": "high_volatility_bear",
            "description": "Higher sigma in both regimes — turbulent market.",
            "param_overrides": {
                "mu_bear": -0.025, "mu_bull": 0.18,
                "sigma_bear": 0.055, "sigma_bull": 0.08,
                "regime_switch_day": 23.0,
            },
        },
        {
            "label": "tight_spread",
            "description": "Tighter bid-ask spread (more liquid market).",
            "param_overrides": {
                "spread_base": 0.02, "spread_volatility": 0.002,
                "mu_bear": -0.025, "mu_bull": 0.18,
                "regime_switch_day": 23.0,
            },
        },
    ],
}

# Date mapping helpers ──────────────────────────────────────────────────────────
_START_DATE = "Feb-14"
_DATE_LABELS = [
    "Feb-14","Feb-15","Feb-16","Feb-17","Feb-18","Feb-19","Feb-20",
    "Feb-21","Feb-22","Feb-23","Feb-24","Feb-25","Feb-26","Feb-27",
    "Feb-28","Mar-01","Mar-02","Mar-03","Mar-04","Mar-05","Mar-06",
    "Mar-07","Mar-08","Mar-09","Mar-10","Mar-11","Mar-12","Mar-13",
    "Mar-14","Mar-15",
]


def day_to_date(day_float: float) -> str:
    idx = int(day_float)
    idx = max(0, min(idx, len(_DATE_LABELS) - 1))
    return _DATE_LABELS[idx]


# ── Core simulation ────────────────────────────────────────────────────────────
def run_single_path(params: dict, seed: int) -> dict:
    """Run one Euler-Maruyama path and return arrays indexed by step."""
    rng = np.random.default_rng(seed)

    dt          = params["dt"]
    T_total     = params["T_total"]
    N_steps     = int(T_total / dt)

    mu_bear     = params["mu_bear"]
    mu_bull     = params["mu_bull"]
    sigma_bear  = params["sigma_bear"]
    sigma_bull  = params["sigma_bull"]
    rsd         = params["regime_switch_day"]
    spread_base = params["spread_base"]
    spread_vol  = params["spread_volatility"]
    vol_b_mean  = params["volume_bear_mean"]
    vol_bull_mean = params["volume_bull_mean"]
    vnoise      = params["volume_noise_scale"]
    kappa       = params["kappa_spread"]
    und_amp     = params["undulation_amplitude"]
    und_per     = params["undulation_period"]

    # allocate arrays
    time_arr   = np.zeros(N_steps + 1)
    buy_arr    = np.zeros(N_steps + 1)
    sell_arr   = np.zeros(N_steps + 1)
    spread_arr = np.zeros(N_steps + 1)
    regime_arr = np.zeros(N_steps + 1)
    volume_arr = np.zeros(N_steps + 1)  # carried at step resolution (daily)

    # initialise
    buy_arr[0]    = 1.02
    spread_arr[0] = spread_base
    sell_arr[0]   = max(0.005, buy_arr[0] - spread_arr[0])
    volume_arr[0] = vol_b_mean
    time_arr[0]   = 0.0

    steps_per_day = int(round(1.0 / dt))  # = 10
    current_day_vol = vol_b_mean

    for i in range(N_steps):
        t = time_arr[i]
        time_arr[i + 1] = t + dt

        # regime
        if t < rsd:
            regime_arr[i] = 0.0
            undulation = und_amp * math.sin(2 * math.pi * t / und_per) * math.exp(-t / 15.0)
            mu    = mu_bear + undulation
            sigma = sigma_bear
            vol_mean = vol_b_mean
        else:
            regime_arr[i] = 1.0
            mu    = mu_bull
            sigma = sigma_bull
            vol_mean = vol_bull_mean

        # price SDE
        dW = math.sqrt(dt) * rng.standard_normal()
        new_buy = buy_arr[i] * math.exp((mu - 0.5 * sigma ** 2) * dt + sigma * dW)
        new_buy = max(new_buy, 0.01)
        # clamp to spec range
        new_buy = max(0.45, min(1.10, new_buy))
        buy_arr[i + 1] = new_buy

        # spread OU
        dW_s = math.sqrt(dt) * rng.standard_normal()
        new_spread = (spread_arr[i]
                      + kappa * (spread_base - spread_arr[i]) * dt
                      + spread_vol * dW_s)
        new_spread = max(0.005, new_spread)
        new_spread = max(0.02, min(0.12, new_spread))
        spread_arr[i + 1] = new_spread

        new_sell = max(0.005, new_buy - new_spread)
        new_sell = max(0.42, min(1.05, new_sell))
        sell_arr[i + 1] = new_sell

        # volume: update once per day
        if (i + 1) % steps_per_day == 0:
            ln_vol = math.log(vol_mean) + vnoise * rng.standard_normal() - 0.5 * vnoise ** 2
            current_day_vol = math.exp(ln_vol)
            current_day_vol = max(20000.0, min(600000.0, current_day_vol))
        volume_arr[i + 1] = current_day_vol

    regime_arr[N_steps] = regime_arr[N_steps - 1]  # carry last value

    return {
        "time":   time_arr,
        "buy":    buy_arr,
        "sell":   sell_arr,
        "spread": spread_arr,
        "regime": regime_arr,
        "volume": volume_arr,
    }


def compute_daily_metrics(path: dict, params: dict) -> dict:
    """Return day-level arrays from a sub-step path."""
    dt = params["dt"]
    steps_per_day = int(round(1.0 / dt))
    N_steps = len(path["time"]) - 1
    N_days  = int(N_steps / steps_per_day)

    days         = np.zeros(N_days)
    daily_buy    = np.zeros(N_days)
    daily_sell   = np.zeros(N_days)
    daily_spread = np.zeros(N_days)
    daily_vol    = np.zeros(N_days)
    daily_regime = np.zeros(N_days)
    daily_ret_buy  = np.zeros(N_days)
    daily_ret_sell = np.zeros(N_days)
    log_ret_buy    = np.zeros(N_days)
    cum_ret_buy    = np.zeros(N_days)

    init_buy = path["buy"][0]

    for d in range(N_days):
        start_idx = d * steps_per_day
        end_idx   = (d + 1) * steps_per_day

        days[d]         = path["time"][end_idx]
        daily_buy[d]    = path["buy"][end_idx]
        daily_sell[d]   = path["sell"][end_idx]
        daily_spread[d] = path["spread"][end_idx]
        daily_vol[d]    = path["volume"][end_idx]
        daily_regime[d] = path["regime"][end_idx]

        b_start = path["buy"][start_idx]
        b_end   = path["buy"][end_idx]
        s_start = path["sell"][start_idx]
        s_end   = path["sell"][end_idx]

        if b_start > 0:
            daily_ret_buy[d] = (b_end - b_start) / b_start
            log_ret_buy[d]   = math.log(max(b_end / b_start, 1e-10))
        if s_start > 0:
            daily_ret_sell[d] = (s_end - s_start) / s_start
        if init_buy > 0:
            cum_ret_buy[d] = b_end / init_buy - 1.0

    return {
        "days": days,
        "buy": daily_buy,
        "sell": daily_sell,
        "spread": daily_spread,
        "volume": daily_vol,
        "regime": daily_regime,
        "daily_ret_buy": daily_ret_buy,
        "daily_ret_sell": daily_ret_sell,
        "log_ret_buy": log_ret_buy,
        "cum_ret_buy": cum_ret_buy,
    }


def run_scenario(scenario: dict, scenario_idx: int) -> tuple:
    """Run all Monte Carlo paths for one scenario.
    Returns (all_paths_substep, all_daily_metrics).
    """
    np.random.seed(scenario_idx)  # reproducibility per spec

    # build param dict with overrides
    params = dict(MODEL_PROFILE["parameters"])
    for k, v in scenario.get("param_overrides", {}).items():
        params[k] = v

    n_sim = int(params["n_simulations"])
    label = scenario["label"]

    paths_substep = []
    paths_daily   = []

    for sim_i in range(n_sim):
        seed = scenario_idx * 10000 + sim_i
        path  = run_single_path(params, seed)
        daily = compute_daily_metrics(path, params)
        paths_substep.append(path)
        paths_daily.append(daily)

    return params, paths_substep, paths_daily


# ── CSV helpers ────────────────────────────────────────────────────────────────
def build_simulation_outputs(all_scenario_results: list) -> list:
    """Build rows for simulation_outputs.csv (daily resolution)."""
    rows = []
    sim_id_counter = 0

    for scenario_idx, (scenario, params, _, paths_daily) in enumerate(all_scenario_results):
        label = scenario["label"]
        for daily in paths_daily:
            N_days = len(daily["days"])
            for d in range(N_days):
                rows.append({
                    "simulation_id":      sim_id_counter,
                    "scenario":           label,
                    "time_days":          round(float(daily["days"][d]), 4),
                    "date_label":         day_to_date(daily["days"][d]),
                    "buy_price":          round(float(daily["buy"][d]), 6),
                    "sell_price":         round(float(daily["sell"][d]), 6),
                    "spread":             round(float(daily["spread"][d]), 6),
                    "volume":             round(float(daily["volume"][d]), 2),
                    "regime":             round(float(daily["regime"][d]), 4),
                    "daily_return_buy":   round(float(daily["daily_ret_buy"][d]), 6),
                    "daily_return_sell":  round(float(daily["daily_ret_sell"][d]), 6),
                    "log_return_buy":     round(float(daily["log_ret_buy"][d]), 6),
                    "cumulative_return_buy": round(float(daily["cum_ret_buy"][d]), 6),
                })
            sim_id_counter += 1

    return rows


def write_simulation_outputs(rows: list, out_dir: Path) -> None:
    if not rows:
        print("WARNING: simulation_outputs rows are empty, skipping.")
        return
    fieldnames = [
        "simulation_id", "scenario", "time_days", "date_label",
        "buy_price", "sell_price", "spread", "volume", "regime",
        "daily_return_buy", "daily_return_sell", "log_return_buy",
        "cumulative_return_buy",
    ]
    filepath = out_dir / "simulation_outputs.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {filepath}  ({len(rows)} rows)")


def write_scenario_summary(all_scenario_results: list, out_dir: Path) -> None:
    rows = []
    for scenario_idx, (scenario, params, _, paths_daily) in enumerate(all_scenario_results):
        label = scenario["label"]
        buy_vals    = np.concatenate([d["buy"]    for d in paths_daily])
        sell_vals   = np.concatenate([d["sell"]   for d in paths_daily])
        spread_vals = np.concatenate([d["spread"] for d in paths_daily])
        vol_vals    = np.concatenate([d["volume"] for d in paths_daily])
        ret_vals    = np.concatenate([d["log_ret_buy"] for d in paths_daily])
        cum_ret_last = np.array([d["cum_ret_buy"][-1] for d in paths_daily])

        rows.append({
            "scenario":             label,
            "buy_price_mean":       round(float(np.mean(buy_vals)), 6),
            "buy_price_std":        round(float(np.std(buy_vals)), 6),
            "buy_price_min":        round(float(np.min(buy_vals)), 6),
            "buy_price_max":        round(float(np.max(buy_vals)), 6),
            "sell_price_mean":      round(float(np.mean(sell_vals)), 6),
            "sell_price_std":       round(float(np.std(sell_vals)), 6),
            "sell_price_min":       round(float(np.min(sell_vals)), 6),
            "sell_price_max":       round(float(np.max(sell_vals)), 6),
            "spread_mean":          round(float(np.mean(spread_vals)), 6),
            "spread_std":           round(float(np.std(spread_vals)), 6),
            "volume_mean":          round(float(np.mean(vol_vals)), 2),
            "volume_std":           round(float(np.std(vol_vals)), 2),
            "log_return_mean":      round(float(np.mean(ret_vals)), 6),
            "log_return_std":       round(float(np.std(ret_vals)), 6),
            "cumulative_return_final_mean": round(float(np.mean(cum_ret_last)), 6),
            "cumulative_return_final_std":  round(float(np.std(cum_ret_last)), 6),
            "regime_switch_day":    params["regime_switch_day"],
            "mu_bear":              params["mu_bear"],
            "mu_bull":              params["mu_bull"],
            "sigma_bear":           params["sigma_bear"],
            "sigma_bull":           params["sigma_bull"],
            "spread_base":          params["spread_base"],
        })

    if not rows:
        print("WARNING: scenario_summary rows empty, skipping.")
        return
    filepath = out_dir / "scenario_summary.csv"
    fieldnames = list(rows[0].keys())
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {filepath}  ({len(rows)} rows)")


def write_parameters_used(out_dir: Path) -> None:
    param_meta = [
        ("mu_bear",            -0.025,    "per day",       "extracted",
         "Mean drift in bearish regime"),
        ("mu_bull",             0.18,     "per day",       "extracted",
         "Mean drift in bullish recovery regime"),
        ("sigma_bear",          0.025,    "per day^0.5",   "extracted",
         "Volatility in bearish regime"),
        ("sigma_bull",          0.045,    "per day^0.5",   "extracted",
         "Volatility in bullish regime"),
        ("regime_switch_day",  23.0,      "days",          "extracted",
         "Day of regime switch from bear to bull"),
        ("spread_base",         0.055,    "USD",           "extracted",
         "Baseline bid-ask spread"),
        ("spread_volatility",   0.005,    "USD",           "extracted",
         "Std of stochastic spread fluctuations"),
        ("volume_bear_mean",   80000.0,   "USD",           "extracted",
         "Mean daily volume in bear regime"),
        ("volume_bull_mean",  400000.0,   "USD",           "extracted",
         "Mean daily volume in bull spike"),
        ("volume_noise_scale",  0.4,      "a.u.",          "extracted",
         "Lognormal noise scale for volume"),
        ("dt",                  0.1,      "days",          "assumed",
         "Euler-Maruyama time step"),
        ("T_total",            30.0,      "days",          "extracted",
         "Total simulation window"),
        ("undulation_amplitude",0.06,     "USD",           "extracted",
         "Amplitude of mid-drawdown oscillations"),
        ("undulation_period",   6.0,      "days",          "extracted",
         "Period of mid-drawdown oscillations"),
        ("n_simulations",      50.0,      "a.u.",          "assumed",
         "Number of Monte Carlo paths"),
        ("kappa_spread",        1.0,      "per day",       "assumed",
         "Mean-reversion speed of spread OU process"),
    ]
    filepath = out_dir / "parameters_used.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["name", "value", "unit", "source", "description"])
        for row in param_meta:
            writer.writerow(list(row))
    print(f"Saved {filepath}  ({len(param_meta)} rows)")


def write_summary_json(all_scenario_results: list, out_dir: Path) -> None:
    summary = {}
    for scenario_idx, (scenario, params, _, paths_daily) in enumerate(all_scenario_results):
        label = scenario["label"]
        final_buys = np.array([d["buy"][-1] for d in paths_daily])
        final_cumret = np.array([d["cum_ret_buy"][-1] for d in paths_daily])
        all_log_ret  = np.concatenate([d["log_ret_buy"] for d in paths_daily])
        summary[label] = {
            "final_buy_price_mean":     round(float(np.mean(final_buys)), 6),
            "final_buy_price_std":      round(float(np.std(final_buys)), 6),
            "final_cumulative_return_mean": round(float(np.mean(final_cumret)), 6),
            "log_return_mean":          round(float(np.mean(all_log_ret)), 6),
            "log_return_std":           round(float(np.std(all_log_ret)), 6),
            "regime_switch_day":        params["regime_switch_day"],
        }
    filepath = out_dir / "summary.json"
    with open(filepath, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"Saved {filepath}")


# ── Figure generation ──────────────────────────────────────────────────────────
STYLE = "dark_background"
BUY_COLOR  = "#00CED1"
SELL_COLOR = "#FF4444"
VOL_COLOR  = "#8B0000"
SCENARIO_COLORS = ["#00CED1", "#FF6B6B", "#90EE90", "#FFD700", "#DA70D6"]


def fig1_price_timeseries(all_scenario_results: list, out_dir: Path) -> None:
    """Buy and Sell Price Over 30-Day Window (baseline scenario)."""
    try:
        baseline = None
        for sc, params, paths_sub, paths_daily in all_scenario_results:
            if sc["label"] == "baseline_observed":
                baseline = paths_daily
                break
        if baseline is None:
            print("WARNING fig1: baseline not found.")
            return

        # build ensemble mean
        N_days = len(baseline[0]["days"])
        days_arr = baseline[0]["days"].copy()
        buy_matrix  = np.array([d["buy"]  for d in baseline])
        sell_matrix = np.array([d["sell"] for d in baseline])

        mean_buy  = np.mean(buy_matrix,  axis=0)
        mean_sell = np.mean(sell_matrix, axis=0)
        assert len(days_arr) == len(mean_buy) == len(mean_sell)

        plt.style.use(STYLE)
        fig, ax = plt.subplots(figsize=(12, 6))

        ax.plot(days_arr, mean_buy,  color=BUY_COLOR,  linewidth=2.0, label="Buy Price")
        ax.plot(days_arr, mean_sell, color=SELL_COLOR, linewidth=2.0, label="Sell Price")

        ax.axhline(mean_buy[-1],  color=BUY_COLOR,  linestyle="--", linewidth=1, alpha=0.7,
                   label=f"Final Buy ≈ {mean_buy[-1]:.3f}")
        ax.axhline(mean_sell[-1], color=SELL_COLOR, linestyle="--", linewidth=1, alpha=0.7,
                   label=f"Final Sell ≈ {mean_sell[-1]:.3f}")

        ax.fill_between(days_arr, mean_buy, mean_sell, alpha=0.15, color="grey")

        ax.set_title("Buy and Sell Price Over 30-Day Window", fontsize=14, pad=12)
        ax.set_xlabel("Time (days from Feb-14)", fontsize=11)
        ax.set_ylabel("Price (USD)", fontsize=11)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        # x-tick date labels every 5 days
        tick_positions = np.arange(0, 31, 5)
        tick_labels = [day_to_date(d) for d in tick_positions]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=30, ha="right", fontsize=8)

        fig.tight_layout()
        savepath = out_dir / "fig1_price_timeseries.png"
        fig.savefig(savepath, dpi=150)
        plt.close(fig)
        print(f"Saved {savepath}")
    except Exception as e:
        print(f"WARNING fig1 failed: {e}")


def fig2_volume_bars(all_scenario_results: list, out_dir: Path) -> None:
    """Daily Trading Volume Bar Chart (baseline scenario)."""
    try:
        baseline = None
        for sc, params, paths_sub, paths_daily in all_scenario_results:
            if sc["label"] == "baseline_observed":
                baseline = paths_daily
                break
        if baseline is None:
            print("WARNING fig2: baseline not found.")
            return

        days_arr = baseline[0]["days"].copy()
        vol_matrix = np.array([d["volume"] for d in baseline])
        mean_vol = np.mean(vol_matrix, axis=0)

        assert len(days_arr) == len(mean_vol)

        bar_width = 0.7
        plt.style.use(STYLE)
        fig, ax = plt.subplots(figsize=(12, 4))

        ax.bar(days_arr, mean_vol, width=bar_width, color=VOL_COLOR, alpha=0.85, label="Volume")

        ax.set_title("Daily Trading Volume (30-Day Window)", fontsize=14, pad=12)
        ax.set_xlabel("Time (days from Feb-14)", fontsize=11)
        ax.set_ylabel("Volume (USD)", fontsize=11)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.2, axis='y')

        tick_positions = np.arange(0, 31, 5)
        tick_labels    = [day_to_date(d) for d in tick_positions]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=30, ha="right", fontsize=8)

        fig.tight_layout()
        savepath = out_dir / "fig2_volume_bars.png"
        fig.savefig(savepath, dpi=150)
        plt.close(fig)
        print(f"Saved {savepath}")
    except Exception as e:
        print(f"WARNING fig2 failed: {e}")


def fig3_spread_dynamics(all_scenario_results: list, out_dir: Path) -> None:
    """Bid-Ask Spread Over Time — baseline + tight_spread overlay."""
    try:
        baseline_data = None
        tight_data    = None
        for sc, params, paths_sub, paths_daily in all_scenario_results:
            if sc["label"] == "baseline_observed":
                baseline_data = paths_daily
            if sc["label"] == "tight_spread":
                tight_data = paths_daily

        if baseline_data is None:
            print("WARNING fig3: baseline not found.")
            return

        plt.style.use(STYLE)
        fig, ax = plt.subplots(figsize=(12, 5))

        days_b = baseline_data[0]["days"].copy()
        spread_matrix_b = np.array([d["spread"] for d in baseline_data])
        mean_spread_b   = np.mean(spread_matrix_b, axis=0)
        p10_b = np.percentile(spread_matrix_b, 10, axis=0)
        p90_b = np.percentile(spread_matrix_b, 90, axis=0)

        assert len(days_b) == len(mean_spread_b)

        ax.plot(days_b, mean_spread_b, color=BUY_COLOR, linewidth=2, label="Baseline Spread")
        ax.fill_between(days_b, p10_b, p90_b, color=BUY_COLOR, alpha=0.2, label="10–90 pctile")

        if tight_data is not None:
            days_t = tight_data[0]["days"].copy()
            spread_matrix_t = np.array([d["spread"] for d in tight_data])
            mean_spread_t   = np.mean(spread_matrix_t, axis=0)
            assert len(days_t) == len(mean_spread_t)
            ax.plot(days_t, mean_spread_t, color="#DA70D6", linewidth=1.5,
                    linestyle="--", label="Tight Spread")

        ax.set_title("Bid-Ask Spread Over Time", fontsize=14, pad=12)
        ax.set_xlabel("Time (days from Feb-14)", fontsize=11)
        ax.set_ylabel("Spread (USD)", fontsize=11)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        tick_positions = np.arange(0, 31, 5)
        tick_labels    = [day_to_date(d) for d in tick_positions]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=30, ha="right", fontsize=8)

        fig.tight_layout()
        savepath = out_dir / "fig3_spread_dynamics.png"
        fig.savefig(savepath, dpi=150)
        plt.close(fig)
        print(f"Saved {savepath}")
    except Exception as e:
        print(f"WARNING fig3 failed: {e}")


def fig4_scenario_comparison(all_scenario_results: list, out_dir: Path) -> None:
    """Buy Price Comparison Across All Scenarios."""
    try:
        plt.style.use(STYLE)
        fig, ax = plt.subplots(figsize=(12, 6))

        for idx, (sc, params, paths_sub, paths_daily) in enumerate(all_scenario_results):
            label = sc["label"]
            days_arr = paths_daily[0]["days"].copy()
            buy_matrix = np.array([d["buy"] for d in paths_daily])
            mean_buy   = np.mean(buy_matrix, axis=0)
            assert len(days_arr) == len(mean_buy)
            color = SCENARIO_COLORS[idx % len(SCENARIO_COLORS)]
            ax.plot(days_arr, mean_buy, color=color, linewidth=2, label=label)

        ax.set_title("Buy Price Comparison Across Scenarios", fontsize=14, pad=12)
        ax.set_xlabel("Time (days from Feb-14)", fontsize=11)
        ax.set_ylabel("Buy Price (USD)", fontsize=11)
        ax.legend(fontsize=8, loc="best")
        ax.grid(True, alpha=0.3)

        tick_positions = np.arange(0, 31, 5)
        tick_labels    = [day_to_date(d) for d in tick_positions]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=30, ha="right", fontsize=8)

        fig.tight_layout()
        savepath = out_dir / "fig4_scenario_comparison.png"
        fig.savefig(savepath, dpi=150)
        plt.close(fig)
        print(f"Saved {savepath}")
    except Exception as e:
        print(f"WARNING fig4 failed: {e}")


def fig5_monte_carlo_ensemble(all_scenario_results: list, out_dir: Path) -> None:
    """Monte Carlo Fan Chart — Baseline Scenario."""
    try:
        baseline_daily = None
        for sc, params, paths_sub, paths_daily in all_scenario_results:
            if sc["label"] == "baseline_observed":
                baseline_daily = paths_daily
                break
        if baseline_daily is None:
            print("WARNING fig5: baseline not found.")
            return

        days_arr   = baseline_daily[0]["days"].copy()
        buy_matrix = np.array([d["buy"] for d in baseline_daily])
        mean_buy   = np.mean(buy_matrix,  axis=0)
        p10_buy    = np.percentile(buy_matrix, 10, axis=0)
        p90_buy    = np.percentile(buy_matrix, 90, axis=0)

        assert len(days_arr) == buy_matrix.shape[1]

        plt.style.use(STYLE)
        fig, ax = plt.subplots(figsize=(12, 6))

        # individual paths (thin)
        for i in range(buy_matrix.shape[0]):
            x = days_arr
            y = buy_matrix[i]
            assert len(x) == len(y)
            ax.plot(x, y, color=BUY_COLOR, linewidth=0.4, alpha=0.25)

        # percentile band
        ax.fill_between(days_arr, p10_buy, p90_buy, color=BUY_COLOR, alpha=0.3,
                        label="10–90 pctile band")
        ax.plot(days_arr, mean_buy, color="white", linewidth=2.0, label="Ensemble mean")

        ax.set_title("Monte Carlo Ensemble of Buy Price Paths (Baseline)", fontsize=14, pad=12)
        ax.set_xlabel("Time (days from Feb-14)", fontsize=11)
        ax.set_ylabel("Buy Price (USD)", fontsize=11)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        tick_positions = np.arange(0, 31, 5)
        tick_labels    = [day_to_date(d) for d in tick_positions]
        ax.set_xticks(tick_positions)
        ax.set_xticklabels(tick_labels, rotation=30, ha="right", fontsize=8)

        fig.tight_layout()
        savepath = out_dir / "fig5_monte_carlo_ensemble.png"
        fig.savefig(savepath, dpi=150)
        plt.close(fig)
        print(f"Saved {savepath}")
    except Exception as e:
        print(f"WARNING fig5 failed: {e}")


def fig6_return_distribution(all_scenario_results: list, out_dir: Path) -> None:
    """Distribution of Daily Log-Returns by Regime (Baseline)."""
    try:
        baseline_daily = None
        for sc, params, paths_sub, paths_daily in all_scenario_results:
            if sc["label"] == "baseline_observed":
                baseline_daily = paths_daily
                baseline_params = params
                break
        if baseline_daily is None:
            print("WARNING fig6: baseline not found.")
            return

        # collect returns split by regime
        bear_returns = []
        bull_returns = []

        for d in baseline_daily:
            for i in range(len(d["days"])):
                ret = float(d["log_ret_buy"][i])
                reg = float(d["regime"][i])
                if reg < 0.5:
                    bear_returns.append(ret)
                else:
                    bull_returns.append(ret)

        bear_arr = np.array(bear_returns)
        bull_arr = np.array(bull_returns)

        if len(bear_arr) == 0 or len(bull_arr) == 0:
            print("WARNING fig6: insufficient regime data.")
            return

        plt.style.use(STYLE)
        fig, ax = plt.subplots(figsize=(10, 5))

        bins_bear = min(40, max(10, len(bear_arr) // 10))
        bins_bull = min(40, max(10, len(bull_arr) // 10))

        ax.hist(bear_arr, bins=bins_bear, color=SELL_COLOR, alpha=0.6, density=True,
                label=f"Bearish regime  (n={len(bear_arr)})")
        ax.hist(bull_arr, bins=bins_bull, color=BUY_COLOR,  alpha=0.6, density=True,
                label=f"Bullish regime  (n={len(bull_arr)})")

        ax.axvline(float(np.mean(bear_arr)), color=SELL_COLOR, linestyle="--",
                   linewidth=1.5, label=f"Bear mean={np.mean(bear_arr):.4f}")
        ax.axvline(float(np.mean(bull_arr)), color=BUY_COLOR, linestyle="--",
                   linewidth=1.5, label=f"Bull mean={np.mean(bull_arr):.4f}")

        ax.set_title("Distribution of Daily Log-Returns by Regime (Baseline)", fontsize=14, pad=12)
        ax.set_xlabel("Daily Log-Return", fontsize=11)
        ax.set_ylabel("Density", fontsize=11)
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        fig.tight_layout()
        savepath = out_dir / "fig6_price_return_distribution.png"
        fig.savefig(savepath, dpi=150)
        plt.close(fig)
        print(f"Saved {savepath}")
    except Exception as e:
        print(f"WARNING fig6 failed: {e}")


# ── Main ───────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(
        description="Crypto token price dynamics simulator (regime-switching GBM)."
    )
    parser.add_argument("--output", default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    scenarios = MODEL_PROFILE["scenarios"]
    all_scenario_results = []  # list of (scenario_dict, params, paths_sub, paths_daily)

    for idx, scenario in enumerate(scenarios):
        print(f"\n[Scenario {idx}] {scenario['label']}")
        params, paths_sub, paths_daily = run_scenario(scenario, idx)
        all_scenario_results.append((scenario, params, paths_sub, paths_daily))
        print(f"  Ran {len(paths_daily)} paths × {len(paths_daily[0]['days'])} days")

    # ── CSV outputs ──────────────────────────────────────────────────────────
    print("\n--- Writing CSV files ---")
    rows = build_simulation_outputs(all_scenario_results)
    write_simulation_outputs(rows, out_dir)
    write_scenario_summary(all_scenario_results, out_dir)
    write_parameters_used(out_dir)
    write_summary_json(all_scenario_results, out_dir)

    # ── Figures ──────────────────────────────────────────────────────────────
    print("\n--- Generating figures ---")
    fig1_price_timeseries(all_scenario_results, out_dir)
    fig2_volume_bars(all_scenario_results, out_dir)
    fig3_spread_dynamics(all_scenario_results, out_dir)
    fig4_scenario_comparison(all_scenario_results, out_dir)
    fig5_monte_carlo_ensemble(all_scenario_results, out_dir)
    fig6_return_distribution(all_scenario_results, out_dir)

    print("\nSimulation complete.")


if __name__ == "__main__":
    main()