================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 596e45c0-60b1-40f6-9899-f7a7291101cf
    Generated   : 2026-04-26  19:07:19 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Cryptocurrency/Token Price Chart: Buy/Sell Price Dynamics Over 30-Day Period (Feb 14 - Mar 13)

    CATEGORIES
    ----------
    Financial, Signal Processing, Computational Intelligence

    KEYWORDS
    --------
    cryptocurrency price simulation, regime-switching stochastic model, bid-ask spread dynamics, geometric Brownian motion, market microstructure

    ABSTRACT
    --------
    This simulator models the buy/sell price dynamics of a low-value cryptocurrency token over a 30-day trading window, reproducing the characteristic pattern of a sustained bearish drawdown followed by a sharp late-period price spike as observed in the source chart. The core model uses regime-switching geometric Brownian motion (Euler-Maruyama method) with two regimes: a bearish phase with sinusoidal undulations (mu=-0.025/day) and a bullish spike phase (mu=0.18/day), coupled with an Ornstein-Uhlenbeck process for the bid-ask spread. The simulator generates Monte Carlo ensembles of price paths, daily volume bars, spread time series, and return distributions across five distinct market scenarios. Researchers, students, and quantitative analysts can use the synthetic dataset and publication-quality figures to study market microstructure, test trading strategies, and understand regime-switching behavior in volatile assets.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    1773520453418.jpg

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    buy_price, sell_price, spread, volume, regime, time_days

    SCENARIOS  (5 total)
    ---------------------------------
        1. baseline_observed — Reproduces the exact chart: bearish drawdown from Feb 14 to Mar 9 followed by sharp recovery spike to Mar 13, with spread ~0.057 at end.
2. no_recovery_continued_bear — Counterfactual: regime never switches to bullish; prices continue declining through the full 30-day window, showing what would happen without the late spike.
3. early_recovery — Regime switches to bullish earlier (day 15, ~Mar 1), producing a shallower drawdown and earlier but still sharp spike recovery.
4. high_volatility_bear — Increased volatility during drawdown phase, producing more erratic undulations and wider spread variation, representing a more turbulent market.
5. tight_spread — Tighter bid-ask spread (more liquid market), spread_base = 0.02, all other dynamics identical to baseline.

    PARAMETERS
    ----------
    15 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1_price_timeseries, fig2_volume_bars, fig3_spread_dynamics, fig4_scenario_comparison, fig5_monte_carlo_ensemble, fig6_price_return_distribution

    DOMAIN SUMMARY
    --------------
    A 30-day candlestick-style price chart showing buy and sell price tracks for a low-value token/cryptocurrency, exhibiting a characteristic drawdown followed by a sharp recovery spike, with volume bars overlaid at the bottom.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.