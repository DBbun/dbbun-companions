================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : b0e92785-e914-4521-b537-32a8977b8b6f
    Generated   : 2026-04-21  16:24:09 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Falklands War - Wikipedia

    CATEGORIES
    ----------
    Other, Social Sciences

    KEYWORDS
    --------
    military conflict simulation, Falklands War, attrition modelling, force balance, stochastic combat

    ABSTRACT
    --------
    This simulator models the 1982 Falklands War between Argentina and the United Kingdom as a stochastic, phase-structured agent-based conflict simulation. It faithfully represents the documented force compositions (127 UK ships, 42 UK aircraft, 13,000 Argentine garrison, 122 Argentine jets), the sequence of operational phases (diplomatic, naval/air campaign, amphibious landing, ground combat), and key discrete events such as the sinking of ARA General Belgrano (323 killed) and HMS Sheffield (20 killed). The simulator generates synthetic daily records of aircraft remaining, ship losses, territorial control, casualties, morale indices, and prisoner counts across five historically grounded scenarios and Monte Carlo ensembles. Researchers, military historians, and students can use it to explore how changes in air power balance, Exocet effectiveness, task force size, and Argentine fleet posture alter conflict duration and outcome, producing publication-quality figures and reproducible CSV datasets.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Falklands War - Wikipedia.pdf

    SIMULATION BACKEND
    ------------------
    agent_based

    STATE VARIABLES
    ---------------
    uk_ships_remaining, arg_ships_remaining, uk_aircraft_remaining, arg_aircraft_remaining, uk_land_troops, arg_land_troops, uk_casualties_cumulative, arg_casualties_cumulative, arg_pows_cumulative, uk_ships_lost, arg_ships_lost, uk_aircraft_lost, arg_aircraft_lost, territorial_control_pct_uk, diplomatic_pressure_uk, arg_morale_index, uk_morale_index, day

    SCENARIOS  (5 total)
    ---------------------------------
        1. historical_baseline — Reproduces the historical conflict with documented force levels, attrition rates, and event timings as extracted from the source. UK task force of 127 ships, 42 aircraft, vs. 13,000 Argentine garrison and 122 Argentine jets. Conflict ends in UK victory at day 74.
2. argentina_early_air_dominance — Scenario where Argentina fields more effective air power — 180 serviceable jets, higher attrition rate on UK aircraft, and better Exocet hit probability — to test whether UK could maintain its task force under heavier aerial pressure.
3. uk_aew_advantage — Counterfactual where the UK possessed Airborne Early Warning aircraft (noted as a critical deficiency), reducing Argentine aircraft effectiveness and improving UK interception rates significantly.
4. argentina_fleet_stays — Counterfactual where the Argentine fleet does not withdraw after the Belgrano sinking and continues to threaten the British task force from sea, requiring UK nuclear submarines to remain in anti-surface rather than coastal surveillance roles.
5. reduced_uk_task_force — Scenario modelling a smaller UK task force (reflecting the proposed 1981 Defence White Paper cuts) with only 80 ships and 30 combat aircraft, testing whether a reduced force could successfully retake the islands.

    PARAMETERS
    ----------
    35 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7

    DOMAIN SUMMARY
    --------------
    The source covers the 1982 Falklands War between Argentina and the United Kingdom, detailing military operations, force strengths, casualties, naval engagements, air combat, and the strategic/diplomatic context of a 74-day conflict over the Falkland Islands.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.