# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-21T16:24:09.872656Z
# Run ID    : b0e92785-e914-4521-b537-32a8977b8b6f
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Falklands War Conflict Simulator
Based on: 'Falklands War - Wikipedia'

Models the 1982 Falklands War (2 April - 14 June 1982) as a stochastic,
phase-structured agent-based conflict simulation. Faithfully represents
documented force compositions, operational phases, and key discrete events.

Phases:
  - Diplomatic    (days  0-28)
  - Naval/Air     (days 29-48)
  - Amphibious    (days 49-65)
  - Ground        (days 66-74)
"""

import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Any, Optional


# ─────────────────────────────────────────────────────────────────────────────
# MODEL PROFILE
# ─────────────────────────────────────────────────────────────────────────────

MODEL_PROFILE = {
    "title": "Falklands War Conflict Simulator",
    "domain": "Military conflict simulation — 1982 Falklands War",
    "backend": "agent_based",
    "parameters": {
        "conflict_duration_days":         74.0,
        "uk_total_ships":                127.0,
        "arg_peak_garrison":           13000.0,
        "uk_peak_land_force":           7500.0,
        "uk_combat_aircraft_initial":     42.0,
        "arg_serviceable_jets_initial":  122.0,
        "arg_ships_initial":              20.0,
        "arg_air_superiority_fighters":   50.0,
        "arg_strike_aircraft":            72.0,
        "uk_killed_total":               255.0,
        "arg_killed_total":              649.0,
        "uk_wounded_total":              775.0,
        "arg_wounded_total":            1657.0,
        "arg_captured_total":          11313.0,
        "uk_captured_total":             107.0,
        "uk_ships_sunk":                   7.0,
        "arg_ships_sunk":                  4.0,
        "uk_aircraft_lost_total":         34.0,
        "arg_aircraft_lost_total":        75.0,
        "general_belgrano_crew_killed":  323.0,
        "sheffield_crew_killed":          20.0,
        "air_attrition_rate_arg":        0.014,
        "air_attrition_rate_uk":         0.006,
        "land_attrition_rate_arg":       0.008,
        "land_attrition_rate_uk":        0.004,
        "naval_engagement_probability":  0.05,
        "exocet_hit_probability":         0.40,
        "sea_harrier_kill_prob":          0.25,
        "arg_naval_withdrawal_day":        3.0,
        "uk_TEZ_start_day":               28.0,
        "amphibious_landing_day":         19.0,
        "south_georgia_recapture_day":    23.0,
        "black_buck_day":                 29.0,
        "morale_decay_rate_arg":          0.01,
        "territorial_gain_rate_uk":        1.5,
        "diplomatic_support_boost_un502":  0.20,
    },
    "scenarios": [
        {
            "label": "historical_baseline",
            "description": "Reproduces the historical conflict with documented force levels.",
            "param_overrides": {
                "uk_combat_aircraft_initial":    42.0,
                "arg_serviceable_jets_initial": 122.0,
                "arg_peak_garrison":          13000.0,
                "uk_peak_land_force":          7500.0,
                "air_attrition_rate_arg":       0.014,
                "air_attrition_rate_uk":        0.006,
                "exocet_hit_probability":        0.40,
            }
        },
        {
            "label": "argentina_early_air_dominance",
            "description": "Argentina fields 180 serviceable jets, higher UK attrition, better Exocet hit probability.",
            "param_overrides": {
                "arg_serviceable_jets_initial": 180.0,
                "air_attrition_rate_uk":        0.012,
                "air_attrition_rate_arg":       0.010,
                "exocet_hit_probability":        0.60,
                "uk_combat_aircraft_initial":    42.0,
            }
        },
        {
            "label": "uk_aew_advantage",
            "description": "UK possesses Airborne Early Warning aircraft, reducing Argentine effectiveness.",
            "param_overrides": {
                "air_attrition_rate_arg":   0.025,
                "air_attrition_rate_uk":    0.003,
                "sea_harrier_kill_prob":     0.40,
                "exocet_hit_probability":    0.20,
            }
        },
        {
            "label": "argentina_fleet_stays",
            "description": "Argentine fleet does not withdraw after Belgrano sinking.",
            "param_overrides": {
                "arg_naval_withdrawal_day":        999.0,
                "naval_engagement_probability":    0.12,
                "uk_ships_sunk":                   12.0,
                "arg_ships_sunk":                   6.0,
            }
        },
        {
            "label": "reduced_uk_task_force",
            "description": "Smaller UK task force reflecting 1981 Defence White Paper cuts.",
            "param_overrides": {
                "uk_total_ships":             80.0,
                "uk_combat_aircraft_initial": 30.0,
                "uk_peak_land_force":       5000.0,
                "territorial_gain_rate_uk":   0.9,
            }
        },
    ],
}

# Parameter metadata for parameters_used.csv
PARAMETER_META = [
    ("conflict_duration_days",         "days",           "extracted", "Total duration of the conflict from 2 April to 14 June 1982"),
    ("uk_total_ships",                 "count",          "extracted", "Total UK task force ships: 43 Royal Navy + 22 RFA + 62 merchant"),
    ("arg_peak_garrison",              "count",          "extracted", "Peak Argentine land force garrison on the Falkland Islands"),
    ("uk_peak_land_force",             "count",          "extracted", "Approximate peak British land forces deployed"),
    ("uk_combat_aircraft_initial",     "count",          "extracted", "Initial UK combat aircraft: 28 Sea Harriers + 6 Harrier GR.3s + 8 reserve"),
    ("arg_serviceable_jets_initial",   "count",          "extracted", "Approximate Argentine serviceable jet fighters at start"),
    ("arg_ships_initial",              "count",          "extracted", "Initial Argentine naval vessels"),
    ("arg_air_superiority_fighters",   "count",          "extracted", "Argentine aircraft used as air superiority fighters"),
    ("arg_strike_aircraft",            "count",          "extracted", "Argentine jets used as strike aircraft"),
    ("uk_killed_total",                "count",          "extracted", "Total UK military personnel killed"),
    ("arg_killed_total",               "count",          "extracted", "Total Argentine military personnel killed"),
    ("uk_wounded_total",               "count",          "extracted", "Total UK military personnel wounded"),
    ("arg_wounded_total",              "count",          "extracted", "Total Argentine military personnel wounded"),
    ("arg_captured_total",             "count",          "extracted", "Total Argentine personnel captured or surrendered"),
    ("uk_captured_total",              "count",          "extracted", "Total UK personnel captured"),
    ("uk_ships_sunk",                  "count",          "extracted", "UK major vessels sunk or lost"),
    ("arg_ships_sunk",                 "count",          "extracted", "Key Argentine vessels sunk"),
    ("uk_aircraft_lost_total",         "count",          "extracted", "Total UK aircraft lost during conflict"),
    ("arg_aircraft_lost_total",        "count",          "extracted", "Approximate total Argentine aircraft lost"),
    ("general_belgrano_crew_killed",   "count",          "extracted", "Crew killed in sinking of ARA General Belgrano"),
    ("sheffield_crew_killed",          "count",          "extracted", "UK crew killed when HMS Sheffield was hit"),
    ("air_attrition_rate_arg",         "per day",        "assumed",   "Daily fractional attrition rate of Argentine aircraft"),
    ("air_attrition_rate_uk",          "per day",        "assumed",   "Daily fractional attrition rate of UK aircraft"),
    ("land_attrition_rate_arg",        "per day",        "assumed",   "Daily fractional attrition rate of Argentine land forces"),
    ("land_attrition_rate_uk",         "per day",        "assumed",   "Daily fractional attrition rate of UK land forces"),
    ("naval_engagement_probability",   "per day",        "assumed",   "Base daily probability of a significant naval engagement"),
    ("exocet_hit_probability",         "probability",    "assumed",   "Probability that a fired Exocet missile successfully hits"),
    ("sea_harrier_kill_prob",          "per engagement", "assumed",   "Probability a Sea Harrier kills an Argentine aircraft per engagement"),
    ("arg_naval_withdrawal_day",       "days after Belgrano", "extracted", "Argentine fleet withdrew to port after Belgrano sinking"),
    ("uk_TEZ_start_day",               "days",           "extracted", "Day when 200nm Total Exclusion Zone was enforced"),
    ("amphibious_landing_day",         "days",           "assumed",   "Approximate day British amphibious forces began landing"),
    ("south_georgia_recapture_day",    "days",           "extracted", "Day South Georgia was recaptured"),
    ("black_buck_day",                 "days",           "extracted", "Day of first Black Buck raid on Stanley airfield"),
    ("morale_decay_rate_arg",          "per day",        "assumed",   "Daily decay rate of Argentine morale index"),
    ("territorial_gain_rate_uk",       "percent per day","assumed",   "Daily rate of UK territorial gain after amphibious landing"),
    ("diplomatic_support_boost_un502", "a.u.",           "extracted", "Boost to UK diplomatic support following UN Resolution 502"),
]


# ─────────────────────────────────────────────────────────────────────────────
# SIMULATION CORE
# ─────────────────────────────────────────────────────────────────────────────

def get_phase(day: int) -> str:
    if day < 29:
        return 'diplomatic'
    elif day < 49:
        return 'naval_air'
    elif day < 66:
        return 'amphibious'
    else:
        return 'ground'


def build_params(scenario_overrides: Dict[str, Any]) -> Dict[str, Any]:
    """Build a full parameter dict from defaults + scenario overrides."""
    params = dict(MODEL_PROFILE["parameters"])
    params.update(scenario_overrides)
    return params


def run_simulation(params: Dict[str, Any], seed: int = 0) -> Tuple[List[Dict], int]:
    """
    Run a single Monte Carlo simulation of the Falklands War.
    Returns (list_of_daily_records, conflict_end_day).
    """
    rng = np.random.default_rng(seed)

    # Local copy so we don't mutate the shared params dict
    p = dict(params)

    # State initialisation
    state = {
        'uk_ships_remaining':          float(p['uk_total_ships']),
        'arg_ships_remaining':         float(p.get('arg_ships_initial', 20.0)),
        'uk_aircraft_remaining':       float(p['uk_combat_aircraft_initial']),
        'arg_aircraft_remaining':      float(p['arg_serviceable_jets_initial']),
        'uk_land_troops':              0.0,
        'arg_land_troops':             float(p['arg_peak_garrison']),
        'uk_casualties_cumulative':    0.0,
        'arg_casualties_cumulative':   0.0,
        'arg_pows_cumulative':         0.0,
        'uk_ships_lost':               0.0,
        'arg_ships_lost':              0.0,
        'uk_aircraft_lost':            0.0,
        'arg_aircraft_lost':           0.0,
        'territorial_control_pct_uk':  0.0,
        'diplomatic_pressure_uk':      0.30,
        'arg_morale_index':            1.0,
        'uk_morale_index':             1.0,
    }

    # Range clamps
    CLAMPS = {
        'uk_ships_remaining':         (0.0, float(p['uk_total_ships'])),
        'arg_ships_remaining':        (0.0, 20.0),
        'uk_aircraft_remaining':      (0.0, float(p['uk_combat_aircraft_initial'])),
        'arg_aircraft_remaining':     (0.0, float(p['arg_serviceable_jets_initial'])),
        'uk_land_troops':             (0.0, 10000.0),
        'arg_land_troops':            (0.0, 13000.0),
        'uk_casualties_cumulative':   (0.0, 500.0),
        'arg_casualties_cumulative':  (0.0, 1000.0),
        'arg_pows_cumulative':        (0.0, 12000.0),
        'uk_ships_lost':              (0.0, 20.0),
        'arg_ships_lost':             (0.0, 10.0),
        'uk_aircraft_lost':           (0.0, 42.0),
        'arg_aircraft_lost':          (0.0, 122.0),
        'territorial_control_pct_uk': (0.0, 100.0),
        'diplomatic_pressure_uk':     (0.0, 1.0),
        'arg_morale_index':           (0.0, 1.0),
        'uk_morale_index':            (0.0, 1.0),
    }

    conflict_end_day = int(p['conflict_duration_days'])
    naval_engagement_prob = float(p['naval_engagement_probability'])
    belgrano_sunk = False
    fleet_withdrawn = False
    records = []

    EVENT_DAYS = {1, 23, 29, 31, 33, 49, 74}

    for day in range(int(p['conflict_duration_days']) + 1):
        phase = get_phase(day)

        # ── DIPLOMATIC PHASE ──────────────────────────────────────────────
        if phase == 'diplomatic':
            if day == 1:
                state['diplomatic_pressure_uk'] = min(1.0,
                    state['diplomatic_pressure_uk'] + p['diplomatic_support_boost_un502'])
            state['arg_morale_index'] *= (1.0 - p['morale_decay_rate_arg'] * 0.3)
            if day >= 15:
                state['uk_land_troops'] = min(p['uk_peak_land_force'],
                    state['uk_land_troops'] + p['uk_peak_land_force'] / 20.0)

        # ── NAVAL/AIR CAMPAIGN PHASE ──────────────────────────────────────
        elif phase == 'naval_air':
            # Argentine air attrition
            eff_arg_rate = float(p['air_attrition_rate_arg']) * state['arg_morale_index']
            n_arg = max(0, int(state['arg_aircraft_remaining']))
            arg_ac_loss = int(rng.binomial(n_arg, min(0.99, eff_arg_rate)))
            state['arg_aircraft_remaining'] = max(0.0, state['arg_aircraft_remaining'] - arg_ac_loss)
            state['arg_aircraft_lost'] += arg_ac_loss
            state['arg_casualties_cumulative'] += arg_ac_loss * float(rng.uniform(0.8, 1.5))

            # UK aircraft attrition
            n_uk = max(0, int(state['uk_aircraft_remaining']))
            uk_ac_loss = int(rng.binomial(n_uk, min(0.99, float(p['air_attrition_rate_uk']))))
            state['uk_aircraft_remaining'] = max(0.0, state['uk_aircraft_remaining'] - uk_ac_loss)
            state['uk_aircraft_lost'] += uk_ac_loss
            state['uk_casualties_cumulative'] += uk_ac_loss * float(rng.uniform(0.5, 1.2))

            # Naval engagement events
            if not fleet_withdrawn:
                if float(rng.random()) < naval_engagement_prob:
                    if float(rng.random()) < float(p['exocet_hit_probability']):
                        ships_hit = int(rng.integers(1, 3))
                        state['uk_ships_remaining'] = max(0.0, state['uk_ships_remaining'] - ships_hit)
                        state['uk_ships_lost'] += ships_hit
                        state['uk_casualties_cumulative'] += ships_hit * float(rng.uniform(15.0, 30.0))
                        if day == 31:
                            state['uk_casualties_cumulative'] += float(p['sheffield_crew_killed'])

            # Belgrano event: day 31
            if day == 31 and not belgrano_sunk:
                belgrano_sunk = True
                state['arg_casualties_cumulative'] += float(p['general_belgrano_crew_killed'])
                state['arg_ships_remaining'] = max(0.0, state['arg_ships_remaining'] - 1.0)
                state['arg_ships_lost'] += 1.0
                # Fleet withdrawal check
                if float(p['arg_naval_withdrawal_day']) < 900:
                    fleet_withdrawn = True
                    naval_engagement_prob *= 0.1

            # Morale impacts
            loss_ratio = state['arg_aircraft_lost'] / max(1.0, float(p['arg_serviceable_jets_initial']))
            state['arg_morale_index'] = max(0.05,
                state['arg_morale_index'] - p['morale_decay_rate_arg'] * (1.0 + loss_ratio))
            uk_ship_ratio = state['uk_ships_lost'] / max(1.0, float(p['uk_total_ships']))
            state['uk_morale_index'] = max(0.1, min(1.0,
                state['uk_morale_index'] - 0.003 * uk_ship_ratio))

        # ── AMPHIBIOUS LANDING PHASE ──────────────────────────────────────
        elif phase == 'amphibious':
            state['uk_land_troops'] = min(p['uk_peak_land_force'],
                state['uk_land_troops'] + p['uk_peak_land_force'] * 0.05)

            morale_factor = state['uk_morale_index'] / max(0.05, state['arg_morale_index'])
            gain = float(p['territorial_gain_rate_uk']) * morale_factor
            gain = max(0.01, gain)
            state['territorial_control_pct_uk'] = min(60.0,
                state['territorial_control_pct_uk'] + float(rng.normal(gain, gain * 0.2)))

            arg_rate = float(p['land_attrition_rate_arg']) * (1.0 - state['arg_morale_index'] * 0.5)
            arg_rate = max(0.0, min(0.99, arg_rate))
            n_arg_land = max(0, int(state['arg_land_troops']))
            arg_land_loss = int(rng.binomial(n_arg_land, arg_rate))

            uk_rate = max(0.0, min(0.99, float(p['land_attrition_rate_uk'])))
            n_uk_land = max(0, int(state['uk_land_troops']))
            uk_land_loss = int(rng.binomial(n_uk_land, uk_rate))

            state['arg_land_troops'] = max(0.0, state['arg_land_troops'] - arg_land_loss)
            state['uk_land_troops'] = max(0.0, state['uk_land_troops'] - uk_land_loss)
            state['arg_casualties_cumulative'] += arg_land_loss * float(rng.uniform(0.3, 0.6))
            state['uk_casualties_cumulative'] += uk_land_loss * float(rng.uniform(0.4, 0.8))
            state['arg_pows_cumulative'] += arg_land_loss * float(rng.uniform(1.5, 3.0))

            state['arg_morale_index'] = max(0.05,
                state['arg_morale_index'] - p['morale_decay_rate_arg'] * 1.5)

            # Air attrition continues at lower rate
            n_arg2 = max(0, int(state['arg_aircraft_remaining']))
            arg_ac_loss2 = int(rng.binomial(n_arg2,
                min(0.99, float(p['air_attrition_rate_arg']) * 0.5)))
            state['arg_aircraft_remaining'] = max(0.0, state['arg_aircraft_remaining'] - arg_ac_loss2)
            state['arg_aircraft_lost'] += arg_ac_loss2

        # ── GROUND COMBAT PHASE ───────────────────────────────────────────
        elif phase == 'ground':
            gain = float(p['territorial_gain_rate_uk']) * 2.5 * state['uk_morale_index']
            gain = max(0.01, gain)
            state['territorial_control_pct_uk'] = min(100.0,
                state['territorial_control_pct_uk'] + float(rng.normal(gain, gain * 0.15)))

            arg_rate2 = float(p['land_attrition_rate_arg']) * 2.0 * (1.0 - state['arg_morale_index'])
            arg_rate2 = max(0.0, min(0.99, arg_rate2))
            n_arg_g = max(0, int(state['arg_land_troops']))
            arg_land_loss = int(rng.binomial(n_arg_g, arg_rate2))

            uk_rate2 = max(0.0, min(0.99, float(p['land_attrition_rate_uk']) * 0.8))
            n_uk_g = max(0, int(state['uk_land_troops']))
            uk_land_loss = int(rng.binomial(n_uk_g, uk_rate2))

            state['arg_land_troops'] = max(0.0, state['arg_land_troops'] - arg_land_loss)
            state['uk_land_troops'] = max(0.0, state['uk_land_troops'] - uk_land_loss)
            state['arg_casualties_cumulative'] += arg_land_loss * float(rng.uniform(0.2, 0.4))
            state['uk_casualties_cumulative'] += uk_land_loss * float(rng.uniform(0.3, 0.6))

            new_pows = arg_land_loss * float(rng.uniform(3.0, 6.0))
            state['arg_pows_cumulative'] = min(float(p['arg_captured_total']),
                state['arg_pows_cumulative'] + new_pows)

            state['arg_morale_index'] = max(0.01,
                state['arg_morale_index'] - p['morale_decay_rate_arg'] * 3.0)

            # Termination condition
            if state['territorial_control_pct_uk'] >= 95.0 or state['arg_morale_index'] <= 0.05:
                conflict_end_day = day
                state['territorial_control_pct_uk'] = 100.0
                state['arg_pows_cumulative'] = min(float(p['arg_captured_total']),
                    state['arg_pows_cumulative'] + state['arg_land_troops'])

        # ── Clip all state variables ──────────────────────────────────────
        for k, (lo, hi) in CLAMPS.items():
            state[k] = float(max(lo, min(hi, state[k])))

        # ── Record row ────────────────────────────────────────────────────
        row = {
            'day':   day,
            'phase': phase,
            'event_flag': 1 if day in EVENT_DAYS else 0,
        }
        row.update({k: state[k] for k in state})
        records.append(row)

        # Break if conflict fully resolved
        if state['territorial_control_pct_uk'] >= 100.0 and phase == 'ground':
            break

    return records, conflict_end_day


# ─────────────────────────────────────────────────────────────────────────────
# SCENARIO RUNNER
# ─────────────────────────────────────────────────────────────────────────────

N_RUNS = 100  # Monte Carlo runs per scenario


def run_scenario(scenario: Dict[str, Any], scenario_index: int) -> Tuple[List[Dict], List[int]]:
    """
    Run N_RUNS Monte Carlo simulations for a scenario.
    Returns (all_records, end_days_list).
    """
    np.random.seed(scenario_index)  # Fix scenario-level seed for reproducibility
    params = build_params(scenario['param_overrides'])
    label = scenario['label']

    all_records = []
    end_days = []

    for run_id in range(N_RUNS):
        seed = scenario_index * 10000 + run_id
        records, end_day = run_simulation(params, seed=seed)
        for row in records:
            row['scenario'] = label
            row['run_id'] = run_id
        all_records.extend(records)
        end_days.append(end_day)

    return all_records, end_days


# ─────────────────────────────────────────────────────────────────────────────
# AGGREGATION HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def compute_scenario_summary(all_scenario_records: Dict[str, List[Dict]]) -> List[Dict]:
    """Compute aggregate metrics per scenario for scenario_summary.csv."""
    summary_rows = []
    state_vars = [
        'uk_ships_remaining', 'arg_ships_remaining',
        'uk_aircraft_remaining', 'arg_aircraft_remaining',
        'uk_land_troops', 'arg_land_troops',
        'uk_casualties_cumulative', 'arg_casualties_cumulative',
        'arg_pows_cumulative', 'uk_ships_lost', 'arg_ships_lost',
        'uk_aircraft_lost', 'arg_aircraft_lost',
        'territorial_control_pct_uk', 'diplomatic_pressure_uk',
        'arg_morale_index', 'uk_morale_index',
    ]

    for scenario_label, records in all_scenario_records.items():
        if not records:
            continue
        row = {'scenario': scenario_label}
        for var in state_vars:
            vals = np.array([r[var] for r in records if var in r], dtype=float)
            if len(vals) > 0:
                row[f'{var}_mean'] = float(np.mean(vals))
                row[f'{var}_std']  = float(np.std(vals))
                row[f'{var}_min']  = float(np.min(vals))
                row[f'{var}_max']  = float(np.max(vals))
            else:
                row[f'{var}_mean'] = 0.0
                row[f'{var}_std']  = 0.0
                row[f'{var}_min']  = 0.0
                row[f'{var}_max']  = 0.0
        summary_rows.append(row)
    return summary_rows


def get_median_run_records(records: List[Dict], scenario_label: str) -> List[Dict]:
    """Get records from the median run (run closest to median end day)."""
    run_ids = sorted(set(r['run_id'] for r in records))
    # Use run_id 0 as representative median
    median_records = [r for r in records if r['run_id'] == 0 and r['scenario'] == scenario_label]
    return sorted(median_records, key=lambda r: r['day'])


# ─────────────────────────────────────────────────────────────────────────────
# FIGURE GENERATION
# ─────────────────────────────────────────────────────────────────────────────

SCENARIO_COLORS = {
    'historical_baseline':          '#1f77b4',
    'argentina_early_air_dominance':'#d62728',
    'uk_aew_advantage':             '#2ca02c',
    'argentina_fleet_stays':        '#ff7f0e',
    'reduced_uk_task_force':        '#9467bd',
}


def fig1_aircraft_remaining(all_scenario_records: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 1: Combat aircraft remaining over conflict duration."""
    try:
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        ax_arg, ax_uk = axes

        for sc_label, records in all_scenario_records.items():
            med = get_median_run_records(records, sc_label)
            if not med:
                continue
            days = np.array([r['day'] for r in med])
            arg_ac = np.array([r['arg_aircraft_remaining'] for r in med])
            uk_ac  = np.array([r['uk_aircraft_remaining']  for r in med])
            assert len(days) == len(arg_ac) == len(uk_ac), "Array length mismatch fig1"
            color = SCENARIO_COLORS.get(sc_label, 'gray')
            ax_arg.plot(days, arg_ac, color=color, label=sc_label.replace('_', ' '), linewidth=2)
            ax_uk.plot( days, uk_ac,  color=color, label=sc_label.replace('_', ' '), linewidth=2)

        for ax, title, ylab in [
            (ax_arg, 'Argentine Combat Aircraft Remaining', 'Aircraft (count)'),
            (ax_uk,  'UK Combat Aircraft Remaining',        'Aircraft (count)'),
        ]:
            ax.set_xlabel('Day of Conflict')
            ax.set_ylabel(ylab)
            ax.set_title(title)
            ax.axvline(x=29, color='gray', linestyle='--', alpha=0.5, label='Air campaign start (day 29)')
            ax.axvline(x=49, color='black', linestyle=':', alpha=0.5, label='Amphibious landing (day 49)')
            ax.legend(fontsize=7, loc='upper right')
            ax.grid(True, alpha=0.3)

        fig.suptitle('Combat Aircraft Remaining Over the Conflict Duration', fontsize=13, fontweight='bold')
        plt.tight_layout()
        fig.savefig(output_dir / 'fig1_aircraft_remaining.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig1_aircraft_remaining.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def fig2_casualties(all_scenario_records: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 2: Cumulative military casualties over time."""
    try:
        fig, ax = plt.subplots(figsize=(12, 7))

        for sc_label, records in all_scenario_records.items():
            med = get_median_run_records(records, sc_label)
            if not med:
                continue
            days    = np.array([r['day'] for r in med])
            uk_cas  = np.array([r['uk_casualties_cumulative']  for r in med])
            arg_cas = np.array([r['arg_casualties_cumulative'] for r in med])
            assert len(days) == len(uk_cas) == len(arg_cas), "Array length mismatch fig2"
            color = SCENARIO_COLORS.get(sc_label, 'gray')
            ax.plot(days, uk_cas,  color=color, linewidth=2, linestyle='-',
                    label=f'UK — {sc_label.replace("_", " ")}')
            ax.plot(days, arg_cas, color=color, linewidth=2, linestyle='--',
                    label=f'ARG — {sc_label.replace("_", " ")}')

        ax.axvline(x=31, color='red', linestyle=':', alpha=0.7, label='Belgrano / Sheffield (day 31)')
        ax.axvline(x=49, color='blue', linestyle=':', alpha=0.7, label='Amphibious landing (day 49)')
        ax.set_xlabel('Day of Conflict')
        ax.set_ylabel('Cumulative Personnel Killed (count)')
        ax.set_title('Cumulative Military Casualties Over Time: UK vs. Argentina', fontweight='bold')
        ax.legend(fontsize=6, loc='upper left', ncol=2)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig2_casualties.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig2_casualties.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def fig3_territorial_control(all_scenario_records: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 3: UK territorial control over time."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for sc_label, records in all_scenario_records.items():
            med = get_median_run_records(records, sc_label)
            if not med:
                continue
            days    = np.array([r['day'] for r in med])
            control = np.array([r['territorial_control_pct_uk'] for r in med])
            assert len(days) == len(control), "Array length mismatch fig3"
            color = SCENARIO_COLORS.get(sc_label, 'gray')
            ax.plot(days, control, color=color, linewidth=2.5,
                    label=sc_label.replace('_', ' '))

        ax.axvline(x=23, color='green',  linestyle=':', alpha=0.8, label='South Georgia recaptured (day 23)')
        ax.axvline(x=49, color='navy',   linestyle=':', alpha=0.8, label='San Carlos landing (day 49)')
        ax.axvline(x=74, color='purple', linestyle=':', alpha=0.8, label='Stanley falls (day 74)')
        ax.set_xlabel('Day of Conflict')
        ax.set_ylabel('UK Territorial Control (%)')
        ax.set_title('UK Territorial Control of the Falkland Islands Over Time', fontweight='bold')
        ax.set_ylim(0, 105)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig3_territorial_control.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig3_territorial_control.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def fig4_arg_morale(all_scenario_records: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 4: Argentine morale index over conflict."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for sc_label, records in all_scenario_records.items():
            med = get_median_run_records(records, sc_label)
            if not med:
                continue
            days   = np.array([r['day'] for r in med])
            morale = np.array([r['arg_morale_index'] for r in med])
            assert len(days) == len(morale), "Array length mismatch fig4"
            color = SCENARIO_COLORS.get(sc_label, 'gray')
            ax.plot(days, morale, color=color, linewidth=2.5,
                    label=sc_label.replace('_', ' '))

        ax.axvline(x=31, color='red',   linestyle=':', alpha=0.8, label='Belgrano sinking (day 31)')
        ax.axvline(x=49, color='blue',  linestyle=':', alpha=0.8, label='Amphibious landing (day 49)')
        ax.axvline(x=66, color='black', linestyle=':', alpha=0.8, label='Ground phase (day 66)')
        ax.axhline(y=0.1, color='orange', linestyle='--', alpha=0.7, label='Surrender threshold (0.10)')
        ax.set_xlabel('Day of Conflict')
        ax.set_ylabel('Argentine Morale Index (a.u.)')
        ax.set_title('Argentine Military Morale Index Over the Conflict', fontweight='bold')
        ax.set_ylim(0, 1.05)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig4_arg_morale.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig4_arg_morale.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def fig5_scatter_losses(all_scenario_records: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 5: Scatter plot — Argentine aircraft lost vs UK ships lost."""
    try:
        fig, ax = plt.subplots(figsize=(10, 7))

        for sc_label, records in all_scenario_records.items():
            run_ids = sorted(set(r['run_id'] for r in records))
            arg_lost_list = []
            uk_ship_list  = []
            for rid in run_ids:
                run_recs = [r for r in records if r['run_id'] == rid]
                if not run_recs:
                    continue
                last = max(run_recs, key=lambda r: r['day'])
                arg_lost_list.append(last['arg_aircraft_lost'])
                uk_ship_list.append(last['uk_ships_lost'])

            if not arg_lost_list:
                continue

            x_arr = np.array(arg_lost_list, dtype=float)
            y_arr = np.array(uk_ship_list,  dtype=float)
            assert len(x_arr) == len(y_arr), "Array length mismatch fig5"

            color = SCENARIO_COLORS.get(sc_label, 'gray')
            ax.scatter(x_arr, y_arr, color=color, alpha=0.5, s=30,
                       label=sc_label.replace('_', ' '))

            # 1-sigma ellipse
            if len(x_arr) > 2:
                try:
                    from matplotlib.patches import Ellipse
                    mx, my = np.mean(x_arr), np.mean(y_arr)
                    sx, sy = np.std(x_arr), np.std(y_arr)
                    ellipse = Ellipse((mx, my), width=2*sx, height=2*sy,
                                      edgecolor=color, facecolor='none',
                                      linewidth=1.5, linestyle='--', alpha=0.8)
                    ax.add_patch(ellipse)
                except Exception:
                    pass

        ax.set_xlabel('Total Argentine Aircraft Lost (count)')
        ax.set_ylabel('Total UK Ships Lost (count)')
        ax.set_title('Argentine Aircraft Losses vs. UK Ship Losses Across Scenarios', fontweight='bold')
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig5_scatter_losses.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig5_scatter_losses.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def fig6_heatmap_sweep(output_dir: Path) -> None:
    """Fig 6: Heatmap — UK ships lost as function of Exocet accuracy and Argentine fleet size."""
    try:
        exocet_probs  = np.linspace(0.1, 0.9, 9)
        arg_jet_inits = np.linspace(60, 180, 7)
        MC_RUNS       = 20

        base_params = build_params({})
        heat = np.zeros((len(arg_jet_inits), len(exocet_probs)), dtype=float)

        for i, arg_jets in enumerate(arg_jet_inits):
            for j, exo_prob in enumerate(exocet_probs):
                ships_lost_vals = []
                for run_id in range(MC_RUNS):
                    sweep_params = dict(base_params)
                    sweep_params['arg_serviceable_jets_initial'] = float(arg_jets)
                    sweep_params['exocet_hit_probability']       = float(exo_prob)
                    seed = 99000 + i * 100 + j * 10 + run_id
                    records, _ = run_simulation(sweep_params, seed=seed)
                    if records:
                        last = records[-1]
                        ships_lost_vals.append(last['uk_ships_lost'])
                heat[i, j] = np.mean(ships_lost_vals) if ships_lost_vals else 0.0

        fig, ax = plt.subplots(figsize=(10, 7))
        im = ax.imshow(heat, aspect='auto', origin='lower',
                       extent=[exocet_probs[0], exocet_probs[-1],
                               arg_jet_inits[0], arg_jet_inits[-1]],
                       cmap='YlOrRd', interpolation='bilinear')
        plt.colorbar(im, ax=ax, label='Mean UK Ships Lost')

        # Historical point
        ax.scatter([0.40], [122], marker='*', color='white', s=200,
                   zorder=5, label='Historical parameters')

        # Contour at 10 ships lost
        try:
            cs = ax.contour(exocet_probs, arg_jet_inits, heat,
                            levels=[10.0], colors='cyan', linewidths=2)
            ax.clabel(cs, fmt='%.0f ships', fontsize=9)
        except Exception:
            pass

        ax.set_xlabel('Exocet Hit Probability')
        ax.set_ylabel('Argentine Serviceable Jets (initial count)')
        ax.set_title('UK Ships Lost: Exocet Accuracy vs. Argentine Air Fleet Size', fontweight='bold')
        ax.legend(fontsize=9)
        plt.tight_layout()
        fig.savefig(output_dir / 'fig6_heatmap_sweep.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig6_heatmap_sweep.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def fig7_histogram_end_days(output_dir: Path) -> None:
    """Fig 7: Histogram of conflict end day across 500 Monte Carlo runs."""
    try:
        MC_500 = 500
        baseline_params = build_params(
            MODEL_PROFILE['scenarios'][0]['param_overrides'])
        aad_params      = build_params(
            MODEL_PROFILE['scenarios'][1]['param_overrides'])

        baseline_ends = []
        aad_ends      = []

        for run_id in range(MC_500):
            seed_b = 50000 + run_id
            _, end_b = run_simulation(baseline_params, seed=seed_b)
            baseline_ends.append(end_b)

            seed_a = 60000 + run_id
            _, end_a = run_simulation(aad_params, seed=seed_a)
            aad_ends.append(end_a)

        baseline_arr = np.array(baseline_ends, dtype=float)
        aad_arr      = np.array(aad_ends, dtype=float)

        assert len(baseline_arr) == MC_500, "Baseline end-days array wrong length"
        assert len(aad_arr)      == MC_500, "AAD end-days array wrong length"

        fig, ax = plt.subplots(figsize=(12, 6))
        bins = np.arange(60, 80, 1)
        ax.hist(baseline_arr, bins=bins, color='#1f77b4', alpha=0.7, density=False,
                label=f'Historical baseline (n={MC_500})')
        ax.hist(aad_arr, bins=bins, color='#d62728', alpha=0.5, density=False,
                label=f'Argentina early air dominance (n={MC_500})')
        ax.axvline(x=74, color='red', linestyle='--', linewidth=2, label='Historical end day (74)')
        ax.set_xlabel('Conflict End Day')
        ax.set_ylabel('Frequency (runs)')
        ax.set_title('Distribution of Simulated Conflict End Day Across 500 Monte Carlo Runs',
                     fontweight='bold')
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        # Annotate statistics
        ax.text(0.02, 0.95, f'Baseline: mean={np.mean(baseline_arr):.1f}, std={np.std(baseline_arr):.1f}',
                transform=ax.transAxes, fontsize=9, verticalalignment='top', color='#1f77b4')
        ax.text(0.02, 0.88, f'AAD: mean={np.mean(aad_arr):.1f}, std={np.std(aad_arr):.1f}',
                transform=ax.transAxes, fontsize=9, verticalalignment='top', color='#d62728')

        plt.tight_layout()
        fig.savefig(output_dir / 'fig7_histogram_end_days.png', dpi=150, bbox_inches='tight')
        plt.close(fig)
        print("Saved fig7_histogram_end_days.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# CSV / JSON WRITERS
# ─────────────────────────────────────────────────────────────────────────────

DATASET_SCHEMA = [
    "scenario", "run_id", "day",
    "uk_ships_remaining", "arg_ships_remaining",
    "uk_aircraft_remaining", "arg_aircraft_remaining",
    "uk_land_troops", "arg_land_troops",
    "uk_casualties_cumulative", "arg_casualties_cumulative",
    "arg_pows_cumulative",
    "uk_ships_lost", "arg_ships_lost",
    "uk_aircraft_lost", "arg_aircraft_lost",
    "territorial_control_pct_uk", "diplomatic_pressure_uk",
    "arg_morale_index", "uk_morale_index",
    "phase", "event_flag",
]


def write_simulation_outputs(all_records: List[Dict], output_dir: Path) -> None:
    """Write simulation_outputs.csv — full time-series for all scenarios."""
    try:
        if not all_records:
            print("WARNING: No records to write to simulation_outputs.csv")
            return
        fpath = output_dir / 'simulation_outputs.csv'
        with open(fpath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA, extrasaction='ignore')
            writer.writeheader()
            for row in all_records:
                writer.writerow(row)
        print(f"Saved simulation_outputs.csv ({len(all_records)} rows)")
    except Exception as e:
        print(f"WARNING: simulation_outputs.csv write failed: {e}")


def write_scenario_summary(summary_rows: List[Dict], output_dir: Path) -> None:
    """Write scenario_summary.csv — one row per scenario."""
    try:
        if not summary_rows:
            print("WARNING: No summary rows to write.")
            return
        fpath = output_dir / 'scenario_summary.csv'
        fieldnames = list(summary_rows[0].keys())
        with open(fpath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for row in summary_rows:
                writer.writerow(row)
        print(f"Saved scenario_summary.csv ({len(summary_rows)} rows)")
    except Exception as e:
        print(f"WARNING: scenario_summary.csv write failed: {e}")


def write_parameters_used(output_dir: Path) -> None:
    """Write parameters_used.csv — one row per parameter."""
    try:
        fpath = output_dir / 'parameters_used.csv'
        params = MODEL_PROFILE['parameters']
        with open(fpath, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['name', 'value', 'unit', 'source', 'description'])
            writer.writeheader()
            for name, unit, source, description in PARAMETER_META:
                writer.writerow({
                    'name':        name,
                    'value':       params.get(name, ''),
                    'unit':        unit,
                    'source':      source,
                    'description': description,
                })
        print("Saved parameters_used.csv")
    except Exception as e:
        print(f"WARNING: parameters_used.csv write failed: {e}")


def write_summary_json(
    all_scenario_records: Dict[str, List[Dict]],
    scenario_end_days: Dict[str, List[int]],
    output_dir: Path
) -> None:
    """Write summary.json with key aggregate metrics."""
    try:
        summary = {}
        for sc_label, records in all_scenario_records.items():
            if not records:
                continue
            # Final state of run_0
            run0 = [r for r in records if r['run_id'] == 0]
            last = max(run0, key=lambda r: r['day']) if run0 else {}
            ends = scenario_end_days.get(sc_label, [74])
            summary[sc_label] = {
                'mean_conflict_end_day':      float(np.mean(ends)),
                'std_conflict_end_day':       float(np.std(ends)),
                'mean_uk_ships_lost':         float(np.mean([
                    max((r['uk_ships_lost'] for r in records if r['run_id'] == rid), default=0)
                    for rid in set(r['run_id'] for r in records)
                ])),
                'mean_arg_aircraft_lost':     float(np.mean([
                    max((r['arg_aircraft_lost'] for r in records if r['run_id'] == rid), default=0)
                    for rid in set(r['run_id'] for r in records)
                ])),
                'final_territorial_control_run0': float(last.get('territorial_control_pct_uk', 0)),
                'final_arg_morale_run0':          float(last.get('arg_morale_index', 0)),
                'n_runs':                         N_RUNS,
            }
        fpath = output_dir / 'summary.json'
        with open(fpath, 'w') as f:
            json.dump(summary, f, indent=2)
        print("Saved summary.json")
    except Exception as e:
        print(f"WARNING: summary.json write failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description='Falklands War Conflict Simulator (1982)')
    parser.add_argument('--output', type=str, default='./sim_outputs',
                        help='Output directory for all simulation artefacts')
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir}")

    # ── Run all scenarios ────────────────────────────────────────────────────
    all_records_combined: List[Dict]                    = []
    all_scenario_records: Dict[str, List[Dict]]         = {}
    scenario_end_days:    Dict[str, List[int]]          = {}

    for sc_idx, scenario in enumerate(MODEL_PROFILE['scenarios']):
        label = scenario['label']
        print(f"\n[{sc_idx+1}/{len(MODEL_PROFILE['scenarios'])}] Running scenario: {label}")
        records, end_days = run_scenario(scenario, sc_idx)
        all_records_combined.extend(records)
        all_scenario_records[label] = records
        scenario_end_days[label]    = end_days
        print(f"  Completed {N_RUNS} runs; mean end day = {np.mean(end_days):.1f}")

    # ── Write CSVs ───────────────────────────────────────────────────────────
    print("\n── Writing CSV files ──")
    write_simulation_outputs(all_records_combined, output_dir)

    summary_rows = compute_scenario_summary(all_scenario_records)
    write_scenario_summary(summary_rows, output_dir)

    write_parameters_used(output_dir)

    # ── Write JSON ───────────────────────────────────────────────────────────
    write_summary_json(all_scenario_records, scenario_end_days, output_dir)

    # ── Generate figures ─────────────────────────────────────────────────────
    print("\n── Generating figures ──")
    fig1_aircraft_remaining(all_scenario_records, output_dir)
    fig2_casualties(all_scenario_records, output_dir)
    fig3_territorial_control(all_scenario_records, output_dir)
    fig4_arg_morale(all_scenario_records, output_dir)
    fig5_scatter_losses(all_scenario_records, output_dir)
    fig6_heatmap_sweep(output_dir)
    fig7_histogram_end_days(output_dir)

    print("\n✓ Simulation complete. All outputs saved to:", output_dir)


if __name__ == '__main__':
    main()