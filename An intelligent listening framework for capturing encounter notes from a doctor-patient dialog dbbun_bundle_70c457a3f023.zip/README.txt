================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 3e2bbdea-5f05-4e6b-8a3f-c2b3679ea4ae
    Generated   : 2026-04-21  02:14:40 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    An intelligent listening framework for capturing encounter notes from a doctor-patient dialog

    CATEGORIES
    ----------
    Biomedical and Health Sciences, Artificial Intelligence, Machine Learning, Signal Processing, Health

    KEYWORDS
    --------
    automated speech recognition, medical natural language processing, clinical encounter notes, concept extraction, doctor-patient dialog

    ABSTRACT
    --------
    This simulator models the end-to-end pipeline of an Intelligent Listening Framework (ILF) for capturing structured clinical encounter notes from doctor-patient conversations, faithfully reproducing the concept detection F-measure (73.6%), categorization accuracy (85.7%), and note completeness dynamics reported in the source paper. The simulation generates synthetic encounter utterances, applies stochastic ASR word error rates, and triggers MNLP concept extraction in batches controlled by configurable granularity parameters (utterance-limit and dump-limit), producing running metrics for precision, recall, F-measure, and note field population over the course of the encounter. Six scenarios span baseline proof-of-concept performance, in-domain retraining, high-noise ASR, fine and coarse granularity settings, and an ideal upper-bound system. Researchers can use the simulator to explore the sensitivity of clinical note completeness to ASR quality, training domain mismatch, and processing granularity without requiring expensive clinical data collection. Students and engineers can use it to understand NLP pipeline design tradeoffs in healthcare informatics.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    1472-6947-9-S1-S3.pdf

    SIMULATION BACKEND
    ------------------
    event_process

    STATE VARIABLES
    ---------------
    utterance_count, unprocessed_buffer_size, processed_concepts_total, true_positive_concepts, false_positive_concepts, false_negative_concepts, correctly_categorized_concepts, f_measure, precision, recall, categorization_accuracy, asr_word_error_rate, dump_count, encounter_time_s, note_completeness

    SCENARIOS  (6 total)
    ---------------------------------
        1. baseline_proof_of_concept — Simulates the proof-of-concept system with CaRE trained on discharge summaries applied to clinical conversational speech, reproducing the reported F-measure of 73.6% and categorization accuracy of 85.7%
2. in_domain_training — Simulates improved MNLP performance after retraining CaRE on doctor-patient conversational corpora, eliminating the domain mismatch penalty and approaching discharge-summary performance
3. high_asr_noise — Simulates degraded ASR conditions such as noisy clinic environments, multiple speakers, or accented speech, increasing WER and observing downstream MNLP and note completeness degradation
4. fine_granularity — Simulates more frequent MNLP processing with smaller utterance-limit and dump-limit, trading latency for more real-time note updating
5. coarse_granularity — Simulates infrequent MNLP processing with large batch sizes, modeling delayed but potentially more accurate batch processing
6. ideal_system — Hypothetical fully optimized system with low ASR WER and MNLP trained on in-domain data with human-level concept detection, representing an upper bound on performance

    PARAMETERS
    ----------
    20 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This paper describes a clinical NLP pipeline that combines automated speech recognition (ASR) with medical natural language processing (MNLP) to extract structured encounter notes from doctor-patient conversations in real time, reporting concept detection F-measures and categorization accuracy from a proof-of-concept system.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.