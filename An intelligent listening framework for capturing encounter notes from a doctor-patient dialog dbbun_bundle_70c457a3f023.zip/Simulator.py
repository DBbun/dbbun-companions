# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-21T02:14:40.300833Z
# Run ID    : 3e2bbdea-5f05-4e6b-8a3f-c2b3679ea4ae
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Simulator for: An intelligent listening framework for capturing encounter notes from a doctor-patient dialog

This script models the end-to-end pipeline of an Intelligent Listening Framework (ILF)
for capturing structured clinical encounter notes from doctor-patient conversations.
It reproduces the concept detection F-measure (73.6%), categorization accuracy (85.7%),
and note completeness dynamics reported in the source paper across six simulation scenarios.

Reference:
  "An intelligent listening framework for capturing encounter notes from a doctor-patient dialog"
"""

import argparse
import csv
import json
import pathlib
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "utterance_limit": {"value": 3.0, "unit": "count", "source": "extracted",
                            "description": "Number of utterances after which a speech file dump is triggered"},
        "dump_limit": {"value": 2.0, "unit": "count", "source": "extracted",
                       "description": "Number of speech file dumps after which MNLP processing is executed"},
        "base_concept_density": {"value": 0.12, "unit": "concepts/word", "source": "assumed",
                                  "description": "Expected fraction of words corresponding to clinical concepts"},
        "base_asr_wer": {"value": 0.08, "unit": "a.u.", "source": "assumed",
                          "description": "Baseline word error rate for Dragon NaturallySpeaking Medical Edition"},
        "mnlp_base_recall": {"value": 0.736, "unit": "a.u.", "source": "extracted",
                              "description": "Base recall of CaRE MNLP concept detection module"},
        "mnlp_base_precision": {"value": 0.736, "unit": "a.u.", "source": "extracted",
                                 "description": "Base precision of CaRE MNLP concept detection module"},
        "care_discharge_fmeasure": {"value": 0.90, "unit": "a.u.", "source": "extracted",
                                     "description": "F-measure of CaRE on hospital discharge summaries"},
        "categorization_base_rate": {"value": 0.857, "unit": "a.u.", "source": "extracted",
                                      "description": "Fraction of correctly detected concepts also correctly categorized"},
        "words_per_utterance_mean": {"value": 12.0, "unit": "words", "source": "assumed",
                                      "description": "Mean number of words per utterance"},
        "words_per_utterance_std": {"value": 5.0, "unit": "words", "source": "assumed",
                                     "description": "Standard deviation of words per utterance"},
        "utterance_interval_mean_s": {"value": 6.0, "unit": "s", "source": "assumed",
                                       "description": "Mean time between utterance completions"},
        "total_utterances": {"value": 80, "unit": "count", "source": "assumed",
                              "description": "Total number of utterances in a simulated clinical encounter"},
        "asr_wer_noise_std": {"value": 0.03, "unit": "a.u.", "source": "assumed",
                               "description": "Standard deviation of per-utterance WER fluctuation"},
        "mnlp_recall_asr_sensitivity": {"value": 0.5, "unit": "a.u.", "source": "assumed",
                                         "description": "Sensitivity of MNLP recall to ASR WER"},
        "num_total_note_fields": {"value": 10.0, "unit": "count", "source": "assumed",
                                   "description": "Total number of structured fields in encounter note template"},
        "omission_rate_1975": {"value": 0.22, "unit": "a.u.", "source": "extracted",
                                "description": "Omission rate of compliance data from 1975 study"},
        "omission_rate_allergy": {"value": 0.12, "unit": "a.u.", "source": "extracted",
                                   "description": "Omission rate of allergy data from 1975 study"},
        "omission_rate_followup": {"value": 0.31, "unit": "a.u.", "source": "extracted",
                                    "description": "Omission rate of follow-up indications from 1975 study"},
        "omission_rate_cause": {"value": 0.51, "unit": "a.u.", "source": "extracted",
                                 "description": "Omission rate of cause-of-illness data from 1975 study"},
        "training_domain_mismatch_penalty": {"value": 0.15, "unit": "a.u.", "source": "assumed",
                                              "description": "Reduction in MNLP recall due to domain mismatch"},
    },
    "scenarios": [
        {
            "label": "baseline_proof_of_concept",
            "description": "Baseline system with CaRE trained on discharge summaries",
            "param_overrides": {
                "base_asr_wer": 0.08,
                "mnlp_base_recall": 0.736,
                "mnlp_base_precision": 0.736,
                "categorization_base_rate": 0.857,
                "training_domain_mismatch_penalty": 0.15
            }
        },
        {
            "label": "in_domain_training",
            "description": "Improved MNLP after retraining on doctor-patient corpora",
            "param_overrides": {
                "base_asr_wer": 0.08,
                "mnlp_base_recall": 0.85,
                "mnlp_base_precision": 0.88,
                "categorization_base_rate": 0.92,
                "training_domain_mismatch_penalty": 0.0
            }
        },
        {
            "label": "high_asr_noise",
            "description": "Degraded ASR conditions with higher WER",
            "param_overrides": {
                "base_asr_wer": 0.25,
                "asr_wer_noise_std": 0.06,
                "mnlp_base_recall": 0.736,
                "mnlp_base_precision": 0.736
            }
        },
        {
            "label": "fine_granularity",
            "description": "More frequent MNLP processing with smaller batch sizes",
            "param_overrides": {
                "utterance_limit": 1.0,
                "dump_limit": 1.0,
                "base_asr_wer": 0.08,
                "mnlp_base_recall": 0.736
            }
        },
        {
            "label": "coarse_granularity",
            "description": "Infrequent MNLP processing with large batch sizes",
            "param_overrides": {
                "utterance_limit": 8.0,
                "dump_limit": 4.0,
                "base_asr_wer": 0.08,
                "mnlp_base_recall": 0.736
            }
        },
        {
            "label": "ideal_system",
            "description": "Fully optimized system representing upper bound on performance",
            "param_overrides": {
                "base_asr_wer": 0.03,
                "mnlp_base_recall": 0.95,
                "mnlp_base_precision": 0.95,
                "categorization_base_rate": 0.97,
                "training_domain_mismatch_penalty": 0.0
            }
        }
    ]
}

# ============================================================
# SIMULATION ENGINE
# ============================================================

def get_params(scenario_overrides: Dict[str, Any]) -> Dict[str, Any]:
    """Build parameter dict from MODEL_PROFILE defaults + scenario overrides."""
    params = {k: v["value"] for k, v in MODEL_PROFILE["parameters"].items()}
    params.update(scenario_overrides)
    return params


def run_scenario(label: str, scenario_index: int, param_overrides: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Run a single scenario simulation and return list of row dicts."""
    np.random.seed(scenario_index)

    p = get_params(param_overrides)

    U_LIM = int(p["utterance_limit"])
    D_LIM = int(p["dump_limit"])
    W0 = float(p["base_asr_wer"])
    W_STD = float(p["asr_wer_noise_std"])
    CD = float(p["base_concept_density"])
    R0 = float(p["mnlp_base_recall"])
    P0 = float(p["mnlp_base_precision"])
    SENS = float(p["mnlp_recall_asr_sensitivity"])
    MMP = float(p["training_domain_mismatch_penalty"])
    CAT = float(p["categorization_base_rate"])
    WPU_MU = float(p["words_per_utterance_mean"])
    WPU_STD = float(p["words_per_utterance_std"])
    T_MU = float(p["utterance_interval_mean_s"])
    N_UTT = int(p["total_utterances"])
    NF = float(p["num_total_note_fields"])

    # Effective MNLP parameters accounting for domain mismatch
    effective_recall = max(0.0, R0 - MMP)
    effective_precision = max(0.0, P0 - 0.5 * MMP)

    # State initialization
    cumulative_tp = 0
    cumulative_fp = 0
    cumulative_fn = 0
    cumulative_cat = 0
    dump_count = 0
    utterances_since_dump = 0
    dumps_since_mnlp = 0
    encounter_time = 0.0
    processed_concepts_total = 0
    note_fields_populated = 0
    unprocessed_buffer: List[Dict[str, Any]] = []

    rows = []

    for t in range(N_UTT):
        # 1. UTTERANCE ARRIVAL
        words = max(1, int(round(np.random.normal(WPU_MU, WPU_STD))))
        dt = np.random.exponential(T_MU)
        encounter_time = min(encounter_time + dt, 1800.0)
        wer = float(np.clip(np.random.normal(W0, W_STD), 0.0, 0.5))

        # 2. GROUND TRUTH CONCEPTS
        n_gt = int(np.random.binomial(words, min(CD, 1.0)))

        # 3. MNLP DETECTION per utterance (stored in buffer)
        adj_recall = float(np.clip(
            effective_recall - SENS * max(0.0, wer - W0), 0.0, 1.0
        ))
        adj_precision = float(np.clip(
            effective_precision * (1.0 - 0.3 * max(0.0, wer - W0)), 0.0, 1.0
        ))

        unprocessed_buffer.append({
            "wer": wer,
            "n_gt": n_gt,
            "adj_recall": adj_recall,
            "adj_precision": adj_precision
        })
        utterances_since_dump += 1

        # Per-utterance values for row (default: no processing this step)
        tp_last = 0
        fp_last = 0
        fn_last = 0
        cat_last = 0
        detected_last = 0

        # 4. GRANULARITY CONTROL — DUMP TRIGGER
        if utterances_since_dump >= U_LIM:
            dump_count += 1
            utterances_since_dump = 0
            dumps_since_mnlp += 1

        # 5. GRANULARITY CONTROL — MNLP BATCH TRIGGER
        mnlp_fired = False
        if dumps_since_mnlp >= D_LIM:
            mnlp_fired = True
            dumps_since_mnlp = 0

            batch_tp = 0
            batch_fp = 0
            batch_fn = 0
            batch_cat = 0

            for entry in unprocessed_buffer:
                e_ngt = entry["n_gt"]
                e_recall = entry["adj_recall"]
                e_prec = max(entry["adj_precision"], 0.001)

                tp_e = int(round(e_ngt * e_recall))
                tp_e = max(0, tp_e)
                detected_e = tp_e / e_prec
                fp_e = max(0, int(round(detected_e - tp_e)))
                fn_e = max(0, e_ngt - tp_e)
                cat_e = int(round(tp_e * CAT))

                batch_tp += tp_e
                batch_fp += fp_e
                batch_fn += fn_e
                batch_cat += cat_e

            cumulative_tp += batch_tp
            cumulative_fp += batch_fp
            cumulative_fn += batch_fn
            cumulative_cat += batch_cat
            processed_concepts_total += batch_tp

            # Update note completeness via Poisson draw
            new_fields_lambda = max(0.0, batch_tp * 0.15)
            new_fields = int(np.random.poisson(new_fields_lambda)) if new_fields_lambda > 0 else 0
            note_fields_populated = int(min(NF, note_fields_populated + new_fields))

            # Set per-utterance stats to the last entry in the batch
            if unprocessed_buffer:
                last = unprocessed_buffer[-1]
                e_recall = last["adj_recall"]
                e_prec = max(last["adj_precision"], 0.001)
                tp_last = int(round(last["n_gt"] * e_recall))
                tp_last = max(0, tp_last)
                detected_last = int(round(tp_last / e_prec))
                fp_last = max(0, detected_last - tp_last)
                fn_last = max(0, last["n_gt"] - tp_last)
                cat_last = int(round(tp_last * CAT))

            unprocessed_buffer = []

        # 6. COMPUTE RUNNING METRICS
        denom_p = max(cumulative_tp + cumulative_fp, 1)
        denom_r = max(cumulative_tp + cumulative_fn, 1)
        precision_val = cumulative_tp / denom_p
        recall_val = cumulative_tp / denom_r
        pr_sum = precision_val + recall_val
        f_measure_val = (2.0 * precision_val * recall_val / max(pr_sum, 1e-9)) if pr_sum > 0 else 0.0
        cat_acc_val = cumulative_cat / max(cumulative_tp, 1)
        note_completeness_val = note_fields_populated / NF

        # Clamp all metrics to valid ranges
        precision_val = float(np.clip(precision_val, 0.0, 1.0))
        recall_val = float(np.clip(recall_val, 0.0, 1.0))
        f_measure_val = float(np.clip(f_measure_val, 0.0, 1.0))
        cat_acc_val = float(np.clip(cat_acc_val, 0.0, 1.0))
        note_completeness_val = float(np.clip(note_completeness_val, 0.0, 1.0))

        # 7. RECORD ROW
        rows.append({
            "scenario": label,
            "utterance_count": t + 1,
            "encounter_time_s": round(encounter_time, 3),
            "words_in_utterance": words,
            "asr_word_error_rate": round(wer, 6),
            "ground_truth_concepts_in_utterance": n_gt,
            "detected_concepts_in_utterance": detected_last,
            "true_positives_in_utterance": tp_last,
            "false_positives_in_utterance": fp_last,
            "false_negatives_in_utterance": fn_last,
            "correctly_categorized_in_utterance": cat_last,
            "cumulative_true_positives": cumulative_tp,
            "cumulative_false_positives": cumulative_fp,
            "cumulative_false_negatives": cumulative_fn,
            "cumulative_correctly_categorized": cumulative_cat,
            "precision": round(precision_val, 6),
            "recall": round(recall_val, 6),
            "f_measure": round(f_measure_val, 6),
            "categorization_accuracy": round(cat_acc_val, 6),
            "unprocessed_buffer_size": len(unprocessed_buffer),
            "dump_count": dump_count,
            "mnlp_batch_fired": int(mnlp_fired),
            "processed_concepts_total": processed_concepts_total,
            "note_completeness": round(note_completeness_val, 6),
            "note_fields_populated": note_fields_populated
        })

    return rows


# ============================================================
# CSV WRITING
# ============================================================

DATASET_SCHEMA = [
    "scenario", "utterance_count", "encounter_time_s", "words_in_utterance",
    "asr_word_error_rate", "ground_truth_concepts_in_utterance",
    "detected_concepts_in_utterance", "true_positives_in_utterance",
    "false_positives_in_utterance", "false_negatives_in_utterance",
    "correctly_categorized_in_utterance", "cumulative_true_positives",
    "cumulative_false_positives", "cumulative_false_negatives",
    "cumulative_correctly_categorized", "precision", "recall", "f_measure",
    "categorization_accuracy", "unprocessed_buffer_size", "dump_count",
    "mnlp_batch_fired", "processed_concepts_total", "note_completeness",
    "note_fields_populated"
]


def write_simulation_outputs(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write simulation_outputs.csv."""
    if not all_rows:
        print("WARNING: No simulation rows to write.")
        return
    filepath = out_dir / "simulation_outputs.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=DATASET_SCHEMA)
        writer.writeheader()
        writer.writerows(all_rows)
    print(f"Written: {filepath}")


def write_scenario_summary(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write scenario_summary.csv with aggregate metrics per scenario."""
    if not all_rows:
        print("WARNING: No rows for scenario_summary.")
        return

    scenarios_data: Dict[str, List[Dict[str, Any]]] = {}
    for row in all_rows:
        sc = row["scenario"]
        if sc not in scenarios_data:
            scenarios_data[sc] = []
        scenarios_data[sc].append(row)

    numeric_cols = [
        "f_measure", "precision", "recall", "categorization_accuracy",
        "note_completeness", "asr_word_error_rate", "processed_concepts_total",
        "cumulative_true_positives", "cumulative_false_positives",
        "cumulative_false_negatives", "unprocessed_buffer_size"
    ]

    summary_rows = []
    for sc, rows in scenarios_data.items():
        summary = {"scenario": sc}
        for col in numeric_cols:
            vals = np.array([r[col] for r in rows], dtype=float)
            summary[f"{col}_mean"] = round(float(np.mean(vals)), 6)
            summary[f"{col}_std"] = round(float(np.std(vals)), 6)
            summary[f"{col}_min"] = round(float(np.min(vals)), 6)
            summary[f"{col}_max"] = round(float(np.max(vals)), 6)
        # Final values
        last = rows[-1]
        summary["final_f_measure"] = last["f_measure"]
        summary["final_precision"] = last["precision"]
        summary["final_recall"] = last["recall"]
        summary["final_categorization_accuracy"] = last["categorization_accuracy"]
        summary["final_note_completeness"] = last["note_completeness"]
        summary["total_utterances"] = last["utterance_count"]
        summary["total_dump_count"] = last["dump_count"]
        summary["final_encounter_time_s"] = last["encounter_time_s"]
        # Count MNLP batch fires
        summary["mnlp_batch_fires"] = sum(r["mnlp_batch_fired"] for r in rows)
        summary_rows.append(summary)

    if not summary_rows:
        print("WARNING: No summary rows to write.")
        return

    fieldnames = list(summary_rows[0].keys())
    filepath = out_dir / "scenario_summary.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"Written: {filepath}")


def write_parameters_used(out_dir: pathlib.Path) -> None:
    """Write parameters_used.csv."""
    rows = []
    for name, info in MODEL_PROFILE["parameters"].items():
        rows.append({
            "name": name,
            "value": info["value"],
            "unit": info["unit"],
            "source": info["source"],
            "description": info["description"]
        })

    if not rows:
        print("WARNING: No parameters to write.")
        return

    filepath = out_dir / "parameters_used.csv"
    with open(filepath, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Written: {filepath}")


# ============================================================
# SUMMARY JSON
# ============================================================

def write_summary_json(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Write summary.json with key aggregate metrics."""
    scenarios_data: Dict[str, List[Dict[str, Any]]] = {}
    for row in all_rows:
        sc = row["scenario"]
        if sc not in scenarios_data:
            scenarios_data[sc] = []
        scenarios_data[sc].append(row)

    summary = {}
    for sc, rows in scenarios_data.items():
        last = rows[-1]
        f_vals = [r["f_measure"] for r in rows]
        cat_vals = [r["categorization_accuracy"] for r in rows]
        summary[sc] = {
            "final_f_measure": last["f_measure"],
            "final_precision": last["precision"],
            "final_recall": last["recall"],
            "final_categorization_accuracy": last["categorization_accuracy"],
            "final_note_completeness": last["note_completeness"],
            "mean_f_measure": round(float(np.mean(f_vals)), 6),
            "mean_categorization_accuracy": round(float(np.mean(cat_vals)), 6),
            "total_utterances": last["utterance_count"],
            "final_encounter_time_s": last["encounter_time_s"],
            "total_dump_count": last["dump_count"],
            "mnlp_batch_fires": sum(r["mnlp_batch_fired"] for r in rows)
        }

    filepath = out_dir / "summary.json"
    with open(filepath, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"Written: {filepath}")


# ============================================================
# FIGURE GENERATION
# ============================================================

SCENARIO_COLORS = {
    "baseline_proof_of_concept": "#1f77b4",
    "in_domain_training": "#2ca02c",
    "high_asr_noise": "#d62728",
    "fine_granularity": "#ff7f0e",
    "coarse_granularity": "#9467bd",
    "ideal_system": "#8c564b"
}

SCENARIO_LABELS_SHORT = {
    "baseline_proof_of_concept": "Baseline PoC",
    "in_domain_training": "In-Domain Training",
    "high_asr_noise": "High ASR Noise",
    "fine_granularity": "Fine Granularity",
    "coarse_granularity": "Coarse Granularity",
    "ideal_system": "Ideal System"
}


def get_scenario_arrays(all_rows: List[Dict[str, Any]], scenario: str,
                        x_col: str, y_col: str):
    """Extract matched x and y arrays for a scenario."""
    rows = [r for r in all_rows if r["scenario"] == scenario]
    x_vals = np.array([r[x_col] for r in rows], dtype=float)
    y_vals = np.array([r[y_col] for r in rows], dtype=float)
    return x_vals, y_vals


def fig1_f_measure_vs_utterance(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig1: Running F-Measure vs Utterance Count by Scenario."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))

        for sc in scenarios:
            x, y = get_scenario_arrays(all_rows, sc, "utterance_count", "f_measure")
            assert len(x) == len(y), f"Array length mismatch for {sc}"
            if len(x) == 0:
                print(f"WARNING fig1: Empty arrays for {sc}, skipping.")
                continue
            color = SCENARIO_COLORS.get(sc, "#333333")
            label = SCENARIO_LABELS_SHORT.get(sc, sc)
            ax.plot(x, y, color=color, label=label, linewidth=2, alpha=0.85)

        ax.axhline(y=0.736, color="gray", linestyle="--", linewidth=1.0, alpha=0.7,
                   label="Paper reported F=0.736")
        ax.set_xlabel("Utterance Count", fontsize=13)
        ax.set_ylabel("Running F-Measure", fontsize=13)
        ax.set_title("Running F-Measure of Concept Detection vs. Utterance Count by Scenario", fontsize=13)
        ax.legend(loc="lower right", fontsize=9)
        ax.set_ylim(0.0, 1.05)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig1_f_measure_vs_utterance.png", dpi=150)
        plt.close(fig)
        print("Saved: fig1_f_measure_vs_utterance.png")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")


def fig2_note_completeness(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig2: Note Completeness Over Encounter Progress by Scenario."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))

        for sc in scenarios:
            x, y = get_scenario_arrays(all_rows, sc, "utterance_count", "note_completeness")
            assert len(x) == len(y), f"Array length mismatch for {sc}"
            if len(x) == 0:
                print(f"WARNING fig2: Empty arrays for {sc}, skipping.")
                continue
            color = SCENARIO_COLORS.get(sc, "#333333")
            label = SCENARIO_LABELS_SHORT.get(sc, sc)
            ax.plot(x, y, color=color, label=label, linewidth=2, alpha=0.85,
                    drawstyle="steps-post")

        ax.set_xlabel("Utterance Count", fontsize=13)
        ax.set_ylabel("Note Completeness (fraction of fields populated)", fontsize=13)
        ax.set_title("Note Completeness Over Encounter Progress by Scenario", fontsize=13)
        ax.legend(loc="lower right", fontsize=9)
        ax.set_ylim(0.0, 1.05)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig2_note_completeness.png", dpi=150)
        plt.close(fig)
        print("Saved: fig2_note_completeness.png")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")


def fig3_categorization_accuracy(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig3: Categorization Accuracy Over Time by Scenario."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))

        for sc in scenarios:
            x, y = get_scenario_arrays(all_rows, sc, "utterance_count", "categorization_accuracy")
            assert len(x) == len(y), f"Array length mismatch for {sc}"
            if len(x) == 0:
                print(f"WARNING fig3: Empty arrays for {sc}, skipping.")
                continue
            color = SCENARIO_COLORS.get(sc, "#333333")
            label = SCENARIO_LABELS_SHORT.get(sc, sc)
            ax.plot(x, y, color=color, label=label, linewidth=2, alpha=0.85)

        ax.axhline(y=0.857, color="gray", linestyle="--", linewidth=1.0, alpha=0.7,
                   label="Paper reported 85.7%")
        ax.set_xlabel("Utterance Count", fontsize=13)
        ax.set_ylabel("Categorization Accuracy", fontsize=13)
        ax.set_title("Categorization Accuracy of Detected Concepts Over Time by Scenario", fontsize=13)
        ax.legend(loc="lower right", fontsize=9)
        ax.set_ylim(0.0, 1.05)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig3_categorization_accuracy.png", dpi=150)
        plt.close(fig)
        print("Saved: fig3_categorization_accuracy.png")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")


def fig4_wer_vs_fmeasure(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig4: Scatter of ASR WER vs F-Measure pooled across all utterances/scenarios."""
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))

        all_wer = []
        all_fm = []

        for sc in scenarios:
            wer_arr, fm_arr = get_scenario_arrays(all_rows, sc, "asr_word_error_rate", "f_measure")
            assert len(wer_arr) == len(fm_arr), f"Array mismatch for {sc}"
            if len(wer_arr) == 0:
                continue
            color = SCENARIO_COLORS.get(sc, "#333333")
            label = SCENARIO_LABELS_SHORT.get(sc, sc)
            ax.scatter(wer_arr, fm_arr, color=color, label=label, alpha=0.35, s=15)
            all_wer.extend(wer_arr.tolist())
            all_fm.extend(fm_arr.tolist())

        # Trend line
        if len(all_wer) > 5:
            all_wer_np = np.array(all_wer)
            all_fm_np = np.array(all_fm)
            # Filter out zero f_measure (initial states before any batch fires)
            mask = all_fm_np > 0.01
            if np.sum(mask) > 5:
                coeffs = np.polyfit(all_wer_np[mask], all_fm_np[mask], 1)
                x_trend = np.linspace(all_wer_np[mask].min(), all_wer_np[mask].max(), 100)
                y_trend = np.polyval(coeffs, x_trend)
                assert len(x_trend) == len(y_trend)
                ax.plot(x_trend, y_trend, color="black", linewidth=2.0, linestyle="-",
                        label=f"Trend (slope={coeffs[0]:.2f})")

        ax.scatter([0.08], [0.736], color="gold", marker="*", s=200, zorder=5,
                   label="Paper baseline (WER=0.08, F=0.736)", edgecolors="black")
        ax.set_xlabel("ASR Word Error Rate", fontsize=13)
        ax.set_ylabel("Running F-Measure", fontsize=13)
        ax.set_title("Impact of ASR Word Error Rate on Concept Detection F-Measure", fontsize=13)
        ax.legend(loc="upper right", fontsize=8)
        ax.set_xlim(0.0, 0.55)
        ax.set_ylim(0.0, 1.05)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig4_wer_vs_fmeasure.png", dpi=150)
        plt.close(fig)
        print("Saved: fig4_wer_vs_fmeasure.png")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")


def fig5_fmeasure_histogram(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig5: Histogram of per-batch F-Measure across all scenarios."""
    try:
        # Only use rows where MNLP batch fired
        batch_rows = [r for r in all_rows if r["mnlp_batch_fired"] == 1 and r["f_measure"] > 0.01]

        if not batch_rows:
            # Fall back to all rows with non-trivial f_measure
            batch_rows = [r for r in all_rows if r["f_measure"] > 0.01]

        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))
        fig, axes = plt.subplots(2, 3, figsize=(15, 8), sharex=True, sharey=False)
        axes_flat = axes.flatten()

        for idx, sc in enumerate(scenarios):
            ax = axes_flat[idx]
            sc_batch = [r["f_measure"] for r in batch_rows if r["scenario"] == sc]
            if not sc_batch:
                ax.set_title(SCENARIO_LABELS_SHORT.get(sc, sc), fontsize=10)
                ax.text(0.5, 0.5, "No batch data", transform=ax.transAxes,
                        ha="center", va="center")
                continue
            color = SCENARIO_COLORS.get(sc, "#333333")
            fm_arr = np.array(sc_batch)
            bins = np.linspace(0.0, 1.0, 25)
            ax.hist(fm_arr, bins=bins, color=color, alpha=0.7, edgecolor="white")
            ax.axvline(np.mean(fm_arr), color="black", linestyle="--", linewidth=1.5,
                       label=f"Mean={np.mean(fm_arr):.3f}")
            ax.set_title(SCENARIO_LABELS_SHORT.get(sc, sc), fontsize=10)
            ax.legend(fontsize=8)
            ax.set_xlabel("F-Measure", fontsize=9)
            ax.set_ylabel("Frequency", fontsize=9)

        # Hide unused axes
        for idx in range(len(scenarios), len(axes_flat)):
            axes_flat[idx].set_visible(False)

        fig.suptitle("Distribution of Per-Batch F-Measure Across All Scenarios", fontsize=13)
        plt.tight_layout()
        plt.savefig(out_dir / "fig5_fmeasure_histogram.png", dpi=150)
        plt.close(fig)
        print("Saved: fig5_fmeasure_histogram.png")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")


def fig6_performance_heatmap(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig6: Performance Metric Heatmap Across All Scenarios."""
    try:
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))
        metrics = ["f_measure", "precision", "recall", "categorization_accuracy",
                   "note_completeness", "asr_word_error_rate"]
        metric_labels = ["F-Measure", "Precision", "Recall",
                         "Categorization Acc.", "Note Completeness", "Mean ASR WER"]

        # Build matrix: rows = metrics, cols = scenarios
        # Use final values for most metrics, mean for WER
        data_matrix = np.zeros((len(metrics), len(scenarios)))

        for j, sc in enumerate(scenarios):
            sc_rows = [r for r in all_rows if r["scenario"] == sc]
            if not sc_rows:
                continue
            last = sc_rows[-1]
            for i, metric in enumerate(metrics):
                if metric == "asr_word_error_rate":
                    vals = np.array([r[metric] for r in sc_rows])
                    val = float(np.mean(vals))
                else:
                    val = float(last[metric])
                data_matrix[i, j] = val

        # Normalize: for WER, lower is better, so invert
        norm_matrix = data_matrix.copy()
        wer_idx = metrics.index("asr_word_error_rate")
        norm_matrix[wer_idx, :] = 1.0 - data_matrix[wer_idx, :]
        # Normalize each row to [0,1]
        for i in range(len(metrics)):
            row_min = norm_matrix[i, :].min()
            row_max = norm_matrix[i, :].max()
            if row_max > row_min:
                norm_matrix[i, :] = (norm_matrix[i, :] - row_min) / (row_max - row_min)
            else:
                norm_matrix[i, :] = 0.5

        fig, ax = plt.subplots(figsize=(12, 5))
        im = ax.imshow(norm_matrix, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")

        sc_labels = [SCENARIO_LABELS_SHORT.get(sc, sc) for sc in scenarios]
        ax.set_xticks(np.arange(len(scenarios)))
        ax.set_xticklabels(sc_labels, rotation=30, ha="right", fontsize=9)
        ax.set_yticks(np.arange(len(metrics)))
        ax.set_yticklabels(metric_labels, fontsize=10)

        # Annotate cells with actual values
        for i in range(len(metrics)):
            for j in range(len(scenarios)):
                val = data_matrix[i, j]
                txt = f"{val:.3f}"
                text_color = "black"
                ax.text(j, i, txt, ha="center", va="center", fontsize=8,
                        color=text_color, fontweight="bold")

        plt.colorbar(im, ax=ax, label="Normalized Score (0=worst, 1=best)")
        ax.set_title("Performance Metric Heatmap Across All Scenarios", fontsize=13)
        plt.tight_layout()
        plt.savefig(out_dir / "fig6_performance_heatmap.png", dpi=150)
        plt.close(fig)
        print("Saved: fig6_performance_heatmap.png")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")


def fig7_buffer_size_over_time(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig7: Unprocessed Buffer Size Over Encounter Time for granularity scenarios."""
    try:
        target_scenarios = ["fine_granularity", "baseline_proof_of_concept", "coarse_granularity"]
        fig, ax = plt.subplots(figsize=(10, 6))
        plotted = False

        for sc in target_scenarios:
            sc_rows = [r for r in all_rows if r["scenario"] == sc]
            if not sc_rows:
                print(f"WARNING fig7: No data for scenario {sc}, skipping.")
                continue
            x = np.array([r["encounter_time_s"] for r in sc_rows], dtype=float)
            y = np.array([r["unprocessed_buffer_size"] for r in sc_rows], dtype=float)
            assert len(x) == len(y), f"Array mismatch for {sc}"
            if len(x) == 0:
                print(f"WARNING fig7: Empty arrays for {sc}, skipping.")
                continue
            color = SCENARIO_COLORS.get(sc, "#333333")
            label = SCENARIO_LABELS_SHORT.get(sc, sc)
            ax.plot(x, y, color=color, label=label, linewidth=2, alpha=0.85,
                    drawstyle="steps-post")
            plotted = True

        if not plotted:
            print("WARNING fig7: No data to plot.")
            plt.close(fig)
            return

        ax.set_xlabel("Encounter Time (seconds)", fontsize=13)
        ax.set_ylabel("Unprocessed Buffer Size (utterances)", fontsize=13)
        ax.set_title("Unprocessed Buffer Size Over Encounter Time for Different Granularity Settings",
                     fontsize=12)
        ax.legend(loc="upper right", fontsize=10)
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig7_buffer_size_over_time.png", dpi=150)
        plt.close(fig)
        print("Saved: fig7_buffer_size_over_time.png")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")


def fig8_omission_rates(all_rows: List[Dict[str, Any]], out_dir: pathlib.Path) -> None:
    """Fig8: Simulated Medical Record Omission Rates vs Historical."""
    try:
        historical_fields = {
            "Visit Reasons": 0.06,
            "Allergies": 0.12,
            "Compliance": 0.22,
            "Follow-up": 0.31,
            "Cause of Illness": 0.51
        }

        # Get final note_completeness per scenario
        scenarios = list(dict.fromkeys(r["scenario"] for r in all_rows))
        scenario_final_completeness: Dict[str, float] = {}
        for sc in scenarios:
            sc_rows = [r for r in all_rows if r["scenario"] == sc]
            if sc_rows:
                scenario_final_completeness[sc] = float(sc_rows[-1]["note_completeness"])
            else:
                scenario_final_completeness[sc] = 0.0

        field_names = list(historical_fields.keys())
        hist_rates = np.array(list(historical_fields.values()))

        n_fields = len(field_names)
        n_scenarios = len(scenarios)
        x = np.arange(n_fields)
        bar_width = 0.12

        fig, ax = plt.subplots(figsize=(14, 7))

        # Plot historical bars
        bars_hist = ax.bar(x - bar_width * (n_scenarios / 2), hist_rates, bar_width,
                           label="Historical (1975)", color="dimgray", alpha=0.8, edgecolor="black")

        # Plot ILF scenario bars
        for i, sc in enumerate(scenarios):
            residual = 1.0 - scenario_final_completeness[sc]
            residual = float(np.clip(residual, 0.0, 1.0))
            # Scale per-field residual by historical rate
            scaled = hist_rates * residual
            bars = ax.bar(x - bar_width * (n_scenarios / 2 - 1 - i), scaled, bar_width,
                          label=SCENARIO_LABELS_SHORT.get(sc, sc),
                          color=SCENARIO_COLORS.get(sc, "#555555"),
                          alpha=0.75, edgecolor="black")

        ax.set_xlabel("Note Field Category", fontsize=13)
        ax.set_ylabel("Omission Rate", fontsize=13)
        ax.set_title("Simulated Medical Record Omission Rates: Traditional vs. ILF-Assisted Documentation",
                     fontsize=12)
        ax.set_xticks(x)
        ax.set_xticklabels(field_names, fontsize=11)
        ax.legend(loc="upper left", fontsize=8)
        ax.set_ylim(0.0, 0.65)
        ax.grid(True, axis="y", alpha=0.3)
        plt.tight_layout()
        plt.savefig(out_dir / "fig8_omission_rates.png", dpi=150)
        plt.close(fig)
        print("Saved: fig8_omission_rates.png")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="ILF Clinical NLP Pipeline Simulator"
    )
    parser.add_argument(
        "--output", type=str, default="./sim_outputs",
        help="Output directory for all generated files (default: ./sim_outputs)"
    )
    args = parser.parse_args()

    out_dir = pathlib.Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {out_dir.resolve()}")

    # Run all scenarios
    all_rows: List[Dict[str, Any]] = []
    scenarios = MODEL_PROFILE["scenarios"]

    for scenario_index, scenario_cfg in enumerate(scenarios):
        label = scenario_cfg["label"]
        param_overrides = scenario_cfg["param_overrides"]
        print(f"\nRunning scenario [{scenario_index}]: {label}")
        rows = run_scenario(label, scenario_index, param_overrides)
        all_rows.extend(rows)
        print(f"  Completed: {len(rows)} rows, "
              f"final F={rows[-1]['f_measure']:.4f}, "
              f"catAcc={rows[-1]['categorization_accuracy']:.4f}, "
              f"noteComp={rows[-1]['note_completeness']:.4f}")

    print(f"\nTotal rows across all scenarios: {len(all_rows)}")

    # Write CSV files
    print("\nWriting CSV files...")
    write_simulation_outputs(all_rows, out_dir)
    write_scenario_summary(all_rows, out_dir)
    write_parameters_used(out_dir)

    # Write JSON summary
    print("\nWriting JSON summary...")
    write_summary_json(all_rows, out_dir)

    # Generate figures
    print("\nGenerating figures...")
    fig1_f_measure_vs_utterance(all_rows, out_dir)
    fig2_note_completeness(all_rows, out_dir)
    fig3_categorization_accuracy(all_rows, out_dir)
    fig4_wer_vs_fmeasure(all_rows, out_dir)
    fig5_fmeasure_histogram(all_rows, out_dir)
    fig6_performance_heatmap(all_rows, out_dir)
    fig7_buffer_size_over_time(all_rows, out_dir)
    fig8_omission_rates(all_rows, out_dir)

    print(f"\nSimulation complete. All outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()