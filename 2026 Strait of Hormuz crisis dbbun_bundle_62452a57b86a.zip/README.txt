================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : 202bad31-1fec-4279-b2e7-98338acc1578
    Generated   : 2026-04-21  13:28:34 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    2026 Strait of Hormuz Crisis

    CATEGORIES
    ----------
    Transportation, Financial, Geoscience and Remote Sensing, Climate Change/Environmental, Security

    KEYWORDS
    --------
    Strait of Hormuz, maritime blockade, oil price shock, energy supply disruption, geopolitical risk

    ABSTRACT
    --------
    This simulator models the 2026 Strait of Hormuz crisis, reproducing the coupled dynamics of maritime traffic suppression, oil price escalation, war-risk insurance surges, ship attack accumulation, and alternative supply route activation across a 49-day crisis window. The model is driven by a piecewise blockade intensity schedule calibrated to extracted historical data points including the 70% initial traffic drop, $126/barrel oil price peak on day 22, 4-6x insurance multiplier by day 9, and 31 confirmed ship attacks. Five scenarios spanning full closure, partial exemptions, ceasefire, US naval blockade, and hypothetical prolonged closure allow users to explore how different geopolitical outcomes translate into quantitative energy market and shipping disruption impacts. The simulator generates a multi-column CSV dataset and eight publication-quality figures suitable for energy security, maritime policy, and economic modeling research.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    2026 Strait of Hormuz crisis - Wikipedia.pdf

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    tanker_traffic_pct, brent_crude_price, war_risk_insurance_multiplier, ships_attacked_cumulative, ships_anchored_outside, exempt_traffic_pct, pipeline_diversion_pct, blockade_intensity

    SCENARIOS  (5 total)
    ---------------------------------
        1. Full_Blockade_No_Exemptions — Iran closes strait completely, no exemptions granted, no pipeline diversion; mirrors days 1-4 of the actual crisis
2. Partial_Exemptions_China_India_Russia — Iran allows vessels from China, India, Russia, Iraq, Pakistan (announced 26 March); pipeline diversion partially active; mirrors mid-crisis conditions
3. Ceasefire_Partial_Reopening — Temporary ceasefire agreed 8 April; Iran controls traffic with $1M+ tolls; strait nominally open but restricted; mirrors early April
4. US_Naval_Blockade_Freedom_of_Navigation — US blockade from 13 April: only Iranian ports blocked, all other vessels free to transit; mirrors post-13 April scenario
5. Prolonged_Closure_Historical_Comparison — Hypothetical: Full closure persists 90 days with no exemptions or diversion; stress test for energy supply shock magnitude compared to 1970s

    PARAMETERS
    ----------
    21 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8

    DOMAIN SUMMARY
    --------------
    This source documents the 2026 Strait of Hormuz crisis in which Iran blocked a critical maritime chokepoint carrying ~20 million barrels of oil per day, triggering ship attacks, mine-laying, insurance surges, oil price spikes, and geopolitical escalation across multiple phases from late February through April 2026.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.