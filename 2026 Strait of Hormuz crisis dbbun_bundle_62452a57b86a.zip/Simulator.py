# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-04-21T13:28:34.920076Z
# Run ID    : 202bad31-1fec-4279-b2e7-98338acc1578
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
2026 Strait of Hormuz Crisis Dynamical System Simulator

Simulates the coupled dynamics of maritime traffic suppression, oil price escalation,
war-risk insurance surges, ship attack accumulation, and alternative supply route
activation during the 2026 Strait of Hormuz Crisis (28 February – 18 April 2026).

Reference: '2026 Strait of Hormuz Crisis' - documenting Iran's blockade of the critical
maritime chokepoint carrying ~20 million barrels of oil per day, triggering ship attacks,
mine-laying, insurance surges, oil price spikes, and geopolitical escalation.
"""

import argparse
import csv
import json
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Any, Optional

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.colors import Normalize

# =============================================================================
# MODEL PROFILE
# =============================================================================

MODEL_PROFILE = {
    "title": "2026 Strait of Hormuz Crisis Dynamical System Simulator",
    "domain": "Maritime chokepoint disruption, energy security, geopolitical risk",
    "parameters": {
        "baseline_oil_flow_mbd": {"value": 20.0, "unit": "million barrels per day", "source": "extracted",
                                   "description": "Normal daily oil flow through the Strait of Hormuz"},
        "baseline_insurance_pct": {"value": 0.125, "unit": "percent of hull value per transit", "source": "extracted",
                                    "description": "Pre-crisis war-risk insurance premium rate"},
        "pre_escalation_insurance_pct": {"value": 0.3, "unit": "percent of hull value per transit", "source": "extracted",
                                          "description": "Insurance rate in days before strikes (0.2-0.4% range, mid-point used)"},
        "peak_insurance_multiplier": {"value": 6.0, "unit": "multiplier", "source": "extracted",
                                       "description": "Insurance rates increased 4-6x over the week after 28 Feb; upper bound used"},
        "initial_traffic_drop_pct": {"value": 70.0, "unit": "percent", "source": "extracted",
                                      "description": "First reported traffic reduction: ~70% drop within first few days"},
        "ships_anchored_peak": {"value": 150.0, "unit": "count", "source": "extracted",
                                 "description": "Over 150 ships anchored outside the strait at peak congestion"},
        "brent_price_day0": {"value": 75.0, "unit": "USD/barrel", "source": "assumed",
                              "description": "Approximate Brent crude price immediately before the crisis onset Feb 28"},
        "brent_price_100_day": {"value": 8.0, "unit": "days after crisis onset", "source": "extracted",
                                 "description": "Brent crossed $100/barrel on 8 March 2026 (day 8 after Feb 28)"},
        "brent_price_peak": {"value": 126.0, "unit": "USD/barrel", "source": "extracted",
                              "description": "Peak Brent crude price reported during the crisis"},
        "pipeline_max_capacity_mbd": {"value": 9.0, "unit": "million barrels per day", "source": "extracted",
                                       "description": "Combined alternative pipeline capacity (Saudi Yanbu + UAE Fujairah + Iraq Kirkuk-Ceyhan)"},
        "lng_global_share_pct": {"value": 20.0, "unit": "percent", "source": "extracted",
                                  "description": "Share of world LNG trade through the strait under normal conditions"},
        "fertilizer_trade_share_pct": {"value": 30.0, "unit": "percent", "source": "extracted",
                                        "description": "Share of internationally traded fertilizers normally transiting the strait"},
        "total_attacks_confirmed": {"value": 31.0, "unit": "count", "source": "extracted",
                                     "description": "Total confirmed ship attack incidents through 18 April 2026"},
        "attack_rate_early": {"value": 5.0, "unit": "attacks per day", "source": "extracted",
                               "description": "High attack rate during first week (approx 14 attacks 1-4 March over 4 days)"},
        "attack_rate_mid": {"value": 0.5, "unit": "attacks per day", "source": "extracted",
                             "description": "Reduced attack rate mid-crisis (approx 1 every 2 days March 10-31)"},
        "attack_rate_late": {"value": 0.15, "unit": "attacks per day", "source": "extracted",
                              "description": "Low attack rate in April period after partial negotiations"},
        "price_elasticity_traffic": {"value": -0.4, "unit": "dimensionless", "source": "assumed",
                                      "description": "Elasticity of tanker traffic with respect to insurance cost multiplier"},
        "price_recovery_rate": {"value": 0.15, "unit": "per day", "source": "assumed",
                                 "description": "Mean-reversion rate of oil price towards fundamental value when strait partially reopens"},
        "china_traffic_share": {"value": 0.33, "unit": "fraction of baseline", "source": "extracted",
                                 "description": "China receives a third of its oil via the strait; approximate traffic share for exempt nations"},
        "escort_capacity_ships_per_day": {"value": 3.5, "unit": "ships per day", "source": "extracted",
                                           "description": "Short-term escort capacity with 7-8 destroyers: 3-4 ships per day, midpoint"},
        "simulation_duration_days": {"value": 49.0, "unit": "days", "source": "extracted",
                                      "description": "Crisis duration modelled: 28 Feb to 18 April 2026 = 49 days"},
        "baseline_flow": {"value": 20.0, "unit": "Mb/d", "source": "extracted",
                          "description": "Baseline oil flow through strait"},
        "baseline_price": {"value": 75.0, "unit": "USD/bbl", "source": "assumed",
                           "description": "Baseline Brent crude price at crisis onset"},
        "baseline_insurance": {"value": 0.125, "unit": "pct hull value", "source": "extracted",
                               "description": "Baseline insurance premium rate"},
        "VLCC_hull_value": {"value": 100e6, "unit": "USD", "source": "assumed",
                            "description": "Approximate VLCC hull value for insurance cost calculation"},
        "price_fundamental_slope": {"value": 3.5, "unit": "USD/bbl per Mb/d gap", "source": "assumed",
                                     "description": "Oil price increase per unit supply gap"},
        "fear_premium_coefficient": {"value": 15.0, "unit": "USD/bbl", "source": "assumed",
                                      "description": "Geopolitical fear premium at full blockade intensity"},
    },
    "scenarios": [
        {
            "label": "Full_Blockade_No_Exemptions",
            "description": "Iran closes strait completely, no exemptions granted, no pipeline diversion",
            "param_overrides": {
                "exempt_traffic_pct": 0.0,
                "pipeline_diversion_pct": 0.0,
                "blockade_intensity": 1.0,
                "peak_insurance_multiplier": 6.0
            }
        },
        {
            "label": "Partial_Exemptions_China_India_Russia",
            "description": "Iran allows vessels from China, India, Russia, Iraq, Pakistan; pipeline diversion partially active",
            "param_overrides": {
                "exempt_traffic_pct": 20.0,
                "pipeline_diversion_pct": 30.0,
                "blockade_intensity": 0.7,
                "peak_insurance_multiplier": 4.0
            }
        },
        {
            "label": "Ceasefire_Partial_Reopening",
            "description": "Temporary ceasefire agreed 8 April; Iran controls traffic with $1M+ tolls",
            "param_overrides": {
                "exempt_traffic_pct": 35.0,
                "pipeline_diversion_pct": 40.0,
                "blockade_intensity": 0.4,
                "peak_insurance_multiplier": 2.5
            }
        },
        {
            "label": "US_Naval_Blockade_Freedom_of_Navigation",
            "description": "US blockade from 13 April: only Iranian ports blocked, all other vessels free to transit",
            "param_overrides": {
                "exempt_traffic_pct": 60.0,
                "pipeline_diversion_pct": 40.0,
                "blockade_intensity": 0.2,
                "peak_insurance_multiplier": 1.8
            }
        },
        {
            "label": "Prolonged_Closure_Historical_Comparison",
            "description": "Hypothetical: Full closure persists 90 days with no exemptions or diversion",
            "param_overrides": {
                "exempt_traffic_pct": 0.0,
                "pipeline_diversion_pct": 5.0,
                "blockade_intensity": 1.0,
                "peak_insurance_multiplier": 8.0,
                "simulation_duration_days": 90.0
            }
        }
    ]
}

# =============================================================================
# SIMULATION LOGIC
# =============================================================================

def get_phase(t: float) -> int:
    """Return crisis phase based on day t (0 = Feb 28 crisis onset)."""
    if t < 0:
        return 0  # pre-crisis
    elif t <= 4:
        return 1
    elif t <= 9:
        return 2
    elif t <= 25:
        return 3
    elif t <= 38:
        return 4
    elif t <= 43:
        return 5
    else:
        return 6


def get_phase_label(phase: int) -> str:
    labels = {
        0: "pre_crisis",
        1: "initial_blockade",
        2: "full_closure",
        3: "sustained_blockade",
        4: "partial_exemptions",
        5: "ceasefire",
        6: "us_naval_blockade"
    }
    return labels.get(phase, "unknown")


def compute_blockade_intensity(t: float, base_intensity: float,
                                exempt_pct: float) -> float:
    """Compute piecewise blockade intensity."""
    phase = get_phase(t)

    if phase == 0:
        # Pre-crisis: ramp from 0 to small level
        return 0.0
    elif phase == 1:
        # Ramp from 0 to base_intensity over 4 days
        ramp = min(1.0, t / 4.0)
        return base_intensity * ramp
    elif phase == 2:
        return base_intensity
    elif phase == 3:
        return base_intensity
    elif phase == 4:
        # Step down by exemption factor
        exempt_factor = (exempt_pct / 100.0) * 0.5
        return max(0.0, base_intensity - exempt_factor)
    elif phase == 5:
        # Further step down by ceasefire factor
        exempt_factor = (exempt_pct / 100.0) * 0.5
        ceasefire_factor = 0.3
        return max(0.0, base_intensity - exempt_factor - ceasefire_factor)
    elif phase == 6:
        # Further step down by US escort factor
        exempt_factor = (exempt_pct / 100.0) * 0.5
        ceasefire_factor = 0.3
        us_factor = 0.2
        return max(0.0, base_intensity - exempt_factor - ceasefire_factor - us_factor)
    return base_intensity


def compute_attack_rate(t: float, blockade_intensity: float) -> float:
    """Compute attack rate (attacks per day) based on phase."""
    phase = get_phase(t)
    # Scale attack rate by blockade intensity relative to 1.0
    intensity_scale = blockade_intensity

    if phase == 0:
        return 0.0
    elif phase == 1:
        return 5.0 * intensity_scale
    elif phase == 2:
        return 1.5 * intensity_scale
    elif phase == 3:
        return 0.5 * intensity_scale
    elif phase == 4:
        return 0.3 * intensity_scale
    elif phase == 5:
        return 0.1 * intensity_scale
    elif phase == 6:
        return 0.25 * intensity_scale
    return 0.0


def get_attack_type(t: float) -> str:
    """Return dominant attack type for the given day."""
    phase = get_phase(t)
    if phase in [1, 2]:
        return "missile"
    elif phase == 3:
        return "drone"
    else:
        return "mine"


def run_scenario(scenario_cfg: Dict[str, Any], scenario_index: int) -> List[Dict[str, Any]]:
    """
    Run the Hormuz crisis dynamical system simulation for one scenario.
    Returns a list of row dicts, one per day.
    """
    np.random.seed(scenario_index)

    # Extract parameters with overrides
    overrides = scenario_cfg.get("param_overrides", {})
    label = scenario_cfg["label"]

    T_max = int(overrides.get("simulation_duration_days", 49))
    dt = 1.0

    # Scenario-specific parameters
    max_exempt_pct = float(overrides.get("exempt_traffic_pct", 0.0))
    max_pipeline_pct = float(overrides.get("pipeline_diversion_pct", 0.0))
    base_blockade_intensity = float(overrides.get("blockade_intensity", 1.0))
    peak_ins_mult = float(overrides.get("peak_insurance_multiplier", 6.0))

    # Constants
    baseline_flow = 20.0
    baseline_price = 75.0
    baseline_insurance = 0.125  # pct of hull value
    VLCC_hull_value = 100e6
    price_recovery_rate = 0.15
    price_fundamental_slope = 3.5
    fear_premium_coeff = 15.0

    # State initialization
    price = baseline_price
    ins_mult = 1.0
    anchored = 0.0
    cumulative_attacks = 0.0

    rows = []

    # Simulate from day 0 to T_max (inclusive)
    for day in range(0, T_max + 1):
        t = float(day)
        phase = get_phase(t)
        phase_label = get_phase_label(phase)

        # --- 1. BLOCKADE INTENSITY ---
        B = compute_blockade_intensity(t, base_blockade_intensity, max_exempt_pct)
        B = float(np.clip(B, 0.0, 1.0))

        # --- 2. INSURANCE MULTIPLIER ---
        if phase in [1, 2]:
            # Rapid surge during initial phases
            ins_mult = min(peak_ins_mult, ins_mult + 0.8 * B * dt)
        elif phase == 3:
            # Sustained plateau with slight increase
            ins_mult = min(peak_ins_mult, ins_mult + 0.1 * B * dt)
        elif phase in [4, 5, 6]:
            # Decay as blockade eases
            decay_rate = 0.03 * (1.0 - B)
            ins_mult = ins_mult * math.exp(-decay_rate * dt)
            ins_mult = max(1.0, ins_mult)

        ins_mult = float(np.clip(ins_mult, 1.0, 50.0))
        insurance_cost_per_vlcc = (ins_mult * baseline_insurance / 100.0) * VLCC_hull_value

        # --- 3. TANKER TRAFFIC ---
        # Direct suppression by blockade
        traffic_base = 100.0 * (1.0 - B)

        # Exemption boost only in phases 4+
        exempt_active = 1.0 if phase >= 4 else 0.0
        # Ramp in exemptions over phase 4 start
        if phase == 4:
            days_into_phase4 = t - 26.0
            exempt_ramp = min(1.0, days_into_phase4 / 5.0) if days_into_phase4 >= 0 else 0.0
        elif phase >= 5:
            exempt_ramp = 1.0
        else:
            exempt_ramp = 0.0

        exemption_boost = max_exempt_pct * exempt_ramp * exempt_active

        traffic = traffic_base + exemption_boost

        # Economic suppression from high insurance
        if ins_mult > 3.0:
            econ_suppression = min(30.0, (ins_mult - 3.0) / 3.0 * 30.0)
        else:
            econ_suppression = 0.0

        traffic = traffic - econ_suppression
        traffic = float(np.clip(traffic, 0.0, 100.0))

        # Effective exempt traffic (capped at scenario max)
        effective_exempt = min(max_exempt_pct, exemption_boost)
        effective_exempt = float(np.clip(effective_exempt, 0.0, 40.0))

        # --- 4. PIPELINE DIVERSION ---
        if t < 10.0:
            pipeline_pct = 0.0
        else:
            ramp_progress = min(1.0, (t - 10.0) / 15.0)
            pipeline_pct = max_pipeline_pct * ramp_progress

        pipeline_pct = float(np.clip(pipeline_pct, 0.0, 45.0))

        # --- 5. EFFECTIVE FLOW AND SUPPLY GAP ---
        strait_flow = baseline_flow * traffic / 100.0
        diverted_flow = baseline_flow * pipeline_pct / 100.0
        total_flow = strait_flow + diverted_flow
        total_flow = min(baseline_flow, total_flow)
        supply_gap = max(0.0, baseline_flow - total_flow)

        # --- 6. OIL PRICE ---
        price_fundamental = baseline_price + price_fundamental_slope * supply_gap
        fear_premium = fear_premium_coeff * B
        price_target = price_fundamental + fear_premium
        price_target = float(np.clip(price_target, 60.0, 150.0))

        # Mean-reversion update
        price = price + price_recovery_rate * (price_target - price) * dt
        price = float(np.clip(price, 60.0, 150.0))

        brent_pct_change = (price - baseline_price) / baseline_price * 100.0

        # --- 7. SHIPS ANCHORED ---
        daily_arrivals = 20.0 * B
        daily_departures = 20.0 * (1.0 - B) * 0.3

        anchored = anchored + daily_arrivals - daily_departures

        # Decay after exemptions
        if phase >= 4:
            anchored *= 0.92

        anchored = float(np.clip(anchored, 0.0, 200.0))

        # --- 8. ATTACK COUNTS ---
        attack_rate = compute_attack_rate(t, B)
        # Deterministic with Poisson noise scaled by scenario index variation
        if attack_rate > 0:
            attacks_today = float(np.random.poisson(attack_rate * dt))
        else:
            attacks_today = 0.0

        cumulative_attacks += attacks_today
        cumulative_attacks = float(np.clip(cumulative_attacks, 0.0, 50.0))

        # --- 9. SECONDARY COMMODITIES ---
        lng_flow_pct = traffic  # correlated with tanker traffic
        fertilizer_flow_pct = traffic  # same disruption fraction

        # --- FLAGS ---
        ceasefire_active = 1 if phase == 5 else 0
        us_blockade_active = 1 if phase == 6 else 0

        # Exemption nations active
        if phase >= 4:
            exemption_nations = "China,India,Russia,Iraq,Pakistan"
        else:
            exemption_nations = ""

        # Date computation (day 0 = Feb 28, 2026)
        import datetime
        base_date = datetime.date(2026, 2, 28)
        current_date = base_date + datetime.timedelta(days=day)
        date_str = current_date.strftime("%Y-%m-%d")

        # Attack type
        attack_type = get_attack_type(t)

        row = {
            "day": day,
            "date": date_str,
            "scenario": label,
            "phase": phase_label,
            "blockade_intensity": round(B, 4),
            "tanker_traffic_pct": round(traffic, 4),
            "exempt_traffic_pct": round(effective_exempt, 4),
            "pipeline_diversion_pct": round(pipeline_pct, 4),
            "effective_flow_mbd": round(total_flow, 4),
            "supply_gap_mbd": round(supply_gap, 4),
            "brent_crude_price": round(price, 4),
            "brent_pct_change_from_baseline": round(brent_pct_change, 4),
            "war_risk_insurance_multiplier": round(ins_mult, 4),
            "insurance_cost_per_vlcc_usd": round(insurance_cost_per_vlcc, 2),
            "ships_attacked_daily": round(attacks_today, 0),
            "ships_attacked_cumulative": round(cumulative_attacks, 0),
            "ships_anchored_outside": round(anchored, 2),
            "attack_type_missile_drone_mine": attack_type,
            "exemption_nations_active": exemption_nations,
            "ceasefire_active": ceasefire_active,
            "us_blockade_active": us_blockade_active,
            "lng_flow_pct_baseline": round(lng_flow_pct, 4),
            "fertilizer_flow_pct_baseline": round(fertilizer_flow_pct, 4),
        }
        rows.append(row)

    return rows


def run_all_scenarios() -> Dict[str, List[Dict[str, Any]]]:
    """Run all scenarios and return results keyed by scenario label."""
    results = {}
    for idx, scenario_cfg in enumerate(MODEL_PROFILE["scenarios"]):
        label = scenario_cfg["label"]
        rows = run_scenario(scenario_cfg, scenario_index=idx)
        results[label] = rows
    return results


# =============================================================================
# CSV WRITING
# =============================================================================

FIELDNAMES = [
    "day", "date", "scenario", "phase", "blockade_intensity",
    "tanker_traffic_pct", "exempt_traffic_pct", "pipeline_diversion_pct",
    "effective_flow_mbd", "supply_gap_mbd", "brent_crude_price",
    "brent_pct_change_from_baseline", "war_risk_insurance_multiplier",
    "insurance_cost_per_vlcc_usd", "ships_attacked_daily",
    "ships_attacked_cumulative", "ships_anchored_outside",
    "attack_type_missile_drone_mine", "exemption_nations_active",
    "ceasefire_active", "us_blockade_active",
    "lng_flow_pct_baseline", "fertilizer_flow_pct_baseline"
]


def write_simulation_outputs_csv(all_rows: List[Dict[str, Any]], output_dir: Path) -> None:
    """Write the combined simulation_outputs.csv."""
    if not all_rows:
        print("WARNING: No simulation rows to write.")
        return

    filepath = output_dir / "simulation_outputs.csv"
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()
            for row in all_rows:
                writer.writerow(row)
        print(f"Wrote {len(all_rows)} rows to {filepath}")
    except Exception as e:
        print(f"WARNING: Failed to write simulation_outputs.csv: {e}")


def write_scenario_summary_csv(results: Dict[str, List[Dict[str, Any]]], output_dir: Path) -> None:
    """Write scenario_summary.csv with aggregate metrics per scenario."""
    numeric_cols = [
        "tanker_traffic_pct", "brent_crude_price", "war_risk_insurance_multiplier",
        "ships_attacked_cumulative", "ships_anchored_outside", "pipeline_diversion_pct",
        "supply_gap_mbd", "effective_flow_mbd", "blockade_intensity",
        "exempt_traffic_pct", "insurance_cost_per_vlcc_usd"
    ]

    summary_rows = []
    for label, rows in results.items():
        if not rows:
            continue
        row_summary = {"scenario": label, "n_days": len(rows)}
        for col in numeric_cols:
            vals = np.array([r[col] for r in rows if col in r], dtype=float)
            if len(vals) > 0:
                row_summary[f"{col}_mean"] = round(float(np.mean(vals)), 4)
                row_summary[f"{col}_std"] = round(float(np.std(vals)), 4)
                row_summary[f"{col}_min"] = round(float(np.min(vals)), 4)
                row_summary[f"{col}_max"] = round(float(np.max(vals)), 4)
            else:
                row_summary[f"{col}_mean"] = 0.0
                row_summary[f"{col}_std"] = 0.0
                row_summary[f"{col}_min"] = 0.0
                row_summary[f"{col}_max"] = 0.0
        # Final day metrics
        final_row = rows[-1]
        row_summary["final_day"] = final_row["day"]
        row_summary["final_brent_price"] = final_row["brent_crude_price"]
        row_summary["final_cumulative_attacks"] = final_row["ships_attacked_cumulative"]
        row_summary["final_traffic_pct"] = final_row["tanker_traffic_pct"]
        row_summary["final_insurance_mult"] = final_row["war_risk_insurance_multiplier"]
        summary_rows.append(row_summary)

    if not summary_rows:
        print("WARNING: No summary rows to write.")
        return

    # Determine all fieldnames
    all_keys = list(summary_rows[0].keys())

    filepath = output_dir / "scenario_summary.csv"
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=all_keys)
            writer.writeheader()
            for row in summary_rows:
                writer.writerow(row)
        print(f"Wrote scenario_summary.csv with {len(summary_rows)} scenarios.")
    except Exception as e:
        print(f"WARNING: Failed to write scenario_summary.csv: {e}")


def write_parameters_csv(output_dir: Path) -> None:
    """Write parameters_used.csv."""
    params = MODEL_PROFILE["parameters"]
    rows = []
    for name, info in params.items():
        rows.append({
            "name": name,
            "value": info.get("value", ""),
            "unit": info.get("unit", ""),
            "source": info.get("source", "assumed"),
            "description": info.get("description", "")
        })

    if not rows:
        print("WARNING: No parameter rows to write.")
        return

    filepath = output_dir / "parameters_used.csv"
    try:
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["name", "value", "unit", "source", "description"])
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
        print(f"Wrote parameters_used.csv with {len(rows)} parameters.")
    except Exception as e:
        print(f"WARNING: Failed to write parameters_used.csv: {e}")


# =============================================================================
# FIGURE GENERATION
# =============================================================================

SCENARIO_COLORS = {
    "Full_Blockade_No_Exemptions": "#d62728",
    "Partial_Exemptions_China_India_Russia": "#ff7f0e",
    "Ceasefire_Partial_Reopening": "#2ca02c",
    "US_Naval_Blockade_Freedom_of_Navigation": "#1f77b4",
    "Prolonged_Closure_Historical_Comparison": "#9467bd",
}

SCENARIO_STYLES = {
    "Full_Blockade_No_Exemptions": "-",
    "Partial_Exemptions_China_India_Russia": "--",
    "Ceasefire_Partial_Reopening": "-.",
    "US_Naval_Blockade_Freedom_of_Navigation": ":",
    "Prolonged_Closure_Historical_Comparison": (0, (5, 1)),
}


def extract_series(rows: List[Dict], x_col: str, y_col: str):
    """Extract matched x, y arrays from rows."""
    x_vals = []
    y_vals = []
    for r in rows:
        if x_col in r and y_col in r:
            x_vals.append(r[x_col])
            y_vals.append(r[y_col])
    return np.array(x_vals, dtype=float), np.array(y_vals, dtype=float)


def fig1_tanker_traffic(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 1: Daily tanker traffic through strait (% of baseline)."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for label, rows in results.items():
            if not rows:
                continue
            x, y = extract_series(rows, "day", "tanker_traffic_pct")
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0:
                continue
            color = SCENARIO_COLORS.get(label, "gray")
            ls = SCENARIO_STYLES.get(label, "-")
            ax.plot(x, y, label=label.replace("_", " "), color=color, linestyle=ls, linewidth=2)

        ax.axhline(y=30, color="gray", linestyle=":", alpha=0.5, label="30% threshold")
        ax.axvline(x=26, color="purple", linestyle="--", alpha=0.4, label="Day 26: Exemptions announced")
        ax.axvline(x=39, color="green", linestyle="--", alpha=0.4, label="Day 39: Ceasefire")
        ax.axvline(x=44, color="blue", linestyle="--", alpha=0.4, label="Day 44: US Naval Op")

        ax.set_xlabel("Day (0 = Feb 28, 2026)", fontsize=12)
        ax.set_ylabel("Tanker Traffic (% of Baseline)", fontsize=12)
        ax.set_title("Daily Tanker Traffic Through Strait of Hormuz (% of Baseline)", fontsize=14)
        ax.set_ylim(0, 105)
        ax.legend(loc="upper right", fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = output_dir / "fig1_tanker_traffic.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig1 failed: {e}")
        plt.close("all")


def fig2_brent_crude_price(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 2: Brent crude oil price during crisis."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for label, rows in results.items():
            if not rows:
                continue
            x, y = extract_series(rows, "day", "brent_crude_price")
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0:
                continue
            color = SCENARIO_COLORS.get(label, "gray")
            ls = SCENARIO_STYLES.get(label, "-")
            ax.plot(x, y, label=label.replace("_", " "), color=color, linestyle=ls, linewidth=2)

        ax.axhline(y=100, color="red", linestyle="--", alpha=0.7, linewidth=1.5, label="$100/bbl threshold")
        ax.axhline(y=126, color="darkred", linestyle="--", alpha=0.7, linewidth=1.5, label="$126/bbl peak")
        ax.axvline(x=8, color="orange", linestyle=":", alpha=0.6, label="Day 8: $100 crossed (8 March)")

        ax.set_xlabel("Day (0 = Feb 28, 2026)", fontsize=12)
        ax.set_ylabel("Brent Crude Price (USD/barrel)", fontsize=12)
        ax.set_title("Brent Crude Oil Price During Hormuz Crisis (USD/barrel)", fontsize=14)
        ax.set_ylim(60, 155)
        ax.legend(loc="upper left", fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = output_dir / "fig2_brent_crude_price.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig2 failed: {e}")
        plt.close("all")


def fig3_insurance_multiplier(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 3: War-risk insurance premium multiplier."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for label, rows in results.items():
            if not rows:
                continue
            x, y = extract_series(rows, "day", "war_risk_insurance_multiplier")
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0:
                continue
            color = SCENARIO_COLORS.get(label, "gray")
            ls = SCENARIO_STYLES.get(label, "-")
            ax.plot(x, y, label=label.replace("_", " "), color=color, linestyle=ls, linewidth=2)

        ax.axhline(y=3, color="orange", linestyle="--", alpha=0.6, label="3x economic closure threshold")
        ax.axhline(y=6, color="red", linestyle="--", alpha=0.6, label="6x peak multiplier (extracted)")
        ax.axvline(x=9, color="gray", linestyle=":", alpha=0.5, label="Day 9: Full insurance impact")

        ax.set_xlabel("Day (0 = Feb 28, 2026)", fontsize=12)
        ax.set_ylabel("Insurance Multiplier (x baseline)", fontsize=12)
        ax.set_title("War-Risk Insurance Premium Multiplier Over Time", fontsize=14)
        ax.set_ylim(0.5, 12)
        ax.legend(loc="upper right", fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = output_dir / "fig3_insurance_multiplier.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig3 failed: {e}")
        plt.close("all")


def fig4_cumulative_attacks(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 4: Cumulative ship attacks."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for label, rows in results.items():
            if not rows:
                continue
            x, y = extract_series(rows, "day", "ships_attacked_cumulative")
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0:
                continue
            color = SCENARIO_COLORS.get(label, "gray")
            ls = SCENARIO_STYLES.get(label, "-")
            ax.step(x, y, label=label.replace("_", " "), color=color, linestyle=ls, linewidth=2, where="post")

        ax.axhline(y=31, color="black", linestyle="--", alpha=0.7, label="31 confirmed attacks (extracted)")
        ax.axvline(x=4, color="red", linestyle=":", alpha=0.5, label="Day 4: End of initial surge")

        ax.set_xlabel("Day (0 = Feb 28, 2026)", fontsize=12)
        ax.set_ylabel("Cumulative Ship Attacks (count)", fontsize=12)
        ax.set_title("Cumulative Ship Attacks (Confirmed) Over Crisis Duration", fontsize=14)
        ax.legend(loc="upper left", fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = output_dir / "fig4_cumulative_attacks.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig4 failed: {e}")
        plt.close("all")


def fig5_ships_anchored(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 5: Ships anchored outside strait."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for label, rows in results.items():
            if not rows:
                continue
            x, y = extract_series(rows, "day", "ships_anchored_outside")
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0:
                continue
            color = SCENARIO_COLORS.get(label, "gray")
            ls = SCENARIO_STYLES.get(label, "-")
            ax.plot(x, y, label=label.replace("_", " "), color=color, linestyle=ls, linewidth=2)

        ax.axhline(y=150, color="red", linestyle="--", alpha=0.7, label="150 ships peak (extracted)")
        ax.axvline(x=26, color="green", linestyle=":", alpha=0.5, label="Day 26: Exemptions start clearance")

        ax.set_xlabel("Day (0 = Feb 28, 2026)", fontsize=12)
        ax.set_ylabel("Ships Anchored Outside Strait (count)", fontsize=12)
        ax.set_title("Ships Anchored Outside Strait Awaiting Passage", fontsize=14)
        ax.set_ylim(0, 210)
        ax.legend(loc="upper right", fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = output_dir / "fig5_ships_anchored.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig5 failed: {e}")
        plt.close("all")


def fig6_pipeline_diversion(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 6: Alternative pipeline diversion %."""
    try:
        fig, ax = plt.subplots(figsize=(12, 6))

        for label, rows in results.items():
            if not rows:
                continue
            x, y = extract_series(rows, "day", "pipeline_diversion_pct")
            assert len(x) == len(y), f"Array length mismatch for {label}"
            if len(x) == 0:
                continue
            color = SCENARIO_COLORS.get(label, "gray")
            ls = SCENARIO_STYLES.get(label, "-")
            ax.plot(x, y, label=label.replace("_", " "), color=color, linestyle=ls, linewidth=2)

        ax.axhline(y=45, color="black", linestyle="--", alpha=0.7, label="45% maximum (9 Mb/d physical ceiling)")
        ax.axvline(x=10, color="blue", linestyle=":", alpha=0.5, label="Day 10: Pipeline rerouting begins")

        ax.set_xlabel("Day (0 = Feb 28, 2026)", fontsize=12)
        ax.set_ylabel("Pipeline Diversion (% of Strait Capacity)", fontsize=12)
        ax.set_title("Alternative Pipeline Diversion (% of Blocked Strait Capacity)", fontsize=14)
        ax.set_ylim(-1, 50)
        ax.legend(loc="upper left", fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

        plt.tight_layout()
        out_path = output_dir / "fig6_pipeline_diversion.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig6 failed: {e}")
        plt.close("all")


def fig7_scenario_heatmap(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 7: Scenario comparison heatmap at day 30."""
    try:
        metrics = [
            "tanker_traffic_pct", "brent_crude_price", "war_risk_insurance_multiplier",
            "ships_attacked_cumulative", "ships_anchored_outside", "pipeline_diversion_pct"
        ]
        metric_labels = [
            "Tanker Traffic %", "Brent Price ($/bbl)", "Insurance Multiplier",
            "Cumulative Attacks", "Ships Anchored", "Pipeline Diversion %"
        ]

        scenario_labels = list(results.keys())
        n_scenarios = len(scenario_labels)
        n_metrics = len(metrics)

        target_day = 30
        data_matrix = np.zeros((n_scenarios, n_metrics))

        for i, label in enumerate(scenario_labels):
            rows = results[label]
            # Find row closest to day 30
            day_rows = [r for r in rows if r["day"] == target_day]
            if not day_rows:
                # Find closest day
                available_days = [r["day"] for r in rows]
                closest_day = min(available_days, key=lambda d: abs(d - target_day))
                day_rows = [r for r in rows if r["day"] == closest_day]

            if day_rows:
                row = day_rows[0]
                for j, metric in enumerate(metrics):
                    data_matrix[i, j] = float(row.get(metric, 0.0))

        # Normalize each metric column by its maximum across scenarios
        col_maxs = np.max(data_matrix, axis=0)
        col_maxs[col_maxs == 0] = 1.0  # avoid division by zero
        norm_matrix = data_matrix / col_maxs

        fig, ax = plt.subplots(figsize=(12, 6))
        im = ax.imshow(norm_matrix, cmap="RdYlGn_r", aspect="auto", vmin=0, vmax=1)

        ax.set_xticks(range(n_metrics))
        ax.set_xticklabels(metric_labels, rotation=30, ha="right", fontsize=10)
        ax.set_yticks(range(n_scenarios))
        ax.set_yticklabels([s.replace("_", " ") for s in scenario_labels], fontsize=9)

        # Add value annotations
        for i in range(n_scenarios):
            for j in range(n_metrics):
                val = data_matrix[i, j]
                if val >= 1000:
                    txt = f"{val:.0f}"
                elif val >= 10:
                    txt = f"{val:.1f}"
                else:
                    txt = f"{val:.2f}"
                ax.text(j, i, txt, ha="center", va="center", fontsize=8,
                        color="black" if norm_matrix[i, j] < 0.7 else "white")

        plt.colorbar(im, ax=ax, label="Normalized Value (0=best, 1=worst)")
        ax.set_title(f"Scenario Comparison Heatmap: Key Crisis Metrics at Day {target_day}", fontsize=13)

        plt.tight_layout()
        out_path = output_dir / "fig7_scenario_heatmap.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig7 failed: {e}")
        plt.close("all")


def fig8_oil_price_vs_traffic(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Fig 8: Oil price vs strait traffic scatter (supply-shock relationship)."""
    try:
        markers = ["o", "s", "^", "D", "v"]
        fig, ax = plt.subplots(figsize=(10, 8))

        for idx, (label, rows) in enumerate(results.items()):
            if not rows:
                continue
            x_arr, y_arr = extract_series(rows, "tanker_traffic_pct", "brent_crude_price")
            day_arr, _ = extract_series(rows, "day", "brent_crude_price")

            assert len(x_arr) == len(y_arr), f"Array length mismatch for {label}"
            if len(x_arr) == 0:
                continue

            # Color by day
            n_pts = len(x_arr)
            norm = Normalize(vmin=0, vmax=max(day_arr) if len(day_arr) > 0 else 90)
            cmap = cm.get_cmap("plasma")
            colors = [cmap(norm(d)) for d in day_arr[:n_pts]]

            marker = markers[idx % len(markers)]
            sc = ax.scatter(x_arr, y_arr, c=day_arr[:n_pts], cmap="plasma",
                            marker=marker, s=40, alpha=0.7, label=label.replace("_", " "),
                            vmin=0, vmax=max(90, max(day_arr) if len(day_arr) > 0 else 90))

        # Reference lines
        ax.axhline(y=100, color="red", linestyle="--", alpha=0.5, linewidth=1, label="$100/bbl")
        ax.axhline(y=126, color="darkred", linestyle="--", alpha=0.5, linewidth=1, label="$126/bbl peak")
        ax.axvline(x=30, color="gray", linestyle=":", alpha=0.5, linewidth=1)

        ax.set_xlabel("Tanker Traffic (% of Baseline)", fontsize=12)
        ax.set_ylabel("Brent Crude Price (USD/barrel)", fontsize=12)
        ax.set_title("Oil Price vs. Strait Traffic: Supply-Shock Relationship", fontsize=13)
        ax.set_xlim(-2, 102)
        ax.set_ylim(58, 155)
        ax.legend(loc="upper right", fontsize=8)
        ax.grid(True, alpha=0.3)

        # Colorbar
        sm = cm.ScalarMappable(cmap="plasma", norm=Normalize(vmin=0, vmax=90))
        sm.set_array([])
        plt.colorbar(sm, ax=ax, label="Day number (0=crisis onset)")

        plt.tight_layout()
        out_path = output_dir / "fig8_price_vs_traffic.png"
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved {out_path}")
    except Exception as e:
        print(f"WARNING: fig8 failed: {e}")
        plt.close("all")


# =============================================================================
# SUMMARY JSON
# =============================================================================

def write_summary_json(results: Dict[str, List[Dict]], output_dir: Path) -> None:
    """Write summary.json with key aggregate metrics."""
    summary = {
        "title": "2026 Strait of Hormuz Crisis Simulation",
        "scenarios": {}
    }

    for label, rows in results.items():
        if not rows:
            continue
        prices = np.array([r["brent_crude_price"] for r in rows], dtype=float)
        traffic = np.array([r["tanker_traffic_pct"] for r in rows], dtype=float)
        ins_mult = np.array([r["war_risk_insurance_multiplier"] for r in rows], dtype=float)
        attacks = np.array([r["ships_attacked_cumulative"] for r in rows], dtype=float)
        anchored = np.array([r["ships_anchored_outside"] for r in rows], dtype=float)

        final = rows[-1]
        summary["scenarios"][label] = {
            "n_days": len(rows),
            "final_day": int(final["day"]),
            "brent_price_mean": round(float(np.mean(prices)), 2),
            "brent_price_max": round(float(np.max(prices)), 2),
            "brent_price_final": round(float(final["brent_crude_price"]), 2),
            "traffic_mean": round(float(np.mean(traffic)), 2),
            "traffic_min": round(float(np.min(traffic)), 2),
            "traffic_final": round(float(final["tanker_traffic_pct"]), 2),
            "insurance_max": round(float(np.max(ins_mult)), 2),
            "insurance_final": round(float(final["war_risk_insurance_multiplier"]), 2),
            "cumulative_attacks_final": round(float(final["ships_attacked_cumulative"]), 0),
            "ships_anchored_max": round(float(np.max(anchored)), 1),
            "ships_anchored_final": round(float(final["ships_anchored_outside"]), 1),
        }

    summary["calibration_anchors"] = {
        "brent_crosses_100_day": 8,
        "brent_peak_day": 22,
        "brent_peak_value": 126.0,
        "traffic_initial_drop_pct": 70.0,
        "total_confirmed_attacks": 31,
        "ships_anchored_peak": 150
    }

    filepath = output_dir / "summary.json"
    try:
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        print(f"Saved summary.json")
    except Exception as e:
        print(f"WARNING: Failed to write summary.json: {e}")


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="2026 Strait of Hormuz Crisis Dynamical System Simulator"
    )
    parser.add_argument("--output", type=str, default="./sim_outputs",
                        help="Output directory for all files (default: ./sim_outputs)")
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    # --- Run all scenarios ---
    print("\n=== Running simulations ===")
    results = run_all_scenarios()
    for label, rows in results.items():
        print(f"  Scenario '{label}': {len(rows)} days simulated")

    # --- Combine all rows ---
    all_rows = []
    for label, rows in results.items():
        all_rows.extend(rows)

    # --- Write CSVs ---
    print("\n=== Writing CSV files ===")
    write_simulation_outputs_csv(all_rows, output_dir)
    write_scenario_summary_csv(results, output_dir)
    write_parameters_csv(output_dir)

    # --- Generate figures ---
    print("\n=== Generating figures ===")
    fig1_tanker_traffic(results, output_dir)
    fig2_brent_crude_price(results, output_dir)
    fig3_insurance_multiplier(results, output_dir)
    fig4_cumulative_attacks(results, output_dir)
    fig5_ships_anchored(results, output_dir)
    fig6_pipeline_diversion(results, output_dir)
    fig7_scenario_heatmap(results, output_dir)
    fig8_oil_price_vs_traffic(results, output_dir)

    # --- Write summary JSON ---
    print("\n=== Writing summary JSON ===")
    write_summary_json(results, output_dir)

    print(f"\n=== Simulation complete. All outputs in: {output_dir.resolve()} ===")


if __name__ == "__main__":
    main()