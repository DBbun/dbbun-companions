================================================================
    DBbun LLC — Executable Publication Layer
    Simulator Bundle  |  paper_to_simulator_builder v3.4.0
    ================================================================
    Vendor      : DBbun LLC  |  dbbun.com
    CAGE        : 16VU3   |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
    Run ID      : d409bac0-2828-49fc-ab94-bb969bcbbdfa
    Generated   : 2026-05-02  23:17:14 UTC
    © 2024-2025 DBbun LLC. All rights reserved.
    ================================================================

    TITLE
    -----
    Transformer Full Architecture — Encoder-Decoder Attention Mechanism

    CATEGORIES
    ----------
    Artificial Intelligence, Machine Learning, Signal Processing

    KEYWORDS
    --------
    Transformer, multi-head attention, encoder-decoder, positional encoding, attention entropy

    ABSTRACT
    --------
    This simulator faithfully reproduces the forward-pass information flow of the full Transformer encoder-decoder architecture as depicted in the canonical architecture diagram, including sinusoidal positional encodings, multi-headed self-attention, masked causal self-attention, cross-attention, residual connections, layer normalization, and position-wise feed-forward networks. It generates synthetic attention weight matrices, residual stream norms, and attention entropy profiles across all encoder and decoder layers for multiple architectural configurations. Researchers can use the simulator to study how hyperparameters such as number of heads, model depth, and attention temperature affect information routing, attention sharpness, and representational diversity without training a full language model. Students can visualize attention alignment patterns and positional encoding structures interactively. Engineers can benchmark architectural variants to inform hyperparameter search prior to expensive training runs.

    DATA FORMAT
    -----------
    CSV, PNG, JSON

    SOURCE FILES
    ------------
    Transformer,_full_architecture.png

    SIMULATION BACKEND
    ------------------
    dynamical_system

    STATE VARIABLES
    ---------------
    X_enc, X_dec, A_self_enc, A_self_dec, A_cross, PE, layer_index, entropy_self_enc, entropy_cross, residual_norm_enc, residual_norm_dec

    SCENARIOS  (7 total)
    ---------------------------------
        1. baseline_6L_8H_512D — Default Transformer: 6 layers, 8 heads, d_model=512. Baseline attention patterns and residual norms.
2. shallow_2L_8H_512D — Reduced depth: 2 encoder/decoder layers to study how attention entropy changes with shallower networks.
3. narrow_6L_4H_256D — Smaller model: 4 heads, d_model=256, d_ff=1024 — study how reduced width affects attention sharpness.
4. wide_6L_16H_512D — More heads: 16 heads while keeping d_model=512, d_k=32 — examines head diversity and entropy.
5. deep_12L_8H_512D — Deeper model: 12 layers (BERT-base equivalent) to study residual norm growth and attention entropy decay.
6. high_temperature — Temperature scaling > 1 (softer attention) to study entropy and information flow differences.
7. low_temperature — Temperature scaling < 1 (sharper attention) to study peaked attention patterns.

    PARAMETERS
    ----------
    12 parameters (see simulation_spec.json for full list with units and sources)

    FIGURES PLANNED
    ---------------
    fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig10

    DOMAIN SUMMARY
    --------------
    The source describes the full Transformer encoder-decoder architecture, including multi-headed self-attention, masked multi-headed self-attention, cross-attention, feed-forward sublayers, residual connections, layer normalization, and positional encodings used for sequence-to-sequence modelling.

    FILES IN THIS BUNDLE
    --------------------
    Simulator.py          — runnable document-specific simulator (Python)
    Spec.json    — full analysis spec with DBbun provenance (JSON)
    Documentation.pdf       — auto-generated simulator documentation (PDF)
    README.txt                  — this file
    NOTICE.txt              — legal ownership notice
    sim_outputs/            — CSV datasets, PNG figures, summary.json
      simulation_outputs.csv      — full per-step simulation rows
      scenario_summary.csv        — one row per scenario with aggregate KPIs
      parameters_used.csv         — reproducibility / parameter provenance table
      summary.json                — key aggregate metrics
      *.png                       — publication-quality figures

    INSTRUCTIONS
    ------------
    Requirements:
        pip install numpy matplotlib

    Run with defaults:
        python Simulator.py

    Specify output directory:
        python Simulator.py --output ./my_results

    The simulator is self-contained — no API key or network access needed.
    All parameters are embedded in MODEL_PROFILE at the top of the script
    and can be edited directly to explore sensitivity or extend scenarios.

    See NOTICE.txt for full legal and licensing terms.