# =============================================================================
# DBbun LLC — Executable Publication Layer
# Tool      : paper_to_simulator_builder  v3.4.0
# Generated : 2026-05-02T23:17:14.801869Z
# Run ID    : d409bac0-2828-49fc-ab94-bb969bcbbdfa
#
# © 2024-2025 DBbun LLC. All rights reserved.  |  dbbun.com
# CAGE: 16VU3  |  UEI: QY39Y38E6WG8  |  Cambridge, MA, USA
#
# This simulator, synthetic datasets, and all derived intellectual property
# are the exclusive property of DBbun LLC.  Unauthorised reproduction,
# distribution, or commercial use is prohibited without prior written consent.
# =============================================================================
#
"""
Transformer Full Architecture — Encoder-Decoder Attention Mechanism Simulator

Simulates the forward-pass information flow of the full Transformer encoder-decoder
architecture, including sinusoidal positional encodings, multi-headed self-attention,
masked causal self-attention, cross-attention, residual connections, layer normalization,
and position-wise feed-forward networks.

Paper reference: "Attention Is All You Need" (Vaswani et al., 2017)
                 Transformer Full Architecture — Encoder-Decoder Attention Mechanism
"""

import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Tuple

# ============================================================
# MODEL PROFILE
# ============================================================
MODEL_PROFILE = {
    "parameters": {
        "d_model": {"value": 512.0, "unit": "dimensionless", "source": "extracted",
                    "description": "Model embedding / hidden dimension from original Transformer paper"},
        "num_heads": {"value": 8.0, "unit": "dimensionless", "source": "extracted",
                      "description": "Number of attention heads in multi-head attention"},
        "d_k": {"value": 64.0, "unit": "dimensionless", "source": "extracted",
                "description": "Dimension per attention head (d_model / num_heads)"},
        "d_v": {"value": 64.0, "unit": "dimensionless", "source": "extracted",
                "description": "Value dimension per head"},
        "d_ff": {"value": 2048.0, "unit": "dimensionless", "source": "extracted",
                 "description": "Inner dimension of the position-wise feed-forward network"},
        "num_layers": {"value": 6.0, "unit": "dimensionless", "source": "extracted",
                       "description": "Number of encoder layers (Nx) and separately decoder layers (Nx)"},
        "seq_len": {"value": 20.0, "unit": "tokens", "source": "assumed",
                    "description": "Source sequence length used in simulation"},
        "tgt_len": {"value": 20.0, "unit": "tokens", "source": "assumed",
                    "description": "Target sequence length used in simulation"},
        "dropout_rate": {"value": 0.1, "unit": "dimensionless", "source": "extracted",
                         "description": "Dropout probability applied in attention and FFN sublayers"},
        "temperature_scale": {"value": 1.0, "unit": "dimensionless", "source": "assumed",
                              "description": "Multiplicative scaling of 1/sqrt(d_k) softmax temperature"},
        "vocab_size": {"value": 1000.0, "unit": "dimensionless", "source": "assumed",
                       "description": "Vocabulary size for embedding simulation"},
        "init_std": {"value": 0.02, "unit": "dimensionless", "source": "assumed",
                     "description": "Standard deviation for random weight initialization"},
    },
    "scenarios": [
        {
            "label": "baseline_6L_8H_512D",
            "description": "Default Transformer: 6 layers, 8 heads, d_model=512.",
            "param_overrides": {"num_layers": 6, "num_heads": 8, "d_model": 512, "d_ff": 2048}
        },
        {
            "label": "shallow_2L_8H_512D",
            "description": "Reduced depth: 2 encoder/decoder layers.",
            "param_overrides": {"num_layers": 2, "num_heads": 8, "d_model": 512, "d_ff": 2048}
        },
        {
            "label": "narrow_6L_4H_256D",
            "description": "Smaller model: 4 heads, d_model=256, d_ff=1024.",
            "param_overrides": {"num_layers": 6, "num_heads": 4, "d_model": 256, "d_ff": 1024}
        },
        {
            "label": "wide_6L_16H_512D",
            "description": "More heads: 16 heads while keeping d_model=512.",
            "param_overrides": {"num_layers": 6, "num_heads": 16, "d_model": 512, "d_ff": 2048}
        },
        {
            "label": "deep_12L_8H_512D",
            "description": "Deeper model: 12 layers (BERT-base equivalent).",
            "param_overrides": {"num_layers": 12, "num_heads": 8, "d_model": 512, "d_ff": 2048}
        },
        {
            "label": "high_temperature",
            "description": "Temperature scaling > 1 (softer attention).",
            "param_overrides": {"num_layers": 6, "num_heads": 8, "d_model": 512, "temperature_scale": 2.0}
        },
        {
            "label": "low_temperature",
            "description": "Temperature scaling < 1 (sharper attention).",
            "param_overrides": {"num_layers": 6, "num_heads": 8, "d_model": 512, "temperature_scale": 0.5}
        },
    ]
}

# ============================================================
# CORE SIMULATION FUNCTIONS
# ============================================================

def sinusoidal_pe(seq_len: int, d_model: int) -> np.ndarray:
    """Compute sinusoidal positional encoding matrix."""
    PE = np.zeros((seq_len, d_model))
    pos = np.arange(seq_len)[:, None]       # (seq_len, 1)
    i = np.arange(d_model // 2)[None, :]   # (1, d_model/2)
    angle = pos / np.power(10000.0, 2 * i / d_model)
    PE[:, 0::2] = np.sin(angle)
    PE[:, 1::2] = np.cos(angle)
    return PE  # shape: (seq_len, d_model)


def scaled_dot_product_attention(
    Q: np.ndarray, K: np.ndarray, V: np.ndarray,
    d_k: int, temperature_scale: float = 1.0,
    mask: Optional[np.ndarray] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """Scaled dot-product attention with optional causal mask."""
    scale = temperature_scale / np.sqrt(float(d_k))
    scores = np.matmul(Q, K.swapaxes(-2, -1)) * scale
    if mask is not None:
        scores = np.where(mask, -1e9, scores)
    scores_max = scores.max(axis=-1, keepdims=True)
    exp_scores = np.exp(scores - scores_max)
    A = exp_scores / (exp_scores.sum(axis=-1, keepdims=True) + 1e-9)
    out = np.matmul(A, V)
    return A, out


def multihead_attention(
    X_q: np.ndarray, X_k: np.ndarray, X_v: np.ndarray,
    W_q: np.ndarray, W_k: np.ndarray, W_v: np.ndarray, W_o: np.ndarray,
    num_heads: int, d_k: int, d_v: int,
    temperature_scale: float = 1.0,
    mask: Optional[np.ndarray] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """Multi-head attention mechanism."""
    seq_q = X_q.shape[0]
    seq_k = X_k.shape[0]
    Q = (X_q @ W_q).reshape(seq_q, num_heads, d_k).transpose(1, 0, 2)
    K = (X_k @ W_k).reshape(seq_k, num_heads, d_k).transpose(1, 0, 2)
    V = (X_v @ W_v).reshape(seq_k, num_heads, d_v).transpose(1, 0, 2)
    A, context = scaled_dot_product_attention(Q, K, V, d_k,
                                              temperature_scale=temperature_scale,
                                              mask=mask)
    context_cat = context.transpose(1, 0, 2).reshape(seq_q, num_heads * d_v)
    out = context_cat @ W_o
    return A, out


def layer_norm(X: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """Layer normalization."""
    mu = X.mean(axis=-1, keepdims=True)
    sigma = X.std(axis=-1, keepdims=True) + eps
    return (X - mu) / sigma


def ffn(X: np.ndarray, W1: np.ndarray, b1: np.ndarray,
        W2: np.ndarray, b2: np.ndarray) -> np.ndarray:
    """Position-wise feed-forward network with ReLU."""
    hidden = np.maximum(0, X @ W1 + b1)
    return hidden @ W2 + b2


def attention_entropy(A: np.ndarray) -> np.ndarray:
    """Compute Shannon entropy (in nats) for attention weight distributions."""
    eps = 1e-9
    H = -(A * np.log(A + eps)).sum(axis=-1)
    return H


def init_weights(d_model: int, d_k: int, d_v: int, d_ff: int,
                 num_heads: int, rng: np.random.Generator,
                 std: float = 0.02) -> Tuple:
    """Initialize random projection matrices."""
    W_q = rng.normal(0, std, (d_model, num_heads * d_k))
    W_k = rng.normal(0, std, (d_model, num_heads * d_k))
    W_v = rng.normal(0, std, (d_model, num_heads * d_v))
    W_o = rng.normal(0, std, (num_heads * d_v, d_model))
    W1 = rng.normal(0, std, (d_model, d_ff))
    b1 = np.zeros(d_ff)
    W2 = rng.normal(0, std, (d_ff, d_model))
    b2 = np.zeros(d_model)
    return W_q, W_k, W_v, W_o, W1, b1, W2, b2


def causal_mask(tgt_len: int) -> np.ndarray:
    """Upper-triangular causal mask."""
    return np.triu(np.ones((tgt_len, tgt_len), dtype=bool), k=1)


def run_scenario(scenario_cfg: Dict[str, Any], rng_seed: int = 0) -> Dict[str, Any]:
    """
    Run the Transformer forward-pass simulation for a given scenario configuration.
    Returns records list plus key matrices for plotting.
    """
    np.random.seed(rng_seed)
    rng = np.random.default_rng(rng_seed)

    # Extract parameters with overrides
    d_model = int(scenario_cfg.get('d_model', 512))
    num_heads = int(scenario_cfg.get('num_heads', 8))
    d_ff = int(scenario_cfg.get('d_ff', 2048))
    N = int(scenario_cfg.get('num_layers', 6))
    seq_len = int(scenario_cfg.get('seq_len', 20))
    tgt_len = int(scenario_cfg.get('tgt_len', 20))
    temp = float(scenario_cfg.get('temperature_scale', 1.0))
    d_k = d_model // num_heads
    d_v = d_k
    std = float(scenario_cfg.get('init_std', 0.02))
    label = scenario_cfg['label']

    # Positional encodings
    PE_src = sinusoidal_pe(seq_len, d_model)
    PE_tgt = sinusoidal_pe(tgt_len, d_model)

    # Clamp PE to [-1, 1] as specified
    PE_src = np.clip(PE_src, -1.0, 1.0)
    PE_tgt = np.clip(PE_tgt, -1.0, 1.0)

    # Random token embeddings
    E_src = rng.normal(0, 1, (seq_len, d_model)) + PE_src
    E_tgt = rng.normal(0, 1, (tgt_len, d_model)) + PE_tgt

    records = []

    # =========================================================
    # ENCODER PASS
    # =========================================================
    X_enc = layer_norm(E_src)
    enc_norms = []
    enc_entropies = []  # list of (num_heads, seq_len) arrays
    A_self_last = None  # track last layer's self-attention for figures

    for layer in range(N):
        W_q, W_k, W_v, W_o, W1, b1, W2, b2 = init_weights(
            d_model, d_k, d_v, d_ff, num_heads, rng, std)
        A_self, attn_out = multihead_attention(
            X_enc, X_enc, X_enc,
            W_q, W_k, W_v, W_o,
            num_heads, d_k, d_v, temp)
        X_enc = layer_norm(X_enc + attn_out)
        ffn_out = ffn(X_enc, W1, b1, W2, b2)
        X_enc = layer_norm(X_enc + ffn_out)

        # Clamp X_enc to [-10, 10]
        X_enc = np.clip(X_enc, -10.0, 10.0)

        # Metrics
        norm_val = float(np.linalg.norm(X_enc) / (seq_len * d_model) ** 0.5)
        norm_val = float(np.clip(norm_val, 0.0, 50.0))
        enc_norms.append(norm_val)

        H = attention_entropy(A_self)  # (num_heads, seq_len)
        enc_entropies.append(H)
        A_self_last = A_self

        for h in range(num_heads):
            mean_H = float(np.clip(H[h].mean(), 0.0, 5.0))
            records.append({
                'scenario': label,
                'num_layers': N,
                'num_heads': num_heads,
                'd_model': d_model,
                'd_ff': d_ff,
                'd_k': d_k,
                'temperature_scale': temp,
                'component': 'encoder_self_attn',
                'layer_index': layer,
                'head_index': h,
                'seq_position': -1,
                'tgt_position': -1,
                'entropy_self_enc': mean_H,
                'entropy_self_dec': '',
                'entropy_cross': '',
                'residual_norm_enc': norm_val,
                'residual_norm_dec': '',
                'attention_weight_sample': float(A_self[h, seq_len // 2, :].mean()),
                'cross_attention_weight_sample': '',
                'pe_value_dim0': float(PE_src[seq_len // 2, 0]),
                'pe_value_dim1': float(PE_src[seq_len // 2, 1]),
                'pe_value_dim50': float(PE_src[seq_len // 2, min(50, d_model - 1)]),
                'pe_value_dim100': float(PE_src[seq_len // 2, min(100, d_model - 1)]),
                'mean_cross_attention_entropy': '',
            })

    # =========================================================
    # DECODER PASS
    # =========================================================
    X_dec = layer_norm(E_tgt)
    dec_norms = []
    cross_entropies_all = []
    mask = causal_mask(tgt_len)
    A_cross_last = None

    for layer in range(N):
        Wq1, Wk1, Wv1, Wo1, _, _, _, _ = init_weights(
            d_model, d_k, d_v, d_ff, num_heads, rng, std)
        Wq2, Wk2, Wv2, Wo2, W1, b1, W2, b2 = init_weights(
            d_model, d_k, d_v, d_ff, num_heads, rng, std)

        # Masked self-attention
        A_masked, self_out = multihead_attention(
            X_dec, X_dec, X_dec,
            Wq1, Wk1, Wv1, Wo1,
            num_heads, d_k, d_v, temp, mask)
        X_dec = layer_norm(X_dec + self_out)

        # Cross-attention
        A_cross, cross_out = multihead_attention(
            X_dec, X_enc, X_enc,
            Wq2, Wk2, Wv2, Wo2,
            num_heads, d_k, d_v, temp)
        X_dec = layer_norm(X_dec + cross_out)

        # FFN
        ffn_out = ffn(X_dec, W1, b1, W2, b2)
        X_dec = layer_norm(X_dec + ffn_out)

        # Clamp X_dec to [-10, 10]
        X_dec = np.clip(X_dec, -10.0, 10.0)

        norm_val = float(np.linalg.norm(X_dec) / (tgt_len * d_model) ** 0.5)
        norm_val = float(np.clip(norm_val, 0.0, 50.0))
        dec_norms.append(norm_val)

        H_self = attention_entropy(A_masked)   # (num_heads, tgt_len)
        H_cross = attention_entropy(A_cross)   # (num_heads, tgt_len)
        cross_entropies_all.append(H_cross)
        A_cross_last = A_cross

        for h in range(num_heads):
            mH_self = float(np.clip(H_self[h].mean(), 0.0, 5.0))
            mH_cross = float(np.clip(H_cross[h].mean(), 0.0, 5.0))
            records.append({
                'scenario': label,
                'num_layers': N,
                'num_heads': num_heads,
                'd_model': d_model,
                'd_ff': d_ff,
                'd_k': d_k,
                'temperature_scale': temp,
                'component': 'decoder',
                'layer_index': layer,
                'head_index': h,
                'seq_position': -1,
                'tgt_position': -1,
                'entropy_self_enc': '',
                'entropy_self_dec': mH_self,
                'entropy_cross': mH_cross,
                'residual_norm_enc': '',
                'residual_norm_dec': norm_val,
                'attention_weight_sample': float(A_masked[h, tgt_len // 2, :].mean()),
                'cross_attention_weight_sample': float(A_cross[h, tgt_len // 2, :].mean()),
                'pe_value_dim0': float(PE_tgt[tgt_len // 2, 0]),
                'pe_value_dim1': float(PE_tgt[tgt_len // 2, 1]),
                'pe_value_dim50': float(PE_tgt[tgt_len // 2, min(50, d_model - 1)]),
                'pe_value_dim100': float(PE_tgt[tgt_len // 2, min(100, d_model - 1)]),
                'mean_cross_attention_entropy': mH_cross,
            })

    # Positional encoding rows
    for pos in range(seq_len):
        records.append({
            'scenario': label,
            'num_layers': N,
            'num_heads': num_heads,
            'd_model': d_model,
            'd_ff': d_ff,
            'd_k': d_k,
            'temperature_scale': temp,
            'component': 'positional_encoding',
            'layer_index': -1,
            'head_index': -1,
            'seq_position': pos,
            'tgt_position': -1,
            'entropy_self_enc': '',
            'entropy_self_dec': '',
            'entropy_cross': '',
            'residual_norm_enc': '',
            'residual_norm_dec': '',
            'attention_weight_sample': '',
            'cross_attention_weight_sample': '',
            'pe_value_dim0': float(PE_src[pos, 0]),
            'pe_value_dim1': float(PE_src[pos, 1]),
            'pe_value_dim50': float(PE_src[pos, min(50, d_model - 1)]),
            'pe_value_dim100': float(PE_src[pos, min(100, d_model - 1)]),
            'mean_cross_attention_entropy': '',
        })

    # Compute aggregate metrics
    all_cross_entropy_vals = []
    for H_cross_layer in cross_entropies_all:
        all_cross_entropy_vals.extend(H_cross_layer.flatten().tolist())
    mean_cross_entropy = float(np.mean(all_cross_entropy_vals)) if all_cross_entropy_vals else 0.0

    all_enc_entropy_vals = []
    for H_enc_layer in enc_entropies:
        all_enc_entropy_vals.extend(H_enc_layer.flatten().tolist())
    mean_enc_entropy = float(np.mean(all_enc_entropy_vals)) if all_enc_entropy_vals else 0.0

    return {
        'records': records,
        'A_self_last': A_self_last,
        'A_cross_last': A_cross_last,
        'PE_src': PE_src,
        'X_enc': X_enc,
        'X_dec': X_dec,
        'enc_norms': enc_norms,
        'dec_norms': dec_norms,
        'enc_entropies': enc_entropies,   # list[N] of (num_heads, seq_len)
        'cross_entropies': cross_entropies_all,  # list[N] of (num_heads, tgt_len)
        'mean_cross_entropy': mean_cross_entropy,
        'mean_enc_entropy': mean_enc_entropy,
        'N': N,
        'num_heads': num_heads,
        'd_model': d_model,
        'd_ff': d_ff,
        'd_k': d_k,
        'temp': temp,
        'seq_len': seq_len,
        'tgt_len': tgt_len,
        'label': label,
    }


# ============================================================
# FIGURE GENERATION
# ============================================================

def generate_figures(all_results: List[Dict], output_dir: Path) -> None:
    """Generate all figures for all scenarios."""
    scenarios = [r['label'] for r in all_results]
    colors = plt.cm.tab10(np.linspace(0, 1, len(all_results)))

    # ---- FIG 1: Encoder Self-Attention Heatmap per scenario ----
    for idx, result in enumerate(all_results):
        try:
            A_self = result['A_self_last']
            label = result['label']
            if A_self is None:
                print(f"WARNING fig1: A_self_last is None for {label}, skipping.")
                continue
            # Use layer index based on last layer (or layer min(3, N-1))
            # A_self is the last layer's attention weights: (num_heads, seq_len, seq_len)
            fig, ax = plt.subplots(figsize=(7, 6))
            head_idx = 0
            data = A_self[head_idx]
            assert data.shape[0] == data.shape[1], "Attention matrix not square"
            im = ax.imshow(data, cmap='viridis', vmin=0, vmax=1, aspect='auto')
            plt.colorbar(im, ax=ax, label='Attention Weight')
            ax.set_xlabel('Key Position (token index)')
            ax.set_ylabel('Query Position (token index)')
            ax.set_title(f'Encoder Self-Attention Heatmap\n(Last Layer, Head 0) — {label}')
            plt.tight_layout()
            plt.savefig(output_dir / f'fig1_enc_self_attn_{label}.png', dpi=100)
            plt.close(fig)
        except Exception as e:
            print(f"WARNING fig1 for {result.get('label','?')}: {e}")

    # ---- FIG 2: Decoder Cross-Attention Heatmap per scenario ----
    for idx, result in enumerate(all_results):
        try:
            A_cross = result['A_cross_last']
            label = result['label']
            if A_cross is None:
                print(f"WARNING fig2: A_cross_last is None for {label}, skipping.")
                continue
            fig, ax = plt.subplots(figsize=(7, 6))
            head_idx = 0
            data = A_cross[head_idx]  # (tgt_len, seq_len)
            if data.ndim != 2 or data.shape[0] == 0 or data.shape[1] == 0:
                print(f"WARNING fig2: empty cross-attention for {label}, skipping.")
                continue
            im = ax.imshow(data, cmap='plasma', vmin=0, vmax=1, aspect='auto')
            plt.colorbar(im, ax=ax, label='Cross-Attention Weight')
            ax.set_xlabel('Key Position (source token)')
            ax.set_ylabel('Query Position (target token)')
            ax.set_title(f'Decoder Cross-Attention Heatmap\n(Last Layer, Head 0) — {label}')
            plt.tight_layout()
            plt.savefig(output_dir / f'fig2_dec_cross_attn_{label}.png', dpi=100)
            plt.close(fig)
        except Exception as e:
            print(f"WARNING fig2 for {result.get('label','?')}: {e}")

    # ---- FIG 3: Encoder Self-Attention Entropy vs Layer ----
    try:
        fig, ax = plt.subplots(figsize=(9, 5))
        for idx, result in enumerate(all_results):
            label = result['label']
            enc_entropies = result['enc_entropies']
            N = result['N']
            if len(enc_entropies) == 0:
                print(f"WARNING fig3: no enc_entropies for {label}, skipping.")
                continue
            x_vals = np.arange(len(enc_entropies))
            y_vals = np.array([float(H.mean()) for H in enc_entropies])
            assert len(x_vals) == len(y_vals), "fig3 shape mismatch"
            if len(x_vals) == 0:
                continue
            ax.plot(x_vals, y_vals, marker='o', label=label, color=colors[idx])
        ax.set_xlabel('Layer Index')
        ax.set_ylabel('Mean Entropy (nats)')
        ax.set_title('Encoder Self-Attention Entropy vs. Layer Depth')
        ax.legend(fontsize=7, loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig3_enc_entropy_vs_layer.png', dpi=100)
        plt.close(fig)
    except Exception as e:
        print(f"WARNING fig3: {e}")

    # ---- FIG 4: Decoder Cross-Attention Entropy vs Layer ----
    try:
        fig, ax = plt.subplots(figsize=(9, 5))
        for idx, result in enumerate(all_results):
            label = result['label']
            cross_entropies = result['cross_entropies']
            if len(cross_entropies) == 0:
                continue
            x_vals = np.arange(len(cross_entropies))
            y_vals = np.array([float(H.mean()) for H in cross_entropies])
            assert len(x_vals) == len(y_vals), "fig4 shape mismatch"
            if len(x_vals) == 0:
                continue
            ax.plot(x_vals, y_vals, marker='s', label=label, color=colors[idx])
        ax.set_xlabel('Layer Index')
        ax.set_ylabel('Mean Cross-Attention Entropy (nats)')
        ax.set_title('Decoder Cross-Attention Entropy vs. Layer Depth')
        ax.legend(fontsize=7, loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig4_cross_entropy_vs_layer.png', dpi=100)
        plt.close(fig)
    except Exception as e:
        print(f"WARNING fig4: {e}")

    # ---- FIG 5: Encoder Residual Norm vs Layer ----
    try:
        fig, ax = plt.subplots(figsize=(9, 5))
        for idx, result in enumerate(all_results):
            label = result['label']
            enc_norms = result['enc_norms']
            if len(enc_norms) == 0:
                continue
            x_vals = np.arange(len(enc_norms))
            y_vals = np.array(enc_norms, dtype=float)
            assert len(x_vals) == len(y_vals), "fig5 shape mismatch"
            ax.plot(x_vals, y_vals, marker='o', label=label, color=colors[idx])
        ax.set_xlabel('Layer Index')
        ax.set_ylabel('Encoder Residual L2 Norm (a.u.)')
        ax.set_title('Encoder Residual Stream L2 Norm vs. Layer')
        ax.legend(fontsize=7, loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig5_enc_residual_norm.png', dpi=100)
        plt.close(fig)
    except Exception as e:
        print(f"WARNING fig5: {e}")

    # ---- FIG 6: Decoder Residual Norm vs Layer ----
    try:
        fig, ax = plt.subplots(figsize=(9, 5))
        for idx, result in enumerate(all_results):
            label = result['label']
            dec_norms = result['dec_norms']
            if len(dec_norms) == 0:
                continue
            x_vals = np.arange(len(dec_norms))
            y_vals = np.array(dec_norms, dtype=float)
            assert len(x_vals) == len(y_vals), "fig6 shape mismatch"
            ax.plot(x_vals, y_vals, marker='s', label=label, color=colors[idx])
        ax.set_xlabel('Layer Index')
        ax.set_ylabel('Decoder Residual L2 Norm (a.u.)')
        ax.set_title('Decoder Residual Stream L2 Norm vs. Layer')
        ax.legend(fontsize=7, loc='best')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(output_dir / 'fig6_dec_residual_norm.png', dpi=100)
        plt.close(fig)
    except Exception as e:
        print(f"WARNING fig6: {e}")

    # ---- FIG 7: Per-Head Entropy Heatmap (Encoder) per scenario ----
    for idx, result in enumerate(all_results):
        try:
            label = result['label']
            enc_entropies = result['enc_entropies']
            N = result['N']
            num_heads = result['num_heads']
            if len(enc_entropies) == 0:
                print(f"WARNING fig7: no enc_entropies for {label}, skipping.")
                continue
            # Build (N, num_heads) entropy matrix
            H_matrix = np.zeros((N, num_heads))
            for layer_i, H in enumerate(enc_entropies):
                # H shape: (num_heads, seq_len)
                H_matrix[layer_i] = H.mean(axis=-1)
            H_matrix = np.clip(H_matrix, 0.0, 5.0)
            fig, ax = plt.subplots(figsize=(max(6, num_heads), max(4, N)))
            im = ax.imshow(H_matrix, cmap='hot', vmin=0, vmax=5, aspect='auto')
            plt.colorbar(im, ax=ax, label='Mean Entropy (nats)')
            ax.set_xlabel('Head Index')
            ax.set_ylabel('Layer Index')
            ax.set_xticks(np.arange(num_heads))
            ax.set_yticks(np.arange(N))
            ax.set_title(f'Per-Head Encoder Self-Attention Entropy\n{label}')
            plt.tight_layout()
            plt.savefig(output_dir / f'fig7_head_entropy_heatmap_{label}.png', dpi=100)
            plt.close(fig)
        except Exception as e:
            print(f"WARNING fig7 for {result.get('label','?')}: {e}")

    # ---- FIG 8: Mean Cross-Attention Entropy Across Scenarios ----
    try:
        labels_list = []
        entropy_vals = []
        for result in all_results:
            labels_list.append(result['label'])
            entropy_vals.append(result['mean_cross_entropy'])
        assert len(labels_list) == len(entropy_vals), "fig8 shape mismatch"
        if len(labels_list) == 0:
            print("WARNING fig8: no data, skipping.")
        else:
            x_pos = np.arange(len(labels_list))
            fig, ax = plt.subplots(figsize=(12, 5))
            bars = ax.bar(x_pos, entropy_vals, color=colors[:len(labels_list)], alpha=0.85)
            ax.set_xticks(x_pos)
            ax.set_xticklabels(labels_list, rotation=30, ha='right', fontsize=9)
            ax.set_ylabel('Mean Cross-Attention Entropy (nats)')
            ax.set_title('Mean Cross-Attention Entropy Across Scenarios')
            ax.grid(True, axis='y', alpha=0.3)
            for bar, val in zip(bars, entropy_vals):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                        f'{val:.3f}', ha='center', va='bottom', fontsize=8)
            plt.tight_layout()
            plt.savefig(output_dir / 'fig8_mean_cross_entropy_scenarios.png', dpi=100)
            plt.close(fig)
    except Exception as e:
        print(f"WARNING fig8: {e}")

    # ---- FIG 9: Positional Encoding Waveforms ----
    for idx, result in enumerate(all_results):
        try:
            label = result['label']
            d_model = result['d_model']
            seq_len = result['seq_len']
            PE = sinusoidal_pe(seq_len, d_model)
            PE = np.clip(PE, -1.0, 1.0)

            # Select dims to display
            candidate_dims = [0, 1, 2, 3, 50, 100, 200, d_model - 1]
            selected_dims = [d for d in candidate_dims if d < d_model]
            selected_dims = list(dict.fromkeys(selected_dims))  # remove duplicates

            positions = np.arange(seq_len)
            fig, ax = plt.subplots(figsize=(10, 5))
            for dim in selected_dims:
                pe_vals = PE[:, dim]
                assert len(positions) == len(pe_vals), f"fig9 shape mismatch dim={dim}"
                ax.plot(positions, pe_vals, label=f'dim={dim}', marker='.')
            ax.set_xlabel('Position')
            ax.set_ylabel('PE Value')
            ax.set_title(f'Positional Encoding Waveforms\n(d_model={d_model}) — {label}')
            ax.legend(fontsize=7, loc='best', ncol=2)
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(output_dir / f'fig9_pe_waveforms_{label}.png', dpi=100)
            plt.close(fig)
        except Exception as e:
            print(f"WARNING fig9 for {result.get('label','?')}: {e}")

    # ---- FIG 10: Positional Encoding Matrix Heatmap ----
    for idx, result in enumerate(all_results):
        try:
            label = result['label']
            d_model = result['d_model']
            seq_len = result['seq_len']
            PE = sinusoidal_pe(seq_len, d_model)
            PE = np.clip(PE, -1.0, 1.0)

            if PE.shape[0] == 0 or PE.shape[1] == 0:
                print(f"WARNING fig10: empty PE for {label}, skipping.")
                continue

            fig, ax = plt.subplots(figsize=(12, 5))
            im = ax.imshow(PE, cmap='RdBu', vmin=-1, vmax=1, aspect='auto')
            plt.colorbar(im, ax=ax, label='PE Value')
            ax.set_xlabel('Embedding Dimension')
            ax.set_ylabel('Position')
            ax.set_title(f'Positional Encoding Matrix Heatmap\n(seq_len={seq_len}, d_model={d_model}) — {label}')
            plt.tight_layout()
            plt.savefig(output_dir / f'fig10_pe_heatmap_{label}.png', dpi=100)
            plt.close(fig)
        except Exception as e:
            print(f"WARNING fig10 for {result.get('label','?')}: {e}")


# ============================================================
# CSV WRITING
# ============================================================

DATASET_COLUMNS = [
    'scenario', 'num_layers', 'num_heads', 'd_model', 'd_ff', 'd_k',
    'temperature_scale', 'component', 'layer_index', 'head_index',
    'seq_position', 'tgt_position', 'entropy_self_enc', 'entropy_self_dec',
    'entropy_cross', 'residual_norm_enc', 'residual_norm_dec',
    'attention_weight_sample', 'cross_attention_weight_sample',
    'pe_value_dim0', 'pe_value_dim1', 'pe_value_dim50', 'pe_value_dim100',
    'mean_cross_attention_entropy'
]


def save_simulation_outputs(all_records: List[Dict], output_dir: Path) -> None:
    """Save simulation_outputs.csv with all records."""
    if not all_records:
        print("WARNING: No records to write to simulation_outputs.csv")
        return
    filepath = output_dir / 'simulation_outputs.csv'
    try:
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=DATASET_COLUMNS)
            writer.writeheader()
            for row in all_records:
                # Ensure all columns present
                out_row = {col: row.get(col, '') for col in DATASET_COLUMNS}
                writer.writerow(out_row)
        print(f"Saved: {filepath} ({len(all_records)} rows)")
    except Exception as e:
        print(f"ERROR saving simulation_outputs.csv: {e}")


def save_scenario_summary(all_results: List[Dict], output_dir: Path) -> None:
    """Save scenario_summary.csv with one row per scenario."""
    if not all_results:
        print("WARNING: No results for scenario_summary.csv")
        return
    filepath = output_dir / 'scenario_summary.csv'
    try:
        fieldnames = [
            'scenario', 'num_layers', 'num_heads', 'd_model', 'd_ff', 'd_k',
            'temperature_scale', 'seq_len', 'tgt_len',
            'mean_enc_entropy', 'std_enc_entropy', 'min_enc_entropy', 'max_enc_entropy',
            'mean_cross_entropy', 'std_cross_entropy', 'min_cross_entropy', 'max_cross_entropy',
            'mean_enc_norm', 'std_enc_norm', 'min_enc_norm', 'max_enc_norm',
            'mean_dec_norm', 'std_dec_norm', 'min_dec_norm', 'max_dec_norm',
        ]
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for result in all_results:
                # Gather entropy data
                enc_ent_vals = []
                for H in result['enc_entropies']:
                    enc_ent_vals.extend(H.flatten().tolist())
                cross_ent_vals = []
                for H in result['cross_entropies']:
                    cross_ent_vals.extend(H.flatten().tolist())
                enc_norms = result['enc_norms']
                dec_norms = result['dec_norms']

                def safe_stats(vals):
                    if not vals:
                        return 0.0, 0.0, 0.0, 0.0
                    arr = np.array(vals)
                    return float(arr.mean()), float(arr.std()), float(arr.min()), float(arr.max())

                ee_m, ee_s, ee_mn, ee_mx = safe_stats(enc_ent_vals)
                ce_m, ce_s, ce_mn, ce_mx = safe_stats(cross_ent_vals)
                en_m, en_s, en_mn, en_mx = safe_stats(enc_norms)
                dn_m, dn_s, dn_mn, dn_mx = safe_stats(dec_norms)

                writer.writerow({
                    'scenario': result['label'],
                    'num_layers': result['N'],
                    'num_heads': result['num_heads'],
                    'd_model': result['d_model'],
                    'd_ff': result['d_ff'],
                    'd_k': result['d_k'],
                    'temperature_scale': result['temp'],
                    'seq_len': result['seq_len'],
                    'tgt_len': result['tgt_len'],
                    'mean_enc_entropy': ee_m,
                    'std_enc_entropy': ee_s,
                    'min_enc_entropy': ee_mn,
                    'max_enc_entropy': ee_mx,
                    'mean_cross_entropy': ce_m,
                    'std_cross_entropy': ce_s,
                    'min_cross_entropy': ce_mn,
                    'max_cross_entropy': ce_mx,
                    'mean_enc_norm': en_m,
                    'std_enc_norm': en_s,
                    'min_enc_norm': en_mn,
                    'max_enc_norm': en_mx,
                    'mean_dec_norm': dn_m,
                    'std_dec_norm': dn_s,
                    'min_dec_norm': dn_mn,
                    'max_dec_norm': dn_mx,
                })
        print(f"Saved: {filepath}")
    except Exception as e:
        print(f"ERROR saving scenario_summary.csv: {e}")


def save_parameters_used(output_dir: Path) -> None:
    """Save parameters_used.csv with one row per parameter."""
    filepath = output_dir / 'parameters_used.csv'
    try:
        fieldnames = ['name', 'value', 'unit', 'source', 'description']
        rows = []
        for name, info in MODEL_PROFILE['parameters'].items():
            rows.append({
                'name': name,
                'value': info['value'],
                'unit': info['unit'],
                'source': info['source'],
                'description': info['description'],
            })
        if not rows:
            print("WARNING: No parameter rows to write.")
            return
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
        print(f"Saved: {filepath}")
    except Exception as e:
        print(f"ERROR saving parameters_used.csv: {e}")


def save_summary_json(all_results: List[Dict], output_dir: Path) -> None:
    """Save summary.json with key aggregate metrics."""
    filepath = output_dir / 'summary.json'
    try:
        summary = {}
        for result in all_results:
            label = result['label']
            enc_ent_vals = []
            for H in result['enc_entropies']:
                enc_ent_vals.extend(H.flatten().tolist())
            cross_ent_vals = []
            for H in result['cross_entropies']:
                cross_ent_vals.extend(H.flatten().tolist())

            summary[label] = {
                'num_layers': result['N'],
                'num_heads': result['num_heads'],
                'd_model': result['d_model'],
                'd_ff': result['d_ff'],
                'd_k': result['d_k'],
                'temperature_scale': result['temp'],
                'mean_enc_self_entropy': float(np.mean(enc_ent_vals)) if enc_ent_vals else 0.0,
                'mean_cross_entropy': result['mean_cross_entropy'],
                'mean_enc_residual_norm': float(np.mean(result['enc_norms'])) if result['enc_norms'] else 0.0,
                'mean_dec_residual_norm': float(np.mean(result['dec_norms'])) if result['dec_norms'] else 0.0,
            }
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(summary, f, indent=2)
        print(f"Saved: {filepath}")
    except Exception as e:
        print(f"ERROR saving summary.json: {e}")


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description='Transformer Architecture Simulator — Encoder-Decoder Attention Mechanism')
    parser.add_argument('--output', type=str, default='./sim_outputs',
                        help='Output directory for all generated files (default: ./sim_outputs)')
    args = parser.parse_args()

    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Output directory: {output_dir.resolve()}")

    scenarios = MODEL_PROFILE['scenarios']
    all_results = []
    all_records = []

    # Default parameter values to fill in for scenarios that don't override them
    default_params = {
        'd_model': 512,
        'num_heads': 8,
        'd_ff': 2048,
        'num_layers': 6,
        'seq_len': 20,
        'tgt_len': 20,
        'temperature_scale': 1.0,
        'init_std': 0.02,
        'dropout_rate': 0.1,
        'vocab_size': 1000,
    }

    for scenario_idx, scenario_spec in enumerate(scenarios):
        label = scenario_spec['label']
        print(f"\n[{scenario_idx+1}/{len(scenarios)}] Running scenario: {label}")

        # Build config: start with defaults, apply overrides
        cfg = dict(default_params)
        cfg.update(scenario_spec.get('param_overrides', {}))
        cfg['label'] = label

        # Derived parameter d_k
        cfg['d_k'] = cfg['d_model'] // cfg['num_heads']

        try:
            result = run_scenario(cfg, rng_seed=scenario_idx)
            all_results.append(result)
            all_records.extend(result['records'])
            print(f"  -> {len(result['records'])} records generated")
            print(f"  -> mean cross entropy: {result['mean_cross_entropy']:.4f}")
        except Exception as e:
            print(f"ERROR running scenario {label}: {e}")
            import traceback
            traceback.print_exc()

    print(f"\nTotal records: {len(all_records)}")

    # Generate all figures
    print("\nGenerating figures...")
    generate_figures(all_results, output_dir)

    # Save CSV files
    print("\nSaving CSV files...")
    save_simulation_outputs(all_records, output_dir)
    save_scenario_summary(all_results, output_dir)
    save_parameters_used(output_dir)

    # Save JSON summary
    print("\nSaving JSON summary...")
    save_summary_json(all_results, output_dir)

    print(f"\nSimulation complete. All outputs saved to: {output_dir.resolve()}")


if __name__ == "__main__":
    main()